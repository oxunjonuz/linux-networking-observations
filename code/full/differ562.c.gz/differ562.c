// SPDX-License-Identifier: GPL-2.0
/*
 * differ555.c -- turn 555 / F32: the native `arp` envelope.
 *
 * F30 measured the IPv4/IPv6 branches of nft_nh_write_ok(); F31 measured the
 * netdev and bridge branches and, inside the bridge, the ARP branch
 *     static bool nft_nh_write_ok_arp(const struct nft_payload_set *priv)
 *     {
 *             const unsigned int eth_ip = 2 * (ETH_ALEN + 4);
 *             switch (priv->offset) {
 *             case offsetof(struct arphdr, ar_op):  return priv->len == 2;
 *             }
 *             return priv->offset >= sizeof(struct arphdr) && priv->len <= eth_ip;
 *     }
 * -- reached from a frame whose ETHERNET LABEL said 0x0806.
 *
 * The native envelope is `case NFPROTO_ARP: return nft_nh_write_ok_arp(priv)`
 * in nft_nh_write_ok(), i.e. the nft family `arp`, and that family has never
 * been reachable in this project: CONFIG_NF_TABLES_ARP is "not set" in every
 * config we have booted.  Two kernels are built for this turn with that one
 * symbol on (A553 = 7.3.4, AM553 = 7.2.15) and nothing else changed.
 *
 * Questions, each answered by a counter, a byte or a socket -- never by reading
 * the source:
 *
 *   A  does the family exist?  (`nft add table arp`)
 *   B  which hooks does its filter chain type accept?
 *   C  which of the nine fields nft itself can name are alive, which are dead?
 *   D  what is the guard's predicate at the INPUT hook, as a function of
 *      (offset,len) -- measured over a grid, not read off the switch
 *   E  the same grid at the OUTPUT hook, where the kernel's own ARP skb is
 *      exactly 28 bytes long
 *   F  what a rule in this family does to the host: neighbour table, replies
 *   G  does anything here read hlen/plen out of the message?
 *
 * output
 *   F555 A|<tag>|hook=..|src=..|g=off,len|rule=..|rc=..|cnt=..|nfl=..|chg=..|
 *          nhex=..|ci1=..|ihex=..|co1=..|ohex=..
 *   F555 ARP|<tag>|<ip>|flags=..|mac=..
 *   F555 FAM|<family>|<rc>
 *   F555 HOOK|<hook>|<rc>
 *   F555RC <tag>|<rc>          (nft exit code)
 *   F555X  <tag>|<nft's own words>
 *   F555 SETUP|...
 *
 * Byte evidence at INPUT can only come from NFLOG: an AF_PACKET tap sees the
 * frame on receive before arp_rcv() is called, and arp_rcv() is where the
 * netfilter ARP hook lives.  So every rule logs the packet after the store
 * (`log group 5 prefix "f555.<tag>"`), and the payload is matched back by
 * prefix -- a per-arm string, so no arm can consume another arm's message.
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sched.h>
#include <stdint.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <linux/if_link.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <linux/if_arp.h>
#include <linux/netfilter.h>
#include <linux/netfilter/nfnetlink.h>
#include <linux/netfilter/nf_tables.h>

#define NLA_ALIGN_(len) (((len) + 3) & ~3)
#ifndef VETH_INFO_PEER
#define VETH_INFO_PEER 1
#endif
#define NFNL_SUBSYS_ULOG_	4
#define NFULNL_MSG_PACKET_	0
#define NFULNL_MSG_CONFIG_	1
#define NFULA_PACKET_HDR_	1
#define NFULA_PAYLOAD_		9
#define NFULA_PREFIX_		10
#define NFULA_CFG_CMD_		1
#define NFULA_CFG_MODE_		2
#define NFULA_CFG_TIMEOUT_	4
#define NFULA_CFG_QTHRESH_	5
#define NFULNL_CFG_CMD_BIND_	1
#define NFULNL_COPY_PACKET_	0x02

/* NFTA_LOG_GROUP / _PREFIX / _QTHRESHOLD come from <linux/netfilter/nf_tables.h>
 * as ENUM constants -- and #ifndef does not protect an enum constant, which is
 * how this file carried `#define NFTA_LOG_PREFIX 3` for one smoke run and sent
 * every prefix as NFTA_LOG_SNAPLEN.  Rules installed fine, counters counted, and
 * the NFLOG messages arrived with an empty prefix.  These two assertions make
 * that failure a compile error instead of a silent one. */
_Static_assert(NFTA_LOG_GROUP == 1, "NFTA_LOG_GROUP moved");
_Static_assert(NFTA_LOG_PREFIX == 2, "NFTA_LOG_PREFIX moved");
_Static_assert(NFTA_LOG_QTHRESHOLD == 4, "NFTA_LOG_QTHRESHOLD moved");

/* ---------- netlink toolkit ---------- */

static char opbuf[4096];

static struct nlmsghdr *msg_start(char *buf, int bufsz, uint16_t type,
				  uint16_t flags, uint8_t family)
{
	struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
	struct nfgenmsg *nfg;

	memset(buf, 0, (size_t)bufsz);
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = type;
	nlh->nlmsg_flags = flags;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	return nlh;
}

static struct nlattr *attr_put(struct nlmsghdr *nlh, uint16_t type,
			       const void *payload, int len)
{
	struct nlattr *a = (struct nlattr *)((char *)nlh +
					     NLMSG_ALIGN(nlh->nlmsg_len));

	a->nla_type = type;
	a->nla_len = (uint16_t)(NLA_HDRLEN + len);
	if (len && payload)
		memcpy((char *)a + NLA_HDRLEN, payload, (size_t)len);
	nlh->nlmsg_len = NLMSG_ALIGN(nlh->nlmsg_len) + (uint32_t)NLA_ALIGN_(a->nla_len);
	return a;
}

static struct nlattr *nest_start(struct nlmsghdr *nlh, uint16_t type)
{
	return attr_put(nlh, (uint16_t)(type | NLA_F_NESTED), NULL, 0);
}

static void nest_end(struct nlmsghdr *nlh, struct nlattr *a)
{
	a->nla_len = (uint16_t)((char *)nlh + nlh->nlmsg_len - (char *)a);
}

static void put_str(struct nlmsghdr *nlh, uint16_t t, const char *s)
{
	attr_put(nlh, t, s, (int)strlen(s) + 1);
}

static void put_be32(struct nlmsghdr *nlh, uint16_t t, uint32_t v)
{
	uint32_t be = htonl(v);

	attr_put(nlh, t, &be, (int)sizeof(be));
}

static int nl_open(void)
{
	struct sockaddr_nl sa;
	struct timeval tv = { .tv_sec = 2, .tv_usec = 0 };
	int fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_NETFILTER);

	if (fd < 0)
		return -1;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -1;
	}
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return fd;
}

static int batch_send(int fd, char *buf, int len)
{
	char rbuf[8192];
	int err = 0;

	if (send(fd, buf, (size_t)len, 0) != len)
		return -1000 - errno;
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			if (h->nlmsg_type != NLMSG_ERROR)
				continue;
			{
				struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(h);

				if (e->error && !err)
					err = e->error;
			}
		}
	}
	return err;
}

/* one nfnetlink message, wrapped in BEGIN/END, sent as a batch */
static int nft_one(char *msgbuf, int msglen)
{
	char batch[8192];
	struct nlmsghdr *bn, *en;
	int off, fd, rc;

	bn = msg_start(batch, (int)sizeof(batch), NFNL_MSG_BATCH_BEGIN,
		       NLM_F_REQUEST, 0);
	((struct nfgenmsg *)NLMSG_DATA(bn))->res_id = htons(NFNL_SUBSYS_NFTABLES);
	off = (int)NLMSG_ALIGN(bn->nlmsg_len);
	memcpy(batch + off, msgbuf, (size_t)NLMSG_ALIGN(msglen));
	off += (int)NLMSG_ALIGN(msglen);
	en = msg_start(batch + off, (int)(sizeof(batch) - off), NFNL_MSG_BATCH_END,
		       NLM_F_REQUEST, 0);
	((struct nfgenmsg *)NLMSG_DATA(en))->res_id = htons(NFNL_SUBSYS_NFTABLES);
	off += (int)NLMSG_ALIGN(en->nlmsg_len);
	fd = nl_open();
	if (fd < 0)
		return -1;
	rc = batch_send(fd, batch, off);
	close(fd);
	return rc;
}

/* ---------- rtnetlink ---------- */

static int rtnl_open(void)
{
	struct sockaddr_nl sa;
	struct timeval tv = { .tv_sec = 2, .tv_usec = 0 };
	int fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);

	if (fd < 0)
		return -1;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -2;
	}
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return fd;
}

static int rtnl_talk(int fd, struct nlmsghdr *nlh)
{
	struct sockaddr_nl sa;
	char rbuf[4096];
	struct nlmsghdr *rh;
	int r;

	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	nlh->nlmsg_flags |= NLM_F_REQUEST | NLM_F_ACK;
	nlh->nlmsg_seq = 1;
	nlh->nlmsg_pid = 0;
	if (sendto(fd, nlh, nlh->nlmsg_len, 0, (struct sockaddr *)&sa,
		   sizeof(sa)) < 0)
		return -errno;
	r = (int)recv(fd, rbuf, sizeof(rbuf), 0);
	if (r < (int)(NLMSG_HDRLEN + sizeof(struct nlmsgerr)))
		return -1000;
	rh = (struct nlmsghdr *)rbuf;
	if (rh->nlmsg_type == NLMSG_ERROR) {
		struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(rh);

		return e->error;
	}
	return -1001;
}

static int f555_ifindex(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int idx = -1;

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFINDEX, &ifr) == 0)
		idx = ifr.ifr_ifindex;
	close(s);
	return idx;
}

static int mac_get(const char *dev, unsigned char *out)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFHWADDR, &ifr) < 0) {
		close(s);
		return -1;
	}
	memcpy(out, ifr.ifr_hwaddr.sa_data, 6);
	close(s);
	return 0;
}

static int set_up(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFFLAGS, &ifr) < 0) {
		close(s);
		return -1;
	}
	ifr.ifr_flags |= IFF_UP | IFF_RUNNING;
	if (ioctl(s, SIOCSIFFLAGS, &ifr) < 0) {
		close(s);
		return -1;
	}
	close(s);
	return 0;
}

static int link_add_veth(const char *a, const char *b)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[512];
	} req;
	struct ifinfomsg zifi;
	struct nlattr *li, *data, *peer;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, a, (int)strlen(a) + 1);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, "veth", 5);
	data = nest_start(&req.nlh, IFLA_INFO_DATA);
	memset(&zifi, 0, sizeof(zifi));
	zifi.ifi_family = AF_UNSPEC;
	peer = attr_put(&req.nlh, (uint16_t)(VETH_INFO_PEER | NLA_F_NESTED), &zifi,
			(int)sizeof(zifi));
	attr_put(&req.nlh, IFLA_IFNAME, b, (int)strlen(b) + 1);
	nest_end(&req.nlh, peer);
	nest_end(&req.nlh, data);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f555_addr_add(const char *dev, uint32_t addr_be, int plen)
{
	struct {
		struct nlmsghdr nlh;
		struct ifaddrmsg ifa;
		char attrs[128];
	} req;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifaddrmsg));
	req.nlh.nlmsg_type = RTM_NEWADDR;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_REPLACE;
	req.nlh.nlmsg_seq = 1;
	req.ifa.ifa_family = AF_INET;
	req.ifa.ifa_prefixlen = (uint8_t)plen;
	req.ifa.ifa_scope = 0;
	req.ifa.ifa_index = (uint32_t)f555_ifindex(dev);
	attr_put(&req.nlh, IFA_LOCAL, &addr_be, 4);
	attr_put(&req.nlh, IFA_ADDRESS, &addr_be, 4);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f555_neigh_del(const char *dev, uint32_t dst_be)
{
	struct {
		struct nlmsghdr nlh;
		struct ndmsg ndm;
		char attrs[64];
	} req;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ndmsg));
	req.nlh.nlmsg_type = RTM_DELNEIGH;
	req.nlh.nlmsg_flags = NLM_F_REQUEST;
	req.nlh.nlmsg_seq = 1;
	req.ndm.ndm_family = AF_INET;
	req.ndm.ndm_ifindex = f555_ifindex(dev);
	attr_put(&req.nlh, NDA_DST, &dst_be, 4);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f555_sysctl(const char *path, const char *val)
{
	int fd = open(path, O_WRONLY);
	int rc;

	if (fd < 0)
		return -1;
	rc = (int)write(fd, val, strlen(val));
	close(fd);
	return rc < 0 ? -1 : 0;
}

/* ---------- /proc/net/arp: the host's own view of what it learned ---------- */

static int arp_flags(const char *ip, char *mac, int macsz)
{
	FILE *f = fopen("/proc/net/arp", "r");
	char line[256];

	if (!f)
		return -1;
	if (!fgets(line, sizeof(line), f)) {
		fclose(f);
		return -1;
	}
	while (fgets(line, sizeof(line), f)) {
		char a[64] = "", hw[32] = "", fl[32] = "", m[64] = "";
		char msk[32] = "", dev[32] = "";

		if (sscanf(line, "%63s %31s %31s %63s %31s %31s", a, hw, fl, m, msk, dev) != 6)
			continue;
		if (strcmp(a, ip))
			continue;
		if (mac && macsz > 0)
			snprintf(mac, (size_t)macsz, "%s", m);
		fclose(f);
		return (int)strtol(fl, NULL, 16);
	}
	fclose(f);
	return -1;		/* no entry at all */
}

static void arp_row(const char *tag, const char *ip)
{
	char mac[64] = "-";
	int fl = arp_flags(ip, mac, (int)sizeof(mac));

	if (fl < 0)
		printf("F555 ARP|%s|%s|flags=none|mac=-\n", tag, ip);
	else
		printf("F555 ARP|%s|%s|flags=0x%x|mac=%s\n", tag, ip, fl, mac);
}

/* ---------- nft through the shell ---------- */

static int sh(const char *cmd)
{
	char full[2048];
	int rc;

	snprintf(full, sizeof(full), "%s >/tmp/f555o 2>&1", cmd);
	rc = system(full);
	return WIFEXITED(rc) ? WEXITSTATUS(rc) : 1000 + rc;
}

static void sh_out(const char *tag)
{
	FILE *f = fopen("/tmp/f555o", "r");
	char line[1024];

	if (!f)
		return;
	while (fgets(line, sizeof(line), f)) {
		char *nl = strchr(line, '\n');

		if (nl)
			*nl = 0;
		if (*line)
			printf("F555X %s|%s\n", tag, line);
	}
	fclose(f);
}

static int nft(const char *tag, const char *cmd)
{
	int rc = sh(cmd);

	printf("F555RC %s|%d\n", tag, rc);
	sh_out(tag);
	return rc;
}

/* ---------- NFLOG: the only way to see the packet AFTER the hook ---------- */

static int nfl_open(int group)
{
	char msg[512], rbuf[2048];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	struct sockaddr_nl sa;
	int fd, rcv = 1 << 21;

	fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_NETFILTER);
	if (fd < 0)
		return -1;
	setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcv, sizeof(rcv));
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -2;
	}
	memset(msg, 0, sizeof(msg));
	nlh = (struct nlmsghdr *)msg;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (uint16_t)((NFNL_SUBSYS_ULOG_ << 8) | NFULNL_MSG_CONFIG_);
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = 0;
	nfg->version = 0;
	nfg->res_id = htons((uint16_t)group);
	{
		uint8_t cmd = NFULNL_CFG_CMD_BIND_;

		attr_put(nlh, NFULA_CFG_CMD_, &cmd, 1);
	}
	{
		struct {
			uint32_t range;
			uint8_t mode;
			uint8_t pad;
		} __attribute__((packed)) cm;

		cm.range = htonl(0);
		cm.mode = NFULNL_COPY_PACKET_;
		cm.pad = 0;
		attr_put(nlh, NFULA_CFG_MODE_, &cm, (int)sizeof(cm));
	}
	{
		uint32_t q = htonl(1);
		uint32_t t = htonl(2);

		attr_put(nlh, NFULA_CFG_QTHRESH_, &q, 4);
		attr_put(nlh, NFULA_CFG_TIMEOUT_, &t, 4);
	}
	if (send(fd, msg, nlh->nlmsg_len, 0) != (ssize_t)nlh->nlmsg_len) {
		close(fd);
		return -3;
	}
	if (recv(fd, rbuf, sizeof(rbuf), 0) > 0) {
		struct nlmsghdr *rh = (struct nlmsghdr *)rbuf;

		if (rh->nlmsg_type == NLMSG_ERROR) {
			struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(rh);

			if (e->error) {
				printf("F555 SETUP|nflog_bind|%d\n", e->error);
				close(fd);
				return -5;
			}
		}
	}
	fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
	return fd;
}

/* one packet message -> prefix + payload.  Returns 1 if a message was parsed. */
static int nfl_one(const unsigned char *buf, int len, char *prefix, int psz,
		   unsigned char *pay, int *paylen)
{
	const struct nlmsghdr *nlh = (const struct nlmsghdr *)buf;
	int rem = len;

	prefix[0] = 0;
	*paylen = 0;
	while (NLMSG_OK(nlh, rem)) {
		if (nlh->nlmsg_type == (uint16_t)((NFNL_SUBSYS_ULOG_ << 8) |
						  NFULNL_MSG_PACKET_)) {
			const unsigned char *p = (const unsigned char *)NLMSG_DATA(nlh);
			int plen = (int)nlh->nlmsg_len - NLMSG_HDRLEN;
			int off = 4;	/* nfgenmsg */

			while (off + (int)sizeof(struct nlattr) <= plen) {
				const struct nlattr *a = (const struct nlattr *)(p + off);
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || off + alen > plen)
					break;
				if ((a->nla_type & 0x3fff) == NFULA_PREFIX_)
					snprintf(prefix, (size_t)psz, "%s",
						 (const char *)a + NLA_HDRLEN);
				else if ((a->nla_type & 0x3fff) == NFULA_PAYLOAD_) {
					int n = alen - NLA_HDRLEN;

					if (n > 128)
						n = 128;
					memcpy(pay, (const char *)a + NLA_HDRLEN, (size_t)n);
					*paylen = n;
				}
				off += (int)NLA_ALIGN_(alen);
			}
			return 1;
		}
		nlh = NLMSG_NEXT(nlh, rem);
	}
	return 0;
}

/* read until a message with exactly this prefix arrives (or the deadline) */
static int nfl_wait(int fd, const char *want, unsigned char *pay, int max,
		    int ms)
{
	struct timeval tv = { .tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000 };
	struct timeval now0, now1;
	fd_set rfds;
	int got = 0, seen = 0;
	char seenpre[2][64] = { "-", "-" };
	int seenlen[2] = { 0, 0 };

	gettimeofday(&now0, NULL);
	for (;;) {
		unsigned char b[4096];
		int r;

		FD_ZERO(&rfds);
		FD_SET(fd, &rfds);
		if (select(fd + 1, &rfds, NULL, NULL, &tv) <= 0)
			break;
		r = (int)recv(fd, b, sizeof(b), 0);
		if (r <= 0)
			break;
		{
			char pre[64];
			unsigned char p[128];
			int pl = 0;

			if (nfl_one(b, r, pre, (int)sizeof(pre), p, &pl)) {
				seen++;
				if (seen <= 2) {
					snprintf(seenpre[seen - 1], sizeof(seenpre[0]),
						 "%s", pre);
					seenlen[seen - 1] = pl;
				}
				if (pl > 0 && (!want || !strcmp(pre, want))) {
					if (pl > max)
						pl = max;
					memcpy(pay, p, (size_t)pl);
					got = pl;
					break;
				}
			}
		}
		gettimeofday(&now1, NULL);
		{
			long used = (now1.tv_sec - now0.tv_sec) * 1000 +
				    (now1.tv_usec - now0.tv_usec) / 1000;

			if (used >= ms)
				break;
			tv.tv_sec = 0;
			tv.tv_usec = (ms - used) * 1000;
		}
	}
	if (!got)
		printf("F555X nfl|want=%s|seen=%d|p1=%s,%d|p2=%s,%d\n",
		       want ? want : "-", seen, seenpre[0], seenlen[0],
		       seenpre[1], seenlen[1]);
	return got;
}

static void nfl_drain(int fd)
{
	unsigned char b[4096];

	while (recv(fd, b, sizeof(b), 0) > 0)
		;
}

/* ---------- frames ---------- */

static const unsigned char MAC_SRC[6] = { 0xaa, 0xbb, 0xcc, 0x00, 0x00, 0x66 };
static const unsigned char MAC_DST[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
static const unsigned char MAC_THA[6] = { 0x22, 0x22, 0x22, 0x22, 0x22, 0x22 };

static void be32_out(unsigned char *p, uint32_t v)
{
	p[0] = (unsigned char)(v >> 24);
	p[1] = (unsigned char)(v >> 16);
	p[2] = (unsigned char)(v >> 8);
	p[3] = (unsigned char)v;
}

/* ethernet + ARP.  hlen/plen are the message's OWN address sizes; the standard
 * ethernet/IPv4 message is hlen=6 plen=4 and is 28 bytes long.  `pad` pads the
 * frame to the 60-byte ethernet minimum, the way a real sender does. */
static int build_arp(unsigned char *out, int op, uint32_t spa, uint32_t tpa,
		     const unsigned char *sha, int hlen, int plen, int pad)
{
	int hl = 14, mlen = 8 + 2 * hlen + 2 * plen;

	memset(out, 0, 160);
	memcpy(out, MAC_DST, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x08;
	out[13] = 0x06;
	out[hl + 0] = 0x00; out[hl + 1] = 0x01;	/* htype: ethernet */
	out[hl + 2] = 0x08; out[hl + 3] = 0x00;	/* ptype: IPv4 */
	out[hl + 4] = (unsigned char)hlen;
	out[hl + 5] = (unsigned char)plen;
	out[hl + 6] = (unsigned char)(op >> 8);
	out[hl + 7] = (unsigned char)op;
	memcpy(out + hl + 8, sha, (size_t)(hlen < 6 ? hlen : 6));
	be32_out(out + hl + 8 + hlen, spa);
	memcpy(out + hl + 8 + hlen + plen, MAC_THA, (size_t)(hlen < 6 ? hlen : 6));
	be32_out(out + hl + 8 + 2 * hlen + plen, tpa);
	if (pad && hl + mlen < 60)
		return 60;		/* memset already zeroed the padding */
	return hl + mlen;
}

static int pkt_send(const char *dev, const unsigned char *fr, int len)
{
	struct sockaddr_ll sll;
	int s, rc, idx = f555_ifindex(dev);

	if (idx < 0)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_ALL);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, fr, 6);
	rc = (int)sendto(s, fr, (size_t)len, 0, (struct sockaddr *)&sll, sizeof(sll));
	close(s);
	return rc < 0 ? -errno : 0;
}

static int cap_open(const char *dev)
{
	struct sockaddr_ll sll;
	int s, idx = f555_ifindex(dev);

	if (idx < 0)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_ALL);
	sll.sll_ifindex = idx;
	if (bind(s, (struct sockaddr *)&sll, sizeof(sll)) < 0) {
		close(s);
		return -3;
	}
	fcntl(s, F_SETFL, fcntl(s, F_GETFL, 0) | O_NONBLOCK);
	return s;
}

static void cap_drain(int s)
{
	unsigned char b[2048];

	while (recv(s, b, sizeof(b), 0) > 0)
		;
}

/* first ARP frame from `mac` on this socket within ms.  ARP only: the arms also
 * push UDP datagrams out of the same device (the poke that triggers the kernel's
 * own ARP request), and the first frame was twice the wrong one in the smoke run
 * of F31 -- once an ICMPv6 solicitation from the bridge, once our own datagram. */
static int cap_arp_t(int s, unsigned char *buf, int max, int ms,
		     const unsigned char *mac, int on_src, uint32_t tpa_be)
{
	struct timeval tv = { .tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000 };
	struct timeval now0, now1;
	fd_set rfds;

	gettimeofday(&now0, NULL);
	for (;;) {
		int r;

		FD_ZERO(&rfds);
		FD_SET(s, &rfds);
		if (select(s + 1, &rfds, NULL, NULL, &tv) <= 0)
			return 0;
		r = (int)recv(s, buf, (size_t)max, 0);
		if (r <= 0)
			return 0;
		if (r >= 42 && buf[12] == 0x08 && buf[13] == 0x06 &&
		    (tpa_be == 0 ||
		     (buf[38] == (unsigned char)(tpa_be >> 24) &&
		      buf[39] == (unsigned char)(tpa_be >> 16) &&
		      buf[40] == (unsigned char)(tpa_be >> 8) &&
		      buf[41] == (unsigned char)tpa_be)) &&
		    ((on_src && !memcmp(buf + 6, mac, 6)) ||
		     (!on_src && !memcmp(buf, mac, 6))))
			return r;
		gettimeofday(&now1, NULL);
		{
			long used = (now1.tv_sec - now0.tv_sec) * 1000 +
				    (now1.tv_usec - now0.tv_usec) / 1000;

			if (used >= ms)
				return 0;
			tv.tv_sec = 0;
			tv.tv_usec = (ms - used) * 1000;
		}
	}
}

static int cap_arp(int s, unsigned char *buf, int max, int ms,
		   const unsigned char *mac, int on_src)
{
	return cap_arp_t(s, buf, max, ms, mac, on_src, 0);
}

static int udp_poke(uint32_t dst_be)
{
	struct sockaddr_in sin;
	char b = 'x';
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int rc;

	if (s < 0)
		return -1;
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = dst_be;
	sin.sin_port = htons(9999);
	rc = (int)sendto(s, &b, 1, 0, (struct sockaddr *)&sin, sizeof(sin));
	close(s);
	return rc < 0 ? -errno : 0;
}

/* ---------- rules over raw netlink ---------- */

static void imm_value(struct nlmsghdr *nlh, uint32_t dreg, const void *val, int len)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "immediate");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_IMMEDIATE_DREG, dreg);
	{
		struct nlattr *v = nest_start(nlh, NFTA_IMMEDIATE_DATA);

		attr_put(nlh, NFTA_DATA_VALUE, val, len);
		nest_end(nlh, v);
	}
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void counter_expr(struct nlmsghdr *nlh)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "counter");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void log_expr(struct nlmsghdr *nlh, int group, const char *prefix)
{
	struct nlattr *e, *d;
	uint16_t g = htons((uint16_t)group);

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "log");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	attr_put(nlh, NFTA_LOG_GROUP, &g, 2);
	put_str(nlh, NFTA_LOG_PREFIX, prefix);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void accept_expr(struct nlmsghdr *nlh)
{
	struct nlattr *e, *d;
	uint32_t code = htonl(NF_ACCEPT);

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "immediate");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_IMMEDIATE_DREG, NFT_REG_VERDICT);
	{
		struct nlattr *v = nest_start(nlh, NFTA_IMMEDIATE_DATA);
		struct nlattr *vd = nest_start(nlh, NFTA_DATA_VERDICT);

		attr_put(nlh, NFTA_VERDICT_CODE, &code, 4);
		nest_end(nlh, vd);
		nest_end(nlh, v);
	}
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* one rule: [store @network+off = imm][log][counter][accept?] */
static int install_store(int family, const char *table, const char *chain,
			 uint32_t off, uint32_t len, const unsigned char *imm,
			 int immlen, int verdict, int loggroup, const char *prefix)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *e, *d;
	int rc;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			(uint8_t)family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	imm_value(nlh, NFT_REG32_00, imm, immlen);
	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "payload");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00);
	put_be32(nlh, NFTA_PAYLOAD_BASE, NFT_PAYLOAD_NETWORK_HEADER);
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
	put_be32(nlh, NFTA_PAYLOAD_LEN, len);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
	nest_end(nlh, d);
	nest_end(nlh, e);
	if (loggroup)
		log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	if (verdict)
		accept_expr(nlh);
	nest_end(nlh, exprs);
	rc = nft_one(opbuf, (int)nlh->nlmsg_len);
	return rc;
}

/* a rule that only logs and counts: the control for byte-level diffing */
static int install_ctl(int family, const char *table, const char *chain,
		       int loggroup, const char *prefix)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			(uint8_t)family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

/* NFT_MSG_DELRULE with table+chain and no handle flushes the chain.  Cheaper
 * than forking nft 130 times, and it cannot fail on a chain that is empty. */
static int flush_chain(int family, const char *table, const char *chain)
{
	struct nlmsghdr *nlh;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_DELRULE,
			NLM_F_REQUEST | NLM_F_ACK, (uint8_t)family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

static int add_table(int family, const char *table)
{
	struct nlmsghdr *nlh;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWTABLE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE, (uint8_t)family);
	put_str(nlh, NFTA_TABLE_NAME, table);
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

/* base chain: hook 0=input 2=output (NF_ARP_*), policy 1=accept 0=drop */
static int add_chain(int family, const char *table, const char *chain,
		     uint32_t hook, uint32_t prio, uint32_t policy)
{
	struct nlmsghdr *nlh;
	struct nlattr *h, *d;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWCHAIN,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE, (uint8_t)family);
	put_str(nlh, NFTA_CHAIN_TABLE, table);
	put_str(nlh, NFTA_CHAIN_NAME, chain);
	h = nest_start(nlh, NFTA_CHAIN_HOOK);
	put_be32(nlh, NFTA_HOOK_HOOKNUM, hook);
	put_be32(nlh, NFTA_HOOK_PRIORITY, prio);
	nest_end(nlh, h);
	put_be32(nlh, NFTA_CHAIN_POLICY, policy);
	put_str(nlh, NFTA_CHAIN_TYPE, "filter");
	(void)d;
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

/* counter read-back without nft's printer */
static unsigned long long f555_count(uint8_t family, const char *table,
				     const char *chain)
{
	char buf[1024], rbuf[16384];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	unsigned long long pkts = 0;
	int fd, sent;

	fd = nl_open();
	if (fd < 0)
		return 0;
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1);
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1);
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return 0;
	}
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			const char *p, *end;

			if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
				goto out;
			if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				continue;
			p = (const char *)h + NLMSG_HDRLEN + sizeof(*nfg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || p + alen > end)
					break;
				if ((a->nla_type & 0x3fff) == NFTA_RULE_EXPRESSIONS) {
					const char *q = (const char *)a + NLA_HDRLEN;
					const char *qe = (const char *)a + alen;

					for (; q + (int)sizeof(struct nlattr) <= qe; ) {
						const struct nlattr *el = (const struct nlattr *)q;
						int ell = (int)el->nla_len;
						const char *r, *re;
						int is_cnt = 0;

						if (ell < (int)sizeof(*el) || q + ell > qe)
							break;
						r = (const char *)el + NLA_HDRLEN;
						re = (const char *)el + ell;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int eal = (int)ea->nla_len;

							if (eal < (int)sizeof(*ea) || r + eal > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_NAME &&
							    !strcmp((const char *)ea + NLA_HDRLEN, "counter"))
								is_cnt = 1;
							r += NLA_ALIGN_(eal);
						}
						if (is_cnt) {
							r = (const char *)el + NLA_HDRLEN;
							for (; r + (int)sizeof(struct nlattr) <= re; ) {
								const struct nlattr *ea = (const struct nlattr *)r;
								int eal = (int)ea->nla_len;

								if (eal < (int)sizeof(*ea) || r + eal > re)
									break;
								if ((ea->nla_type & 0x3fff) == NFTA_EXPR_DATA) {
									const char *d = (const char *)ea + NLA_HDRLEN;
									const char *de = (const char *)ea + eal;

									for (; d + (int)sizeof(struct nlattr) <= de; ) {
										const struct nlattr *da = (const struct nlattr *)d;
										int dal = (int)da->nla_len;

										if (dal < (int)sizeof(*da) || d + dal > de)
											break;
										if ((da->nla_type & 0x3fff) == NFTA_COUNTER_PACKETS) {
											int k, bl = dal - NLA_HDRLEN;
											unsigned long long v = 0;
											const unsigned char *b =
												(const unsigned char *)da + NLA_HDRLEN;

											for (k = 0; k < bl && k < 8; k++)
												v = (v << 8) | b[k];
											pkts += v;
										}
										d += NLA_ALIGN_(dal);
									}
								}
								r += NLA_ALIGN_(eal);
							}
						}
						q += NLA_ALIGN_(ell);
					}
				}
				p += NLA_ALIGN_(alen);
			}
		}
	}
out:
	close(fd);
	return pkts;
}

/* ---------- the row ---------- */

static int hexcopy(char *dst, int dstsz, const unsigned char *src, int len)
{
	int i, at = 0;

	if (len <= 0 || !src) {
		snprintf(dst, (size_t)dstsz, "-");
		return 0;
	}
	for (i = 0; i < len && i < 64; i++)
		at += snprintf(dst + at, (size_t)(dstsz - at), "%02x", src[i]);
	return len;
}

static void chglist(char *dst, int dstsz,
		    const unsigned char *cap, int clen,
		    const unsigned char *ctl, int ctl_len)
{
	int i, n = 0;
	size_t at = 0;

	dst[0] = 0;
	if (!cap || !ctl || clen <= 0 || ctl_len <= 0) {
		snprintf(dst, (size_t)dstsz, "-");
		return;
	}
	for (i = 0; i < clen && i < ctl_len; i++) {
		if (cap[i] == ctl[i])
			continue;
		n++;
		if (at < (size_t)dstsz - 24)
			at += (size_t)snprintf(dst + at, (size_t)(dstsz - (int)at),
					       "%s%d:%02x>%02x", n > 1 ? "," : "",
					       i, ctl[i], cap[i]);
	}
	if (!n)
		snprintf(dst, (size_t)dstsz, "-");
}

/* ---------- environment ---------- */

static unsigned char MAC_I0[6];
static int CAP_I1 = -1, CAP_O1 = -1, CAP_I0 = -1, NFL = -1;

static int env_setup(void)
{
	int rc = 0;

	if (link_add_veth("i0", "i1"))
		rc |= 1;
	if (link_add_veth("o0", "o1"))
		rc |= 2;
	set_up("i0");
	set_up("i1");
	set_up("o0");
	set_up("o1");
	set_up("lo");
	f555_addr_add("i0", htonl(0x0a010001), 24);	/* 10.1.0.1 */
	f555_addr_add("o0", htonl(0x0a090001), 24);	/* 10.9.0.1 */
	f555_sysctl("/proc/sys/net/ipv4/ip_forward", "0");
	mac_get("i0", MAC_I0);
	CAP_I1 = cap_open("i1");
	CAP_I0 = cap_open("i0");
	CAP_O1 = cap_open("o1");
	NFL = nfl_open(5);
	printf("F555 SETUP|rc=%d|mac_i0=%02x:%02x:%02x:%02x:%02x:%02x|cap_i1=%d|"
	       "cap_o1=%d|cap_i0=%d|nflog=%d\n", rc, MAC_I0[0], MAC_I0[1],
	       MAC_I0[2], MAC_I0[3], MAC_I0[4], MAC_I0[5], CAP_I1, CAP_O1,
	       CAP_I0, NFL);
	return rc;
}

/* ---------- A: does the family exist ---------- */

static int HAVE_ARP;

static void sec_a(void)
{
	struct { const char *n; uint8_t f; } fams[] = {
		{ "ip", NFPROTO_IPV4 },
		{ "arp", NFPROTO_ARP },
		{ "bridge", NFPROTO_BRIDGE },
		{ "netdev", NFPROTO_NETDEV },
	};
	char cmd[256], tag[64];
	int i;

	sh("/nft flush ruleset");
	for (i = 0; i < (int)(sizeof(fams) / sizeof(fams[0])); i++) {
		int rc;

		snprintf(tag, sizeof(tag), "a.%s", fams[i].n);
		snprintf(cmd, sizeof(cmd), "/nft add table %s p555f", fams[i].n);
		rc = nft(tag, cmd);
		printf("F555 FAM|%s|%d\n", fams[i].n, rc);
		if (rc == 0) {
			snprintf(cmd, sizeof(cmd), "/nft delete table %s p555f",
				 fams[i].n);
			sh(cmd);
		}
	}
	HAVE_ARP = (nft("a.arp2", "/nft add table arp p555a") == 0);
	printf("F555 HAVE|arp=%d\n", HAVE_ARP);
}

/* ---------- B: which hooks does the arp filter chain type accept ---------- */

static void sec_b(void)
{
	static const char *hs[][2] = {
		{ "input",      "type filter hook input priority 0; policy accept;" },
		{ "output",     "type filter hook output priority 0; policy accept;" },
		{ "forward",    "type filter hook forward priority 0; policy accept;" },
		{ "prerouting", "type filter hook prerouting priority 0; policy accept;" },
		{ "postrouting","type filter hook postrouting priority 0; policy accept;" },
		{ "ingress",    "type filter hook ingress priority 0; policy accept;" },
	};
	char cmd[512], tag[64];
	int i, rc;

	if (!HAVE_ARP) {
		printf("F555 HOOK|SKIP=no-arp-family\n");
		return;
	}
	for (i = 0; i < (int)(sizeof(hs) / sizeof(hs[0])); i++) {
		snprintf(tag, sizeof(tag), "b.%s", hs[i][0]);
		snprintf(cmd, sizeof(cmd), "/nft add chain arp p555a %s '{ %s }'",
			 hs[i][0], hs[i][1]);
		rc = nft(tag, cmd);
		printf("F555 HOOK|%s|%d\n", hs[i][0], rc);
	}
	sh("/nft delete table arp p555a");
}

/* ---------- diagnostic: what is actually in the rule ----------
 * F555D <table>.<chain>|r<N>=[expr(attr=val)...]
 * For a `log` expression both byte orders of NFTA_LOG_GROUP are printed, plus
 * the prefix, because "the rule counts but nothing arrives" has exactly one
 * cheap explanation to rule out first. */
static void dump_exprs(uint8_t family, const char *table, const char *chain)
{
	char buf[1024], rbuf[16384];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	int fd, sent, nrules = 0;

	fd = nl_open();
	if (fd < 0)
		return;
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1);
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1);
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return;
	}
	printf("F555D %s.%s|", table, chain);
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			const char *p, *end;

			if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
				goto done;
			if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				continue;
			printf("r%d=[", nrules);
			p = (const char *)h + NLMSG_HDRLEN + sizeof(*nfg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || p + alen > end)
					break;
				if ((a->nla_type & 0x3fff) == NFTA_RULE_EXPRESSIONS) {
					const char *q = (const char *)a + NLA_HDRLEN;
					const char *qe = (const char *)a + alen;
					int first = 1;

					for (; q + (int)sizeof(struct nlattr) <= qe; ) {
						const struct nlattr *el = (const struct nlattr *)q;
						int ell = (int)el->nla_len;
						const char *r, *re;
						const char *name = "?";
						char extra[128] = "";

						if (ell < (int)sizeof(*el) || q + ell > qe)
							break;
						r = (const char *)el + NLA_HDRLEN;
						re = (const char *)el + ell;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int eal = (int)ea->nla_len;

							if (eal < (int)sizeof(*ea) || r + eal > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_NAME)
								name = (const char *)ea + NLA_HDRLEN;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_DATA &&
							    !strcmp(name, "log")) {
								const char *dd = (const char *)ea + NLA_HDRLEN;
								const char *de = (const char *)ea + eal;
								char pfx[48] = "";
								int g_le = -1, g_be = -1;

								for (; dd + (int)sizeof(struct nlattr) <= de; ) {
									const struct nlattr *da = (const struct nlattr *)dd;
									int dal = (int)da->nla_len;

									if (dal < (int)sizeof(*da) || dd + dal > de)
										break;
									if ((da->nla_type & 0x3fff) == NFTA_LOG_GROUP &&
									    dal - NLA_HDRLEN >= 2) {
										const unsigned char *b =
											(const unsigned char *)da + NLA_HDRLEN;

										g_be = (b[0] << 8) | b[1];
										g_le = (b[1] << 8) | b[0];
									}
									if ((da->nla_type & 0x3fff) == NFTA_LOG_PREFIX)
										snprintf(pfx, sizeof(pfx), "%s",
											 (const char *)da + NLA_HDRLEN);
									dd += NLA_ALIGN_(dal);
								}
								snprintf(extra, sizeof(extra),
									 "{grp_be=%d,grp_le=%d,pfx=%s}",
									 g_be, g_le, pfx);
							}
							r += NLA_ALIGN_(eal);
						}
						printf("%s%s%s", first ? "" : ",", name, extra);
						first = 0;
						q += NLA_ALIGN_(ell);
					}
				}
				p += NLA_ALIGN_(alen);
			}
			printf("]");
			nrules++;
		}
	}
done:
	printf("|rules=%d\n", nrules);
	close(fd);
}

/* ---------- arm plumbing ---------- */

static void imm_pat(unsigned char *imm, int len)
{
	static const unsigned char pat[16] = {
		0xa5, 0x5a, 0x3c, 0xc3, 0x0f, 0xf0, 0x96, 0x69,
		0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88
	};
	int i;

	for (i = 0; i < len && i < 16; i++)
		imm[i] = pat[i];
}


struct rowres {
	int rc;
	int nfl;
	unsigned char nb[128];
	unsigned long long cnt;
	int ci1, co1, ilen, olen;
	unsigned char ib[248], ob[248];
};

static void row(const char *tag, const char *hook, const char *src,
		const char *rule, const char *g,
		const char *table, const char *chain,
		const unsigned char *ctl, int clen, int trig_out, uint32_t tpa,
		struct rowres *rs)
{
	char pre[80], h[160], chg[600];
	int nfl, ni1, no1;
	unsigned long long cnt;

	snprintf(pre, sizeof(pre), "f555.%s", tag);
	nfl = nfl_wait(NFL, pre, rs->nb, (int)sizeof(rs->nb), trig_out ? 600 : 300);
	ni1 = cap_arp_t(CAP_I1, rs->ib, (int)sizeof(rs->ib), trig_out ? 300 : 120,
			MAC_I0, 1, tpa);
	no1 = trig_out ? 0 : cap_arp_t(CAP_O1, rs->ob, (int)sizeof(rs->ob), 30,
				       MAC_I0, 1, 0);
	cnt = f555_count(NFPROTO_ARP, table, chain);
	rs->nfl = nfl;
	rs->cnt = cnt;
	rs->ci1 = ni1 > 0;
	rs->co1 = no1 > 0;
	rs->ilen = ni1;
	rs->olen = no1;
	hexcopy(h, (int)sizeof(h), rs->nb, nfl);
	chglist(chg, (int)sizeof(chg), rs->nb, nfl, ctl, clen);
	printf("F555 A|%s|hook=%s|src=%s|g=%s|rule=%s|rc=%d|cnt=%llu|nfl=%d|"
	       "chg=%s|nhex=%s|ci1=%d|ihex=",
	       tag, hook, src, g, rule, rs->rc, cnt, nfl, chg, h, ni1 > 0);
	hexcopy(h, (int)sizeof(h), rs->ib, ni1);
	printf("%s|co1=%d|ohex=", h, no1 > 0);
	hexcopy(h, (int)sizeof(h), rs->ob, no1);
	printf("%s\n", h);
}

static void arm_in_raw(const char *tag, const char *table, const char *chain,
		       uint32_t off, uint32_t len,
		       const unsigned char *fr, int flen,
		       const unsigned char *ctl, int clen, struct rowres *rs)
{
	unsigned char imm[32];
	char pre[80], g[32];

	memset(imm, 0, sizeof(imm));
	imm_pat(imm, (int)len);
	snprintf(pre, sizeof(pre), "f555.%s", tag);
	flush_chain(NFPROTO_ARP, table, chain);
	rs->rc = install_store(NFPROTO_ARP, table, chain, off, len, imm, (int)len,
			       1, 5, pre);
	cap_drain(CAP_I1);
	cap_drain(CAP_O1);
	nfl_drain(NFL);
	usleep(10000);
	pkt_send("i1", fr, flen);
	snprintf(g, sizeof(g), "%u,%u", off, len);
	row(tag, "in", "raw", "@nh,+", g, table, chain, ctl, clen, 0, 0, rs);
}

static void arm_in_nft(const char *tag, const char *table, const char *chain,
		       const char *ruletext, const char *g,
		       const unsigned char *fr, int flen,
		       const unsigned char *ctl, int clen, struct rowres *rs)
{
	char cmd[700], pre[80];

	snprintf(pre, sizeof(pre), "f555.%s", tag);
	flush_chain(NFPROTO_ARP, table, chain);
	snprintf(cmd, sizeof(cmd),
		 "/nft --debug=netlink add rule arp %s %s '%s log group 5 prefix \"%s\" counter accept'",
		 table, chain, ruletext, pre);
	rs->rc = nft(tag, cmd);
	cap_drain(CAP_I1);
	cap_drain(CAP_O1);
	nfl_drain(NFL);
	usleep(10000);
	pkt_send("i1", fr, flen);
	row(tag, "in", "nft", ruletext, g, table, chain, ctl, clen, 0, 0, rs);
}

static void arm_out_raw(const char *tag, const char *table, const char *chain,
			uint32_t off, uint32_t len, uint32_t poke,
			const unsigned char *ctl, int clen, struct rowres *rs)
{
	unsigned char imm[32];
	char pre[80], g[32];

	memset(imm, 0, sizeof(imm));
	imm_pat(imm, (int)len);
	snprintf(pre, sizeof(pre), "f555.%s", tag);
	flush_chain(NFPROTO_ARP, table, chain);
	rs->rc = install_store(NFPROTO_ARP, table, chain, off, len, imm, (int)len,
			       1, 5, pre);
	cap_drain(CAP_I1);
	nfl_drain(NFL);
	usleep(10000);
	f555_neigh_del("i0", htonl(poke));
	udp_poke(htonl(poke));
	snprintf(g, sizeof(g), "%u,%u", off, len);
	row(tag, "out", "raw", "@nh,+", g, table, chain, ctl, clen, 1, htonl(poke),
	    rs);
}

/* ---------- a control arm for a given table.chain ---------- */

static void arm_ctl(const char *tag, const char *hook, const char *table,
		    const char *chain, int trig_out, uint32_t poke,
		    const unsigned char *fr, int flen, struct rowres *rs)
{
	char pre[80];

	snprintf(pre, sizeof(pre), "f555.%s", tag);
	flush_chain(NFPROTO_ARP, table, chain);
	rs->rc = install_ctl(NFPROTO_ARP, table, chain, 5, pre);
	cap_drain(CAP_I1);
	cap_drain(CAP_O1);
	nfl_drain(NFL);
	usleep(20000);
	if (trig_out) {
		f555_neigh_del("i0", htonl(poke));
		udp_poke(htonl(poke));
	} else {
		pkt_send("i1", fr, flen);
	}
	row(tag, hook, "raw", "log+counter", "-", table, chain, NULL, 0,
	    trig_out, trig_out ? htonl(poke) : 0, rs);
}

/* ---------- C: the nine fields nft itself can name ---------- */

static void sec_c(unsigned char *fr, int flen)
{
	static const char *names[] = {
		"htype", "ptype", "hlen", "plen", "operation",
		"saddr_ether", "saddr_ip", "daddr_ether", "daddr_ip",
	};
	static const char *rules[] = {
		"arp htype set 0x00ab",
		"arp ptype set 0x86dd",
		"arp hlen set 8",
		"arp plen set 16",
		"arp operation set 2",
		"arp saddr ether set aa:bb:cc:00:00:99",
		"arp saddr ip set 10.1.0.66",
		"arp daddr ether set aa:bb:cc:00:00:88",
		"arp daddr ip set 10.9.0.1",
	};
	static const char *geoms[] = {
		"0,2", "2,2", "4,1", "5,1", "6,2", "8,6", "14,4", "18,6", "24,4",
	};
	struct rowres ctl, rs;
	char tag[64];
	int i;

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC c.table|%d\n", add_table(NFPROTO_ARP, "p555c"));
	printf("F555RC c.chain|%d\n", add_chain(NFPROTO_ARP, "p555c", "in", 0, 0, 1));
	arm_ctl("c.ctl", "in", "p555c", "in", 0, 0, fr, flen, &ctl);
	ctl = rs = ctl;
	for (i = 0; i < 9; i++) {
		snprintf(tag, sizeof(tag), "c.%s", names[i]);
		arm_in_nft(tag, "p555c", "in", rules[i], geoms[i], fr, flen,
			   ctl.nb, ctl.nfl, &rs);
	}
	/* C2: the raw escape, in the family nft could never reach before */
	arm_in_nft("c2.spill2016", "p555c", "in",
		   "@nh,160,128 set 0x00112233445566778899aabbccddeeff", "20,16",
		   fr, flen, ctl.nb, ctl.nfl, &rs);
	arm_in_nft("c2.pad288", "p555c", "in",
		   "@nh,224,64 set 0x0102030405060708", "28,8",
		   fr, flen, ctl.nb, ctl.nfl, &rs);
	arm_in_nft("c2.op71", "p555c", "in", "@nh,56,8 set 0xab", "7,1",
		   fr, flen, ctl.nb, ctl.nfl, &rs);
	sh("/nft delete table arp p555c");
}

/* ---------- D: the guard as a function of (offset,len), input hook ---------- */

static const int GRID_OFF[] = { 0, 1, 2, 4, 5, 6, 7, 8, 10, 14, 18, 20, 24, 26, 28, 30 };
static const int GRID_LEN[] = { 1, 2, 4, 6, 8, 16 };

static void sec_d(unsigned char *fr, int flen)
{
	struct rowres ctl, rs;
	int i, j;
	char tag[64];

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC d.table|%d\n", add_table(NFPROTO_ARP, "p555d"));
	printf("F555RC d.chain|%d\n", add_chain(NFPROTO_ARP, "p555d", "in", 0, 0, 1));
	arm_ctl("d.ctl", "in", "p555d", "in", 0, 0, fr, flen, &ctl);
	for (i = 0; i < (int)(sizeof(GRID_OFF) / sizeof(GRID_OFF[0])); i++) {
		for (j = 0; j < (int)(sizeof(GRID_LEN) / sizeof(GRID_LEN[0])); j++) {
			int off = GRID_OFF[i], len = GRID_LEN[j];

			if (off + len > 46)	/* past the padded frame: not the guard */
				continue;
			snprintf(tag, sizeof(tag), "d.%d.%d", off, len);
			arm_in_raw(tag, "p555d", "in", (uint32_t)off, (uint32_t)len,
				   fr, flen, ctl.nb, ctl.nfl, &rs);
		}
	}
	sh("/nft delete table arp p555d");
}

/* ---------- E: the same grid at the OUTPUT hook ---------- */

static void sec_e(unsigned char *fr, int flen)
{
	static const int EOFF[] = { 0, 4, 6, 8, 14, 18, 20, 24, 24, 26, 28, 30 };
	static const int ELEN[] = { 2, 1, 2, 6, 4, 6, 16, 4, 6, 4, 8, 16 };
	struct rowres ctl, rs;
	int i;
	char tag[64];
	(void)fr;
	(void)flen;

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC e.table|%d\n", add_table(NFPROTO_ARP, "p555e"));
	/* NF_ARP_OUT is 1 -- NF_ARP_FORWARD is 2 (netfilter_arp.h), and the first
	 * smoke of this turn asked for hook 2 and got -EOPNOTSUPP for every arm. */
	printf("F555RC e.chain|%d\n", add_chain(NFPROTO_ARP, "p555e", "out", 1, 0, 1));
	arm_ctl("e.ctl", "out", "p555e", "out", 1, 0x0a0100c0, NULL, 0, &ctl);
	for (i = 0; i < (int)(sizeof(EOFF) / sizeof(EOFF[0])); i++) {
		snprintf(tag, sizeof(tag), "e.%d.%d", EOFF[i], ELEN[i]);
		arm_out_raw(tag, "p555e", "out", (uint32_t)EOFF[i],
			    (uint32_t)ELEN[i], 0x0a0100c0,
			    ctl.nb, ctl.nfl, &rs);
	}
	sh("/nft delete table arp p555e");
}

/* ---------- F: what a rule in this family does to the host ---------- */

static void sec_f(void)
{
	struct {
		const char *tag;
		const char *rule;
		uint32_t spa;
		const char *spa_s;
		const char *moved_s;	/* the address a live rewrite would produce */
	} fa[] = {
		{ "f.norule", NULL,                       0x0a010091, "10.1.0.91", "10.5.5.5" },
		{ "f.alive",  "arp saddr ip set 10.5.5.5", 0x0a010092, "10.1.0.92", "10.5.5.5" },
		{ "f.dead",   "arp htype set 2",           0x0a010093, "10.1.0.93", "10.5.5.6" },
		{ "f.op",     "arp operation set 2",       0x0a010094, "10.1.0.94", "10.5.5.7" },
	};
	unsigned char fr[160];
	int flen, i;
	char cmd[700], tag[64];

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC f.table|%d\n", add_table(NFPROTO_ARP, "p555f"));
	printf("F555RC f.chain|%d\n", add_chain(NFPROTO_ARP, "p555f", "in2", 0, 0, 0));
	for (i = 0; i < (int)(sizeof(fa) / sizeof(fa[0])); i++) {
		int rc = 0, ni1, no1;
		unsigned long long cnt;

		flush_chain(NFPROTO_ARP, "p555f", "in2");
		if (fa[i].rule) {
			snprintf(tag, sizeof(tag), "%s.i", fa[i].tag);
			snprintf(cmd, sizeof(cmd),
				 "/nft add rule arp p555f in2 '%s counter accept'",
				 fa[i].rule);
			rc = nft(tag, cmd);
		}
		flen = build_arp(fr, 1, fa[i].spa, 0x0a010001, MAC_SRC, 6, 4, 1);
		cap_drain(CAP_I1);
		cap_drain(CAP_O1);
		usleep(20000);
		pkt_send("i1", fr, flen);
		ni1 = cap_arp(CAP_I1, fr, 248, 300, MAC_I0, 1);
		no1 = cap_arp(CAP_O1, fr, 248, 40, MAC_I0, 1);
		cnt = f555_count(NFPROTO_ARP, "p555f", "in2");
		printf("F555 F|%s|rule=%s|rc=%d|cnt=%llu|reply_i=%d|reply_o=%d\n",
		       fa[i].tag, fa[i].rule ? fa[i].rule : "none", rc, cnt,
		       ni1 > 0, no1 > 0);
		arp_row(fa[i].tag, fa[i].spa_s);
		arp_row(fa[i].tag, fa[i].moved_s);
	}
	sh("/nft delete table arp p555f");
}

/* ---------- G: what the receive path refuses before nft sees the packet ---------- */

static void sec_g(void)
{
	struct {
		const char *tag;
		int hlen, plen;
		uint32_t spa;
	} ga[] = {
		{ "g.h6p4",  6, 4,  0x0a0100b0 },
		{ "g.h8p16", 8, 16, 0x0a0100b1 },
		{ "g.h6p8",  6, 8,  0x0a0100b2 },
	};
	unsigned char fr[160], pay[128];
	int i, flen;
	char tag[64], pre[80];

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC g.table|%d\n", add_table(NFPROTO_ARP, "p555g"));
	printf("F555RC g.chain|%d\n", add_chain(NFPROTO_ARP, "p555g", "in", 0, 0, 1));
	for (i = 0; i < 3; i++) {
		int rc, nfl, rx;
		unsigned long long cnt;

		flush_chain(NFPROTO_ARP, "p555g", "in");
		snprintf(pre, sizeof(pre), "f555.%s", ga[i].tag);
		rc = install_ctl(NFPROTO_ARP, "p555g", "in", 5, pre);
		flen = build_arp(fr, 1, ga[i].spa, 0x0a010001, MAC_SRC,
				 ga[i].hlen, ga[i].plen, 1);
		cap_drain(CAP_I1);
		nfl_drain(NFL);
		usleep(20000);
		pkt_send("i1", fr, flen);
		nfl = nfl_wait(NFL, pre, pay, (int)sizeof(pay), 300);
		rx = cap_arp(CAP_I0, fr, 248, 200, MAC_SRC, 1) > 0;
		cnt = f555_count(NFPROTO_ARP, "p555g", "in");
		snprintf(tag, sizeof(tag), "%s", ga[i].tag);
		printf("F555 G|%s|hlen=%d|plen=%d|flen=%d|rc=%d|rx_i0=%d|cnt=%llu|"
		       "nfl=%d\n", tag, ga[i].hlen, ga[i].plen, flen, rc, rx, cnt, nfl);
	}
	sh("/nft delete table arp p555g");
}

/* ---------- focused experiment (mode f555log): where does the prefix go ---------- */

static void dump_log_hex(uint8_t family, const char *table, const char *chain,
			 const char *tag)
{
	char buf[1024], rbuf[16384];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	int fd, sent;

	fd = nl_open();
	if (fd < 0)
		return;
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1);
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1);
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return;
	}
	printf("F555H %s|", tag);
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			const char *p, *end;

			if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
				goto done;
			if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				continue;
			p = (const char *)h + NLMSG_HDRLEN + sizeof(*nfg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || p + alen > end)
					break;
				if ((a->nla_type & 0x3fff) == NFTA_RULE_EXPRESSIONS) {
					const char *q = (const char *)a + NLA_HDRLEN;
					const char *qe = (const char *)a + alen;

					for (; q + (int)sizeof(struct nlattr) <= qe; ) {
						const struct nlattr *el = (const struct nlattr *)q;
						int ell = (int)el->nla_len;
						const char *r, *re;
						const char *name = "?";

						if (ell < (int)sizeof(*el) || q + ell > qe)
							break;
						r = (const char *)el + NLA_HDRLEN;
						re = (const char *)el + ell;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int eal = (int)ea->nla_len;
							int k;

							if (eal < (int)sizeof(*ea) || r + eal > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_NAME)
								name = (const char *)ea + NLA_HDRLEN;
							r += NLA_ALIGN_(eal);
						}
						if (!strcmp(name, "log")) {
							r = (const char *)el + NLA_HDRLEN;
							for (; r + (int)sizeof(struct nlattr) <= re; ) {
								const struct nlattr *ea = (const struct nlattr *)r;
								int eal = (int)ea->nla_len;

								if (eal < (int)sizeof(*ea) || r + eal > re)
									break;
								if ((ea->nla_type & 0x3fff) == NFTA_EXPR_DATA) {
									const unsigned char *b =
										(const unsigned char *)ea + NLA_HDRLEN;
									int n = eal - NLA_HDRLEN, k;

									printf("logdata[%d]=", n);
									for (k = 0; k < n; k++)
										printf("%02x", b[k]);
									printf("|");
								}
								r += NLA_ALIGN_(eal);
							}
						}
						q += NLA_ALIGN_(ell);
					}
				}
				p += NLA_ALIGN_(alen);
			}
		}
	}
done:
	printf("|end\n");
	close(fd);
}

static void nfl_readall(int fd, int ms, const char *tag)
{
	struct timeval tv = { .tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000 };
	int n = 0;

	for (;;) {
		unsigned char b[4096];
		int r;

		FD_ZERO(&(fd_set){0});
		{
			fd_set rfds;

			FD_ZERO(&rfds);
			FD_SET(fd, &rfds);
			if (select(fd + 1, &rfds, NULL, NULL, &tv) <= 0)
				break;
		}
		r = (int)recv(fd, b, sizeof(b), 0);
		if (r <= 0)
			break;
		{
			struct nlmsghdr *h = (struct nlmsghdr *)b;
			int rem = r;

			for (; NLMSG_OK(h, rem); h = NLMSG_NEXT(h, rem)) {
				const unsigned char *p;
				int plen, off;
				char pre[64] = "";
				unsigned char pay[128];
				int paylen = 0, k;

				if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_ULOG_ << 8) |
								NFULNL_MSG_PACKET_))
					continue;
				p = (const unsigned char *)NLMSG_DATA(h);
				plen = (int)h->nlmsg_len - NLMSG_HDRLEN;
				for (off = 4; off + (int)sizeof(struct nlattr) <= plen; ) {
					const struct nlattr *a = (const struct nlattr *)(p + off);
					int alen = (int)a->nla_len;

					if (alen < (int)sizeof(*a) || off + alen > plen)
						break;
					if ((a->nla_type & 0x3fff) == NFULA_PREFIX_)
						snprintf(pre, sizeof(pre), "%s",
							 (const char *)a + NLA_HDRLEN);
					if ((a->nla_type & 0x3fff) == NFULA_PAYLOAD_) {
						int m = alen - NLA_HDRLEN;

						if (m > 128)
							m = 128;
						memcpy(pay, (const char *)a + NLA_HDRLEN, (size_t)m);
						paylen = m;
					}
					off += (int)NLA_ALIGN_(alen);
				}
				n++;
				printf("F555N %s|n=%d|pre=%s|len=%d|pay=", tag, n, pre, paylen);
				for (k = 0; k < paylen && k < 48; k++)
					printf("%02x", pay[k]);
				printf("\n");
			}
		}
	}
	if (!n)
		printf("F555N %s|n=0\n", tag);
}

/* four variants of the same question, one boot */
static void sec_log(void)
{
	unsigned char fr[160], imm[16];
	char pre[64];
	int flen, i;
	static const struct { const char *tag; const char *pre; int store; } v[] = {
		{ "l.ctl",   "abc.def", 0 },
		{ "l.store", "ghi.jkl", 1 },
	};

	sh("/nft flush ruleset");
	printf("F555RC l.table|%d\n", add_table(NFPROTO_ARP, "p555l"));
	printf("F555RC l.chain|%d\n", add_chain(NFPROTO_ARP, "p555l", "in", 0, 0, 1));
	flen = build_arp(fr, 1, 0x0a010009, 0x0a010001, MAC_SRC, 6, 4, 1);
	memset(imm, 0, sizeof(imm));
	imm_pat(imm, 2);
	for (i = 0; i < 2; i++) {
		int rc;

		snprintf(pre, sizeof(pre), "f555.%s", v[i].tag);
		flush_chain(NFPROTO_ARP, "p555l", "in");
		if (v[i].store)
			rc = install_store(NFPROTO_ARP, "p555l", "in", 8, 2, imm, 2, 1,
					   5, v[i].pre);
		else
			rc = install_ctl(NFPROTO_ARP, "p555l", "in", 5, v[i].pre);
		printf("F555RC %s|%d\n", v[i].tag, rc);
		dump_log_hex(NFPROTO_ARP, "p555l", "in", v[i].tag);
		cap_drain(CAP_I1);
		nfl_drain(NFL);
		usleep(20000);
		pkt_send("i1", fr, flen);
		{
			unsigned long long cnt = f555_count(NFPROTO_ARP, "p555l", "in");

			printf("F555C %s|cnt=%llu\n", v[i].tag, cnt);
		}
		nfl_readall(NFL, 400, v[i].tag);
	}
	/* the same rule, installed by nft */
	flush_chain(NFPROTO_ARP, "p555l", "in");
	printf("F555RC l.nft|%d\n",
	       nft("l.nft", "/nft add rule arp p555l in 'log group 5 prefix \"mno.pqr\" counter accept'"));
	dump_log_hex(NFPROTO_ARP, "p555l", "in", "l.nft");
	cap_drain(CAP_I1);
	nfl_drain(NFL);
	usleep(20000);
	pkt_send("i1", fr, flen);
	nfl_readall(NFL, 400, "l.nft");
	sh("/nft delete table arp p555l");
}
/* ---------- /proc/net/arp sanity + main ---------- */

int f555_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f555";
	unsigned char fr[160];
	int flen;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F555 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F555 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	sec_a();
	sec_b();
	if (!strcmp(mode, "f555bare")) {
		printf("F555 DONE\n");
		return 0;
	}
	env_setup();
	flen = build_arp(fr, 1, 0x0a010009, 0x0a010001, MAC_SRC, 6, 4, 1);
	printf("F555 FRAME|len=%d|hex=", flen);
	{
		int i;

		for (i = 0; i < 60; i++)
			printf("%02x", fr[i]);
		printf("\n");
	}
	if (!strcmp(mode, "f555log")) {
		sec_log();
		printf("F555 DONE\n");
		return 0;
	}
	sec_c(fr, flen);
	sec_d(fr, flen);
	sec_e(fr, flen);
	sec_f();
	sec_g();
	printf("F555 DONE\n");
	return 0;
}
/* differ556_add.c -- turn 556 / F33: one guard, four types, one grid.
 *
 * F30/F31/F32 measured the four branches of nft_nh_write_ok() one at a time,
 * on three DIFFERENT images:
 *
 *   ip4/ip6     stock 7.3.4-B19           (F30)
 *   bridge      src/linux-7.3.4-C553      (F31, ethertype 0x0800 / 0x0806)
 *   netdev      src/linux-7.3.4-C553      (F31, dead code at ingress)
 *   arp         src/linux-7.3.4-A553      (F32)
 *
 * F33 asks a different question: not "does branch X guard byte Y", but "what
 * KIND of function is each branch".  The answer is the SHAPE of the set of
 * (offset,len) pairs it accepts, and a shape measured in three different boots
 * on three different images is not a shape.  So: one kernel (T556) with all
 * four branches live, one boot, and ONE identical 40-cell grid shipped through
 * every envelope:
 *
 *   ip4   family ip,     base nh, chain prerouting   (nft_nh_write_ok_ip4)
 *   ip6   family ip6,    base nh, chain prerouting   (nft_nh_write_ok_ip6)
 *   nd    family netdev, base nh, chain ingress i1   (nft_nh_write_ok -> true)
 *   br4   family bridge, base nh, chain prerouting, ethertype 0x0800
 *   brA   family bridge, base nh, chain prerouting, ethertype 0x0806
 *   arp   family arp,    base nh, chain input        (nft_nh_write_ok_arp)
 *   ll4   family ip,     base ll, chain prerouting   (nft_ll_write_ok)
 *   llN   family netdev, base ll, chain ingress i1
 *   llB   family bridge, base ll, chain prerouting
 *
 * Oracle per arm: the kernel's own counter, placed AFTER the store in the same
 * rule -- cnt=1 means "the guard let the store through and the rest of the
 * rule ran", cnt=0 means the store was refused and the remaining expressions
 * (log, counter, verdict) never ran.  The NFLOG message carries the frame as
 * it looks at the log point, i.e. after the store, so every alive cell also
 * gets its bytes checked against the control arm of the same envelope.
 *
 * This file is appended to a renamed copy of differ555.c (see
 * vm/build_f33_differ.sh); all helpers above it -- netlink toolkit, veth,
 * rtnetlink, NFLOG, build_arp, f555_count -- are the F32 ones, unchanged.
 */

/* ---------- bridge device helpers (same code as differ553.c) ---------- */

static int f556_link_add_kind(const char *name, const char *kind)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[256];
	} req;
	struct nlattr *li;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, name, (int)strlen(name) + 1);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, kind, (int)strlen(kind) + 1);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f556_link_enslave(const char *port, const char *master)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[128];
	} req;
	uint32_t midx = (uint32_t)f555_ifindex(master);
	int fd, rc;

	if ((int)midx < 0)
		return -10;
	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	req.ifi.ifi_index = f555_ifindex(port);
	attr_put(&req.nlh, IFLA_MASTER, &midx, 4);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

/* ---------- one chain, with a device when the hook needs one ---------- */

/* base chain: family, hook number, priority, policy; dev != NULL only for the
 * netdev ingress hook, whose NFTA_HOOK_DEV is a STRING (nf_tables_api.c reads
 * it with nla_get_string()). */
static int f556_add_chain(uint8_t family, const char *table, const char *chain,
			  uint32_t hook, uint32_t prio, uint32_t policy,
			  const char *dev)
{
	struct nlmsghdr *nlh;
	struct nlattr *h;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWCHAIN,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE, family);
	put_str(nlh, NFTA_CHAIN_TABLE, table);
	put_str(nlh, NFTA_CHAIN_NAME, chain);
	h = nest_start(nlh, NFTA_CHAIN_HOOK);
	put_be32(nlh, NFTA_HOOK_HOOKNUM, hook);
	put_be32(nlh, NFTA_HOOK_PRIORITY, prio);
	if (dev)
		put_str(nlh, NFTA_HOOK_DEV, dev);
	nest_end(nlh, h);
	put_be32(nlh, NFTA_CHAIN_POLICY, policy);
	put_str(nlh, NFTA_CHAIN_TYPE, "filter");
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

/* ---------- the store, with an explicit payload BASE ---------- */

/* one rule: [store <base>+off = imm][log][counter][accept] */
static int f556_install_store(uint8_t family, const char *table, const char *chain,
			      uint32_t base, uint32_t off, uint32_t len,
			      const unsigned char *imm, int immlen,
			      int loggroup, const char *prefix)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *e, *d;
	int rc;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	imm_value(nlh, NFT_REG32_00, imm, immlen);
	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "payload");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00);
	put_be32(nlh, NFTA_PAYLOAD_BASE, base);
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
	put_be32(nlh, NFTA_PAYLOAD_LEN, len);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
	nest_end(nlh, d);
	nest_end(nlh, e);
	log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	rc = nft_one(opbuf, (int)nlh->nlmsg_len);
	return rc;
}

/* ---------- frames ---------- */

static const unsigned char M33_BC[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

static unsigned short f556_csum(const void *data, int len)
{
	const unsigned char *p = data;
	unsigned int sum = 0;

	while (len > 1) {
		sum += (unsigned int)((p[0] << 8) | p[1]);
		p += 2;
		len -= 2;
	}
	if (len)
		sum += (unsigned int)(p[0] << 8);
	while (sum >> 16)
		sum = (sum & 0xffff) + (sum >> 16);
	return (unsigned short)~sum;
}

/* frame kinds */
#define FK33_IP4	0	/* ethernet + IPv4 (ihl 5, proto 17) + UDP */
#define FK33_IP6	1	/* ethernet + IPv6 + UDP                     */
#define FK33_ARP	2	/* ethernet + ARP request, padded to 60      */
#define FK33_IP4_IHL6	3	/* the same datagram with ihl 6 -> byte 14 = 0x46 */
#define FK33_IP4_P6	4	/* the same datagram with proto 6 (byte 23 = 0x06) */
#define FK33_IP6_B	5	/* a different IPv6 frame (tc/hop differ)    */

/* Ethernet + IPv4 + UDP.  ihl4 is the header length in 32-bit words; the
 * checksum is computed over exactly ihl4*4 bytes, so an ihl-6 frame is a
 * VALID datagram -- ip_rcv must not drop it before the hook, or the guard
 * would never be asked. */
static int f556_mk_ip4(unsigned char *out, int ihl4, int proto, int ttl)
{
	int hl = ihl4 * 4, tot = hl + 8 + 18;
	unsigned char *ip = out + 14;
	unsigned char *u = out + 14 + hl;
	unsigned short c;

	memset(out, 0, 200);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x08;
	out[13] = 0x00;
	ip[0] = (unsigned char)(0x40 | ihl4);
	ip[1] = 0x00;
	ip[2] = (unsigned char)(tot >> 8);
	ip[3] = (unsigned char)tot;
	ip[4] = 0x12;
	ip[5] = 0x34;
	ip[6] = 0x00;
	ip[7] = 0x00;
	ip[8] = (unsigned char)ttl;
	ip[9] = (unsigned char)proto;
	ip[10] = 0x00;
	ip[11] = 0x00;
	ip[12] = 0x0a; ip[13] = 0x01; ip[14] = 0x00; ip[15] = 0x01;	/* 10.1.0.1 */
	ip[16] = 0x0a; ip[17] = 0x09; ip[18] = 0x00; ip[19] = 0x07;	/* 10.9.0.7 */
	c = f556_csum(ip, hl);
	ip[10] = (unsigned char)(c >> 8);
	ip[11] = (unsigned char)c;
	u[0] = 0x9c; u[1] = 0x40;	/* sport 40000 */
	u[2] = 0x13; u[3] = 0x88;	/* dport 5000  */
	u[4] = 0x00; u[5] = 26;		/* 8 + 18      */
	u[6] = 0x00; u[7] = 0x00;	/* checksum 0 (legal for IPv4) */
	memset(u + 8, 0x77, 18);
	return 14 + tot;
}

/* Ethernet + IPv6 + UDP.  `tc` goes into the traffic-class nibbles of bytes
 * 14..15, `hop` into byte 21 -- the two bytes FK33_IP6_B changes, so the same
 * rule over two IPv6 frames tests whether that branch reads the packet. */
static int f556_mk_ip6(unsigned char *out, int tc, int hop)
{
	int pay = 8 + 18;
	unsigned char *ip = out + 14;
	unsigned char *u = out + 14 + 40;
	static const unsigned char src[16] = { 0xfd, 0, 0, 0, 0, 0, 0, 0,
					       0, 0, 0, 0, 0, 0x98, 0, 1 };
	static const unsigned char dst[16] = { 0xfd, 0, 0, 0, 0, 0, 0, 0,
					       0, 0, 0, 0, 0, 0x99, 0, 9 };

	memset(out, 0, 200);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x86;
	out[13] = 0xdd;
	ip[0] = 0x60 | (unsigned char)((tc >> 4) & 0x0f);
	ip[1] = (unsigned char)((tc << 4) & 0xf0);
	ip[4] = (unsigned char)(pay >> 8);
	ip[5] = (unsigned char)pay;
	ip[6] = 17;
	ip[7] = (unsigned char)hop;
	memcpy(ip + 8, src, 16);
	memcpy(ip + 24, dst, 16);
	u[0] = 0x9c; u[1] = 0x40;
	u[2] = 0x13; u[3] = 0x88;
	u[4] = 0x00; u[5] = 26;
	u[6] = 0x00; u[7] = 0x00;
	memset(u + 8, 0x77, 18);
	return 14 + 40 + pay;
}

static int f556_frame(int kind, unsigned char *out)
{
	switch (kind) {
	case FK33_IP4:
		return f556_mk_ip4(out, 5, 17, 64);
	case FK33_IP4_IHL6:
		return f556_mk_ip4(out, 6, 17, 64);
	case FK33_IP4_P6:
		return f556_mk_ip4(out, 5, 6, 64);
	case FK33_IP6:
		return f556_mk_ip6(out, 0x00, 64);
	case FK33_IP6_B:
		return f556_mk_ip6(out, 0x2e, 33);
	case FK33_ARP:
		return build_arp(out, 1, 0x0a010009, 0x0a090001, MAC_SRC, 6, 4, 1);
	}
	return f556_mk_ip4(out, 5, 17, 64);
}

/* pkt_send() above sets sll_protocol = ETH_P_ALL.  That is what
 * packet_snd() copies into skb->protocol, and at the netdev EGRESS hook the
 * guard switches on exactly that field -- so an egress arm sent with
 * ETH_P_ALL would be judged as "unknown protocol" and every cell would look
 * refused.  This variant sends the frame's own ethertype. */
static int pkt_send_p(const char *dev, const unsigned char *fr, int len,
		      unsigned short proto)
{
	struct sockaddr_ll sll;
	int s, rc, idx = f555_ifindex(dev);

	if (idx < 0)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(proto);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, fr, 6);
	rc = (int)sendto(s, fr, (size_t)len, 0, (struct sockaddr *)&sll, sizeof(sll));
	close(s);
	return rc < 0 ? -errno : 0;
}

static unsigned short f556_proto(int kind)
{
	if (kind == FK33_ARP)
		return 0x0806;
	if (kind == FK33_IP6 || kind == FK33_IP6_B)
		return 0x86dd;
	return 0x0800;
}

/* ---------- the shared grid ---------- */

#define G33_NOFF 12
#define G33_NLEN 3
#define G33_NEXT 4
#define G33_N (G33_NOFF * G33_NLEN + G33_NEXT)

static const int G33_OFF[G33_NOFF] = { 0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24 };
static const int G33_LEN[G33_NLEN] = { 1, 2, 4 };
static const int G33_XOFF[G33_NEXT] = { 0, 8, 16, 20 };
static const int G33_XLEN[G33_NEXT] = { 8, 16, 16, 16 };

/* The value a cell writes.  Where a branch compares a written byte with the
 * frame (ip4 offset 0 and offset 8 + len 2), the value is chosen equal to what
 * the frame carries, so that the LENGTH is what the cell measures and not the
 * value.  The value-dependence itself is measured separately, by the E arms. */
static void f556_imm(int kind, int off, int len, unsigned char *imm)
{
	int i;

	memset(imm, 0, 16);
	for (i = 0; i < len && i < 16; i++)
		imm[i] = (unsigned char)(0x90 + i);
	if (off == 0)
		imm[0] = (kind == FK33_IP6 || kind == FK33_IP6_B) ? 0x60 : 0x45;
	if (off == 8 && len >= 2)
		imm[1] = 0x11;	/* keep byte 9 (protocol) as the frame has it */
}

/* ---------- one envelope ---------- */

struct f556_env {
	const char *tag;
	uint8_t fam;
	const char *table;
	const char *chain;
	uint32_t hook;
	uint32_t base;
	const char *dev;	/* where the frame is injected */
	const char *rule_dev;	/* NFTA_HOOK_DEV, netdev only */
	int kind;		/* default frame kind */
};

static int NFL33 = -1;
static char PRE33[96];

static long f33_ms(void)
{
	struct timeval tv;

	gettimeofday(&tv, NULL);
	return tv.tv_sec * 1000L + tv.tv_usec / 1000;
}

static unsigned long long f556_arm(const struct f556_env *e, const char *tag,
				   int off, int len, const unsigned char *imm,
				   int immlen, int kind)
{
	unsigned char fr[256], pay[192];
	unsigned long long cnt, cnt0;
	int flen, n = 0, rc, i;
	long t0, t1, t2, t3, t4;

	flen = f556_frame(kind, fr);
	snprintf(PRE33, sizeof(PRE33), "f33.%s.%s", e->tag, tag);
	t0 = f33_ms();
	flush_chain(e->fam, e->table, e->chain);
	t1 = f33_ms();
	rc = f556_install_store(e->fam, e->table, e->chain, e->base,
				(uint32_t)off, (uint32_t)len, imm, immlen,
				5, PRE33);
	t2 = f33_ms();
	nfl_drain(NFL33);
	cnt0 = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	if (rc == 0) {
		usleep(15000);
		pkt_send_p(e->dev, fr, flen, f556_proto(kind));
		n = nfl_wait(NFL33, PRE33, pay, (int)sizeof(pay), 200);
	}
	t3 = f33_ms();
	cnt = f555_count(e->fam, e->table, e->chain);
	t4 = f33_ms();
	printf("F556 R|env=%s|arm=%s|off=%d|len=%d|kind=%d|rc=%d|cnt=%llu|cnt0=%llu|"
	       "nfl=%d|ms=%ld,%ld,%ld,%ld|hex=",
	       e->tag, tag, off, len, kind, rc, cnt, cnt0, n, t1 - t0, t2 - t1,
	       t3 - t2, t4 - t3);
	for (i = 0; i < n && i < 96; i++)
		printf("%02x", pay[i]);
	printf("\n");
	return cnt;
}

static void f556_ctl(const struct f556_env *e, int kind)
{
	unsigned char fr[256], pay[192];
	unsigned long long cnt, cnt0;
	int flen, n, rc, i;

	flen = f556_frame(kind, fr);
	snprintf(PRE33, sizeof(PRE33), "f33.%s.ctl", e->tag);
	flush_chain(e->fam, e->table, e->chain);
	rc = install_ctl(e->fam, e->table, e->chain, 5, PRE33);
	nfl_drain(NFL33);
	n = 0;
	cnt0 = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	if (rc == 0) {
		usleep(15000);
		pkt_send_p(e->dev, fr, flen, f556_proto(kind));
		n = nfl_wait(NFL33, PRE33, pay, (int)sizeof(pay), 300);
	}
	cnt = f555_count(e->fam, e->table, e->chain);
	printf("F556 CTL|env=%s|kind=%d|rc=%d|cnt=%llu|cnt0=%llu|nfl=%d|hex=",
	       e->tag, kind, rc, cnt, cnt0, n);
	for (i = 0; i < n && i < 96; i++)
		printf("%02x", pay[i]);
	printf("\n");
}

/* create the table and the one chain this envelope owns */
static int f556_chain(const struct f556_env *e)
{
	int rc, rc2;

	rc = add_table(e->fam, e->table);
	rc2 = f556_add_chain(e->fam, e->table, e->chain, e->hook, 0, 1,
			     e->rule_dev);
	printf("F556 CHAIN|env=%s|table=%d|chain=%d\n", e->tag, rc, rc2);
	return rc || rc2;
}

static void f556_env_run(const struct f556_env *e)
{
	unsigned char imm[16];
	char tag[32];
	int i, j;

	f556_ctl(e, e->kind);
	for (i = 0; i < G33_NOFF; i++) {
		for (j = 0; j < G33_NLEN; j++) {
			f556_imm(e->kind, G33_OFF[i], G33_LEN[j], imm);
			snprintf(tag, sizeof(tag), "g%d_%d", G33_OFF[i], G33_LEN[j]);
			f556_arm(e, tag, G33_OFF[i], G33_LEN[j], imm, G33_LEN[j],
				 e->kind);
		}
	}
	for (i = 0; i < G33_NEXT; i++) {
		f556_imm(e->kind, G33_XOFF[i], G33_XLEN[i], imm);
		snprintf(tag, sizeof(tag), "x%d_%d", G33_XOFF[i], G33_XLEN[i]);
		f556_arm(e, tag, G33_XOFF[i], G33_XLEN[i], imm, G33_XLEN[i],
			 e->kind);
	}
	sh("/nft flush ruleset");
}

/* ---------- environment ---------- */

static int HAVE33_IP, HAVE33_IP6, HAVE33_NETDEV, HAVE33_BRIDGE, HAVE33_ARP;

static void f556_fams(void)
{
	struct { const char *n; uint8_t f; int *have; } fams[] = {
		{ "ip",     NFPROTO_IPV4,   &HAVE33_IP },
		{ "ip6",    NFPROTO_IPV6,   &HAVE33_IP6 },
		{ "netdev", NFPROTO_NETDEV, &HAVE33_NETDEV },
		{ "bridge", NFPROTO_BRIDGE, &HAVE33_BRIDGE },
		{ "arp",    NFPROTO_ARP,    &HAVE33_ARP },
	};
	char cmd[256];
	int i;

	sh("/nft flush ruleset");
	for (i = 0; i < (int)(sizeof(fams) / sizeof(fams[0])); i++) {
		int rc = add_table(fams[i].f, "p33probe");

		*fams[i].have = (rc == 0);
		printf("F556 FAM|%s|%d\n", fams[i].n, rc);
		if (rc == 0) {
			snprintf(cmd, sizeof(cmd), "/nft delete table %s p33probe",
				 fams[i].n);
			sh(cmd);
		}
	}
}

static int f556_env_setup(void)
{
	int rc = 0;

	if (link_add_veth("i0", "i1"))
		rc |= 1;
	if (link_add_veth("s0", "s1"))
		rc |= 2;
	if (link_add_veth("r0", "r1"))
		rc |= 4;
	set_up("i0"); set_up("i1");
	set_up("s0"); set_up("s1");
	set_up("r0"); set_up("r1");
	set_up("lo");
	if (f556_link_add_kind("br0", "bridge"))
		rc |= 8;
	set_up("br0");
	if (f556_link_enslave("s1", "br0") || f556_link_enslave("r1", "br0"))
		rc |= 16;
	printf("F556 SETUP|rc=%d|i1=%d|s1=%d|r1=%d|br0=%d\n", rc,
	       f555_ifindex("i1"), f555_ifindex("s1"), f555_ifindex("r1"),
	       f555_ifindex("br0"));
	return rc;
}

/* ---------- the nine envelopes ---------- */

static void f556_sec(const char *only)
{
	struct f556_env e;

	/* ---- 1. family ip, base nh: nft_nh_write_ok_ip4() ---- */
	if (!only || !strcmp(only, "ip4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "ip4"; e.fam = NFPROTO_IPV4; e.table = "p33f";
		e.chain = "pre"; e.hook = 0;	/* NF_INET_PRE_ROUTING */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 2. family ip6, base nh: nft_nh_write_ok_ip6() ---- */
	if (!only || !strcmp(only, "ip6")) {
		memset(&e, 0, sizeof(e));
		e.tag = "ip6"; e.fam = NFPROTO_IPV6; e.table = "p33g";
		e.chain = "pre"; e.hook = 0;
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0"; e.kind = FK33_IP6;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 3. family netdev, ingress: NFPROTO_NETDEV + ingress -> true ---- */
	if (!only || !strcmp(only, "nd")) {
		memset(&e, 0, sizeof(e));
		e.tag = "nd"; e.fam = NFPROTO_NETDEV; e.table = "p33n";
		e.chain = "ing"; e.hook = 0;	/* NF_NETDEV_INGRESS */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0";
		e.rule_dev = "i1"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 3b. family netdev, EGRESS: nft_nh_write_ok_netdev() ----
	 * F31 called this branch dead code because "netdev has only the
	 * ingress hook".  uapi/linux/netfilter.h has NF_NETDEV_INGRESS then
	 * NF_NETDEV_EGRESS, and nft_chain_filter_netdev's hook_mask has BOTH,
	 * so the branch is reachable -- and at egress the guard is the
	 * switch on skb->protocol, not the constant.  Two labels, two
	 * shapes, same chain. */
	if (!only || !strcmp(only, "eg4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "eg4"; e.fam = NFPROTO_NETDEV; e.table = "p33q";
		e.chain = "egr"; e.hook = 1;	/* NF_NETDEV_EGRESS */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0";
		e.rule_dev = "i0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	if (!only || !strcmp(only, "egA")) {
		memset(&e, 0, sizeof(e));
		e.tag = "egA"; e.fam = NFPROTO_NETDEV; e.table = "p33r";
		e.chain = "egr"; e.hook = 1;
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0";
		e.rule_dev = "i0"; e.kind = FK33_ARP;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 4. family bridge, ethertype 0x0800 ---- */
	if (!only || !strcmp(only, "br4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "br4"; e.fam = NFPROTO_BRIDGE; e.table = "p33b";
		e.chain = "pre"; e.hook = 0;	/* NF_BR_PRE_ROUTING */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "s0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 5. family bridge, ethertype 0x0806 ---- */
	if (!only || !strcmp(only, "brA")) {
		memset(&e, 0, sizeof(e));
		e.tag = "brA"; e.fam = NFPROTO_BRIDGE; e.table = "p33c";
		e.chain = "pre"; e.hook = 0;
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "s0"; e.kind = FK33_ARP;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 6. family arp, hook input: nft_nh_write_ok_arp() ---- */
	if (!only || !strcmp(only, "arp")) {
		memset(&e, 0, sizeof(e));
		e.tag = "arp"; e.fam = NFPROTO_ARP; e.table = "p33a";
		e.chain = "in"; e.hook = 0;	/* NF_ARP_IN */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0"; e.kind = FK33_ARP;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 7..9. base ll in three envelopes: nft_ll_write_ok() ---- */
	if (!only || !strcmp(only, "ll4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "ll4"; e.fam = NFPROTO_IPV4; e.table = "p33h";
		e.chain = "pre"; e.hook = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	if (!only || !strcmp(only, "llN")) {
		memset(&e, 0, sizeof(e));
		e.tag = "llN"; e.fam = NFPROTO_NETDEV; e.table = "p33i";
		e.chain = "ing"; e.hook = 0;	/* NF_NETDEV_INGRESS */
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.rule_dev = "i1";
		e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	if (!only || !strcmp(only, "llE")) {
		memset(&e, 0, sizeof(e));
		e.tag = "llE"; e.fam = NFPROTO_NETDEV; e.table = "p33s";
		e.chain = "egr"; e.hook = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.rule_dev = "i0";
		e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	if (!only || !strcmp(only, "llB")) {
		memset(&e, 0, sizeof(e));
		e.tag = "llB"; e.fam = NFPROTO_BRIDGE; e.table = "p33j";
		e.chain = "pre"; e.hook = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
}

/* ---------- E arms: does the branch read the PACKET, or the VALUE? ---------- */

static void f556_sec_e(void)
{
	struct f556_env e;
	unsigned char imm[16];

	/* ip4, offset 0, len 2: the guard compares the WRITTEN first byte with
	 * the one in the packet (nft_nh_write_ok_ip4 case 0, skb_copy_bits).
	 * Same rule, two valid datagrams: ihl 5 (0x45) and ihl 6 (0x46). */
	f556_imm(FK33_IP4, 0, 2, imm);
	imm[0] = 0x45;
	memset(&e, 0, sizeof(e));
	e.tag = "e4"; e.fam = NFPROTO_IPV4; e.table = "p33k";
	e.chain = "pre"; e.hook = 0; e.base = NFT_PAYLOAD_NETWORK_HEADER;
	e.dev = "i0"; e.kind = FK33_IP4;
	if (f556_chain(&e)) {
		printf("F556 E|SKIP=e4-chain\n");
		return;
	}
	f556_arm(&e, "ip4_0_2_ihl5", 0, 2, imm, 2, FK33_IP4);
	f556_arm(&e, "ip4_0_2_ihl6", 0, 2, imm, 2, FK33_IP4_IHL6);
	/* ip4, offset 8, len 2: the guard compares the written SECOND byte with
	 * the protocol byte of the packet.  imm[1] = 0x11, so a proto-17 frame
	 * passes and a proto-6 frame does not -- same rule, other frame. */
	f556_imm(FK33_IP4, 8, 2, imm);
	f556_arm(&e, "ip4_8_2_p17", 8, 2, imm, 2, FK33_IP4);
	f556_arm(&e, "ip4_8_2_p6", 8, 2, imm, 2, FK33_IP4_P6);
	sh("/nft flush ruleset");

	/* ip6, offset 0: nft_nh_write_ok_ip6 case 0 tests ih->version of the
	 * WRITTEN data, not of the packet.  So the VALUE must decide and the
	 * FRAME must not: 0x60 alive on both frames, 0x40 dead on both. */
	memset(&e, 0, sizeof(e));
	e.tag = "e6"; e.fam = NFPROTO_IPV6; e.table = "p33l";
	e.chain = "pre"; e.hook = 0; e.base = NFT_PAYLOAD_NETWORK_HEADER;
	e.dev = "i0"; e.kind = FK33_IP6;
	if (f556_chain(&e)) {
		printf("F556 E|SKIP=e6-chain\n");
		return;
	}
	memset(imm, 0, sizeof(imm));
	imm[0] = 0x60; imm[1] = 0x11; imm[2] = 0x22; imm[3] = 0x33;
	f556_arm(&e, "ip6_0_4_v6_a", 0, 4, imm, 4, FK33_IP6);
	f556_arm(&e, "ip6_0_4_v6_b", 0, 4, imm, 4, FK33_IP6_B);
	imm[0] = 0x40;
	f556_arm(&e, "ip6_0_4_v4_a", 0, 4, imm, 4, FK33_IP6);
	f556_arm(&e, "ip6_0_4_v4_b", 0, 4, imm, 4, FK33_IP6_B);
	sh("/nft flush ruleset");

	/* the envelope decides before the guard: an ARP-family chain never sees
	 * an IPv4 frame at all (arp_rcv is not on that path). */
	memset(&e, 0, sizeof(e));
	e.tag = "ea"; e.fam = NFPROTO_ARP; e.table = "p33m";
	e.chain = "in"; e.hook = 0; e.base = NFT_PAYLOAD_NETWORK_HEADER;
	e.dev = "i0"; e.kind = FK33_ARP;
	if (f556_chain(&e)) {
		printf("F556 E|SKIP=ea-chain\n");
		return;
	}
	f556_imm(FK33_ARP, 8, 2, imm);
	f556_arm(&e, "arp_fam_arpframe", 8, 2, imm, 2, FK33_ARP);
	f556_arm(&e, "arp_fam_ipv4frame", 8, 2, imm, 2, FK33_IP4);
	sh("/nft flush ruleset");

	/* the switch, measured by the same cell under two labels: (6,2) is in
	 * the ARP predicate and in none of the IPv4 case labels. */
	memset(&e, 0, sizeof(e));
	e.tag = "eb"; e.fam = NFPROTO_BRIDGE; e.table = "p33o";
	e.chain = "pre"; e.hook = 0; e.base = NFT_PAYLOAD_NETWORK_HEADER;
	e.dev = "s0"; e.kind = FK33_IP4;
	if (f556_chain(&e)) {
		printf("F556 E|SKIP=eb-chain\n");
		return;
	}
	f556_imm(FK33_IP4, 6, 2, imm);
	f556_arm(&e, "br_6_2_ip", 6, 2, imm, 2, FK33_IP4);
	f556_arm(&e, "br_6_2_arp", 6, 2, imm, 2, FK33_ARP);
	f556_arm(&e, "br_6_4_arp", 6, 4, imm, 4, FK33_ARP);
	sh("/nft flush ruleset");
}

/* ---------- diagnostic: why does the ingress chain not count ---------- */

static void f556_diag_nd(void)
{
	unsigned char fr[256];
	unsigned long long cnt;
	int flen, rc;

	flen = f556_frame(FK33_IP4, fr);
	sh("/nft flush ruleset");

	/* D1: ingress (NF_NETDEV_INGRESS = 0) on i1, frame sent from i0 */
	printf("F556 DN|table_i|%d\n", add_table(NFPROTO_NETDEV, "p33di"));
	rc = f556_add_chain(NFPROTO_NETDEV, "p33di", "ing", 0, 0, 1, "i1");
	printf("F556 DN|chain_ingress|%d\n", rc);
	nft("dn.list_ing", "/nft list chain netdev p33di ing");
	printf("F556 DN|ctl_ing|%d\n",
	       install_ctl(NFPROTO_NETDEV, "p33di", "ing", 5, "dn.ing"));
	nfl_drain(NFL33);
	usleep(20000);
	pkt_send_p("i0", fr, flen, 0x0800);
	cnt = f555_count(NFPROTO_NETDEV, "p33di", "ing");
	printf("F556 DN|ctl_ingress_cnt|%llu\n", cnt);

	/* D2: egress (NF_NETDEV_EGRESS = 1) on i0, frame sent from i0 */
	sh("/nft flush ruleset");
	printf("F556 DN|table_e|%d\n", add_table(NFPROTO_NETDEV, "p33de"));
	rc = f556_add_chain(NFPROTO_NETDEV, "p33de", "egr", 1, 0, 1, "i0");
	printf("F556 DN|chain_egress|%d\n", rc);
	nft("dn.list_egr", "/nft list chain netdev p33de egr");
	printf("F556 DN|ctl_egr|%d\n",
	       install_ctl(NFPROTO_NETDEV, "p33de", "egr", 5, "dn.egr"));
	nfl_drain(NFL33);
	usleep(20000);
	pkt_send_p("i0", fr, flen, 0x0800);
	cnt = f555_count(NFPROTO_NETDEV, "p33de", "egr");
	printf("F556 DN|ctl_egress_cnt|%llu\n", cnt);

	/* D3: the same egress chain written by nft itself, for comparison */
	sh("/nft flush ruleset");
	nft("dn.table_nft", "/nft add table netdev p33df");
	nft("dn.chain_nft", "/nft add chain netdev p33df egr '{ type filter hook egress device i0 priority 0; }'");
	nft("dn.rule_nft", "/nft add rule netdev p33df egr 'counter accept'");
	usleep(20000);
	pkt_send_p("i0", fr, flen, 0x0800);
	nft("dn.after_egr", "/nft list chain netdev p33df egr");

	/* D4: and the ingress chain written by nft, as F31 did */
	sh("/nft flush ruleset");
	nft("dn.table_nft2", "/nft add table netdev p33dg");
	nft("dn.chain_nft2", "/nft add chain netdev p33dg ing '{ type filter hook ingress device i1 priority 0; }'");
	nft("dn.rule_nft2", "/nft add rule netdev p33dg ing 'counter accept'");
	usleep(20000);
	pkt_send_p("i0", fr, flen, 0x0800);
	nft("dn.after_ing", "/nft list chain netdev p33dg ing");
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int f556_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f556";
	const char *only = argc > 2 ? argv[2] : NULL;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F556 BEGIN|mode=%s|only=%s\n", mode, only ? only : "-");
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F556 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	if (!strcmp(mode, "f556bare")) {
		printf("F556 DONE\n");
		return 0;
	}
	if (!HAVE33_IP || !HAVE33_IP6 || !HAVE33_NETDEV || !HAVE33_BRIDGE ||
	    !HAVE33_ARP)
		printf("F556 WARN|missing_family|ip=%d|ip6=%d|nd=%d|br=%d|arp=%d\n",
		       HAVE33_IP, HAVE33_IP6, HAVE33_NETDEV, HAVE33_BRIDGE,
		       HAVE33_ARP);
	f556_env_setup();
	NFL33 = nfl_open(5);
	printf("F556 NFL|%d\n", NFL33);
	if (!strncmp(mode, "f556one:", 8)) {
		f556_sec(mode + 8);
		printf("F556 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f556nd")) {
		f556_diag_nd();
		printf("F556 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f556e")) {
		f556_sec("ip4");
		f556_sec_e();
		printf("F556 DONE\n");
		return 0;
	}
	f556_sec(only);
	if (!only)
		f556_sec_e();
	printf("F556 DONE\n");
	return 0;
}
/* differ557_add.c -- turn 557 / F35: is the ll boundary a property of the
 * WRITE or of the ENVELOPE?
 *
 * F33 measured the shape of nft_ll_write_ok() on ethernet frames and found a
 * boundary at 14 -- exactly the ethernet header length.  The guard is
 *
 *	static bool nft_ll_write_ok(pkt, int offset)
 *	{
 *		if (nft_in_ingress(pkt->state)) return true;
 *		return offset <= skb_network_offset(pkt->skb);
 *	}
 *
 * called as `nft_ll_write_ok(pkt, priv->len + priv->offset + offset)` where
 * `offset = skb_mac_header(skb) - skb->data - vlan_hlen`, and in 7.3
 * `skb_network_offset()` is `skb_network_header() - skb->data` (NOT relative
 * to the mac header -- that changed long ago and the guard's arithmetic
 * depends on it).  Substituting, the condition is
 *
 *	priv->offset + priv->len  <=  skb_network_header - skb_mac_header + vlan_hlen
 *
 * i.e. "the write ends at or before the network header", where the right
 * side is the length of the LINK HEADER OF THIS ENVELOPE, plus vlan_hlen.
 * On ethernet that is 14.  This differ asks what it is when the envelope is
 *
 *   VLAN    an 802.1Q frame whose tag the receive path pulled into skb
 *           metadata (skb_vlan_tag_present): vlan_hlen = 4 for stores at
 *           offset >= 16, and mac_header was advanced by 4 by
 *           skb_reorder_vlan_header().  The two do NOT cancel: the right
 *           side becomes 18 (prediction).
 *
 *   ipip    an L3 tunnel: ipip_tunnel_rcv() calls skb_reset_mac_header()
 *           right after iptunnel_pull_header(), so mac_header == data and
 *           the right side is 0 (prediction): EVERY ll store dies.
 *
 *   vxlan   an L2 tunnel: vxlan_set_mac() calls skb_reset_mac_header() and
 *           then eth_type_trans(), so the inner packet looks exactly like a
 *           received ethernet frame and the right side is 14 again
 *           (prediction).
 *
 * Sections
 *   A  the 40-cell grid of F33 on plain and VLAN frames, in the ip family
 *      (prerouting) and the bridge family (prerouting).  p4s is the SAME
 *      grid through the OLD (2 s ACK window) helper, as a calibration of the
 *      fast helper used everywhere else in this file.
 *   B  the verdict: chain policy drop, `@ll,... counter accept`.  On an
 *      untagged frame cell (12,1) is alive and (16,2) is dead; on a tagged
 *      frame the same two cells must swap (prediction).
 *   C  the tunnels: the same grid on the packet that comes OUT of an ipip
 *      device and out of a vxlan device, with the rule gated on `meta iif`
 *      so the OUTER packet is not counted.  The control arm (no store) is
 *      the proof that the inner packet really reaches the chain.
 *
 * Oracle per arm: the kernel's own counter, placed AFTER the store in the
 * same rule (cnt=1: the guard passed and the rest of the rule ran, cnt=0: the
 * store was refused and log/counter/verdict never ran).  NFLOG carries the
 * frame as it looks at the log point, so every alive cell also gets its bytes
 * against the control arm.
 */

#include <linux/if_tunnel.h>

/* ---------- fast nfnetlink: same batch, a 250 ms ACK window ----------
 *
 * nl_open() in differ555.c sets SO_RCVTIMEO to 2 s and batch_send() drains
 * ACKs until recv() times out, so every single-message transaction costs the
 * full 2 s (the F33 arm timings show ms=2009,2048,...).  This differ needs
 * ~200 arms per boot, so the wait is shortened to 250 ms and the number of
 * ACKs is PRINTED in every arm, which is what makes the speed-up auditable:
 * a transaction that was not acknowledged shows up as acks=0.
 */
static int f557_nl_open(int tmo_ms)
{
	struct sockaddr_nl sa;
	struct timeval tv;
	int fd;

	tv.tv_sec = tmo_ms / 1000;
	tv.tv_usec = (tmo_ms % 1000) * 1000;
	fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_NETFILTER);
	if (fd < 0)
		return -1;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -2;
	}
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return fd;
}

static int f557_batch(char *buf, int len, int *acks)
{
	char rbuf[8192];
	int fd, err = 0, n = 0;

	*acks = 0;
	fd = f557_nl_open(250);
	if (fd < 0)
		return -1;
	if (send(fd, buf, (size_t)len, 0) != len) {
		close(fd);
		return -2;
	}
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl);
		     h = NLMSG_NEXT(h, rl)) {
			if (h->nlmsg_type != NLMSG_ERROR)
				continue;
			{
				struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(h);

				n++;
				if (e->error && !err)
					err = e->error;
			}
		}
	}
	close(fd);
	*acks = n;
	return err;
}

static int f557_nft_one(char *msgbuf, int msglen, int *acks)
{
	char batch[8192];
	struct nlmsghdr *bn, *en;
	int off;

	bn = msg_start(batch, (int)sizeof(batch), NFNL_MSG_BATCH_BEGIN,
		       NLM_F_REQUEST, 0);
	((struct nfgenmsg *)NLMSG_DATA(bn))->res_id = htons(NFNL_SUBSYS_NFTABLES);
	off = (int)NLMSG_ALIGN(bn->nlmsg_len);
	memcpy(batch + off, msgbuf, (size_t)NLMSG_ALIGN(msglen));
	off += (int)NLMSG_ALIGN(msglen);
	en = msg_start(batch + off, (int)(sizeof(batch) - off),
		       NFNL_MSG_BATCH_END, NLM_F_REQUEST, 0);
	((struct nfgenmsg *)NLMSG_DATA(en))->res_id = htons(NFNL_SUBSYS_NFTABLES);
	off += (int)NLMSG_ALIGN(en->nlmsg_len);
	return f557_batch(batch, off, acks);
}

static int f557_flush(uint8_t fam, const char *table, const char *chain,
		      int *acks)
{
	struct nlmsghdr *nlh;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_DELRULE,
			NLM_F_REQUEST | NLM_F_ACK, fam);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, acks);
}

/* one rule: [meta iif == iif ][store <base>+off = imm][log][counter][accept]
 * iif == 0 means: no match, the rule sees every packet that reaches the
 * chain (this is how every non-tunnel arm runs). */
static int f557_install(uint8_t fam, const char *table, const char *chain,
			uint32_t iif, uint32_t base, uint32_t off, uint32_t len,
			const unsigned char *imm, int immlen, int do_store,
			int loggroup, const char *prefix, int *acks)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *e, *d, *cd;
	/* nft_meta_store_ifindex() writes the index with *dest = ifindex,
	 * i.e. NATIVE order -- comparing against htonl() never matches
	 * (measured: every gated arm was 0, including a gate on the device
	 * the frame demonstrably arrives on). */
	uint32_t iif_be = iif;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			fam);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (iif) {
		e = nest_start(nlh, NFTA_LIST_ELEM);
		put_str(nlh, NFTA_EXPR_NAME, "meta");
		d = nest_start(nlh, NFTA_EXPR_DATA);
		put_be32(nlh, NFTA_META_KEY, NFT_META_IIF);
		put_be32(nlh, NFTA_META_DREG, NFT_REG32_00);
		nest_end(nlh, d);
		nest_end(nlh, e);

		e = nest_start(nlh, NFTA_LIST_ELEM);
		put_str(nlh, NFTA_EXPR_NAME, "cmp");
		d = nest_start(nlh, NFTA_EXPR_DATA);
		put_be32(nlh, NFTA_CMP_SREG, NFT_REG32_00);
		put_be32(nlh, NFTA_CMP_OP, NFT_CMP_EQ);
		cd = nest_start(nlh, NFTA_CMP_DATA);
		attr_put(nlh, NFTA_DATA_VALUE, &iif_be, 4);
		nest_end(nlh, cd);
		nest_end(nlh, d);
		nest_end(nlh, e);
	}
	if (do_store) {
		imm_value(nlh, NFT_REG32_00, imm, immlen);
		e = nest_start(nlh, NFTA_LIST_ELEM);
		put_str(nlh, NFTA_EXPR_NAME, "payload");
		d = nest_start(nlh, NFTA_EXPR_DATA);
		put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00);
		put_be32(nlh, NFTA_PAYLOAD_BASE, base);
		put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
		put_be32(nlh, NFTA_PAYLOAD_LEN, len);
		put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
		put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
		nest_end(nlh, d);
		nest_end(nlh, e);
	}
	log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, acks);
}

/* ---------- frames ---------- */

enum { F557_PLAIN = 0, F557_VLAN, F557_IPIP, F557_VXLAN };

/* the plain ethernet + IPv4 + UDP frame, unchanged from F33 */
static int f557_mk_plain(unsigned char *out)
{
	return f556_frame(FK33_IP4, out);
}

/* the SAME datagram inside an 802.1Q frame: dst, src, 0x8100, TCI 0x0064,
 * inner ethertype 0x0800, then the identical IPv4 header and payload.  The
 * receive path will pull the 4 tag bytes into skb metadata, which is the
 * envelope this arm is about. */
static int f557_mk_vlan(unsigned char *out)
{
	unsigned char tmp[256];
	int n = f556_frame(FK33_IP4, tmp);

	memset(out, 0, 256);
	memcpy(out, M33_BC, 6);		/* dst */
	memcpy(out + 6, MAC_SRC, 6);		/* src */
	out[12] = 0x81; out[13] = 0x00;		/* 802.1Q */
	out[14] = 0x00; out[15] = 0x64;		/* TCI: prio 0, vlan 100 */
	out[16] = 0x08; out[17] = 0x00;		/* inner ethertype */
	memcpy(out + 18, tmp + 14, (size_t)(n - 14));
	return n + 4;
}

/* ethernet + IPv4(proto 4) + IPv4(proto 17) + UDP, outer dst = the guest's
 * own address on i1, so the frame is delivered locally and ipip_tunnel_rcv()
 * decapsulates it into the ipip device. */
static int f557_mk_ipip(unsigned char *out)
{
	unsigned char *oip = out + 14;
	unsigned char *iip = oip + 20;
	unsigned char *u = iip + 20;
	int tot = 20 + 20 + 8 + 18;
	unsigned short c;

	memset(out, 0, 512);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x08; out[13] = 0x00;
	oip[0] = 0x45;
	oip[2] = (unsigned char)(tot >> 8);
	oip[3] = (unsigned char)tot;
	oip[4] = 0x12; oip[5] = 0x35;
	oip[8] = 64; oip[9] = 4;
	oip[12] = 0x0a; oip[13] = 0x01; oip[14] = 0x00; oip[15] = 0x01;
	oip[16] = 0x0a; oip[17] = 0x09; oip[18] = 0x00; oip[19] = 0x07;
	c = f556_csum(oip, 20);
	oip[10] = (unsigned char)(c >> 8); oip[11] = (unsigned char)c;

	iip[0] = 0x45;
	iip[2] = 0; iip[3] = 20 + 8 + 18;
	iip[4] = 0x12; iip[5] = 0x36;
	iip[8] = 63; iip[9] = 17;
	iip[12] = 0x0a; iip[13] = 0x42; iip[14] = 0x01; iip[15] = 0x01;	/* 10.66.1.1 */
	iip[16] = 0x0a; iip[17] = 0x42; iip[18] = 0x01; iip[19] = 0x02;	/* 10.66.1.2 */
	c = f556_csum(iip, 20);
	iip[10] = (unsigned char)(c >> 8); iip[11] = (unsigned char)c;

	u[0] = 0x9c; u[1] = 0x41; u[2] = 0x13; u[3] = 0x89;
	u[4] = 0x00; u[5] = 26;
	memset(u + 8, 0x77, 18);
	return 14 + tot;
}

/* ethernet + IPv4(proto 17) + UDP:4789 + VXLAN(VNI 557) + ethernet +
 * IPv4(proto 17) + UDP.  The outer destination is the guest's address on i1,
 * the vxlan device is bound to it, and the inner frame is a completely
 * ordinary ethernet frame -- that is the L2 envelope. */
static int f557_mk_vxlan(unsigned char *out)
{
	unsigned char *oip = out + 14;
	unsigned char *u = oip + 20;
	unsigned char *vx = u + 8;
	unsigned char *ieh = vx + 8;
	unsigned char *iip = ieh + 14;
	unsigned char *iu = iip + 20;
	int udp_len = 8 + 8 + 14 + 20 + 8 + 18;
	int tot = 20 + udp_len;
	unsigned short c;

	memset(out, 0, 512);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x08; out[13] = 0x00;

	oip[0] = 0x45;
	oip[2] = (unsigned char)(tot >> 8);
	oip[3] = (unsigned char)tot;
	oip[4] = 0x12; oip[5] = 0x37;
	oip[8] = 64; oip[9] = 17;
	oip[12] = 0x0a; oip[13] = 0x01; oip[14] = 0x00; oip[15] = 0x01;
	oip[16] = 0x0a; oip[17] = 0x09; oip[18] = 0x00; oip[19] = 0x07;
	c = f556_csum(oip, 20);
	oip[10] = (unsigned char)(c >> 8); oip[11] = (unsigned char)c;

	u[0] = 0x9c; u[1] = 0x42;			/* sport 40002 */
	u[2] = 0x12; u[3] = 0xb5;			/* dport 4789 */
	u[4] = (unsigned char)(udp_len >> 8);
	u[5] = (unsigned char)udp_len;
	u[6] = 0; u[7] = 0;				/* checksum 0: legal v4 */

	vx[0] = 0x08;					/* VNI valid */
	vx[4] = 0x00; vx[5] = 0x02; vx[6] = 0x2d;	/* VNI 557 */
	vx[7] = 0x00;

	memcpy(ieh, M33_BC, 6);
	memcpy(ieh + 6, MAC_SRC, 6);
	ieh[12] = 0x08; ieh[13] = 0x00;

	iip[0] = 0x45;
	iip[2] = 0; iip[3] = 20 + 8 + 18;
	iip[4] = 0x12; iip[5] = 0x38;
	iip[8] = 63; iip[9] = 17;
	iip[12] = 0x0a; iip[13] = 0x42; iip[14] = 0x02; iip[15] = 0x01;	/* 10.66.2.1 */
	iip[16] = 0x0a; iip[17] = 0x42; iip[18] = 0x02; iip[19] = 0x02;	/* 10.66.2.2 */
	c = f556_csum(iip, 20);
	iip[10] = (unsigned char)(c >> 8); iip[11] = (unsigned char)c;

	iu[0] = 0x9c; iu[1] = 0x43; iu[2] = 0x13; iu[3] = 0x8a;
	iu[4] = 0x00; iu[5] = 26;
	memset(iu + 8, 0x77, 18);
	return 14 + tot;
}

static int f557_frame(int kind, unsigned char *out)
{
	switch (kind) {
	case F557_PLAIN:
		return f557_mk_plain(out);
	case F557_VLAN:
		return f557_mk_vlan(out);
	case F557_IPIP:
		return f557_mk_ipip(out);
	case F557_VXLAN:
		return f557_mk_vxlan(out);
	}
	return 0;
}

static unsigned short f557_proto(int kind)
{
	return kind == F557_VLAN ? 0x8100 : 0x0800;
}

/* ---------- one envelope ---------- */

struct f557_env {
	const char *tag;
	uint8_t fam;
	const char *table;
	const char *chain;
	uint32_t hook;
	uint32_t base;
	const char *dev;
	const char *rule_dev;
	uint32_t iif;
	int kind;
	int policy;		/* 1 = accept, 0 = drop */
	int send_raw;		/* 0 = ethernet frame, 4 = ipip outer,
				 * 17 = vxlan outer, both via a raw socket */
};

static int NFL57 = -1;
static char PRE57[96];
static int f557_raw_send(int proto, const unsigned char *payload, int plen);
static int f557_inner_only(unsigned char *out);
static int f557_vxlan_payload(unsigned char *out);

static void f557_imm(int off, int len, unsigned char *imm)
{
	int i;

	memset(imm, 0, 16);
	for (i = 0; i < len && i < 16; i++)
		imm[i] = (unsigned char)(0x90 + i);
}

static unsigned long long f557_ctl(const struct f557_env *e, const char *tag,
				   int fast)
{
	unsigned char fr[512], pay[192];
	unsigned long long cnt, cnt0;
	int flen, n = 0, rc, acks = -1, i;

	flen = f557_frame(e->kind, fr);
	snprintf(PRE57, sizeof(PRE57), "f57.%s.%s", e->tag, tag);
	if (fast) {
		f557_flush(e->fam, e->table, e->chain, &acks);
		rc = f557_install(e->fam, e->table, e->chain, e->iif, 0, 0, 0,
				  NULL, 0, 0, 5, PRE57, &acks);
	} else {
		flush_chain(e->fam, e->table, e->chain);
		rc = install_ctl(e->fam, e->table, e->chain, 5, PRE57);
	}
	nfl_drain(NFL57);
	cnt0 = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	if (rc == 0) {
		usleep(15000);
		if (e->send_raw) {
			unsigned char inner[512];
			int il = e->send_raw == 17 ? f557_vxlan_payload(inner)
						   : f557_inner_only(inner);

			f557_raw_send(e->send_raw, inner, il);
		} else {
			pkt_send_p(e->dev, fr, flen, f557_proto(e->kind));
		}
		n = nfl_wait(NFL57, PRE57, pay, (int)sizeof(pay), 300);
	}
	cnt = f555_count(e->fam, e->table, e->chain);
	printf("F557 CTL|env=%s|kind=%d|fast=%d|rc=%d|acks=%d|cnt=%llu|cnt0=%llu|nfl=%d|hex=",
	       e->tag, e->kind, fast, rc, acks, cnt, cnt0, n);
	for (i = 0; i < n && i < 96; i++)
		printf("%02x", pay[i]);
	printf("\n");
	return cnt;
}

static unsigned long long f557_arm(const struct f557_env *e, const char *tag,
				   int off, int len, const unsigned char *imm,
				   int immlen, int fast)
{
	unsigned char fr[512], pay[192];
	unsigned long long cnt, cnt0;
	int flen, n = 0, rc, acks = -1, i;
	long t0, t1;

	flen = f557_frame(e->kind, fr);
	snprintf(PRE57, sizeof(PRE57), "f57.%s.%s", e->tag, tag);
	t0 = f33_ms();
	if (fast) {
		f557_flush(e->fam, e->table, e->chain, &acks);
		rc = f557_install(e->fam, e->table, e->chain, e->iif, e->base,
				  (uint32_t)off, (uint32_t)len, imm, immlen, 1,
				  5, PRE57, &acks);
	} else {
		flush_chain(e->fam, e->table, e->chain);
		rc = f556_install_store(e->fam, e->table, e->chain, e->base, off,
					len, imm, immlen, 5, PRE57);
	}
	t1 = f33_ms();
	nfl_drain(NFL57);
	cnt0 = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	if (rc == 0) {
		usleep(15000);
		if (e->send_raw) {
			unsigned char inner[512];
			int il = e->send_raw == 17 ? f557_vxlan_payload(inner)
						   : f557_inner_only(inner);

			f557_raw_send(e->send_raw, inner, il);
		} else {
			pkt_send_p(e->dev, fr, flen, f557_proto(e->kind));
		}
		n = nfl_wait(NFL57, PRE57, pay, (int)sizeof(pay), 200);
	}
	cnt = f555_count(e->fam, e->table, e->chain);
	printf("F557 R|env=%s|arm=%s|off=%d|len=%d|kind=%d|fast=%d|rc=%d|acks=%d|"
	       "cnt=%llu|cnt0=%llu|nfl=%d|ms=%ld|hex=",
	       e->tag, tag, off, len, e->kind, fast, rc, acks, cnt, cnt0, n,
	       t1 - t0);
	for (i = 0; i < n && i < 96; i++)
		printf("%02x", pay[i]);
	printf("\n");
	return cnt;
}

/* create table + one chain */
static int f557_chain(const struct f557_env *e)
{
	int rc, rc2;

	rc = add_table(e->fam, e->table);
	rc2 = f556_add_chain(e->fam, e->table, e->chain, e->hook, 0,
			     (uint32_t)e->policy, e->rule_dev);
	printf("F557 CHAIN|env=%s|table=%d|chain=%d|policy=%d\n", e->tag, rc, rc2,
	       e->policy);
	return rc || rc2;
}

static const int G57_OFF[12] = { 0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24 };
static const int G57_LEN[3] = { 1, 2, 4 };
static const int T57_OFF[7] = { 0, 6, 10, 12, 14, 16, 20 };

static void f557_grid(const struct f557_env *e, const int *offs, int noff,
		      const int *lens, int nlen, int fast)
{
	unsigned char imm[16];
	char tag[32];
	int i, j;

	for (i = 0; i < noff; i++) {
		for (j = 0; j < nlen; j++) {
			f557_imm(offs[i], lens[j], imm);
			snprintf(tag, sizeof(tag), "g%d_%d", offs[i], lens[j]);
			f557_arm(e, tag, offs[i], lens[j], imm, lens[j], fast);
		}
	}
}


/* ---------- A: plain vs VLAN, in the ip family and in the bridge ---------- */

static void f557_sec_grid(const char *only)
{
	struct f557_env e;
	struct f556_env e33;
	unsigned char imm[16];
	char tag[32];
	int i, j;

	/* p4s: the F33 cell-for-cell reference, through the OLD helper
	 * (2 s ACK window), plain ethernet frame, ip family prerouting.
	 * Whatever the fast helper says in p4 has to match this. */
	if (!only || !strcmp(only, "p4s")) {
		memset(&e33, 0, sizeof(e33));
		e33.tag = "p4s"; e33.fam = NFPROTO_IPV4; e33.table = "p57s";
		e33.chain = "pre"; e33.hook = 0;
		e33.base = NFT_PAYLOAD_LL_HEADER; e33.dev = "i0";
		e33.kind = FK33_IP4;
		if (!f556_chain(&e33)) {
			f556_ctl(&e33, FK33_IP4);
			for (i = 0; i < 12; i++) {
				for (j = 0; j < 3; j++) {
					f556_imm(FK33_IP4, G57_OFF[i],
						 G57_LEN[j], imm);
					snprintf(tag, sizeof(tag), "g%d_%d",
						 G57_OFF[i], G57_LEN[j]);
					f556_arm(&e33, tag, G57_OFF[i],
						 G57_LEN[j], imm, G57_LEN[j],
						 FK33_IP4);
				}
			}
			sh("/nft flush ruleset");
		}
	}
	/* p4: the same grid, same envelope, FAST helper */
	if (!only || !strcmp(only, "p4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "p4"; e.fam = NFPROTO_IPV4; e.table = "p57a";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_PLAIN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			f557_grid(&e, G57_OFF, 12, G57_LEN, 3, 1);
		}
	}
	/* v4: 802.1Q frame, same family, same hook, same grid */
	if (!only || !strcmp(only, "v4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "v4"; e.fam = NFPROTO_IPV4; e.table = "p57b";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			f557_grid(&e, G57_OFF, 12, G57_LEN, 3, 1);
		}
	}
	/* pB: plain frame at the bridge prerouting hook -- NFLOG here logs
	 * the L2 frame, so this envelope carries the BYTE evidence */
	if (!only || !strcmp(only, "pB")) {
		memset(&e, 0, sizeof(e));
		e.tag = "pB"; e.fam = NFPROTO_BRIDGE; e.table = "p57c";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0";
		e.kind = F557_PLAIN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			f557_grid(&e, G57_OFF, 12, G57_LEN, 3, 1);
		}
	}
	/* vB: the same, tagged */
	if (!only || !strcmp(only, "vB")) {
		memset(&e, 0, sizeof(e));
		e.tag = "vB"; e.fam = NFPROTO_BRIDGE; e.table = "p57d";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			f557_grid(&e, G57_OFF, 12, G57_LEN, 3, 1);
		}
	}
}

/* ---------- B: the verdict, under policy drop ---------- */

/* Chain policy is DROP and the rule ends in accept, so the kernel's counter
 * answers two questions at once: did the guard pass the store (cnt=1), and
 * did the packet get accepted (cnt=1 for the same reason).  The control arm
 * has the same rule with no store and must be 1 on both frames -- otherwise
 * "cnt=0" would not distinguish "the store was refused" from "the frame never
 * reached this chain". */
static void f557_sec_verdict(const char *only)
{
	static const struct {
		const char *tag;
		int off, len;
		unsigned char v[2];
	} arms[] = {
		{ "b12_1", 12, 1, { 0x90, 0x00 } },
		{ "b14_2", 14, 2, { 0x00, 0x64 } },
		{ "b16_2", 16, 2, { 0x08, 0x06 } },
	};
	struct f557_env e;
	unsigned char imm[16];
	unsigned int k;

	if (!only || !strcmp(only, "verdict")) {
		/* plain frame */
		memset(&e, 0, sizeof(e));
		e.tag = "vp"; e.fam = NFPROTO_IPV4; e.table = "p57e";
		e.chain = "pre"; e.hook = 0; e.policy = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_PLAIN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			for (k = 0; k < 3; k++) {
				memset(imm, 0, sizeof(imm));
				memcpy(imm, arms[k].v, 2);
				f557_arm(&e, arms[k].tag, arms[k].off,
					 arms[k].len, imm, arms[k].len, 1);
			}
		}
		/* tagged frame, same three arms */
		memset(&e, 0, sizeof(e));
		e.tag = "vv"; e.fam = NFPROTO_IPV4; e.table = "p57f";
		e.chain = "pre"; e.hook = 0; e.policy = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			for (k = 0; k < 3; k++) {
				memset(imm, 0, sizeof(imm));
				memcpy(imm, arms[k].v, 2);
				f557_arm(&e, arms[k].tag, arms[k].off,
					 arms[k].len, imm, arms[k].len, 1);
			}
		}
		/* the same three arms in the BRIDGE family, where the tagged
		 * frame demonstrably arrives (T557 has no CONFIG_VLAN_8021Q,
		 * so the ip family never sees it: measured, see DIAG9) */
		memset(&e, 0, sizeof(e));
		e.tag = "bp"; e.fam = NFPROTO_BRIDGE; e.table = "p57g";
		e.chain = "pre"; e.hook = 0; e.policy = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0";
		e.kind = F557_PLAIN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			for (k = 0; k < 3; k++) {
				memset(imm, 0, sizeof(imm));
				memcpy(imm, arms[k].v, 2);
				f557_arm(&e, arms[k].tag, arms[k].off,
					 arms[k].len, imm, arms[k].len, 1);
			}
		}
		memset(&e, 0, sizeof(e));
		e.tag = "bv"; e.fam = NFPROTO_BRIDGE; e.table = "p57i";
		e.chain = "pre"; e.hook = 0; e.policy = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			for (k = 0; k < 3; k++) {
				memset(imm, 0, sizeof(imm));
				memcpy(imm, arms[k].v, 2);
				f557_arm(&e, arms[k].tag, arms[k].off,
					 arms[k].len, imm, arms[k].len, 1);
			}
		}
		sh("/nft flush ruleset");
	}
}

/* ---------- C: the tunnels ---------- */

static int f557_link_add_vxlan(const char *name, uint32_t vni,
			       uint32_t local_be, uint16_t port, uint8_t learn)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[512];
	} req;
	struct nlattr *li, *data;
	uint32_t v = vni;		/* IFLA_VXLAN_ID is read with nla_get_u32() */
	uint16_t p = htons(port);
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, name, (int)strlen(name) + 1);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, "vxlan", 6);
	data = nest_start(&req.nlh, IFLA_INFO_DATA);
	attr_put(&req.nlh, IFLA_VXLAN_ID, &v, 4);
	if (local_be)
		attr_put(&req.nlh, IFLA_VXLAN_LOCAL, &local_be, 4);
	if (port)
		attr_put(&req.nlh, IFLA_VXLAN_PORT, &p, 2);
	attr_put(&req.nlh, IFLA_VXLAN_LEARNING, &learn, 1);
	nest_end(&req.nlh, data);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static void f557_sec_tunnel(const char *only)
{
	struct f557_env e;
	int rc, idx;

	if (only && strcmp(only, "tunnel"))
		return;
	/* the outer datagram is addressed to the guest's own i1, so it is
	 * delivered locally and the tunnel device decapsulates it */
	f555_addr_add("i1", htonl(0x0a090007), 24);
	f555_addr_add("i0", htonl(0x0a010001), 24);

	/* ---- ipip: an L3 tunnel ----
	 * Not created here: ipip_init_net() already made the fallback device
	 * tunl0 in this netns (it is in /proc/net/dev before any code of
	 * this differ runs), with all-zero params, i.e. exactly the wildcard
	 * tunnel a decapsulation needs.  Creating a second one with the same
	 * params returns -EEXIST from ip_tunnel_newlink() -- measured, see
	 * the f557diag arms. */
	rc = set_up("tunl0");
	f555_addr_add("tunl0", htonl(0x0a420102), 32);	/* 10.66.1.2 */
	idx = f555_ifindex("tunl0");
	printf("F557 TUN|ipip|link=%d|ifindex=%d\n", rc, idx);
	memset(&e, 0, sizeof(e));
	e.tag = "ipip"; e.fam = NFPROTO_IPV4; e.table = "p57t";
	e.chain = "pre"; e.hook = 0; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
	e.iif = (uint32_t)idx; e.kind = F557_IPIP; e.send_raw = 4;
	if (!f557_chain(&e)) {
		unsigned long long c = f557_ctl(&e, "ctl", 1);

		printf("F557 TUNCTL|ipip|cnt=%llu\n", c);
		if (c)
			f557_grid(&e, T57_OFF, 7, G57_LEN, 3, 1);
	}

	/* ---- vxlan: an L2 tunnel ---- */
	rc = f557_link_add_vxlan("v557", 557, htonl(0x0a090007), 4789, 1);
	set_up("v557");
	f555_addr_add("v557", htonl(0x0a420202), 24);	/* 10.66.2.2 */
	idx = f555_ifindex("v557");
	printf("F557 TUN|vxlan|link=%d|ifindex=%d\n", rc, idx);
	memset(&e, 0, sizeof(e));
	e.tag = "vxlan"; e.fam = NFPROTO_IPV4; e.table = "p57u";
	e.chain = "pre"; e.hook = 0; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
	e.iif = (uint32_t)idx; e.kind = F557_VXLAN; e.send_raw = 17;
	if (!f557_chain(&e)) {
		unsigned long long c = f557_ctl(&e, "ctl", 1);

		printf("F557 TUNCTL|vxlan|cnt=%llu\n", c);
		if (c)
			f557_grid(&e, T57_OFF, 7, G57_LEN, 3, 1);
	}
	sh("/nft flush ruleset");
}


/* ---------- D: why a tunnel device does not come up ---------- */

static void f557_devlist(void)
{
	int fd = open("/proc/net/dev", O_RDONLY);
	char buf[2048];
	int n;

	if (fd < 0) {
		printf("F557 DEV|open_failed|%d\n", errno);
		return;
	}
	n = (int)read(fd, buf, sizeof(buf) - 1);
	close(fd);
	if (n <= 0) {
		printf("F557 DEV|read_failed|%d\n", n);
		return;
	}
	buf[n] = 0;
	{
		char *l = buf;
		char *nl;

		while ((nl = strchr(l, '\n')) != NULL) {
			*nl = 0;
			if (strchr(l, ':'))
				printf("F557 DEV|%s\n", l);
			l = nl + 1;
		}
	}
}

static void f557_diag(const char *only)
{
	int rc;

	(void)only;
	rc = f556_link_add_kind("t557", "ipip");
	printf("F557 DIAG|ipip_bare|%d|ifindex=%d\n", rc, f555_ifindex("t557"));
	f555_addr_add("i1", htonl(0x0a090007), 24);
	printf("F557 DIAG|tunl0_ifindex|%d|up=%d\n",
	       f555_ifindex("tunl0"), set_up("tunl0"));
	rc = f556_link_add_kind("p557", "ipip");
	printf("F557 DIAG|ipip_second_name|%d|ifindex=%d\n", rc,
	       f555_ifindex("p557"));
	rc = f556_link_add_kind("g557", "gretap");
	printf("F557 DIAG|gretap_bare|%d|ifindex=%d\n", rc, f555_ifindex("g557"));
	rc = f557_link_add_vxlan("x557", 557, 0, 0, 1);
	printf("F557 DIAG|vxlan_id_only|%d|ifindex=%d\n", rc, f555_ifindex("x557"));
	rc = f557_link_add_vxlan("y557", 557, htonl(0x0a090007), 4789, 1);
	printf("F557 DIAG|vxlan_full|%d|ifindex=%d\n", rc, f555_ifindex("y557"));
	f557_devlist();
}


/* ---------- E: does the tunnel decapsulate at all? ----------
 *
 * A chain at ip prerouting with NO meta-iif gate sees the outer packet and,
 * if the tunnel device decapsulated it, the inner packet too: cnt=2 means
 * decapsulation happened, cnt=1 means only the outer packet arrived.  The
 * /proc/net/dev counters of the tunnel device say the same thing from the
 * other side.
 */
static void f557_devline(const char *name)
{
	int fd = open("/proc/net/dev", O_RDONLY);
	char buf[4096];
	int n;

	if (fd < 0)
		return;
	n = (int)read(fd, buf, sizeof(buf) - 1);
	close(fd);
	if (n <= 0)
		return;
	buf[n] = 0;
	{
		char *l = buf;

		while (l && *l) {
			char *nl = strchr(l, '\n');
			char *colon;

			if (nl)
				*nl = 0;
			colon = strchr(l, ':');
			if (colon && strstr(l, name) == l + (colon - l) -
			    (int)strlen(name)) {
				printf("F557 DEVLINE|%s|%s\n", name, colon + 1);
				break;
			}
			l = nl ? nl + 1 : NULL;
		}
	}
}

static void f557_diag2(void)
{
	struct f557_env e;
	unsigned char fr[512];
	unsigned long long cnt;
	int flen;

	f555_addr_add("i1", htonl(0x0a090007), 24);
	f555_addr_add("i0", htonl(0x0a010001), 24);
	set_up("tunl0");
	f555_addr_add("tunl0", htonl(0x0a420102), 32);

	/* --- ipip --- */
	memset(&e, 0, sizeof(e));
	e.tag = "d2ip"; e.fam = NFPROTO_IPV4; e.table = "p57x";
	e.chain = "pre"; e.hook = 0; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.iif = 0;
	e.kind = F557_IPIP;
	if (!f557_chain(&e)) {
		f557_ctl(&e, "ctl", 1);
		cnt = f557_ctl(&e, "ctl2", 1);
		printf("F557 DIAG2|ipip|no_iif_gate|cnt=%llu\n", cnt);
	}
	f557_devline("tunl0");

	/* --- vxlan: the device must exist BEFORE the arm that measures --- */
	{
		int rc = f557_link_add_vxlan("v557", 557, htonl(0x0a090007),
					     4789, 1);

		set_up("v557");
		f555_addr_add("v557", htonl(0x0a420202), 24);
		printf("F557 DIAG2|vxlan_create|%d|ifindex=%d\n", rc,
		       f555_ifindex("v557"));
	}
	memset(&e, 0, sizeof(e));
	e.tag = "d2vx"; e.fam = NFPROTO_IPV4; e.table = "p57y";
	e.chain = "pre"; e.hook = 0; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.iif = 0;
	e.kind = F557_VXLAN;
	if (!f557_chain(&e)) {
		f557_ctl(&e, "ctl", 1);
		cnt = f557_ctl(&e, "ctl2", 1);
		printf("F557 DIAG2|vxlan|no_iif_gate|cnt=%llu\n", cnt);
	}
	f557_devline("v557");

	(void)flen; (void)fr;
}


/* ---------- F: where does the tunnel packet go? ---------- */

static void f557_sysline(const char *path)
{
	int fd = open(path, O_RDONLY);
	char buf[128];
	int n;

	if (fd < 0) {
		printf("F557 SYS|%s|open_failed|%d\n", path, errno);
		return;
	}
	n = (int)read(fd, buf, sizeof(buf) - 1);
	close(fd);
	if (n <= 0) {
		printf("F557 SYS|%s|read_failed\n", path);
		return;
	}
	buf[n] = 0;
	if (buf[n - 1] == '\n')
		buf[n - 1] = 0;
	printf("F557 SYS|%s|%s\n", path, buf);
}

static int f557_link_add_ipip(const char *name, uint32_t local_be,
			      uint32_t remote_be)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[256];
	} req;
	struct nlattr *li, *data;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, name, (int)strlen(name) + 1);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, "ipip", 5);
	data = nest_start(&req.nlh, IFLA_INFO_DATA);
	attr_put(&req.nlh, IFLA_IPTUN_LOCAL, &local_be, 4);
	attr_put(&req.nlh, IFLA_IPTUN_REMOTE, &remote_be, 4);
	nest_end(&req.nlh, data);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

/* counters at three hooks of the ip family, one frame, then the numbers */
static char TBL57[32];

static unsigned long long f557_hookcount(uint32_t hook, const char *tag)
{
	struct f557_env e;
	unsigned long long c;

	memset(&e, 0, sizeof(e));
	e.tag = tag; e.fam = NFPROTO_IPV4;
	snprintf(TBL57, sizeof(TBL57), "p57h%d", hook);
	e.table = TBL57;
	e.chain = "c"; e.hook = hook; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.iif = 0;
	e.kind = F557_IPIP;
	if (f557_chain(&e))
		return 0;
	f555_count(e.fam, e.table, e.chain);
	c = f557_ctl(&e, "c1", 1);
	return c;
}

static void f557_diag3(void)
{
	int rc1, rc2, rc3;
	unsigned char fr[512];
	int flen;

	rc1 = f555_addr_add("i1", htonl(0x0a090007), 24);
	rc2 = f555_addr_add("i0", htonl(0x0a010001), 24);
	rc3 = set_up("tunl0");
	printf("F557 DIAG3|addr_i1=%d|addr_i0=%d|tunl0_up=%d|tunl0_ifindex=%d\n",
	       rc1, rc2, rc3, f555_ifindex("tunl0"));
	f555_addr_add("tunl0", htonl(0x0a420102), 32);
	f557_sysline("/sys/class/net/tunl0/flags");

	printf("F557 DIAG3|prerouting_cnt=%llu\n", f557_hookcount(0, "p0"));
	printf("F557 DIAG3|local_in_cnt=%llu\n", f557_hookcount(1, "p1"));
	printf("F557 DIAG3|forward_cnt=%llu\n", f557_hookcount(2, "p2"));

	/* an explicit tunnel with named endpoints, if the fallback is the
	 * problem: same frame, the same three probes */
	rc1 = f557_link_add_ipip("t557", htonl(0x0a090007), htonl(0x0a010001));
	set_up("t557");
	f555_addr_add("t557", htonl(0x0a420102), 32);
	printf("F557 DIAG3|explicit_tunnel|link=%d|ifindex=%d\n", rc1,
	       f555_ifindex("t557"));
	f557_sysline("/sys/class/net/t557/flags");

	f557_sysline("/sys/class/net/i0/flags");
	f557_sysline("/sys/class/net/tunl0/operstate");
	f557_sysline("/sys/class/net/tunl0/type");
	if (f555_ifindex("t557") >= 0) {
		char path[64];
		int idx = f555_ifindex("t557");

		snprintf(path, sizeof(path), "/sys/class/net/t557/uevent");
		f557_sysline(path);
		printf("F557 DIAG3|t557_index=%d\n", idx);
	}
	f557_devlist();
	flen = f557_frame(F557_IPIP, fr);
	printf("F557 DIAG3|frame_len=%d\n", flen);
}


/* ---------- G: routing, rp_filter, and a plain frame as a control ---------- */

static void f557_syswrite(const char *path, const char *val)
{
	int fd = open(path, O_WRONLY);
	int rc = -1;

	if (fd >= 0) {
		rc = (int)write(fd, val, strlen(val));
		close(fd);
	}
	printf("F557 SYSW|%s|%s|rc=%d\n", path, val, rc);
}

static unsigned long long f557_hookcnt_kind(uint32_t hook, const char *tag,
					    int kind)
{
	struct f557_env e;
	char tbl[32];

	memset(&e, 0, sizeof(e));
	snprintf(tbl, sizeof(tbl), "p57k%d_%d", hook, kind);
	e.tag = tag; e.fam = NFPROTO_IPV4; e.table = tbl;
	e.chain = "c"; e.hook = hook; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.iif = 0;
	e.kind = kind;
	if (f557_chain(&e))
		return 0;
	f555_count(e.fam, e.table, e.chain);
	return f557_ctl(&e, "c1", 1);
}

static void f557_diag4(void)
{
	f555_addr_add("i1", htonl(0x0a090007), 24);
	f555_addr_add("i0", htonl(0x0a010001), 24);
	set_up("tunl0");
	f555_addr_add("tunl0", htonl(0x0a420102), 32);

	f557_sysline("/proc/sys/net/ipv4/conf/all/rp_filter");
	f557_sysline("/proc/sys/net/ipv4/conf/default/rp_filter");
	f557_sysline("/proc/sys/net/ipv4/conf/i1/rp_filter");
	f557_sysline("/proc/sys/net/ipv4/ip_forward");
	f557_sysline("/proc/sys/net/ipv4/conf/all/accept_local");

	/* control: an ordinary UDP frame to the same destination address */
	printf("F557 DIAG4|plain_local_in=%llu\n",
	       f557_hookcnt_kind(1, "gpl", F557_PLAIN));
	printf("F557 DIAG4|plain_prerouting=%llu\n",
	       f557_hookcnt_kind(0, "gpp", F557_PLAIN));

	/* ipip frame, before and after rp_filter is forced off */
	printf("F557 DIAG4|ipip_local_in_before=%llu\n",
	       f557_hookcnt_kind(1, "gil0", F557_IPIP));
	f557_syswrite("/proc/sys/net/ipv4/conf/all/rp_filter", "0");
	f557_syswrite("/proc/sys/net/ipv4/conf/default/rp_filter", "0");
	f557_syswrite("/proc/sys/net/ipv4/conf/i1/rp_filter", "0");
	printf("F557 DIAG4|ipip_local_in_after=%llu\n",
	       f557_hookcnt_kind(1, "gil1", F557_IPIP));
	printf("F557 DIAG4|ipip_prerouting=%llu\n",
	       f557_hookcnt_kind(0, "gip", F557_IPIP));
	f557_devline("tunl0");
}


/* ---------- H: is the address really there? ---------- */

static void f557_procgrep(const char *path, const char *needle)
{
	int fd = open(path, O_RDONLY);
	char *buf;
	int n, total = 0;

	buf = (char *)malloc(1 << 16);
	if (!buf)
		return;
	if (fd < 0) {
		free(buf);
		printf("F557 PROC|%s|open_failed|%d\n", path, errno);
		return;
	}
	while (total < (1 << 16) - 1) {
		n = (int)read(fd, buf + total, (1 << 16) - 1 - total);
		if (n <= 0)
			break;
		total += n;
	}
	close(fd);
	buf[total] = 0;
	{
		char *l = buf;

		while (l && *l) {
			char *nl = strchr(l, '\n');

			if (nl)
				*nl = 0;
			if (strstr(l, needle))
				printf("F557 PROC|%s|%s\n", path, l);
			l = nl ? nl + 1 : NULL;
		}
	}
	free(buf);
}

static void f557_diag5(void)
{
	int rc1 = f555_addr_add("i1", htonl(0x0a090007), 24);
	int rc2 = f555_addr_add("i0", htonl(0x0a010001), 24);

	printf("F557 DIAG5|addr_rc|i1=%d|i0=%d\n", rc1, rc2);
	f557_procgrep("/proc/net/fib_trie", "10.9.0");
	f557_procgrep("/proc/net/fib_trie", "10.1.0");
	f557_procgrep("/proc/net/route", "i1");
	f557_procgrep("/proc/net/fib_trie", "LOCAL");
}


/* ---------- I: WHY does the frame not arrive locally? ---------- */

static void f557_snmp(const char *tag)
{
	int fd = open("/proc/net/snmp", O_RDONLY);
	char buf[8192];
	int n;

	if (fd < 0)
		return;
	n = (int)read(fd, buf, sizeof(buf) - 1);
	close(fd);
	if (n <= 0)
		return;
	buf[n] = 0;
	{
		char *l = buf;
		int seen = 0;

		while (l && *l && seen < 2) {
			char *nl = strchr(l, '\n');

			if (nl)
				*nl = 0;
			if (!strncmp(l, "Ip:", 3)) {
				printf("F557 SNMP|%s|%s\n", tag, l);
				seen++;
			}
			l = nl ? nl + 1 : NULL;
		}
	}
}

static void f557_diag6(void)
{
	struct f557_env e;
	unsigned char fr[512];
	unsigned long long cnt;

	f555_addr_add("i1", htonl(0x0a090007), 24);
	f555_addr_add("i0", htonl(0x0a010001), 24);
	set_up("tunl0");

	/* local_in chain on a plain frame */
	printf("F557 DIAG6|plain_local_in=%llu\n",
	       f557_hookcnt_kind(1, "h0", F557_PLAIN));

	/* what does the stack say about the plain frame? */
	memset(&e, 0, sizeof(e));
	e.tag = "h1"; e.fam = NFPROTO_IPV4; e.table = "p57m"; e.chain = "c";
	e.hook = 0; e.policy = 1; e.base = NFT_PAYLOAD_LL_HEADER;
	e.dev = "i0"; e.kind = F557_PLAIN;
	if (!f557_chain(&e)) {
		f557_snmp("before");
		f557_ctl(&e, "c1", 1);
		f557_snmp("after_plain");
	}

	/* and the ipip frame */
	memset(&e, 0, sizeof(e));
	e.tag = "h2"; e.fam = NFPROTO_IPV4; e.table = "p57n"; e.chain = "c";
	e.hook = 0; e.policy = 1; e.base = NFT_PAYLOAD_LL_HEADER;
	e.dev = "i0"; e.kind = F557_IPIP;
	if (!f557_chain(&e)) {
		f557_ctl(&e, "c1", 1);
		f557_snmp("after_ipip");
	}
	(void)fr; (void)cnt;
}


/* ---------- J: inject the outer datagram with a raw socket ----------
 *
 * The hand-built ethernet frame reaches ip prerouting and then disappears
 * without incrementing a single IP counter (measured: IpInReceives +1,
 * InDelivers/ForwDatagrams/InAddrErrors all +0), so the outer datagram is
 * never handed to the tunnel's protocol handler.  A UDP/IP datagram the
 * kernel itself addresses to 10.9.0.7 IS delivered locally (loopback path),
 * so the same outer header -- protocol 4, source 10.1.0.1, destination
 * 10.9.0.7 -- is sent here with IP_HDRINCL and the kernel's own routing.
 * The INNER packet, which is the envelope this turn measures, is built by
 * iptunnel_pull_header()/netif_rx() either way.
 */
static int f557_raw_send(int proto, const unsigned char *payload, int plen)
{
	unsigned char pkt[512];
	unsigned char *ip = pkt;
	struct sockaddr_in dst;
	int s, hl = 20, tot = hl + plen, one = 1;
	unsigned short c;

	memset(pkt, 0, sizeof(pkt));
	ip[0] = 0x45;
	ip[2] = (unsigned char)(tot >> 8);
	ip[3] = (unsigned char)tot;
	ip[4] = 0x12; ip[5] = 0x39;
	ip[8] = 64;
	ip[9] = (unsigned char)proto;
	ip[12] = 0x0a; ip[13] = 0x01; ip[14] = 0x00; ip[15] = 0x01;
	ip[16] = 0x0a; ip[17] = 0x09; ip[18] = 0x00; ip[19] = 0x07;
	c = f556_csum(ip, hl);
	ip[10] = (unsigned char)(c >> 8); ip[11] = (unsigned char)c;
	memcpy(ip + hl, payload, (size_t)plen);

	s = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
	if (s < 0)
		return -errno;
	setsockopt(s, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));
	memset(&dst, 0, sizeof(dst));
	dst.sin_family = AF_INET;
	dst.sin_addr.s_addr = htonl(0x0a090007);
	if (sendto(s, pkt, (size_t)tot, 0, (struct sockaddr *)&dst,
		   sizeof(dst)) != tot) {
		int e = errno;

		close(s);
		return -e;
	}
	close(s);
	return 0;
}

/* the inner datagram of the ipip probe: IPv4 + UDP + payload, no ethernet */
static int f557_inner_only(unsigned char *out)
{
	unsigned char *iip = out;
	unsigned char *u = out + 20;
	unsigned short c;

	memset(out, 0, 128);
	iip[0] = 0x45;
	iip[2] = 0;
	iip[3] = 20 + 8 + 18;
	iip[4] = 0x12; iip[5] = 0x36;
	iip[8] = 63; iip[9] = 17;
	iip[12] = 0x0a; iip[13] = 0x42; iip[14] = 0x01; iip[15] = 0x01;
	iip[16] = 0x0a; iip[17] = 0x42; iip[18] = 0x01; iip[19] = 0x02;
	c = f556_csum(iip, 20);
	iip[10] = (unsigned char)(c >> 8); iip[11] = (unsigned char)c;
	u[0] = 0x9c; u[1] = 0x41; u[2] = 0x13; u[3] = 0x89;
	u[4] = 0x00; u[5] = 26;
	memset(u + 8, 0x77, 18);
	return 20 + 8 + 18;
}

/* UDP + VXLAN + inner ethernet frame, i.e. everything after the outer IPv4
 * header -- the outer header is built by f557_raw_send(17, ...) */
static int f557_vxlan_payload(unsigned char *out)
{
	unsigned char full[512];
	int n = f557_mk_vxlan(full);

	memcpy(out, full + 14 + 20, (size_t)(n - 34));
	return n - 34;
}

static void f557_diag7(void)
{
	struct f557_env e;
	unsigned char inner[128];
	unsigned long long cnt;
	int rc, n;

	f555_addr_add("i1", htonl(0x0a090007), 24);
	f555_addr_add("i0", htonl(0x0a010001), 24);
	set_up("tunl0");
	f555_addr_add("tunl0", htonl(0x0a420102), 32);

	n = f557_inner_only(inner);
	rc = f557_raw_send(4, inner, n);
	printf("F557 DIAG7|raw_send|rc=%d|len=%d\n", rc, n);

	/* prerouting, no gate: outer (if routed) + inner (if decapsulated) */
	printf("F557 DIAG7|prerouting_cnt=%llu\n",
	       f557_hookcnt_kind(0, "j0", F557_IPIP));
	rc = f557_raw_send(4, inner, n);
	printf("F557 DIAG7|raw_send2|rc=%d\n", rc);
	{
		struct f557_env e2;
		char tbl[32];

		memset(&e2, 0, sizeof(e2));
		snprintf(tbl, sizeof(tbl), "p57jp");
		e2.tag = "j1"; e2.fam = NFPROTO_IPV4; e2.table = tbl;
		e2.chain = "c"; e2.hook = 0; e2.policy = 1;
		e2.base = NFT_PAYLOAD_LL_HEADER; e2.dev = "i0"; e2.iif = 0;
		e2.kind = F557_IPIP;
		if (!f557_chain(&e2)) {
			cnt = f557_ctl(&e2, "c1", 1);
			printf("F557 DIAG7|with_own_send_cnt=%llu\n", cnt);
		}
	}
	f557_devline("tunl0");
	(void)e;
}


/* ---------- K: does the meta-iif gate work, and does the inner packet
 * reach ip prerouting at all? ---------- */

static unsigned long long f557_gate_ctl(uint32_t iif, int send_raw,
					const char *tag)
{
	struct f557_env e;
	char tbl[40];

	memset(&e, 0, sizeof(e));
	snprintf(tbl, sizeof(tbl), "p57g_%u_%d", iif, send_raw);
	e.tag = tag; e.fam = NFPROTO_IPV4; e.table = tbl; e.chain = "c";
	e.hook = 0; e.policy = 1; e.base = NFT_PAYLOAD_LL_HEADER;
	e.dev = "i0"; e.iif = iif; e.kind = F557_IPIP; e.send_raw = send_raw;
	if (f557_chain(&e))
		return 0;
	f555_count(e.fam, e.table, e.chain);
	return f557_ctl(&e, "c1", 1);
}

static void f557_diag8(void)
{
	int lo, tl, i1;

	f555_addr_add("i1", htonl(0x0a090007), 24);
	f555_addr_add("i0", htonl(0x0a010001), 24);
	set_up("tunl0");
	f555_addr_add("tunl0", htonl(0x0a420102), 32);
	lo = f555_ifindex("lo");
	tl = f555_ifindex("tunl0");
	i1 = f555_ifindex("i1");
	printf("F557 DIAG8|idx|lo=%d|tunl0=%d|i1=%d\n", lo, tl, i1);

	printf("F557 DIAG8|raw_nogate=%llu\n", f557_gate_ctl(0, 1, "k0"));
	printf("F557 DIAG8|raw_iif_lo=%llu\n", f557_gate_ctl((uint32_t)lo, 1, "k1"));
	printf("F557 DIAG8|raw_iif_tunl0=%llu\n", f557_gate_ctl((uint32_t)tl, 1, "k2"));
	printf("F557 DIAG8|raw_iif_i1=%llu\n", f557_gate_ctl((uint32_t)i1, 1, "k3"));
	printf("F557 DIAG8|frame_iif_lo=%llu\n", f557_gate_ctl((uint32_t)lo, 0, "k4"));
	/* the gate itself, on a packet whose path is known: the hand-built
	 * frame arrives on i1, so a gate on i1 must count it and a gate on
	 * tunl0 must not */
	printf("F557 DIAG8|frame_iif_tunl0=%llu\n", f557_gate_ctl((uint32_t)tl, 0, "k5"));
	printf("F557 DIAG8|frame_iif_i1=%llu\n", f557_gate_ctl((uint32_t)i1, 0, "k6"));
	f557_devline("tunl0");
}


/* ---------- L: where does the 802.1Q frame go? ---------- */

static unsigned long long f557_env_ctl(uint8_t fam, uint32_t hook,
				       const char *rule_dev, int kind,
				       const char *tag)
{
	struct f557_env e;
	char tbl[40];

	memset(&e, 0, sizeof(e));
	snprintf(tbl, sizeof(tbl), "p57q_%u_%d", hook, kind);
	e.tag = tag; e.fam = fam; e.table = tbl; e.chain = "c";
	e.hook = hook; e.policy = 1; e.base = NFT_PAYLOAD_LL_HEADER;
	e.dev = "i0"; e.rule_dev = rule_dev; e.kind = kind;
	if (f557_chain(&e))
		return 0;
	f555_count(e.fam, e.table, e.chain);
	return f557_ctl(&e, "c1", 1);
}

static void f557_diag9(void)
{
	int i1 = f555_ifindex("i1");

	printf("F557 DIAG9|idx_i1=%d\n", i1);
	f557_snmp("before_vlan");
	printf("F557 DIAG9|ip_pre_plain=%llu\n",
	       f557_env_ctl(NFPROTO_IPV4, 0, NULL, F557_PLAIN, "l0"));
	f557_snmp("after_plain");
	printf("F557 DIAG9|ip_pre_vlan=%llu\n",
	       f557_env_ctl(NFPROTO_IPV4, 0, NULL, F557_VLAN, "l1"));
	f557_snmp("after_vlan");
	printf("F557 DIAG9|nd_ing_vlan=%llu\n",
	       f557_env_ctl(NFPROTO_NETDEV, 0, "i1", F557_VLAN, "l2"));
	f557_snmp("after_nd_vlan");
}


/* ---------- M: does the sender's sll_protocol decide it? ---------- */

static unsigned long long f557_ctl_proto(int kind, unsigned short proto,
					 const char *tag)
{
	struct f557_env e;
	unsigned char fr[512], pay[192];
	unsigned long long cnt, cnt0;
	char tbl[40];
	int flen, n = 0, rc, acks = -1;

	flen = f557_frame(kind, fr);
	memset(&e, 0, sizeof(e));
	snprintf(tbl, sizeof(tbl), "p57r_%04x_%d", proto, kind);
	e.tag = tag; e.fam = NFPROTO_IPV4; e.table = tbl; e.chain = "c";
	e.hook = 0; e.policy = 1; e.base = NFT_PAYLOAD_LL_HEADER;
	e.dev = "i0"; e.kind = kind;
	if (f557_chain(&e))
		return 0;
	snprintf(PRE57, sizeof(PRE57), "f57.%s.ctl", tag);
	f557_flush(e.fam, e.table, e.chain, &acks);
	rc = f557_install(e.fam, e.table, e.chain, 0, 0, 0, 0, NULL, 0, 0, 5,
			  PRE57, &acks);
	nfl_drain(NFL57);
	cnt0 = (rc == 0) ? f555_count(e.fam, e.table, e.chain) : 0;
	if (rc == 0) {
		usleep(15000);
		pkt_send_p(e.dev, fr, flen, proto);
		n = nfl_wait(NFL57, PRE57, pay, (int)sizeof(pay), 300);
	}
	cnt = f555_count(e.fam, e.table, e.chain);
	printf("F557 R|env=%s|arm=ctl|off=0|len=0|kind=%d|fast=1|rc=%d|acks=%d|"
	       "cnt=%llu|cnt0=%llu|nfl=%d|ms=0|hex=", tag, kind, rc, acks, cnt,
	       cnt0, n);
	printf("\n");
	return cnt;
}

static void f557_diag10(void)
{
	printf("F557 DIAG10|vlan_sll_8100=%llu\n",
	       f557_ctl_proto(F557_VLAN, 0x8100, "m0"));
	printf("F557 DIAG10|vlan_sll_all=%llu\n",
	       f557_ctl_proto(F557_VLAN, 0x0003, "m1"));
	printf("F557 DIAG10|vlan_sll_0800=%llu\n",
	       f557_ctl_proto(F557_VLAN, 0x0800, "m2"));
	printf("F557 DIAG10|plain_sll_all=%llu\n",
	       f557_ctl_proto(F557_PLAIN, 0x0003, "m3"));
}


/* ---------- N: is the AF_PACKET tap what kills the tagged frame? ---------- */

static void f557_diag11(void)
{
	printf("F557 DIAG11|vlan_ip_pre_with_taps=%llu\n",
	       f557_ctl_proto(F557_VLAN, 0x8100, "n0"));
	/* the differ keeps AF_PACKET taps open on i0/i1/o1 for the byte
	 * evidence of other envelopes; every frame those sockets see is a
	 * CLONE, i.e. skb_shared().  Close them and repeat the same arm. */
	if (CAP_I0 >= 0) { close(CAP_I0); CAP_I0 = -1; }
	if (CAP_I1 >= 0) { close(CAP_I1); CAP_I1 = -1; }
	if (CAP_O1 >= 0) { close(CAP_O1); CAP_O1 = -1; }
	printf("F557 DIAG11|vlan_ip_pre_without_taps=%llu\n",
	       f557_ctl_proto(F557_VLAN, 0x8100, "n1"));
	printf("F557 DIAG11|plain_ip_pre_without_taps=%llu\n",
	       f557_ctl_proto(F557_PLAIN, 0x0800, "n2"));
}


/* ---------- O: the BYTES the accepted store leaves on the wire ----------
 *
 * The counter says the guard passed the store; it does not say what the store
 * wrote.  NFLOG at the bridge hook logs from the network header (the hex of
 * every arm starts with 45 00), so the L2 frame is captured on the other
 * bridge port instead: the frame arrives on s1 and leaves towards r1.
 */
static int f557_cap_first(const char *dev, unsigned char *buf, int max, int ms)
{
	int s = cap_open(dev);
	int n = -1, waited = 0;

	if (s < 0)
		return -1;
	/* cap_open() sets O_NONBLOCK, and veth delivers through NAPI, so the
	 * frame is not in the socket buffer when sendto() returns: poll. */
	while (waited < ms) {
		n = (int)recv(s, buf, (size_t)max, 0);
		if (n > 0)
			break;
		usleep(5000);
		waited += 5;
	}
	close(s);
	return n;
}

static void f557_sec_bytes(const char *only)
{
	struct f557_env e;
	unsigned char fr[512], cap[256];
	unsigned char imm[16];
	int flen, n, i;

	if (only && strcmp(only, "bytes"))
		return;
	memset(&e, 0, sizeof(e));
	e.tag = "by"; e.fam = NFPROTO_BRIDGE; e.table = "p57z";
	e.chain = "pre"; e.hook = 0; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0"; e.kind = F557_VLAN;
	flen = f557_frame(e.kind, fr);
	if (f557_chain(&e))
		return;

	printf("F557 BYTES|idx|s0=%d|s1=%d|r0=%d|r1=%d|br0=%d\n",
	       f555_ifindex("s0"), f555_ifindex("s1"), f555_ifindex("r0"),
	       f555_ifindex("r1"), f555_ifindex("br0"));
	/* control A: a PLAIN frame through the same bridge, no store at all */
	{
		int acks = -1;
		unsigned char frp[256];
		int flp = f557_frame(F557_PLAIN, frp);

		f557_flush(e.fam, e.table, e.chain, &acks);
		f557_install(e.fam, e.table, e.chain, 0, 0, 0, 0, NULL, 0, 0, 5,
			     "f57.by.ctlp", &acks);
		usleep(15000);
		n = f557_cap_first("r0", cap, (int)sizeof(cap), 400);
		pkt_send_p(e.dev, frp, flp, 0x0800);
		n = f557_cap_first("r0", cap, (int)sizeof(cap), 400);
		printf("F557 BYTES|ctl_plain|n=%d|hex=", n);
		for (i = 0; i < n && i < 40; i++)
			printf("%02x", cap[i]);
		printf("\n");
	}
	/* control: no store */
	{
		int acks = -1;

		f557_flush(e.fam, e.table, e.chain, &acks);
		f557_install(e.fam, e.table, e.chain, 0, 0, 0, 0, NULL, 0, 0, 5,
			     "f57.by.ctl", &acks);
		usleep(15000);
		n = f557_cap_first("r0", cap, (int)sizeof(cap), 400);	/* drain */
		pkt_send_p(e.dev, fr, flen, 0x8100);
		n = f557_cap_first("r0", cap, (int)sizeof(cap), 400);
		printf("F557 BYTES|ctl|n=%d|hex=", n);
		for (i = 0; i < n && i < 40; i++)
			printf("%02x", cap[i]);
		printf("\n");
	}
	/* the accepted store: off 16 len 2 = the inner ethertype, value 0x0806 */
	{
		int acks = -1;

		memset(imm, 0, sizeof(imm));
		imm[0] = 0x08;
		imm[1] = 0x06;
		f557_flush(e.fam, e.table, e.chain, &acks);
		f557_install(e.fam, e.table, e.chain, 0, NFT_PAYLOAD_LL_HEADER,
			     16, 2, imm, 2, 1, 5, "f57.by.s16", &acks);
		usleep(15000);
		n = f557_cap_first("r0", cap, (int)sizeof(cap), 400);
		pkt_send_p(e.dev, fr, flen, 0x8100);
		n = f557_cap_first("r0", cap, (int)sizeof(cap), 400);
		printf("F557 BYTES|s16_2|n=%d|hex=", n);
		for (i = 0; i < n && i < 40; i++)
			printf("%02x", cap[i]);
		printf("\n");
	}
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int f557_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f557";
	const char *only = argc > 2 ? argv[2] : NULL;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F557 BEGIN|mode=%s|only=%s\n", mode, only ? only : "-");
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F557 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F557 KERNEL|%s\n", "7.3.4-T557");
	f556_env_setup();
	NFL57 = nfl_open(5);
	printf("F557 NFL|%d\n", NFL57);
	if (!strcmp(mode, "f557diag11")) {
		f557_diag11();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag10")) {
		f557_diag10();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag9")) {
		f557_diag9();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag8")) {
		f557_diag8();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag7")) {
		f557_diag7();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag6")) {
		f557_diag6();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag5")) {
		f557_diag5();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag4")) {
		f557_diag4();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag3")) {
		f557_diag3();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag2")) {
		f557_diag2();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag")) {
		f557_diag(only);
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557grid")) {
		f557_sec_grid(NULL);
	} else if (!strcmp(mode, "f557verdict")) {
		f557_sec_verdict(NULL);
	} else if (!strcmp(mode, "f557tun")) {
		f557_sec_tunnel(NULL);
	} else if (!strcmp(mode, "f557bytes")) {
		f557_sec_bytes(NULL);
	} else if (!strncmp(mode, "f557one:", 8)) {
		f557_sec_grid(mode + 8);
	} else {
		f557_sec_grid(only);
		f557_sec_verdict(only);
		f557_sec_bytes(only);
		f557_sec_tunnel(only);
	}
	printf("F557 DONE\n");
	return 0;
}
/* differ558_add.c -- turn 558.
 *
 * Three debts that F35 left as readings, and one config line to pay for:
 *
 *  A. `why`  -- F35's far-side capture returned n=-1 on every arm but one, and
 *     the one frame it caught was an ICMPv6 report from the bridge.  The first
 *     smoke with this instrument found the reason and two instrument facts
 *     worth keeping: (1) matching on the payload instead of taking the first
 *     frame is enough to see our frame at r0 (PACKET_HOST) and at r1
 *     (PACKET_OUTGOING); (2) a veth pair advertises NETIF_F_HW_VLAN_CTAG_TX/RX
 *     (drivers/net/veth.c VETH_FEATURES), so validate_xmit_vlan() never puts
 *     the tag back into the frame: on a veth the 802.1Q tag travels as skb
 *     METADATA and the frame is 60 bytes on both taps.  "The bytes of the tag
 *     on the wire" therefore cannot be measured with AF_PACKET here at all --
 *     but the tag's EFFECT can, at the far side, because vid 0 is delivered to
 *     IPv4 and vid != 0 is marked PACKET_OTHERHOST and dropped.
 *
 *  B. `bytes` -- the store F35 could describe only from the source.  Four arms
 *     on one tagged frame through the bridge, each read twice (TX tap on r1,
 *     RX tap on r0) and once at the far side (IpInReceives):
 *       (16,2) = 0x0806  writes the frame buffer at data-2 = the ethertype
 *       (14,2) = 0x0099  assigns skb->vlan_tci raw: bit 0x1000 (PRESENT) is
 *                        gone, so the frame stops being tagged at all
 *       (14,2) = 0x1064  the same store keeping the PRESENT bit: vid 100
 *       (12,4) = 0x8100 0x0000  full tag through __vlan_hwaccel_put_tag()
 *
 *  C. `vlan` -- the ip family never sees a tagged frame on any image this
 *     project has booted, and F35 recorded that as a config line:
 *     `# CONFIG_VLAN_8021Q is not set`.  T558 is T557 + that symbol, so the
 *     same tagged frame can now arrive through a real vlan device.  Four
 *     envelopes in one boot: plain (p4), tagged without a vlan device (novd,
 *     measured on T557 and on T558), tagged through v1 (vd), and a
 *     priority-tagged frame with vid 0 (v0), which needs no device at all.
 *
 * Instrument note: /sys/class/net is NOT netns-aware here -- the guest mounts
 * sysfs as init and the reproducer unshares CLONE_NEWNET afterwards, so every
 * /sys/class/net/<dev> read is ENOENT while /proc/net/dev is correct.
 */

/* ---------- frames ---------- */

/* f557_mk_vlan() with the TCI as a parameter: vid 100 and vid 0 are then the
 * SAME frame with one 12-bit field different, which is the whole point of the
 * `v0` envelope. */
static int f558_mk_vlan_tci(unsigned char *out, unsigned short tci)
{
	unsigned char tmp[256];
	int n = f556_frame(FK33_IP4, tmp);

	memset(out, 0, 256);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x81; out[13] = 0x00;
	out[14] = (unsigned char)(tci >> 8);
	out[15] = (unsigned char)tci;
	out[16] = 0x08; out[17] = 0x00;
	memcpy(out + 18, tmp + 14, (size_t)(n - 14));
	return n + 4;
}

/* ---------- rtnetlink: a vlan device, and deletion ---------- */

static int f558_link_add_vlan(const char *name, const char *parent,
			      unsigned short vid)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[256];
	} req;
	struct nlattr *li, *data;
	uint32_t pidx = (uint32_t)f555_ifindex(parent);
	int fd, rc;

	if ((int)pidx < 0)
		return -10;
	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, name, (int)strlen(name) + 1);
	attr_put(&req.nlh, IFLA_LINK, &pidx, 4);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, "vlan", 5);
	data = nest_start(&req.nlh, IFLA_INFO_DATA);
	attr_put(&req.nlh, IFLA_VLAN_ID, &vid, 2);	/* u16, native order */
	nest_end(&req.nlh, data);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f558_link_del(const char *name)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[64];
	} req;
	int fd, rc, idx = f555_ifindex(name);

	if (idx < 0)
		return -10;
	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_DELLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	req.ifi.ifi_index = idx;
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

/* ---------- capture: match on the payload, not on being first ---------- */

/* F35's f557_cap_first() opened a fresh socket per arm and took whatever
 * arrived first; on every arm but one that was ICMPv6 noise from the bridge.
 * This one opens once, drains once, and looks for the 0x77 payload the
 * instrument's own datagram carries -- printing how many frames it skipped,
 * so "no frame" and "someone else's frame" cannot be confused. */
static int f558_cap_match(int s, unsigned char *buf, int max, int ms,
			  const unsigned char *needle, int nlen,
			  int *skipped, int *pkttype)
{
	struct timeval now0, now1;
	struct timeval tv;
	fd_set rfds;
	int r, i;

	*skipped = 0;
	*pkttype = -1;
	if (s < 0)
		return -1;
	gettimeofday(&now0, NULL);
	tv.tv_sec = 0;
	tv.tv_usec = ms * 1000;
	for (;;) {
		struct sockaddr_ll from;
		socklen_t fl = sizeof(from);

		FD_ZERO(&rfds);
		FD_SET(s, &rfds);
		if (select(s + 1, &rfds, NULL, NULL, &tv) <= 0)
			return -1;
		memset(&from, 0, sizeof(from));
		r = (int)recvfrom(s, buf, (size_t)max, 0,
				  (struct sockaddr *)&from, &fl);
		if (r <= 0)
			return -1;
		for (i = 0; i + nlen <= r; i++) {
			if (!memcmp(buf + i, needle, (size_t)nlen)) {
				*pkttype = (int)from.sll_pkttype;
				return r;
			}
		}
		(*skipped)++;
		gettimeofday(&now1, NULL);
		{
			long used = (now1.tv_sec - now0.tv_sec) * 1000 +
				    (now1.tv_usec - now0.tv_usec) / 1000;

			if (used >= ms)
				return -1;
			tv.tv_sec = 0;
			tv.tv_usec = (ms - used) * 1000;
		}
	}
}

static void f558_hex(const unsigned char *b, int n)
{
	int i;

	for (i = 0; i < n; i++)
		printf("%02x", b[i]);
}

/* diff of two frames, "index:ctl>got" */
static int f558_chg(char *out, size_t osz, const unsigned char *ctl, int clen,
		    const unsigned char *got, int glen)
{
	int i, n = 0;

	out[0] = 0;
	if (clen <= 0 || glen <= 0)
		return 0;
	for (i = 0; i < glen && i < clen; i++) {
		size_t at;

		if (got[i] == ctl[i])
			continue;
		n++;
		at = strlen(out);
		if (at < osz - 24)
			snprintf(out + at, osz - at, "%s%d:%02x>%02x",
				 n > 1 ? "," : "", i, ctl[i], got[i]);
	}
	if (glen != clen) {
		size_t at = strlen(out);

		if (at < osz - 24)
			snprintf(out + at, osz - at, "%slen:%d>%d",
				 n ? "," : "", clen, glen);
		n++;
	}
	return n;
}

/* IpInReceives of the whole netns.  This is the far side's own decision about
 * our frame: a tagged frame with vid != 0 is PACKET_OTHERHOST by the time
 * ip_rcv() runs and is dropped there, a tag with vid 0 (or no tag at all) is
 * received.  Nothing else in this guest speaks IPv4, so the delta is ours. */
static unsigned long long f558_ipin(void)
{
	FILE *f = fopen("/proc/net/snmp", "r");
	char line[1024];
	unsigned long long fw, ttl, in;

	if (!f)
		return 0;
	while (fgets(line, sizeof(line), f)) {
		if (strncmp(line, "Ip: ", 4))
			continue;
		if (strstr(line, "Forwarding"))
			continue;
		if (sscanf(line, "Ip: %llu %llu %llu", &fw, &ttl, &in) == 3) {
			fclose(f);
			return in;
		}
	}
	fclose(f);
	return 0;
}

/* one capture view: a socket, the control frame it saw, and its length */
struct f558_view {
	const char *tag;		/* "tx" or "rx" */
	int fd;
	unsigned char ctl[2048];
	int clen;
};

static void f558_view_report(const char *env, const char *arm,
			     struct f558_view *v, const unsigned char *cap,
			     int n, int skip, int pt)
{
	char chg[512];
	int k = 0;

	printf("F558 VIEW|env=%s|arm=%s|view=%s|n=%d|skip=%d|pt=%d|",
	       env, arm, v->tag, n, skip, pt);
	if (n > 0 && v->clen > 0) {
		k = f558_chg(chg, sizeof(chg), v->ctl, v->clen, cap, n);
		printf("nchg=%d|chg=%s|", k, chg[0] ? chg : "-");
	} else {
		printf("nchg=-|chg=-|");
	}
	printf("hex=");
	if (n > 0)
		f558_hex(cap, n > 96 ? 96 : n);
	printf("\n");
}

/* ---------- one arm: install, send, capture twice, count three ---------- */

/* off < 0 => control arm (no store at all).  Each view may be inactive. */
static unsigned long long f558_run(const struct f557_env *e, const char *tag,
				   int off, int len, const unsigned char *imm,
				   int immlen, const unsigned char *fr, int flen,
				   struct f558_view *tx, struct f558_view *rx)
{
	static const unsigned char magic[8] = { 0x77, 0x77, 0x77, 0x77,
						0x77, 0x77, 0x77, 0x77 };
	unsigned char cap[2048];
	unsigned char pay[192];
	unsigned long long cnt, cnt0, ip0, ip1;
	int rc, acks = -1, snd = 0, nfl = 0, i;

	snprintf(PRE57, sizeof(PRE57), "f57.%s.%s", e->tag, tag);
	f557_flush(e->fam, e->table, e->chain, &acks);
	if (off < 0)
		rc = f557_install(e->fam, e->table, e->chain, e->iif, 0, 0, 0,
				  NULL, 0, 0, 5, PRE57, &acks);
	else
		rc = f557_install(e->fam, e->table, e->chain, e->iif, e->base,
				  (uint32_t)off, (uint32_t)len, imm, immlen, 1,
				  5, PRE57, &acks);
	if (tx && tx->fd >= 0)
		cap_drain(tx->fd);
	if (rx && rx->fd >= 0)
		cap_drain(rx->fd);
	usleep(20000);
	nfl_drain(NFL57);
	cnt0 = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	ip0 = f558_ipin();
	if (rc == 0 && !e->send_raw) {
		usleep(15000);
		/* drain HERE, immediately before the send: the whole payload of
		 * every arm is identical, so a frame left over from the previous
		 * arm would be indistinguishable from this one and would be
		 * reported as this arm's bytes.  (A second base chain at the same
		 * hook, left over from an earlier section, is the other way the
		 * same mistake shows up: it rewrites every later frame.) */
		if (tx && tx->fd >= 0)
			cap_drain(tx->fd);
		if (rx && rx->fd >= 0)
			cap_drain(rx->fd);
		snd = pkt_send_p(e->dev, fr, flen, f557_proto(e->kind));
		if (tx && tx->fd >= 0) {
			int n, skip = 0, pt = -1;

			memset(cap, 0, sizeof(cap));
			n = f558_cap_match(tx->fd, cap, (int)sizeof(cap), 800,
					   magic, 8, &skip, &pt);
			f558_view_report(e->tag, tag, tx, cap, n, skip, pt);
			if (off < 0 && n > 0) {
				memcpy(tx->ctl, cap, (size_t)n);
				tx->clen = n;
			}
		}
		if (rx && rx->fd >= 0) {
			int n, skip = 0, pt = -1;

			memset(cap, 0, sizeof(cap));
			n = f558_cap_match(rx->fd, cap, (int)sizeof(cap), 500,
					   magic, 8, &skip, &pt);
			f558_view_report(e->tag, tag, rx, cap, n, skip, pt);
			if (off < 0 && n > 0) {
				memcpy(rx->ctl, cap, (size_t)n);
				rx->clen = n;
			}
		}
	}
	usleep(20000);
	ip1 = f558_ipin();
	cnt = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	/* the second witness: the rule's own log, read back by prefix.  It tells
	 * "our frame" from "some other frame crossed this chain", which the bare
	 * counter cannot: an ICMPv6 report through the bridge increments the
	 * same counter as our IPv4 datagram. */
	if (rc == 0 && !e->send_raw)
		nfl = nfl_wait(NFL57, PRE57, pay, (int)sizeof(pay), 250);
	printf("F558 RUN|env=%s|arm=%s|off=%d|len=%d|rc=%d|acks=%d|snd=%d|"
	       "cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|nfl=%d|nflhex=", e->tag,
	       tag, off, len, rc, acks, snd, cnt0, cnt, cnt - cnt0, ip1 - ip0,
	       nfl);
	for (i = 0; i < nfl && i < 24; i++)
		printf("%02x", pay[i]);
	printf("\n");
	return cnt - cnt0;
}

static unsigned long long f558_gframe(const struct f557_env *e,
				      const unsigned char *fr, int flen)
{
	static const int offs[12] = { 0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24 };
	static const int lens[3] = { 1, 2, 4 };
	unsigned char imm[16];
	char tag[32];
	int i, j;
	unsigned long long live = 0;

	for (i = 0; i < 12; i++) {
		for (j = 0; j < 3; j++) {
			f557_imm(offs[i], lens[j], imm);
			snprintf(tag, sizeof(tag), "g%d_%d", offs[i], lens[j]);
			if (f558_run(e, tag, offs[i], lens[j], imm, lens[j], fr,
				     flen, NULL, NULL))
				live++;
		}
	}
	printf("F558 GRID|env=%s|live=%llu|of=36\n", e->tag, live);
	return live;
}

/* ---------- A: why did the far side show nothing ---------- */

static void f558_sec_why(void)
{
	unsigned char fr[512], vl[512];
	int c0 = cap_open("r0"), c1 = cap_open("r1");
	int fl, n, pt = -1, rc, sk = 0;

	/* the two tagged-frame builders must agree: f557_mk_vlan() is the one
	 * F35 measured, f558_mk_vlan_tci() is the parameterised one. */
	fl = f557_frame(F557_VLAN, fr);
	n = f558_mk_vlan_tci(vl, 100);
	printf("F558 WHY|frame_same=%d|len557=%d|len558=%d\n",
	       n == fl && !memcmp(fr, vl, (size_t)fl), fl, n);
	printf("F558 WHY|cap_r0=%d|cap_r1=%d|s0=%d|s1=%d|r0=%d|r1=%d|br0=%d\n",
	       c0, c1, f555_ifindex("s0"), f555_ifindex("s1"),
	       f555_ifindex("r0"), f555_ifindex("r1"), f555_ifindex("br0"));
	/* sysfs is not netns-aware here; this is the evidence, not noise */
	f557_sysline("/sys/class/net/br0/flags");
	f557_devline("s1");
	f557_devline("r1");
	f557_devline("r0");

	/* no nft rules at all: does the bridge forward our frame? */
	sh("/nft flush ruleset");
	fl = f557_frame(F557_PLAIN, fr);
	if (c0 >= 0)
		cap_drain(c0);
	if (c1 >= 0)
		cap_drain(c1);
	usleep(20000);
	rc = pkt_send_p("s0", fr, fl, 0x0800);
	{
		unsigned char cap[2048];

		n = f558_cap_match(c0, cap, (int)sizeof(cap), 800,
				   (const unsigned char *)"\x77\x77\x77\x77\x77\x77\x77\x77",
				   8, &sk, &pt);
		printf("F558 WHY|plain|arm=rx_r0|send_rc=%d|flen=%d|n=%d|skip=%d|pt=%d|hex=",
		       rc, fl, n, sk, pt);
		if (n > 0)
			f558_hex(cap, n > 96 ? 96 : n);
		printf("\n");
		sk = 0;
		pt = -1;
		n = f558_cap_match(c1, cap, (int)sizeof(cap), 400,
				   (const unsigned char *)"\x77\x77\x77\x77\x77\x77\x77\x77",
				   8, &sk, &pt);
		printf("F558 WHY|plain|arm=tx_r1|n=%d|skip=%d|pt=%d|hex=", n, sk, pt);
		if (n > 0)
			f558_hex(cap, n > 96 ? 96 : n);
		printf("\n");
	}
	/* the same frame TAGGED, still with no rule: both views */
	fl = f558_mk_vlan_tci(fr, 100);
	if (c0 >= 0)
		cap_drain(c0);
	if (c1 >= 0)
		cap_drain(c1);
	usleep(20000);
	rc = pkt_send_p("s0", fr, fl, 0x8100);
	{
		unsigned char cap[2048], pl[512];
		int plen = f557_frame(F557_PLAIN, pl);
		char chg[512];

		n = f558_cap_match(c1, cap, (int)sizeof(cap), 800,
				   (const unsigned char *)"\x77\x77\x77\x77\x77\x77\x77\x77",
				   8, &sk, &pt);
		f558_chg(chg, sizeof(chg), pl, plen, cap, n);
		printf("F558 WHY|tagged|arm=tx_r1|send_rc=%d|flen=%d|n=%d|skip=%d|pt=%d|vs_plain=%s|hex=",
		       rc, fl, n, sk, pt, chg[0] ? chg : "-");
		if (n > 0)
			f558_hex(cap, n > 96 ? 96 : n);
		printf("\n");
		sk = 0;
		pt = -1;
		n = f558_cap_match(c0, cap, (int)sizeof(cap), 500,
				   (const unsigned char *)"\x77\x77\x77\x77\x77\x77\x77\x77",
				   8, &sk, &pt);
		f558_chg(chg, sizeof(chg), pl, plen, cap, n);
		printf("F558 WHY|tagged|arm=rx_r0|n=%d|skip=%d|pt=%d|vs_plain=%s|hex=",
		       n, sk, pt, chg[0] ? chg : "-");
		if (n > 0)
			f558_hex(cap, n > 96 ? 96 : n);
		printf("\n");
	}
	f557_devline("s1");
	f557_devline("r1");
	f557_devline("r0");

	/* How many frames does ONE send put through a bridge chain?  The bare
	 * counter cannot tell our frame from someone else's, so the witness is
	 * the rule's own log: read every message it produced, not the first. */
	{
		struct f557_env eb;
		unsigned long long c0, c1;
		unsigned char pay[192];
		int acks = -1, n, k = 0;

		memset(&eb, 0, sizeof(eb));
		eb.tag = "wy"; eb.fam = NFPROTO_BRIDGE; eb.table = "p58w";
		eb.chain = "pre"; eb.hook = 0; eb.policy = 1;
		eb.base = NFT_PAYLOAD_LL_HEADER; eb.dev = "s0";
		eb.kind = F557_PLAIN;
		if (!f557_chain(&eb)) {
			fl = f557_frame(F557_PLAIN, fr);
			snprintf(PRE57, sizeof(PRE57), "f57.wy.one");
			f557_flush(eb.fam, eb.table, eb.chain, &acks);
			f557_install(eb.fam, eb.table, eb.chain, 0, 0, 0, 0, NULL,
				     0, 0, 5, PRE57, &acks);
			nfl_drain(NFL57);
			usleep(20000);
			c0 = f555_count(eb.fam, eb.table, eb.chain);
			pkt_send_p(eb.dev, fr, fl, 0x0800);
			while (k < 8) {
				n = nfl_wait(NFL57, PRE57, pay, (int)sizeof(pay), 150);
				if (n <= 0)
					break;
				printf("F558 WHY|one_send|msg=%d|n=%d|hex=", k, n);
				f558_hex(pay, n > 24 ? 24 : n);
				printf("\n");
				k++;
			}
			c1 = f555_count(eb.fam, eb.table, eb.chain);
			printf("F558 WHY|one_send|cnt_delta=%llu|msgs=%d\n", c1 - c0, k);
		}
	}
	sh("/nft flush ruleset");
}

/* ---------- B: what an accepted store actually does ---------- */

static void f558_sec_bytes(void)
{
	static const struct {
		const char *tag;
		int off, len;
		unsigned char v[4];
	} arms[] = {
		{ "s16_2", 16, 2, { 0x08, 0x06 } },	/* ethertype in the buffer */
		{ "s14_99", 14, 2, { 0x00, 0x99 } },	/* vlan_tci = 153 */
		{ "s14_0", 14, 2, { 0x00, 0x00 } },	/* vlan_tci = 0 -> vid 0 */
		{ "s14_1064", 14, 2, { 0x10, 0x64 } },	/* vlan_tci = 100 */
		{ "s12_4z", 12, 4, { 0x81, 0x00, 0x00, 0x00 } }, /* put_tag vid 0 */
	};
	struct f557_env e;
	struct f558_view tx, rx;
	unsigned char fr[512];
	unsigned char imm[16];
	int fl, k;

	memset(&tx, 0, sizeof(tx));
	memset(&rx, 0, sizeof(rx));
	tx.tag = "tx";
	rx.tag = "rx";
	tx.fd = cap_open("r1");		/* the frame the driver is given */
	rx.fd = cap_open("r0");		/* the frame the next hop's stack sees */
	memset(&e, 0, sizeof(e));
	e.tag = "by"; e.fam = NFPROTO_BRIDGE; e.table = "p58z";
	e.chain = "pre"; e.hook = 0; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0"; e.kind = F557_VLAN;
	fl = f557_frame(e.kind, fr);
	if (f557_chain(&e))
		return;
	printf("F558 BY|tx_fd=%d|rx_fd=%d|flen=%d\n", tx.fd, rx.fd, fl);

	/* control: the tagged frame through the bridge, no store at all */
	f558_run(&e, "ctl", -1, 0, NULL, 0, fr, fl, &tx, &rx);
	/* the PLAIN frame through the same chain: no store at all (the far side
	 * receives it TWICE -- once forwarded to r0, once flooded up to the br0
	 * device -- so "ipin" needs this baseline), and then the very store the
	 * tagged arms test, which must be DEAD here: 16 + 2 > 14.  Same table,
	 * so each arm's own flush removes the previous rule; the views are
	 * copies so the tagged control is not overwritten. */
	{
		struct f558_view txp = tx, rxp = rx;
		unsigned char fp[512];
		int flp = f557_frame(F557_PLAIN, fp);

		txp.clen = 0;
		rxp.clen = 0;
		f558_run(&e, "ctl_plain", -1, 0, NULL, 0, fp, flp, &txp, &rxp);
		f558_run(&e, "s16_2_plain", 16, 2,
			 (const unsigned char *)"\x08\x06", 2, fp, flp,
			 &txp, &rxp);
	}
	for (k = 0; k < (int)(sizeof(arms) / sizeof(arms[0])); k++) {
		memset(imm, 0, sizeof(imm));
		memcpy(imm, arms[k].v, (size_t)arms[k].len);
		f558_run(&e, arms[k].tag, arms[k].off, arms[k].len, imm,
			 arms[k].len, fr, fl, &tx, &rx);
	}
	sh("/nft flush ruleset");
}

/* ---------- C: the ip family meets a tag ---------- */

static void f558_sec_vlan(const char *only)
{
	struct f557_env e;
	unsigned char fr[512], fr0[512];
	int fl = 0, fl0 = 0, rc, add_rc = -99;

	if (!only || !strcmp(only, "p4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "p4"; e.fam = NFPROTO_IPV4; e.table = "p58a";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_PLAIN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			f557_grid(&e, G57_OFF, 12, G57_LEN, 3, 1);
		}
	}
	if (!only || !strcmp(only, "novd")) {
		fl = f558_mk_vlan_tci(fr, 100);
		memset(&e, 0, sizeof(e));
		e.tag = "novd"; e.fam = NFPROTO_IPV4; e.table = "p58b";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e)) {
			f558_run(&e, "ctl", -1, 0, NULL, 0, fr, fl, NULL, NULL);
			f558_run(&e, "g12_2", 12, 2,
				 (const unsigned char *)"\x00\x64", 2, fr, fl,
				 NULL, NULL);
		}
	}
	/* the vlan device: on T557 this is -EOPNOTSUPP, which is itself the
	 * measurement of the config line F35 named. */
	if (!only || !strcmp(only, "vd") || !strcmp(only, "novd")) {
		add_rc = f558_link_add_vlan("v1", "i1", 100);
		if (add_rc == 0)
			set_up("v1");
		printf("F558 VLANDEV|add_rc=%d|idx=%d\n", add_rc,
		       f555_ifindex("v1"));
	}
	if (!only || !strcmp(only, "vd")) {
		if (add_rc != 0) {
			printf("F558 VLANDEV|vd_skipped|reason=no_vlan_device\n");
		} else {
			fl = f558_mk_vlan_tci(fr, 100);
			memset(&e, 0, sizeof(e));
			e.tag = "vd"; e.fam = NFPROTO_IPV4; e.table = "p58c";
			e.chain = "pre"; e.hook = 0; e.policy = 1;
			e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
			e.kind = F557_VLAN;
			if (!f557_chain(&e)) {
				f558_run(&e, "ctl", -1, 0, NULL, 0, fr, fl,
					 NULL, NULL);
				f558_gframe(&e, fr, fl);
			}
		}
	}
	if (!only || !strcmp(only, "vd")) {
		rc = f558_link_del("v1");
		printf("F558 VLANDEV|del_rc=%d|idx=%d\n", rc, f555_ifindex("v1"));
		fl = f558_mk_vlan_tci(fr, 100);
		memset(&e, 0, sizeof(e));
		e.tag = "novd2"; e.fam = NFPROTO_IPV4; e.table = "p58e";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e))
			f558_run(&e, "ctl", -1, 0, NULL, 0, fr, fl, NULL, NULL);
	}
	/* vid 0: a priority tag needs no vlan device at all */
	if (!only || !strcmp(only, "v0")) {
		fl0 = f558_mk_vlan_tci(fr0, 0);
		memset(&e, 0, sizeof(e));
		e.tag = "v0"; e.fam = NFPROTO_IPV4; e.table = "p58d";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e)) {
			f558_run(&e, "ctl", -1, 0, NULL, 0, fr0, fl0, NULL, NULL);
			f558_gframe(&e, fr0, fl0);
		}
	}
	sh("/nft flush ruleset");
}

/* ---------- D: the instrument's own pollution, measured on purpose -------- */

/* One send through a bridge chain with no match expression, run twice: with
 * IPv6 off on the devices (what every other section of this instrument runs
 * with) and with it back on.  The counter cannot tell our IPv4 datagram from
 * the kernel's own MLD/NS chatter, and the rule's log can: each message is
 * printed with its first bytes, so 0x45 is ours and 0x60 is not. */
static void f558_one_send(const char *tag)
{
	struct f557_env eb;
	unsigned long long c0, c1;
	unsigned char fr[512], pay[192];
	static const char *dv[] = { "r0", "s0", "s1", "r1", "br0", "i0", "i1" };
	char path[96];
	int acks = -1, n, k = 0, i, fl;

	memset(&eb, 0, sizeof(eb));
	eb.tag = "wy"; eb.fam = NFPROTO_BRIDGE; eb.table = "p58w";
	eb.chain = "pre"; eb.hook = 0; eb.policy = 1;
	eb.base = NFT_PAYLOAD_LL_HEADER; eb.dev = "s0";
	eb.kind = F557_PLAIN;
	if (f557_chain(&eb))
		return;
	fl = f557_frame(F557_PLAIN, fr);
	snprintf(PRE57, sizeof(PRE57), "f57.wy.%s", tag);
	f557_flush(eb.fam, eb.table, eb.chain, &acks);
	f557_install(eb.fam, eb.table, eb.chain, 0, 0, 0, 0, NULL, 0, 0, 5,
		     PRE57, &acks);
	nfl_drain(NFL57);
	usleep(30000);
	c0 = f555_count(eb.fam, eb.table, eb.chain);
	pkt_send_p(eb.dev, fr, fl, 0x0800);
	while (k < 8) {
		n = nfl_wait(NFL57, PRE57, pay, (int)sizeof(pay), 200);
		if (n <= 0)
			break;
		printf("F558 ONE|%s|msg=%d|n=%d|hex=", tag, k, n);
		f558_hex(pay, n > 24 ? 24 : n);
		printf("\n");
		k++;
	}
	c1 = f555_count(eb.fam, eb.table, eb.chain);
	printf("F558 ONE|%s|cnt_delta=%llu|msgs=%d\n", tag, c1 - c0, k);
	(void)dv;
	(void)path;
	(void)i;
}

static void f558_sec_ipv6(void)
{
	static const char *dv[] = { "r0", "s0", "s1", "r1", "br0" };
	char path[96];
	int i;

	f558_one_send("v6off");
	for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
		snprintf(path, sizeof(path),
			 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
		f555_sysctl(path, "0");
	}
	usleep(300000);
	f558_one_send("v6on1");
	usleep(300000);
	f558_one_send("v6on2");
	for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
		snprintf(path, sizeof(path),
			 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
		f555_sysctl(path, "1");
	}
	usleep(200000);
	f558_one_send("v6off2");
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int f558_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f558";
	const char *only = argc > 2 ? argv[2] : NULL;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F558 BEGIN|mode=%s|only=%s\n", mode, only ? only : "-");
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F558 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F558 KERNEL|%s\n", "7.3.4-T557/T558");
	f556_env_setup();
	/* The counter on an nft chain has no match expression: it counts any
	 * frame that crosses the chain.  The kernel's own IPv6 chatter (MLD/NS
	 * emitted out of r0 and s0, which arrive at their peers r1 and s1 --
	 * bridge ports) therefore lands in the same counter as our IPv4 frame:
	 * measured in `why`, one send produced one IPv4 log message and one
	 * IPv6 one, cnt_delta=2.  IPv6 is turned off on every device of this
	 * netns so that "one frame through the bridge" means one. */
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL57 = nfl_open(5);
	printf("F558 NFL|%d\n", NFL57);
	if (!strcmp(mode, "f558why")) {
		f558_sec_why();
	} else if (!strcmp(mode, "f558bytes")) {
		f558_sec_bytes();
	} else if (!strcmp(mode, "f558ipv6")) {
		f558_sec_ipv6();
	} else if (!strcmp(mode, "f558vlan")) {
		f558_sec_vlan(NULL);
	} else if (!strncmp(mode, "f558vlan:", 9)) {
		f558_sec_vlan(mode + 9);
	} else {
		f558_sec_why();
		f558_sec_bytes();
		f558_sec_vlan(only);
	}
	printf("F558 DONE\n");
	return 0;
}
/* differ559_add.c -- turn 559 / F37: the 802.1Q tag as BYTES.
 *
 * F36 ended with an honest instrument limit: on a veth the tag lives in skb
 * metadata, AF_PACKET taps the frame after skb_vlan_untag() on the way in and
 * after validate_xmit_vlan() on the way out, and veth advertises
 * NETIF_F_HW_VLAN_CTAG_TX so the core never puts the tag back -- so "the bytes
 * of the tag on the wire" could not be measured at all.
 *
 * The way out is not a new driver.  net/ethtool/ioctl.c:ethtool_set_features()
 * writes dev->wanted_features and calls __netdev_update_features(); it does not
 * need an ndo_set_features op.  So ONE BIT can be taken away from a veth from
 * userspace (ETHTOOL_SFEATURES, NETIF_F_HW_VLAN_CTAG_TX), and then
 * net/core/dev.c:validate_xmit_vlan() has to insert the tag into the frame
 * itself.  That single bit is the difference this turn measures.
 *
 * Two views per arm, and they are different instruments:
 *   wire -- AF_PACKET on r1, the port the bridge transmits on.  The tap runs in
 *           xmit_one(), i.e. AFTER validate_xmit_skb(): with the offload it is
 *           60 bytes and tagless, without it the tag is at 12..15.
 *   far  -- AF_PACKET on r0, the peer of r1.  That tap runs in
 *           __netif_receive_skb_core() AFTER skb_vlan_untag(), so it is
 *           untagged in BOTH cases -- but a frame whose ethertype byte was
 *           zeroed reaches it as bytes, and then it is not "the far side's
 *           verdict" any more, it is the frame.
 *
 * Sections
 *   feat   GFEATURES/SFEATURES on every device of the netns; the bit, and the
 *          two frames it decides.
 *   wire   the same eight arms in three feature states (on -> cleared ->
 *          restored), so the causal link is bit -> bytes -> bit.
 *   ih     F36's own debt: the transport-base store at the bridge, on a tagged
 *          and on a plain frame, proto 6 and proto 17, 36 cells each.
 *   chain  two chains at one hook: what `pre` writes into the frame decides
 *          whether `post`'s transport store is alive at all.
 */

#include <linux/sockios.h>	/* SIOCETHTOOL */

/* ---------- frames ---------- */

/* the tagged frame for ANY of the base kinds: the datagram is moved 4 bytes
 * down and the tag is written in front of it, so "tagged" and "plain" differ in
 * exactly those 4 bytes. */
static int f559_frame(int kind, int tagged, unsigned char *out)
{
	unsigned char tmp[512];
	int n = f556_frame(kind, tmp);

	if (!tagged) {
		memcpy(out, tmp, (size_t)n);
		return n;
	}
	memset(out, 0, 512);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x81; out[13] = 0x00;	/* 802.1Q */
	out[14] = 0x00; out[15] = 0x64;	/* prio 0, vid 100 */
	out[16] = 0x08; out[17] = 0x00;	/* inner ethertype */
	memcpy(out + 18, tmp + 14, (size_t)(n - 14));
	return n + 4;
}

/* ---------- ethtool: one bit ---------- */

#define F559_GFEATURES		0x0000003a	/* not 0x3b: that is SFEATURES here */
#define F559_SFEATURES		0x0000003b
#define F559_FWORDS		8
#define F559_TX_BIT		7	/* NETIF_F_HW_VLAN_CTAG_TX_BIT */
#define F559_RX_BIT		8	/* NETIF_F_HW_VLAN_CTAG_RX_BIT */

struct f559_fblk {
	unsigned int avail, want, act, never;
};

static int f559_gfeat(const char *dev, struct f559_fblk *blk, int max, int *nblk)
{
	struct {
		unsigned int cmd, size;
		struct f559_fblk b[F559_FWORDS];
	} c;
	struct ifreq ifr;
	int fd, rc, i;

	memset(&c, 0, sizeof(c));
	c.cmd = F559_GFEATURES;
	c.size = (unsigned int)max;	/* the kernel clamps and reports back */
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, IFNAMSIZ, "%s", dev);
	ifr.ifr_data = (char *)&c;
	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0)
		return -1;
	rc = ioctl(fd, SIOCETHTOOL, &ifr);
	close(fd);
	if (rc < 0)
		return -errno;
	*nblk = (int)c.size;
	for (i = 0; i < *nblk && i < max; i++)
		blk[i] = c.b[i];
	return 0;
}

static int f559_sfeat(const char *dev, int nblk, unsigned int valid0,
		      unsigned int req0)
{
	struct {
		unsigned int cmd, size;
		struct {
			unsigned int valid, req;
		} b[F559_FWORDS];
	} c;
	struct ifreq ifr;
	int fd, rc;

	memset(&c, 0, sizeof(c));
	c.cmd = F559_SFEATURES;
	c.size = (unsigned int)nblk;
	c.b[0].valid = valid0;
	c.b[0].req = req0;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, IFNAMSIZ, "%s", dev);
	ifr.ifr_data = (char *)&c;
	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0)
		return -1;
	rc = ioctl(fd, SIOCETHTOOL, &ifr);
	close(fd);
	return rc < 0 ? -errno : rc;	/* >= 0: an ETHTOOL_F_* mask, not errno */
}

static void f559_featline(const char *stage, const char *dev)
{
	struct f559_fblk b[F559_FWORDS];
	int n = 0, i, rc = f559_gfeat(dev, b, F559_FWORDS, &n);

	printf("F559 FEAT|stage=%s|dev=%s|rc=%d|nwords=%d", stage, dev, rc, n);
	if (rc == 0) {
		for (i = 0; i < n && i < F559_FWORDS; i++)
			printf("|avail%d=%08x|want%d=%08x|act%d=%08x", i,
			       b[i].avail, i, b[i].want, i, b[i].act);
		printf("|avail_tx=%d|act_tx=%d|act_rx=%d",
		       (int)((b[0].avail >> F559_TX_BIT) & 1),
		       (int)((b[0].act >> F559_TX_BIT) & 1),
		       (int)((b[0].act >> F559_RX_BIT) & 1));
	}
	printf("\n");
}

/* on: 1 = ask for the bit, 0 = ask it away.  Returns the raw ioctl result. */
static int f559_setoff(const char *stage, const char *dev, int on)
{
	struct f559_fblk b[F559_FWORDS];
	unsigned int bit = 1u << F559_TX_BIT;
	int n = 0, rc;

	if (f559_gfeat(dev, b, F559_FWORDS, &n) < 0 || n <= 0) {
		printf("F559 SET|stage=%s|dev=%s|no_gfeat\n", stage, dev);
		return -1;
	}
	rc = f559_sfeat(dev, n, bit, on ? bit : 0u);
	printf("F559 SET|stage=%s|dev=%s|valid=%08x|req=%08x|nwords=%d|rc=%d|"
	       "f_unsup=%d|f_wish=%d\n", stage, dev, bit, on ? bit : 0u, n, rc,
	       rc >= 0 ? (rc & 1) : -1, rc >= 0 ? (rc & 2) : -1);
	f559_featline(stage, dev);
	return rc;
}

/* ---------- one arm ---------- */

struct f559_env {
	const char *tag;
	const char *table;
	const char *chain;
	uint32_t base;
	int kind;
	int tagged;
};

struct f559_out {
	int rc, snd, acks;
	int wn, wpt, rn, rpt;
	unsigned long long cnt0, cnt, ipin;
	unsigned char w[2048], r[2048];
};

static int NFL59 = -1;
static const char *F559_STATE = "-";

static const char *f559_hexs(char *out, size_t osz, const unsigned char *b, int n)
{
	size_t at = 0;
	int i;

	out[0] = 0;
	for (i = 0; i < n && i < 96 && at + 3 < osz; i++)
		at += (size_t)snprintf(out + at, osz - at, "%02x", b[i]);
	return out;
}

static int f559_chain(const struct f559_env *e)
{
	int rc = add_table(NFPROTO_BRIDGE, e->table);
	int rc2 = f556_add_chain(NFPROTO_BRIDGE, e->table, e->chain, 0, 0, 1,
				 NULL);

	printf("F559 CHAIN|env=%s|table=%d|chain=%d\n", e->tag, rc, rc2);
	return rc || rc2;
}

/* the frame goes in from s0 (outside the bridge), the bridge floods it to r1
 * and up to br0; the two taps below are the two views. */
static void f559_send(const unsigned char *fr, int flen, int proto, int wfd,
		      int rfd, struct f559_out *o)
{
	static const unsigned char magic[8] = { 0x77, 0x77, 0x77, 0x77,
						0x77, 0x77, 0x77, 0x77 };
	int sk = 0;

	o->wpt = -1; o->rpt = -1;
	if (wfd >= 0)
		cap_drain(wfd);
	if (rfd >= 0)
		cap_drain(rfd);
	usleep(15000);
	if (wfd >= 0)
		cap_drain(wfd);
	if (rfd >= 0)
		cap_drain(rfd);
	memset(o->w, 0, sizeof(o->w));
	memset(o->r, 0, sizeof(o->r));
	o->snd = pkt_send_p("s0", fr, flen, (unsigned short)proto);
	o->wn = f558_cap_match(wfd, o->w, (int)sizeof(o->w), 700, magic, 8, &sk,
			       &o->wpt);
	sk = 0;
	o->rn = f558_cap_match(rfd, o->r, (int)sizeof(o->r), 400, magic, 8, &sk,
			       &o->rpt);
}

/* install one rule, send one frame, read both taps, print one line.
 * `base` (may be NULL) is the arm whose bytes are the diff baseline; *out, if
 * not NULL, receives this arm's capture so that a control arm can become the
 * next arm's baseline. */
static void f559_arm(const struct f559_env *e, const char *arm, int off, int len,
		     const unsigned char *imm, int do_store,
		     const struct f559_out *base, int wfd, int rfd,
		     struct f559_out *out)
{
	struct f559_out o;
	unsigned char fr[512];
	char cw[1024], cr[1024], hw[256], hr[256];
	int flen = f559_frame(e->kind, e->tagged, fr);
	int kw = 0, kr = 0;

	memset(&o, 0, sizeof(o));
	snprintf(PRE57, sizeof(PRE57), "f59.%s.%s", e->tag, arm);
	f557_flush(NFPROTO_BRIDGE, e->table, e->chain, &o.acks);
	o.rc = f557_install(NFPROTO_BRIDGE, e->table, e->chain, 0, e->base,
			    (uint32_t)off, (uint32_t)len, imm,
			    do_store ? len : 0, do_store, 5, PRE57, &o.acks);
	nfl_drain(NFL59);
	o.cnt0 = f555_count(NFPROTO_BRIDGE, e->table, e->chain);
	{
		unsigned long long ip0 = f558_ipin();

		f559_send(fr, flen, e->tagged ? 0x8100 : 0x0800, wfd, rfd, &o);
		usleep(20000);
		o.ipin = f558_ipin() - ip0;
	}
	o.cnt = f555_count(NFPROTO_BRIDGE, e->table, e->chain);
	if (base && o.wn > 0 && base->wn > 0)
		kw = f558_chg(cw, sizeof(cw), base->w, base->wn, o.w, o.wn);
	if (base && o.rn > 0 && base->rn > 0)
		kr = f558_chg(cr, sizeof(cr), base->r, base->rn, o.r, o.rn);
	printf("F559 R|state=%s|env=%s|arm=%s|tagged=%d|base=%u|off=%d|len=%d|"
	       "store=%d|rc=%d|acks=%d|snd=%d|cnt0=%llu|cnt=%llu|live=%llu|"
	       "ipin=%llu|wn=%d|wpt=%d|wchg=%d|wchgs=%s|whex=%s|"
	       "rn=%d|rpt=%d|rchg=%d|rchgs=%s|rhex=%s\n",
	       F559_STATE, e->tag, arm, e->tagged, e->base, off, len, do_store,
	       o.rc, o.acks, o.snd, o.cnt0, o.cnt, o.cnt - o.cnt0, o.ipin,
	       o.wn, o.wpt, kw, cw[0] ? cw : "-",
	       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn) : "-",
	       o.rn, o.rpt, kr, cr[0] ? cr : "-",
	       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn) : "-");
	if (out)
		memcpy(out, &o, sizeof(o));
}

/* ---------- probe: is the ioctl transport itself alive? ---------- */

static int f559_ioctl_raw(const char *dev, void *data)
{
	struct ifreq ifr;
	int fd, rc, e;

	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, IFNAMSIZ, "%s", dev);
	ifr.ifr_data = (char *)data;
	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0)
		return -1000;
	errno = 0;
	rc = ioctl(fd, SIOCETHTOOL, &ifr);
	e = errno;
	close(fd);
	return rc < 0 ? -e : rc;
}

static void f559_sec_probe(void)
{
	struct {
		unsigned int cmd, size;
		unsigned int b[8 * 4];
	} c;
	int rc;

	printf("F559 PROBE|sioc_ethtool=%08x|sizeof_ifreq=%d|sizeof_gfeat=%d|"
	       "sizeof_sfeat=%d\n", (unsigned int)SIOCETHTOOL,
	       (int)sizeof(struct ifreq), 8 + 16 * 3, 8 + 8 * 3);
	/* ETHTOOL_GSET = 0x1, GDRVINFO = 0x3, GLINK = 0xa */
	memset(&c, 0, sizeof(c));
	c.cmd = 0x00000001; c.size = 0;
	rc = f559_ioctl_raw("r1", &c);
	printf("F559 PROBE|gset=%d\n", rc);
	memset(&c, 0, sizeof(c));
	c.cmd = 0x0000000a;
	rc = f559_ioctl_raw("r1", &c);
	printf("F559 PROBE|glink=%d|link=%u\n", rc, c.size);
	memset(&c, 0, sizeof(c));
	c.cmd = F559_GFEATURES; c.size = 3;
	rc = f559_ioctl_raw("r1", &c);
	printf("F559 PROBE|gfeat3=%d|size=%u|avail0=%08x|act0=%08x\n", rc, c.size,
	       c.b[0], c.b[2]);
	memset(&c, 0, sizeof(c));
	c.cmd = F559_GFEATURES; c.size = 8;
	rc = f559_ioctl_raw("r1", &c);
	printf("F559 PROBE|gfeat8=%d|size=%u|avail0=%08x|act0=%08x\n", rc, c.size,
	       c.b[0], c.b[2]);
	memset(&c, 0, sizeof(c));
	c.cmd = F559_SFEATURES; c.size = 3;
	rc = f559_ioctl_raw("r1", &c);
	printf("F559 PROBE|sfeat_nop=%d\n", rc);
}

/* ---------- feat ---------- */

static void f559_sec_feat(void)
{
	static const char *dv[] = { "lo", "i0", "i1", "s0", "s1", "r0", "r1",
				    "br0" };
	int i;

	for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++)
		f559_featline("init", dv[i]);
	/* the causal chain, on the port the bridge transmits on */
	f559_setoff("clear", "r1", 0);
	f559_setoff("restore", "r1", 1);
}

/* ---------- wire: eight arms, three feature states ---------- */

static void f559_sec_wire(const char *state)
{
	static const struct {
		const char *tag;
		int off, len;
		unsigned char v[4];
	} arms[] = {
		{ "s16_2", 16, 2, { 0x08, 0x06 } },
		{ "s14_99", 14, 2, { 0x00, 0x99 } },
		{ "s14_0", 14, 2, { 0x00, 0x00 } },
		{ "s12_2z", 12, 2, { 0x00, 0x00 } },
		{ "s12_4z", 12, 4, { 0x81, 0x00, 0x00, 0x00 } },
	};
	struct f559_env et, ep;
	struct f559_out ct, cp, o;
	unsigned char imm[16];
	unsigned char fr[512];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int k;

	F559_STATE = state;
	memset(&et, 0, sizeof(et));
	et.tag = "wire"; et.table = "p59a"; et.chain = "pre";
	et.base = NFT_PAYLOAD_LL_HEADER; et.kind = FK33_IP4; et.tagged = 1;
	ep = et; ep.tagged = 0;
	if (f559_chain(&et))
		return;
	printf("F559 SECTION|wire|state=%s|wfd=%d|rfd=%d|flen_t=%d|flen_p=%d\n",
	       state, wfd, rfd, f559_frame(FK33_IP4, 1, fr),
	       f559_frame(FK33_IP4, 0, fr));
	memset(&ct, 0, sizeof(ct));
	f559_arm(&et, "ctl", 0, 0, NULL, 0, NULL, wfd, rfd, &ct);
	for (k = 0; k < (int)(sizeof(arms) / sizeof(arms[0])); k++) {
		memset(imm, 0, sizeof(imm));
		memcpy(imm, arms[k].v, (size_t)arms[k].len);
		f559_arm(&et, arms[k].tag, arms[k].off, arms[k].len, imm,
			 arms[k].len, &ct, wfd, rfd, &o);
	}
	/* the same store on a plain frame: 16+2 > 14, so it must be dead */
	memset(&cp, 0, sizeof(cp));
	f559_arm(&ep, "ctl_plain", 0, 0, NULL, 0, NULL, wfd, rfd, &cp);
	f559_arm(&ep, "s16_2_plain", 16, 2, (const unsigned char *)"\x08\x06",
		 2, &cp, wfd, rfd, &o);
	sh("/nft flush ruleset");
}

/* ---------- ih: transport base at the bridge, tagged and plain ---------- */

static void f559_sec_ih(void)
{
	static const int offs[12] = { 0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24 };
	static const int lens[3] = { 1, 2, 4 };
	static const struct {
		const char *tag;
		const char *table;
		int kind;
		int tagged;
	} combos[] = {
		{ "p6T", "p59b1", FK33_IP4_P6, 1 },
		{ "p6P", "p59b2", FK33_IP4_P6, 0 },
		{ "uT", "p59b3", FK33_IP4, 1 },
		{ "uP", "p59b4", FK33_IP4, 0 },
	};
	struct f559_env e;
	struct f559_out ctl, o;
	unsigned char imm[16], fr[512];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int c, i, j;

	F559_STATE = "clear";
	for (c = 0; c < (int)(sizeof(combos) / sizeof(combos[0])); c++) {
		memset(&e, 0, sizeof(e));
		e.tag = combos[c].tag;
		e.table = combos[c].table;
		e.chain = "pre";
		e.base = NFT_PAYLOAD_TRANSPORT_HEADER;
		e.kind = combos[c].kind;
		e.tagged = combos[c].tagged;
		if (f559_chain(&e))
			continue;
		printf("F559 SECTION|ih|combo=%s|wfd=%d|rfd=%d|flen=%d\n",
		       e.tag, wfd, rfd, f559_frame(e.kind, e.tagged, fr));
		memset(&ctl, 0, sizeof(ctl));
		f559_arm(&e, "ctl", 0, 0, NULL, 0, NULL, wfd, rfd, &ctl);
		for (i = 0; i < 12; i++) {
			for (j = 0; j < 3; j++) {
				char arm[32];

				f557_imm(offs[i], lens[j], imm);
				snprintf(arm, sizeof(arm), "g%d_%d", offs[i],
					 lens[j]);
				f559_arm(&e, arm, offs[i], lens[j], imm,
					 lens[j], &ctl, wfd, rfd, &o);
			}
		}
	}
	sh("/nft flush ruleset");
}

/* ---------- chain: the envelope is a property of the moment ---------- */

static void f559_two(const unsigned char *fr, int flen, const char *arm,
		     int pre_do, uint32_t pre_base, int pre_off, int pre_len,
		     const unsigned char *pre_imm, int wfd, int rfd,
		     const struct f559_out *base)
{
	unsigned char pimm[4] = { 0x1f, 0x90 };	/* the transport store */
	struct f559_out o;
	char cw[1024], cr[1024], hw[256], hr[256];
	int kw = 0, kr = 0;
	int acks = 0;	/* f557_nft_one() writes *acks unconditionally */

	memset(&o, 0, sizeof(o));
	f557_flush(NFPROTO_BRIDGE, "p59c", "pre", &acks);
	f557_flush(NFPROTO_BRIDGE, "p59c", "post", &acks);
	if (pre_do) {
		snprintf(PRE57, sizeof(PRE57), "f59.pre.%s", arm);
		f557_install(NFPROTO_BRIDGE, "p59c", "pre", 0, pre_base,
			     (uint32_t)pre_off, (uint32_t)pre_len, pre_imm,
			     pre_len, 1, 5, PRE57, &o.acks);
	}
	snprintf(PRE57, sizeof(PRE57), "f59.post.%s", arm);
	o.rc = f557_install(NFPROTO_BRIDGE, "p59c", "post", 0,
			    NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, pimm, 2, 1, 5,
			    PRE57, &o.acks);
	nfl_drain(NFL59);
	o.cnt0 = f555_count(NFPROTO_BRIDGE, "p59c", "post");
	{
		unsigned long long ip0 = f558_ipin();

		f559_send(fr, flen, 0x8100, wfd, rfd, &o);
		usleep(20000);
		o.ipin = f558_ipin() - ip0;
	}
	o.cnt = f555_count(NFPROTO_BRIDGE, "p59c", "post");
	if (base && o.wn > 0 && base->wn > 0)
		kw = f558_chg(cw, sizeof(cw), base->w, base->wn, o.w, o.wn);
	if (base && o.rn > 0 && base->rn > 0)
		kr = f558_chg(cr, sizeof(cr), base->r, base->rn, o.r, o.rn);
	printf("F559 C|state=%s|arm=%s|pre=%d|prebase=%u|preoff=%d|prelen=%d|"
	       "rc=%d|cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|"
	       "wn=%d|wchg=%d|wchgs=%s|whex=%s|rn=%d|rchg=%d|rchgs=%s|rhex=%s\n",
	       F559_STATE, arm, pre_do, pre_base, pre_off, pre_len, o.rc,
	       o.cnt0, o.cnt, o.cnt - o.cnt0, o.ipin, o.wn, kw,
	       cw[0] ? cw : "-",
	       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn) : "-", o.rn,
	       kr, cr[0] ? cr : "-",
	       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn) : "-");
}

static void f559_sec_chain(void)
{
	struct f559_out ctl;
	unsigned char fr[512];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int flen = f559_frame(FK33_IP4_P6, 1, fr);
	int rc, rc1, rc2;
	int acks = 0;

	F559_STATE = "clear";
	rc = add_table(NFPROTO_BRIDGE, "p59c");
	rc1 = f556_add_chain(NFPROTO_BRIDGE, "p59c", "pre", 0, 0, 1, NULL);
	rc2 = f556_add_chain(NFPROTO_BRIDGE, "p59c", "post", 0, 10, 1, NULL);
	printf("F559 SECTION|chain|table=%d|pre=%d|post=%d|flen=%d\n", rc, rc1,
	       rc2, flen);
	if (rc || rc1 || rc2)
		return;
	/* baseline: both chains empty, so the diffs below are the stores' own */
	memset(&ctl, 0, sizeof(ctl));
	f557_flush(NFPROTO_BRIDGE, "p59c", "pre", &acks);
	f557_flush(NFPROTO_BRIDGE, "p59c", "post", &acks);
	f559_send(fr, flen, 0x8100, wfd, rfd, &ctl);
	f559_two(fr, flen, "a_none", 0, 0, 0, 0, NULL, wfd, rfd, &ctl);
	f559_two(fr, flen, "b_et", 1, NFT_PAYLOAD_LL_HEADER, 16, 2,
		 (const unsigned char *)"\x08\x06", wfd, rfd, &ctl);
	f559_two(fr, flen, "c_tci", 1, NFT_PAYLOAD_LL_HEADER, 14, 2,
		 (const unsigned char *)"\x00\x99", wfd, rfd, &ctl);
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int f559_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f559";

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F559 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F559 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F559 KERNEL|%s\n", "7.3.4-T558");
	f556_env_setup();
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL59 = nfl_open(5);
	printf("F559 NFL|%d\n", NFL59);
	if (!strcmp(mode, "f559probe")) {
		f559_sec_probe();
	} else if (!strcmp(mode, "f559feat")) {
		f559_sec_feat();
	} else if (!strcmp(mode, "f559wire")) {
		f559_sec_wire("on");
	} else if (!strcmp(mode, "f559wiron")) {
		f559_sec_wire("on");
	} else if (!strcmp(mode, "f559wiroff")) {
		f559_setoff("clear", "r1", 0);
		f559_sec_wire("clear");
	} else if (!strcmp(mode, "f559ih")) {
		f559_setoff("clear", "r1", 0);
		f559_sec_ih();
	} else if (!strcmp(mode, "f559chain")) {
		f559_setoff("clear", "r1", 0);
		f559_sec_chain();
	} else if (!strcmp(mode, "f559smoke")) {
		f559_sec_feat();
		f559_sec_wire("on");
		f559_setoff("clear", "r1", 0);
		f559_sec_wire("clear");
	} else {
		f559_sec_feat();
		f559_sec_wire("on");
		f559_setoff("clear", "r1", 0);
		f559_sec_wire("clear");
		f559_setoff("restore", "r1", 1);
		f559_sec_wire("restored");
		f559_setoff("clear2", "r1", 0);
		f559_sec_ih();
		f559_sec_chain();
	}
	printf("F559 DONE\n");
	return 0;
}
/* differ560_add.c -- turn 560 / F38: the RECEIVING side of the tag.
 *
 * F37 ended with the tag measured as bytes on the wire: a veth whose
 * NETIF_F_HW_VLAN_CTAG_TX bit was taken away makes validate_xmit_vlan() insert
 * the tag into the frame itself, so the wire shows `8100 0064 0800 ...`.
 *
 * This turn sends that frame back IN, from an AF_PACKET socket, and asks what
 * the receiving kernel and the four guards make of it:
 *
 *   recv  family bridge, base ll, the 36-cell grid, five representations of one
 *         tagged frame: plain, wire-tagged (0x8100 vid 100), the SAME tag put
 *         into skb metadata by a `pre`-chain rule, a priority tag (vid 0), and
 *         a 0x9100 frame with the same four tag-shaped bytes.  Two of them are
 *         the same object seen from two sides; the grid must not be able to
 *         tell them apart, and neither must the wire.
 *   ndin  family netdev, INGRESS hook on s1, base nh, 40 cells: the guard
 *         returns true before it looks at skb->protocol -- but the receive path
 *         has already popped the tag, so the store's coordinates are skb
 *         coordinates, not wire coordinates.
 *   ndeg  family netdev, EGRESS hook on i0, base nh, 40 cells, three sends with
 *         sll_protocol = 0x0800 / 0x8100 / 0x9100: the only hook where a human
 *         chooses what the guard's switch reads.
 *   arp   family bridge, base nh, an 0x8100 + 0x0806 frame: F32's ARP branch
 *         (offset >= 8 && len <= 20, no test of the message length) through the
 *         new envelope.
 *   drop  policy drop at the bridge: the same rule refuses one representation
 *         and accepts the other.
 *
 * Views: w = AF_PACKET on r1 (xmit side, AFTER validate_xmit_skb: the tag the
 *        port actually put there), r = AF_PACKET on r0 (receive side, AFTER
 *        skb_vlan_untag: the frame as the far stack gets it).
 * Oracle for the guard: the rule's own counter, read before and after one send.
 */

/* ---------- frames ---------- */

/* the plain frame of `kind` with a 4-byte tag inserted in front of its
 * ethertype; tpid is the outer ethertype, tci the tag control word */
static int f560_tag(unsigned char *out, int kind, unsigned int tpid,
		    unsigned int tci)
{
	unsigned char tmp[512];
	int n = f556_frame(kind, tmp);

	memset(out, 0, 512);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = (unsigned char)((tpid >> 8) & 0xff);
	out[13] = (unsigned char)(tpid & 0xff);
	out[14] = (unsigned char)((tci >> 8) & 0xff);
	out[15] = (unsigned char)(tci & 0xff);
	memcpy(out + 16, tmp + 12, 2);		/* inner ethertype */
	memcpy(out + 18, tmp + 14, (size_t)(n - 14));	/* the datagram */
	return n + 4;
}

static const unsigned char MAGIC77[8] = { 0x77, 0x77, 0x77, 0x77,
					  0x77, 0x77, 0x77, 0x77 };

/* ---------- one send, two taps ---------- */

static void f560_send2(const char *dev, unsigned short proto,
		       const unsigned char *fr, int flen,
		       const unsigned char *magic, int mlen,
		       int wfd, int rfd, struct f559_out *o)
{
	int sk = 0;

	o->wpt = -1;
	o->rpt = -1;
	if (wfd >= 0)
		cap_drain(wfd);
	if (rfd >= 0)
		cap_drain(rfd);
	usleep(15000);
	if (wfd >= 0)
		cap_drain(wfd);
	if (rfd >= 0)
		cap_drain(rfd);
	memset(o->w, 0, sizeof(o->w));
	memset(o->r, 0, sizeof(o->r));
	o->snd = pkt_send_p(dev, fr, flen, proto);
	o->wn = f558_cap_match(wfd, o->w, (int)sizeof(o->w), 700, magic, mlen,
			       &sk, &o->wpt);
	sk = 0;
	o->rn = f558_cap_match(rfd, o->r, (int)sizeof(o->r), 400, magic, mlen,
			       &sk, &o->rpt);
}

/* ---------- one arm: one rule, one frame, two taps, one counter delta ---------- */

/* the section name, so that "p" in recv and "p" in ndin are two different
 * environments in every line of the log (the smoke run proved they collide) */
static const char *F560_SEC = "-";

static void f560_arm(const char *env, const char *arm, uint8_t fam,
		     const char *table, const char *chain, uint32_t base,
		     int off, int len, const unsigned char *imm, int do_store,
		     const unsigned char *fr, int flen, const char *sdev,
		     unsigned short sproto, const unsigned char *magic, int mlen,
		     int wfd, int rfd, const struct f559_out *base_out,
		     struct f559_out *out)
{
	struct f559_out o;
	char cw[1024], cr[1024], hw[256], hr[256];
	int kw = 0, kr = 0;

	memset(&o, 0, sizeof(o));
	snprintf(PRE57, sizeof(PRE57), "f60.%s.%s", env, arm);
	f557_flush(fam, table, chain, &o.acks);
	o.rc = f557_install(fam, table, chain, 0, base, (uint32_t)off,
			    (uint32_t)len, imm, do_store ? len : 0, do_store, 5,
			    PRE57, &o.acks);
	nfl_drain(NFL59);
	o.cnt0 = f555_count(fam, table, chain);
	{
		unsigned long long ip0 = f558_ipin();

		f560_send2(sdev, sproto, fr, flen, magic, mlen, wfd, rfd, &o);
		usleep(20000);
		o.ipin = f558_ipin() - ip0;
	}
	o.cnt = f555_count(fam, table, chain);
	if (base_out && o.wn > 0 && base_out->wn > 0)
		kw = f558_chg(cw, sizeof(cw), base_out->w, base_out->wn, o.w,
			      o.wn);
	if (base_out && o.rn > 0 && base_out->rn > 0)
		kr = f558_chg(cr, sizeof(cr), base_out->r, base_out->rn, o.r,
			      o.rn);
	printf("F560 R|env=%s.%s|arm=%s|fam=%u|base=%u|off=%d|len=%d|store=%d|"
	       "rc=%d|acks=%d|snd=%d|cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|"
	       "wn=%d|wpt=%d|wchg=%d|wchgs=%s|whex=%s|"
	       "rn=%d|rpt=%d|rchg=%d|rchgs=%s|rhex=%s\n",
	       F560_SEC, env, arm, (unsigned)fam, (unsigned)base, off, len,
	       do_store,
	       o.rc, o.acks, o.snd, o.cnt0, o.cnt, o.cnt - o.cnt0, o.ipin,
	       o.wn, o.wpt, kw, cw[0] ? cw : "-",
	       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn) : "-",
	       o.rn, o.rpt, kr, cr[0] ? cr : "-",
	       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn) : "-");
	if (out)
		memcpy(out, &o, sizeof(o));
}

/* the 12x3 grid (36 cells), every (off,len) of it */
static void f560_grid36(const char *env, uint8_t fam, const char *table,
			const char *chain, uint32_t base,
			const unsigned char *fr, int flen, int kind,
			const char *sdev, unsigned short sproto,
			const unsigned char *magic, int mlen, int wfd, int rfd,
			const struct f559_out *ctl)
{
	unsigned char imm[16];
	char arm[32];
	int i, j;

	for (i = 0; i < G33_NOFF; i++) {
		for (j = 0; j < G33_NLEN; j++) {
			f556_imm(kind, G33_OFF[i], G33_LEN[j], imm);
			snprintf(arm, sizeof(arm), "g%d_%d", G33_OFF[i],
				 G33_LEN[j]);
			f560_arm(env, arm, fam, table, chain, base, G33_OFF[i],
				 G33_LEN[j], imm, G33_LEN[j], fr, flen, sdev,
				 sproto, magic, mlen, wfd, rfd, ctl, NULL);
		}
	}
}

/* the same 36 cells plus the four wide arms = F33's 40-cell grid */
static void f560_grid40(const char *env, uint8_t fam, const char *table,
			const char *chain, uint32_t base,
			const unsigned char *fr, int flen, int kind,
			const char *sdev, unsigned short sproto,
			const unsigned char *magic, int mlen, int wfd, int rfd,
			const struct f559_out *ctl)
{
	unsigned char imm[16];
	char arm[32];
	int i;

	f560_grid36(env, fam, table, chain, base, fr, flen, kind, sdev, sproto,
		    magic, mlen, wfd, rfd, ctl);
	for (i = 0; i < G33_NEXT; i++) {
		f556_imm(kind, G33_XOFF[i], G33_XLEN[i], imm);
		snprintf(arm, sizeof(arm), "x%d_%d", G33_XOFF[i], G33_XLEN[i]);
		f560_arm(env, arm, fam, table, chain, base, G33_XOFF[i],
			 G33_XLEN[i], imm, G33_XLEN[i], fr, flen, sdev, sproto,
			 magic, mlen, wfd, rfd, ctl, NULL);
	}
}

/* ---------- recv: five representations of one tagged frame ---------- */

struct f560_rep {
	const char *tag;
	int kind;
	unsigned int tpid;	/* 0 = no tag in the frame bytes */
	unsigned int tci;
	const unsigned char *mtag;	/* four bytes for the `pre` chain, or NULL */
	unsigned short sproto;	/* sll_protocol of the send */
	int only_x;		/* 1 = only the eight informative cells */
};

/* the eight cells that a tag moves: (10,4) (12,1) (12,2) (12,4) (14,2)
 * (16,1) (16,2) (16,4) */
static const int X560_OFF[8] = { 10, 12, 12, 12, 14, 16, 16, 16 };
static const int X560_LEN[8] = { 4, 1, 2, 4, 2, 1, 2, 4 };

static int X560_IS(int off, int len)
{
	int k;

	for (k = 0; k < 8; k++)
		if (X560_OFF[k] == off && X560_LEN[k] == len)
			return 1;
	return 0;
}

static void f560_sec_recv(void)
{
	static const struct f560_rep reps[] = {
		{ "p",    FK33_IP4, 0,      0,      NULL, 0x0800, 0 },
		{ "w100", FK33_IP4, 0x8100, 0x0064, NULL, 0x8100, 0 },
		{ "m100", FK33_IP4, 0,      0,
		  (const unsigned char *)"\x81\x00\x00\x64", 0x0800, 0 },
		{ "v0",   FK33_IP4, 0x8100, 0x0000, NULL, 0x8100, 1 },
		{ "x91",  FK33_IP4, 0x9100, 0x0064, NULL, 0x9100, 1 },
	};
	struct f559_out ctl;
	unsigned char fr[512], imm[16];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int acks = 0, r, i, j, flen;

	F560_SEC = "recv";
	printf("F560 SECTION|recv|wfd=%d|rfd=%d|reps=%d\n", wfd, rfd,
	       (int)(sizeof(reps) / sizeof(reps[0])));
	if (add_table(NFPROTO_BRIDGE, "p60a") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p60a", "pre", 0, 0, 1, NULL) ||
	    f556_add_chain(NFPROTO_BRIDGE, "p60a", "g", 0, 10, 1, NULL)) {
		printf("F560 FAIL|recv|chain\n");
		return;
	}
	for (r = 0; r < (int)(sizeof(reps) / sizeof(reps[0])); r++) {
		if (reps[r].tpid)
			flen = f560_tag(fr, reps[r].kind, reps[r].tpid,
					reps[r].tci);
		else
			flen = f556_frame(reps[r].kind, fr);
		/* the `pre` chain holds the tag store, or nothing at all */
		f557_flush(NFPROTO_BRIDGE, "p60a", "pre", &acks);
		if (reps[r].mtag) {
			int prerc;

			snprintf(PRE57, sizeof(PRE57), "f60.tag.%s",
				 reps[r].tag);
			prerc = f557_install(NFPROTO_BRIDGE, "p60a", "pre", 0,
					     NFT_PAYLOAD_LL_HEADER, 12, 4,
					     reps[r].mtag, 4, 1, 5, PRE57,
					     &acks);
			printf("F560 TAGSTORE|rep=%s|rc=%d|acks=%d|off=12|len=4|"
			       "imm=%02x%02x%02x%02x\n", reps[r].tag, prerc,
			       acks, reps[r].mtag[0], reps[r].mtag[1],
			       reps[r].mtag[2], reps[r].mtag[3]);
		}
		printf("F560 REP|env=recv|rep=%s|flen=%d|tpid=%04x|tci=%04x|"
		       "meta=%d|sproto=%04x|only_x=%d\n", reps[r].tag, flen,
		       reps[r].tpid, reps[r].tci, reps[r].mtag != NULL,
		       reps[r].sproto, reps[r].only_x);
		memset(&ctl, 0, sizeof(ctl));
		f560_arm(reps[r].tag, "ctl", NFPROTO_BRIDGE, "p60a", "g", 0, 0, 0,
			 NULL, 0, fr, flen, "s0", reps[r].sproto, MAGIC77, 8,
			 wfd, rfd, NULL, &ctl);
		for (i = 0; i < G33_NOFF; i++) {
			for (j = 0; j < G33_NLEN; j++) {
				char arm[32];

				if (reps[r].only_x &&
				    !X560_IS(G33_OFF[i], G33_LEN[j]))
					continue;
				f556_imm(reps[r].kind, G33_OFF[i], G33_LEN[j],
					 imm);
				snprintf(arm, sizeof(arm), "g%d_%d",
					 G33_OFF[i], G33_LEN[j]);
				f560_arm(reps[r].tag, arm, NFPROTO_BRIDGE,
					 "p60a", "g", NFT_PAYLOAD_LL_HEADER,
					 G33_OFF[i], G33_LEN[j], imm,
					 G33_LEN[j], fr, flen, "s0",
					 reps[r].sproto, MAGIC77, 8, wfd, rfd,
					 &ctl, NULL);
			}
		}
	}
	sh("/nft flush ruleset");
}

/* ---------- ndin: the ingress hook, three ethertypes ---------- */

static void f560_sec_ndin(void)
{
	struct f559_out ctl;
	unsigned char fr[512];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int flen, i;
	static const struct {
		const char *tag;
		unsigned int tpid;
		unsigned short sproto;
	} reps[] = {
		{ "p",    0,      0x0800 },
		{ "w100", 0x8100, 0x8100 },
		{ "x91",  0x9100, 0x9100 },
	};

	F560_SEC = "ndin";
	printf("F560 SECTION|ndin|wfd=%d|rfd=%d\n", wfd, rfd);
	if (add_table(NFPROTO_NETDEV, "p60b") ||
	    f556_add_chain(NFPROTO_NETDEV, "p60b", "ing", 0, 0, 1, "s1")) {
		printf("F560 FAIL|ndin|chain\n");
		return;
	}
	for (i = 0; i < 3; i++) {
		if (reps[i].tpid)
			flen = f560_tag(fr, FK33_IP4, reps[i].tpid, 0x0064);
		else
			flen = f556_frame(FK33_IP4, fr);
		printf("F560 REP|env=ndin|rep=%s|flen=%d|sproto=%04x|dev=s1\n",
		       reps[i].tag, flen, reps[i].sproto);
		memset(&ctl, 0, sizeof(ctl));
		f560_arm(reps[i].tag, "ctl", NFPROTO_NETDEV, "p60b", "ing", 0, 0,
			 0, NULL, 0, fr, flen, "s0", reps[i].sproto, MAGIC77,
			 8, wfd, rfd, NULL, &ctl);
		f560_grid40(reps[i].tag, NFPROTO_NETDEV, "p60b", "ing",
			    NFT_PAYLOAD_NETWORK_HEADER, fr, flen, FK33_IP4, "s0",
			    reps[i].sproto, MAGIC77, 8, wfd, rfd, &ctl);
	}
	sh("/nft flush ruleset");
}

/* ---------- ndeg: the egress hook, three sll_protocol values ---------- */

static void f560_sec_ndeg(void)
{
	struct f559_out ctl;
	unsigned char fr[512];
	int wfd = cap_open("i0"), rfd = cap_open("i1");
	int flen, i;
	static const struct {
		const char *tag;
		unsigned int tpid;
		unsigned short sproto;
	} reps[] = {
		{ "s0800", 0,      0x0800 },
		{ "s8100", 0x8100, 0x8100 },
		{ "s9100", 0x9100, 0x9100 },
	};

	F560_SEC = "ndeg";
	printf("F560 SECTION|ndeg|wfd=%d|rfd=%d\n", wfd, rfd);
	if (add_table(NFPROTO_NETDEV, "p60c") ||
	    f556_add_chain(NFPROTO_NETDEV, "p60c", "egr", 1, 0, 1, "i0")) {
		printf("F560 FAIL|ndeg|chain\n");
		return;
	}
	for (i = 0; i < 3; i++) {
		if (reps[i].tpid)
			flen = f560_tag(fr, FK33_IP4, reps[i].tpid, 0x0064);
		else
			flen = f556_frame(FK33_IP4, fr);
		printf("F560 REP|env=ndeg|rep=%s|flen=%d|sproto=%04x|dev=i0\n",
		       reps[i].tag, flen, reps[i].sproto);
		memset(&ctl, 0, sizeof(ctl));
		f560_arm(reps[i].tag, "ctl", NFPROTO_NETDEV, "p60c", "egr", 0, 0,
			 0, NULL, 0, fr, flen, "i0", reps[i].sproto, MAGIC77,
			 8, wfd, rfd, NULL, &ctl);
		f560_grid40(reps[i].tag, NFPROTO_NETDEV, "p60c", "egr",
			    NFT_PAYLOAD_NETWORK_HEADER, fr, flen, FK33_IP4, "i0",
			    reps[i].sproto, MAGIC77, 8, wfd, rfd, &ctl);
	}
	sh("/nft flush ruleset");
}

/* ---------- arp: F32's branch through the new envelope ---------- */

static void f560_sec_arp(void)
{
	struct f559_out ctl;
	unsigned char fr[512];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int flen, i;
	static const struct {
		const char *tag;
		unsigned int tpid;
		unsigned short sproto;
	} reps[] = {
		{ "a",    0,      0x0806 },
		{ "aw100", 0x8100, 0x8100 },
		{ "ax91", 0x9100, 0x9100 },
	};

	F560_SEC = "arp";
	printf("F560 SECTION|arp|wfd=%d|rfd=%d\n", wfd, rfd);
	if (add_table(NFPROTO_BRIDGE, "p60d") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p60d", "g", 0, 0, 1, NULL)) {
		printf("F560 FAIL|arp|chain\n");
		return;
	}
	for (i = 0; i < 3; i++) {
		if (reps[i].tpid)
			flen = f560_tag(fr, FK33_ARP, reps[i].tpid, 0x0064);
		else
			flen = f556_frame(FK33_ARP, fr);
		printf("F560 REP|env=arp|rep=%s|flen=%d|sproto=%04x|dev=s0\n",
		       reps[i].tag, flen, reps[i].sproto);
		memset(&ctl, 0, sizeof(ctl));
		f560_arm(reps[i].tag, "ctl", NFPROTO_BRIDGE, "p60d", "g", 0, 0, 0,
			 NULL, 0, fr, flen, "s0", reps[i].sproto, MAC_SRC, 6,
			 wfd, rfd, NULL, &ctl);
		f560_grid40(reps[i].tag, NFPROTO_BRIDGE, "p60d", "g",
			    NFT_PAYLOAD_NETWORK_HEADER, fr, flen, FK33_ARP, "s0",
			    reps[i].sproto, MAC_SRC, 6, wfd, rfd, &ctl);
	}
	sh("/nft flush ruleset");
}

/* ---------- drop: one rule, two representations, two verdicts ---------- */

static void f560_sec_drop(void)
{
	static const struct {
		const char *tag;
		int off, len;
		unsigned int tpid;
		unsigned short sproto;
	} arms[] = {
		{ "ctl_p", 0, 0, 0, 0x0800 },
		{ "ctl_w", 0, 0, 0x8100, 0x8100 },
		{ "p16_2", 16, 2, 0, 0x0800 },
		{ "w16_2", 16, 2, 0x8100, 0x8100 },
		{ "p14_2", 14, 2, 0, 0x0800 },
		{ "w14_2", 14, 2, 0x8100, 0x8100 },
	};
	struct f559_out o;
	unsigned char fr[512], imm[16];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int i, flen;

	F560_SEC = "drop";
	printf("F560 SECTION|drop|wfd=%d|rfd=%d\n", wfd, rfd);
	if (add_table(NFPROTO_BRIDGE, "p60e") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p60e", "g", 0, 0, 0, NULL)) {
		printf("F560 FAIL|drop|chain\n");
		return;
	}
	for (i = 0; i < (int)(sizeof(arms) / sizeof(arms[0])); i++) {
		if (arms[i].tpid)
			flen = f560_tag(fr, FK33_IP4, arms[i].tpid, 0x0064);
		else
			flen = f556_frame(FK33_IP4, fr);
		f556_imm(FK33_IP4, arms[i].off, arms[i].len, imm);
		f560_arm("drop", arms[i].tag, NFPROTO_BRIDGE, "p60e", "g",
			 NFT_PAYLOAD_LL_HEADER, arms[i].off, arms[i].len, imm,
			 arms[i].len, fr, flen, "s0", arms[i].sproto, MAGIC77,
			 8, wfd, rfd, NULL, &o);
	}
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int f560_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f560";

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F560 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F560 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F560 KERNEL|%s\n", "7.3.4-T558");
	f556_env_setup();
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL59 = nfl_open(5);
	printf("F560 NFL|%d\n", NFL59);
	/* the tag must survive the egress port, or the wire view is 60 bytes
	 * of nothing -- F37's one feature bit, cleared here once */
	if (!strcmp(mode, "f560recv")) {
		f559_setoff("clear", "r1", 0);
		f560_sec_recv();
	} else if (!strcmp(mode, "f560ndin")) {
		f559_setoff("clear", "r1", 0);
		f560_sec_ndin();
	} else if (!strcmp(mode, "f560ndeg")) {
		f560_sec_ndeg();
	} else if (!strcmp(mode, "f560arp")) {
		f559_setoff("clear", "r1", 0);
		f560_sec_arp();
	} else if (!strcmp(mode, "f560drop")) {
		f559_setoff("clear", "r1", 0);
		f560_sec_drop();
	} else {
		f559_setoff("clear", "r1", 0);
		f560_sec_recv();
		f560_sec_ndin();
		f560_sec_ndeg();
		f560_sec_arp();
		f560_sec_drop();
	}
	printf("F560 DONE\n");
	return 0;
}
/* differ561_add.c -- turn 561 / F39: 802.1AD and Q-in-Q.
 *
 * F38 ended with "на veth метку в байтах кадра не показать" and with a promise:
 * eth_type_vlan() knows two constants and only one of them was measured.
 *
 * This instrument measures the second one -- 0x88a8 -- and the two-tag frame.
 * Same kernel as F36..F38 (7.3.4-T558), no new build: every file that matters
 * (nft_payload.c, nft_chain_filter.c, nft_meta.c, skbuff.c, dev.c, vlan_core.c)
 * is byte-for-byte the one those findings measured.
 *
 *   meta   what the packet IS, per representation: `meta protocol` compared
 *          against eight candidate ethertypes.  The counter is the oracle, so
 *          the value is read out of a match, never out of a print.
 *   ll     bridge prerouting, base ll, the 36-cell grid, six representations.
 *   unlock the same 40-cell network grid with and without a `meta protocol`
 *          expression in front of the store: the guard switches on pkt->ethertype,
 *          and pkt->ethertype is a field another expression may rewrite.
 *   xmit   the way out.  F37's one feature bit (NETIF_F_HW_VLAN_CTAG_TX) plus
 *          the one it never touched (NETIF_F_HW_VLAN_STAG_TX, bit 46): whether
 *          a stored skb->vlan_proto survives to the wire depends on both.
 *   far    the receiving side of a two-tag frame, no bridge: one pop or two?
 *   ndin   netdev ingress on the bridge port, the 40-cell network grid on a
 *          plain and on a QinQ frame: both are 40/40, and the bytes tell where
 *          "accepted" ends and "landed in the field" begins.
 *
 * Views: w = AF_PACKET on r1 (or i0), after validate_xmit_skb; r = AF_PACKET on
 * r0 (or i1), after skb_vlan_untag.  Oracle for every store: the rule's own
 * counter, read before and after one send.
 */

/* ---------- frames ---------- */

struct f561_rep {
	const char *tag;
	int ntag;
	unsigned int tp1, tc1, tp2, tc2;
};

static const struct f561_rep R561[] = {
	{ "p",   0, 0x0000, 0x0000, 0x0000, 0x0000 },
	{ "w",   1, 0x8100, 0x0064, 0x0000, 0x0000 },
	{ "s88", 1, 0x88a8, 0x0064, 0x0000, 0x0000 },
	{ "q",   2, 0x88a8, 0x0064, 0x8100, 0x00c8 },
	{ "q81", 2, 0x8100, 0x0064, 0x8100, 0x00c8 },
	{ "x91", 1, 0x9100, 0x0064, 0x0000, 0x0000 },
};
#define N561 ((int)(sizeof(R561) / sizeof(R561[0])))

/* the plain frame with ntag tags inserted in front of its ethertype */
static int f561_mkframe(const struct f561_rep *r, unsigned char *out)
{
	unsigned char tmp[512];
	unsigned int tp[2], tc[2];
	int n = f556_frame(FK33_IP4, tmp), i;

	tp[0] = r->tp1; tc[0] = r->tc1;
	tp[1] = r->tp2; tc[1] = r->tc2;
	memset(out, 0, 512);
	memcpy(out, tmp, 12);
	for (i = 0; i < r->ntag; i++) {
		out[12 + 4 * i] = (unsigned char)(tp[i] >> 8);
		out[13 + 4 * i] = (unsigned char)tp[i];
		out[14 + 4 * i] = (unsigned char)(tc[i] >> 8);
		out[15 + 4 * i] = (unsigned char)tc[i];
	}
	memcpy(out + 12 + 4 * r->ntag, tmp + 12, (size_t)(n - 12));
	return n + 4 * r->ntag;
}

/* the ethertype the frame announces (what eth_type_trans() will copy) */
static unsigned short f561_proto(const struct f561_rep *r)
{
	return r->ntag ? (unsigned short)r->tp1 : 0x0800;
}

static const unsigned char M561_77[8] = { 0x77, 0x77, 0x77, 0x77,
					  0x77, 0x77, 0x77, 0x77 };

/* ---------- rules: up to one gate in front of one store ---------- */

#define F561_GATE_NONE		0
#define F561_GATE_META_NE	1	/* meta protocol != 0xffff  */
#define F561_GATE_META_EQ	2	/* meta protocol == want    */
#define F561_REG_META		NFT_REG32_08

static int f561_rule(uint8_t fam, const char *table, const char *chain,
		     int gate, unsigned int want, uint32_t base, uint32_t off,
		     uint32_t len, const unsigned char *imm, int immlen,
		     int do_store, int loggroup, const char *prefix, int *acks)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *e, *d, *cd;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			fam);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (gate != F561_GATE_NONE) {
		uint16_t v = htons((uint16_t)(gate == F561_GATE_META_EQ ? want
								       : 0xffff));

		e = nest_start(nlh, NFTA_LIST_ELEM);
		put_str(nlh, NFTA_EXPR_NAME, "meta");
		d = nest_start(nlh, NFTA_EXPR_DATA);
		put_be32(nlh, NFTA_META_KEY, NFT_META_PROTOCOL);
		put_be32(nlh, NFTA_META_DREG, F561_REG_META);
		nest_end(nlh, d);
		nest_end(nlh, e);

		e = nest_start(nlh, NFTA_LIST_ELEM);
		put_str(nlh, NFTA_EXPR_NAME, "cmp");
		d = nest_start(nlh, NFTA_EXPR_DATA);
		put_be32(nlh, NFTA_CMP_SREG, F561_REG_META);
		put_be32(nlh, NFTA_CMP_OP,
			 gate == F561_GATE_META_EQ ? NFT_CMP_EQ : NFT_CMP_NEQ);
		cd = nest_start(nlh, NFTA_CMP_DATA);
		attr_put(nlh, NFTA_DATA_VALUE, &v, 2);
		nest_end(nlh, cd);
		nest_end(nlh, d);
		nest_end(nlh, e);
	}
	if (do_store) {
		imm_value(nlh, NFT_REG32_00, imm, immlen);
		e = nest_start(nlh, NFTA_LIST_ELEM);
		put_str(nlh, NFTA_EXPR_NAME, "payload");
		d = nest_start(nlh, NFTA_EXPR_DATA);
		put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00);
		put_be32(nlh, NFTA_PAYLOAD_BASE, base);
		put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
		put_be32(nlh, NFTA_PAYLOAD_LEN, len);
		put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
		put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
		nest_end(nlh, d);
		nest_end(nlh, e);
	}
	log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, acks);
}

/* ---------- one arm ---------- */

static const char *F561_SEC = "-";

static void f561_arm(const char *env, const char *arm, int gate,
		     unsigned int want, uint8_t fam, const char *table,
		     const char *chain, uint32_t base, int off, int len,
		     const unsigned char *imm, int do_store,
		     const unsigned char *fr, int flen, const char *sdev,
		     unsigned short sproto, const unsigned char *magic, int mlen,
		     int wfd, int rfd, const struct f559_out *base_out,
		     struct f559_out *out)
{
	struct f559_out o;
	char cw[1024], cr[1024], hw[512], hr[512];
	int kw = 0, kr = 0;

	/* F39: without this, an arm with no baseline printed the PREVIOUS arm's
	 * diff string (uninitialised stack) under wchg=0.  Found by reading the
	 * ll.q control of the smoke, fixed before any number was quoted. */
	cw[0] = 0;
	cr[0] = 0;

	memset(&o, 0, sizeof(o));
	snprintf(PRE57, sizeof(PRE57), "f61.%s.%s", env, arm);
	f557_flush(fam, table, chain, &o.acks);
	o.rc = f561_rule(fam, table, chain, gate, want, base, (uint32_t)off,
			 (uint32_t)len, imm, do_store ? len : 0, do_store, 5,
			 PRE57, &o.acks);
	nfl_drain(NFL59);
	o.cnt0 = f555_count(fam, table, chain);
	{
		unsigned long long ip0 = f558_ipin();

		f560_send2(sdev, sproto, fr, flen, magic, mlen, wfd, rfd, &o);
		usleep(20000);
		o.ipin = f558_ipin() - ip0;
	}
	o.cnt = f555_count(fam, table, chain);
	if (base_out && o.wn > 0 && base_out->wn > 0)
		kw = f558_chg(cw, sizeof(cw), base_out->w, base_out->wn, o.w,
			      o.wn);
	if (base_out && o.rn > 0 && base_out->rn > 0)
		kr = f558_chg(cr, sizeof(cr), base_out->r, base_out->rn, o.r,
			      o.rn);
	printf("F561 R|env=%s.%s|arm=%s|gate=%d|want=%04x|fam=%u|base=%u|"
	       "off=%d|len=%d|store=%d|"
	       "rc=%d|acks=%d|snd=%d|cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|"
	       "wn=%d|wpt=%d|wchg=%d|wchgs=%s|whex=%s|"
	       "rn=%d|rpt=%d|rchg=%d|rchgs=%s|rhex=%s\n",
	       F561_SEC, env, arm, gate, want, (unsigned)fam, (unsigned)base,
	       off, len, do_store,
	       o.rc, o.acks, o.snd, o.cnt0, o.cnt, o.cnt - o.cnt0, o.ipin,
	       o.wn, o.wpt, kw, cw[0] ? cw : "-",
	       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn) : "-",
	       o.rn, o.rpt, kr, cr[0] ? cr : "-",
	       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn) : "-");
	if (out)
		memcpy(out, &o, sizeof(o));
}

/* the 36-cell grid */
static void f561_grid36(const char *env, uint8_t fam, const char *table,
			const char *chain, uint32_t base, int gate,
			const unsigned char *fr, int flen, const char *sdev,
			unsigned short sproto, const unsigned char *magic,
			int mlen, int wfd, int rfd, const struct f559_out *ctl)
{
	unsigned char imm[16];
	char arm[32];
	int i, j;

	for (i = 0; i < G33_NOFF; i++) {
		for (j = 0; j < G33_NLEN; j++) {
			f556_imm(FK33_IP4, G33_OFF[i], G33_LEN[j], imm);
			snprintf(arm, sizeof(arm), "g%d_%d", G33_OFF[i],
				 G33_LEN[j]);
			f561_arm(env, arm, gate, 0, fam, table, chain, base,
				 G33_OFF[i], G33_LEN[j], imm, G33_LEN[j], fr,
				 flen, sdev, sproto, magic, mlen, wfd, rfd, ctl,
				 NULL);
		}
	}
}

/* the 36 cells plus the four wide arms = the 40-cell grid */
static void f561_grid40(const char *env, uint8_t fam, const char *table,
			const char *chain, uint32_t base, int gate,
			const unsigned char *fr, int flen, const char *sdev,
			unsigned short sproto, const unsigned char *magic,
			int mlen, int wfd, int rfd, const struct f559_out *ctl)
{
	unsigned char imm[16];
	char arm[32];
	int i;

	f561_grid36(env, fam, table, chain, base, gate, fr, flen, sdev, sproto,
		    magic, mlen, wfd, rfd, ctl);
	for (i = 0; i < G33_NEXT; i++) {
		f556_imm(FK33_IP4, G33_XOFF[i], G33_XLEN[i], imm);
		snprintf(arm, sizeof(arm), "x%d_%d", G33_XOFF[i], G33_XLEN[i]);
		f561_arm(env, arm, gate, 0, fam, table, chain, base, G33_XOFF[i],
			 G33_XLEN[i], imm, G33_XLEN[i], fr, flen, sdev, sproto,
			 magic, mlen, wfd, rfd, ctl, NULL);
	}
}

/* ---------- feature bits ---------- */

#define F561_CTAG_TX_BIT	7	/* NETIF_F_HW_VLAN_CTAG_TX_BIT */
#define F561_STAG_TX_BIT	45	/* NETIF_F_HW_VLAN_STAG_TX_BIT */
#define F561_STAG_SHIFT		(F561_STAG_TX_BIT - 32)

static void f561_feat(const char *stage, const char *dev)
{
	struct f559_fblk b[F559_FWORDS];
	int n = 0, i, rc = f559_gfeat(dev, b, F559_FWORDS, &n);

	printf("F561 FEAT|stage=%s|dev=%s|rc=%d|nwords=%d", stage, dev, rc, n);
	if (rc == 0) {
		for (i = 0; i < n && i < F559_FWORDS; i++)
			printf("|avail%d=%08x|want%d=%08x|act%d=%08x", i,
			       b[i].avail, i, b[i].want, i, b[i].act);
		printf("|ctag_tx=%d|stag_tx=%d|stag_rx=%d",
		       (int)((b[0].act >> F561_CTAG_TX_BIT) & 1),
		       n > 1 ? (int)((b[1].act >> F561_STAG_SHIFT) & 1) : -1,
		       n > 1 ? (int)((b[1].act >> (F561_STAG_SHIFT + 1)) & 1)
			     : -1);
	}
	printf("\n");
}

static int f561_sfeat2(const char *dev, int nblk, unsigned int v0,
		       unsigned int r0, unsigned int v1, unsigned int r1)
{
	struct {
		unsigned int cmd, size;
		struct {
			unsigned int valid, req;
		} b[F559_FWORDS];
	} c;
	struct ifreq ifr;
	int fd, rc;

	memset(&c, 0, sizeof(c));
	c.cmd = F559_SFEATURES;
	c.size = (unsigned int)nblk;
	c.b[0].valid = v0;
	c.b[0].req = r0;
	c.b[1].valid = v1;
	c.b[1].req = r1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, IFNAMSIZ, "%s", dev);
	ifr.ifr_data = (char *)&c;
	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0)
		return -1;
	rc = ioctl(fd, SIOCETHTOOL, &ifr);
	close(fd);
	return rc < 0 ? -errno : rc;
}

/* ctag/stag: 1 = ask for the bit, 0 = ask it away.  Returns the raw ioctl. */
static int f561_setbits(const char *stage, const char *dev, int ctag, int stag)
{
	struct f559_fblk b[F559_FWORDS];
	unsigned int v0 = 1u << F561_CTAG_TX_BIT, r0 = 0;
	unsigned int v1 = 0, r1 = 0;
	int n = 0, rc;

	if (f559_gfeat(dev, b, F559_FWORDS, &n) < 0 || n <= 0) {
		printf("F561 SET|stage=%s|dev=%s|no_gfeat\n", stage, dev);
		return -1;
	}
	if (ctag)
		r0 = v0;
	if (n > 1) {
		v1 = 1u << F561_STAG_SHIFT;
		if (stag)
			r1 = v1;
	}
	rc = f561_sfeat2(dev, n, v0, r0, v1, r1);
	printf("F561 SET|stage=%s|dev=%s|nwords=%d|valid0=%08x|req0=%08x|"
	       "valid1=%08x|req1=%08x|rc=%d|f_unsup=%d|f_wish=%d\n",
	       stage, dev, n, v0, r0, v1, r1, rc, rc >= 0 ? (rc & 1) : -1,
	       rc >= 0 ? (rc & 2) : -1);
	f561_feat(stage, dev);
	return rc;
}

/* ---------- meta: what the packet is ---------- */

static const unsigned int V561[8] = { 0x0800, 0x0806, 0x8100, 0x88a8,
				      0x9100, 0x4500, 0x86dd, 0x0002 };

static void f561_sec_meta(void)
{
	unsigned char fr[512];
	int r, v, acks = 0, flen;
	struct f559_out o;

	F561_SEC = "meta";
	f561_feat("meta.in", "r1");
	if (add_table(NFPROTO_BRIDGE, "p61a") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p61a", "g", 0, 0, 1, NULL)) {
		printf("F561 FAIL|meta|chain\n");
		return;
	}
	for (r = 0; r < N561; r++) {
		flen = f561_mkframe(&R561[r], fr);
		memset(&o, 0, sizeof(o));
		snprintf(PRE57, sizeof(PRE57), "f61.meta.%s.ctl", R561[r].tag);
		f557_flush(NFPROTO_BRIDGE, "p61a", "g", &acks);
		o.rc = f561_rule(NFPROTO_BRIDGE, "p61a", "g", F561_GATE_NONE, 0,
				 0, 0, 0, NULL, 0, 0, 5, PRE57, &acks);
		o.cnt0 = f555_count(NFPROTO_BRIDGE, "p61a", "g");
		o.snd = pkt_send_p("s0", fr, flen, f561_proto(&R561[r]));
		usleep(20000);
		o.cnt = f555_count(NFPROTO_BRIDGE, "p61a", "g");
		printf("F561 M|env=meta|rep=%s|want=-|ctl=1|rc=%d|acks=%d|"
		       "snd=%d|cnt0=%llu|cnt=%llu|live=%llu\n",
		       R561[r].tag, o.rc, o.acks, o.snd, o.cnt0, o.cnt,
		       o.cnt - o.cnt0);
		for (v = 0; v < 8; v++) {
			f557_flush(NFPROTO_BRIDGE, "p61a", "g", &acks);
			snprintf(PRE57, sizeof(PRE57), "f61.meta.%s.%04x",
				 R561[r].tag, V561[v]);
			o.rc = f561_rule(NFPROTO_BRIDGE, "p61a", "g",
					 F561_GATE_META_EQ, V561[v], 0, 0, 0,
					 NULL, 0, 0, 5, PRE57, &acks);
			o.cnt0 = f555_count(NFPROTO_BRIDGE, "p61a", "g");
			o.snd = pkt_send_p("s0", fr, flen,
					   f561_proto(&R561[r]));
			usleep(20000);
			o.cnt = f555_count(NFPROTO_BRIDGE, "p61a", "g");
			printf("F561 M|env=meta|rep=%s|want=%04x|ctl=0|rc=%d|"
			       "acks=%d|snd=%d|cnt0=%llu|cnt=%llu|live=%llu\n",
			       R561[r].tag, V561[v], o.rc, o.acks, o.snd,
			       o.cnt0, o.cnt, o.cnt - o.cnt0);
		}
	}
	sh("/nft flush ruleset");
}

/* ---------- ll: the 36-cell grid over six representations ---------- */

static void f561_sec_ll(void)
{
	unsigned char fr[512];
	struct f559_out ctl;
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int r, flen;

	F561_SEC = "ll";
	f561_feat("ll.in", "r1");
	printf("F561 SECTION|ll|wfd=%d|rfd=%d|reps=%d\n", wfd, rfd, N561);
	if (add_table(NFPROTO_BRIDGE, "p61b") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p61b", "g", 0, 0, 1, NULL)) {
		printf("F561 FAIL|ll|chain\n");
		return;
	}
	for (r = 0; r < N561; r++) {
		flen = f561_mkframe(&R561[r], fr);
		printf("F561 REP|env=ll|rep=%s|flen=%d|ntag=%d|tp1=%04x|"
		       "tp2=%04x|sproto=%04x\n",
		       R561[r].tag, flen, R561[r].ntag, R561[r].tp1,
		       R561[r].tp2, f561_proto(&R561[r]));
		memset(&ctl, 0, sizeof(ctl));
		f561_arm(R561[r].tag, "ctl", F561_GATE_NONE, 0, NFPROTO_BRIDGE,
			 "p61b", "g", NFT_PAYLOAD_LL_HEADER, 0, 0, NULL, 0, fr,
			 flen, "s0", f561_proto(&R561[r]), M561_77, 8, wfd,
			 rfd, NULL, &ctl);
		f561_grid36(R561[r].tag, NFPROTO_BRIDGE, "p61b", "g",
			    NFT_PAYLOAD_LL_HEADER, F561_GATE_NONE, fr, flen, "s0",
			    f561_proto(&R561[r]), M561_77, 8, wfd, rfd, &ctl);
	}
	sh("/nft flush ruleset");
}

/* ---------- unlock: the guard reads a field another expression rewrites ---- */

static void f561_sec_unlock(void)
{
	static const int reps[2] = { 1, 3 };	/* w, q */
	unsigned char fr[512];
	struct f559_out ctl;
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int k, r, flen, gate;

	F561_SEC = "unlock";
	f561_feat("unlock.in", "r1");
	printf("F561 SECTION|unlock|wfd=%d|rfd=%d\n", wfd, rfd);
	if (add_table(NFPROTO_BRIDGE, "p61c") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p61c", "g", 0, 0, 1, NULL)) {
		printf("F561 FAIL|unlock|chain\n");
		return;
	}
	for (k = 0; k < 2; k++) {
		r = reps[k];
		flen = f561_mkframe(&R561[r], fr);
		for (gate = 0; gate < 2; gate++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", R561[r].tag,
				 gate ? "meta" : "bare");
			printf("F561 REP|env=unlock|rep=%s|flen=%d|gate=%d\n",
			       env, flen, gate);
			memset(&ctl, 0, sizeof(ctl));
			f561_arm(env, "ctl", F561_GATE_NONE, 0,
				 NFPROTO_BRIDGE, "p61c", "g",
				 NFT_PAYLOAD_NETWORK_HEADER, 0, 0, NULL, 0, fr,
				 flen, "s0", f561_proto(&R561[r]), M561_77, 8,
				 wfd, rfd, NULL, &ctl);
			f561_grid40(env, NFPROTO_BRIDGE, "p61c", "g",
				    NFT_PAYLOAD_NETWORK_HEADER,
				    gate ? F561_GATE_META_NE : F561_GATE_NONE,
				    fr, flen, "s0", f561_proto(&R561[r]),
				    M561_77, 8, wfd, rfd, &ctl);
		}
	}
	sh("/nft flush ruleset");
}

/* ---------- xmit: does a stored vlan_proto survive the wire? ---------- */

static void f561_sec_xmit(void)
{
	static const struct {
		const char *tag;
		int off, len;
		unsigned int v1, v2;
	} A[] = {
		{ "ctl",   0,  0, 0x0000, 0x0000 },
		{ "p8100", 12, 2, 0x8100, 0x0000 },
		{ "p88a8", 12, 2, 0x88a8, 0x0000 },
		{ "p0000", 12, 2, 0x0000, 0x0000 },
		{ "t88a8", 12, 4, 0x88a8, 0x0064 },
	};
	static const struct {
		const char *tag;
		int ctag, stag;
	} S[] = {
		{ "A_11", 1, 1 },
		{ "B_01", 0, 1 },
		{ "C_00", 0, 0 },
	};
	unsigned char fr[512], imm[16];
	struct f559_out ctl;
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int s, a, flen;

	F561_SEC = "xmit";
	printf("F561 SECTION|xmit|wfd=%d|rfd=%d\n", wfd, rfd);
	if (add_table(NFPROTO_BRIDGE, "p61d") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p61d", "g", 0, 0, 1, NULL)) {
		printf("F561 FAIL|xmit|chain\n");
		return;
	}
	flen = f561_mkframe(&R561[1], fr);	/* the single 0x8100 tag frame */
	printf("F561 REP|env=xmit|rep=w|flen=%d|sproto=%04x\n", flen,
	       f561_proto(&R561[1]));
	for (s = 0; s < 3; s++) {
		f561_setbits(S[s].tag, "r1", S[s].ctag, S[s].stag);
		for (a = 0; a < (int)(sizeof(A) / sizeof(A[0])); a++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", S[s].tag,
				 A[a].tag);
			memset(imm, 0, sizeof(imm));
			imm[0] = (unsigned char)(A[a].v1 >> 8);
			imm[1] = (unsigned char)A[a].v1;
			imm[2] = (unsigned char)(A[a].v2 >> 8);
			imm[3] = (unsigned char)A[a].v2;
			memset(&ctl, 0, sizeof(ctl));
			if (a == 0)
				f561_arm(env, "ctl", F561_GATE_NONE, 0,
					 NFPROTO_BRIDGE, "p61d", "g",
					 NFT_PAYLOAD_LL_HEADER, 0, 0, NULL, 0,
					 fr, flen, "s0", f561_proto(&R561[1]),
					 M561_77, 8, wfd, rfd, NULL, &ctl);
			else
				f561_arm(env, A[a].tag, F561_GATE_NONE, 0,
					 NFPROTO_BRIDGE, "p61d", "g",
					 NFT_PAYLOAD_LL_HEADER, A[a].off,
					 A[a].len, imm, 1, fr, flen, "s0",
					 f561_proto(&R561[1]), M561_77, 8, wfd,
					 rfd, &ctl, NULL);
		}
	}
	f561_setbits("restore", "r1", 1, 1);
	sh("/nft flush ruleset");
}

/* ---------- far: the receiving side of a two-tag frame ---------- */

static void f561_sec_far(void)
{
	unsigned char fr[512];
	int r, flen;
	int wfd = cap_open("i0"), rfd = cap_open("i1");

	F561_SEC = "far";
	printf("F561 SECTION|far|wfd=%d|rfd=%d|dev=i0->i1\n", wfd, rfd);
	for (r = 0; r < N561; r++) {
		struct f559_out o;

		flen = f561_mkframe(&R561[r], fr);
		memset(&o, 0, sizeof(o));
		{
			unsigned long long ip0 = f558_ipin();

			f560_send2("i0", f561_proto(&R561[r]), fr, flen, M561_77,
				   8, wfd, rfd, &o);
			usleep(20000);
			o.ipin = f558_ipin() - ip0;
		}
		{
			char hw[512], hr[512];

			printf("F561 FAR|rep=%s|flen=%d|snd=%d|ipin=%llu|"
			       "wn=%d|wpt=%d|whex=%s|rn=%d|rpt=%d|rhex=%s\n",
			       R561[r].tag, flen, o.snd, o.ipin, o.wn, o.wpt,
			       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn)
					: "-",
			       o.rn, o.rpt,
			       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn)
					: "-");
		}
	}
}

/* ---------- ndin: netdev ingress, plain vs QinQ ---------- */

static void f561_sec_ndin(void)
{
	static const int reps[2] = { 0, 3 };	/* p, q */
	unsigned char fr[512];
	struct f559_out ctl;
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int k, r, flen;

	F561_SEC = "ndin";
	f561_feat("ndin.in", "s1");
	printf("F561 SECTION|ndin|wfd=%d|rfd=%d|dev=s1\n", wfd, rfd);
	if (add_table(NFPROTO_NETDEV, "p61e") ||
	    f556_add_chain(NFPROTO_NETDEV, "p61e", "ing", 0, 0, 1, "s1")) {
		printf("F561 FAIL|ndin|chain\n");
		return;
	}
	for (k = 0; k < 2; k++) {
		r = reps[k];
		flen = f561_mkframe(&R561[r], fr);
		printf("F561 REP|env=ndin|rep=%s|flen=%d|sproto=%04x\n",
		       R561[r].tag, flen, f561_proto(&R561[r]));
		memset(&ctl, 0, sizeof(ctl));
		f561_arm(R561[r].tag, "ctl", F561_GATE_NONE, 0, NFPROTO_NETDEV,
			 "p61e", "ing", NFT_PAYLOAD_NETWORK_HEADER, 0, 0, NULL,
			 0, fr, flen, "s0", f561_proto(&R561[r]), M561_77, 8,
			 wfd, rfd, NULL, &ctl);
		f561_grid40(R561[r].tag, NFPROTO_NETDEV, "p61e", "ing",
			    NFT_PAYLOAD_NETWORK_HEADER, F561_GATE_NONE, fr, flen,
			    "s0", f561_proto(&R561[r]), M561_77, 8, wfd, rfd,
			    &ctl);
	}
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int f561_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f561";

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F561 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F561 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F561 KERNEL|%s\n", "7.3.4-T558");
	f556_env_setup();
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL59 = nfl_open(5);
	printf("F561 NFL|%d\n", NFL59);
	if (!strcmp(mode, "f561meta")) {
		f561_sec_meta();
	} else if (!strcmp(mode, "f561ll")) {
		f561_sec_ll();
	} else if (!strcmp(mode, "f561unlock")) {
		f561_sec_unlock();
	} else if (!strcmp(mode, "f561xmit")) {
		f561_sec_xmit();
	} else if (!strcmp(mode, "f561far")) {
		f561_sec_far();
	} else if (!strcmp(mode, "f561ndin")) {
		f561_sec_ndin();
	} else {
		f561_sec_far();
		f561_sec_meta();
		f561_sec_ll();
		f561_sec_unlock();
		f561_sec_xmit();
		f561_sec_ndin();
	}
	printf("F561 DONE\n");
	return 0;
}
/* differ562_add.c -- turn 562 / F40: the read side of @nh.
 *
 * F39 ended with the one guard input it saw in code and had not measured:
 *   nft_payload_eval()   (read)  offset = skb_network_offset(skb) + pkt->nhoff
 *   nft_payload_set_eval (store) offset = skb_network_offset(skb)
 * so a cell (offset,len) names one byte to a read and another to a store as
 * soon as pkt->nhoff != 0.  nhoff becomes 4 in exactly one place:
 * nft_meta_pktinfo_may_update(), reached from `meta protocol`, on an skb whose
 * skb->protocol is 0x8100 -- a Q-in-Q frame after the receive path popped
 * exactly one tag (F39's `q`).
 *
 * Same kernel as F36..F39 (7.3.4-T558, sha 459f02a5...): every file that
 * decides this (nft_payload.c, nft_meta.c, nf_tables_core.c, skbuff.c) is
 * byte-for-byte the one those findings measured.
 *
 * Sections:
 *   ctl    one counter-only rule per representation: the envelope arrives.
 *   rd     the read grid: 40 cells x {p, w, q} x {bare, meta} x 2 candidates.
 *          Candidate A = cap[14+off], the byte the STORE of that cell writes.
 *          Candidate B = cap[18+off], where a read lands if pkt->nhoff == 4.
 *          No store in these arms: neither the guard nor skb_ensure_writable
 *          is between the read and the counter.
 *   pair   one rule on one packet: read and store of the SAME cell, in both
 *          orders (rdwr: read then store; wrrd: store then read).
 *   ih     the transport base: meta's repair sets pkt->thoff from nhoff, and
 *          both the read and the store use nft_thoff() -- so they agree there.
 *   qarp   ARP in Q-in-Q: meta sets pkt->ethertype = 0x0806 but validates
 *          nothing, so nhoff stays 0 and the guard writes "ar_op" into ar_pro.
 *
 * Views: w = AF_PACKET on r1 (after xmit), r = AF_PACKET on r0.  Oracle for
 * every arm: the rule's own counter, read before and after one send.
 * Frame layout on the capture: cap starts at mac_header, skb->data is 14
 * bytes further, so a data-relative offset D is cap[14+D].
 */

/* ---------- frames ---------- */

struct f562_frame {
	const char *tag;
	int kind;			/* FK33_IP4 or FK33_ARP */
	int ntag;
	unsigned int tp1, tc1, tp2, tc2;
	unsigned char plain[256];	/* the untagged layout, as captured */
	int plainlen;
	unsigned char cap[256];		/* the captured layout (mac_header on) */
	int caplen;
	unsigned short sproto;		/* what the sender declares */
	unsigned char magic[8];		/* capture needle: the UDP payload 0x77.. */
	int mlen;			/* for IPv4, the ARP sender protocol address */
};

static int f562_wire(const struct f562_frame *f, unsigned char *out)
{
	unsigned int tp[2], tc[2];
	int i, n = f->plainlen;

	tp[0] = f->tp1; tc[0] = f->tc1;
	tp[1] = f->tp2; tc[1] = f->tc2;
	memcpy(out, f->plain, 12);
	for (i = 0; i < f->ntag; i++) {
		out[12 + 4 * i] = (unsigned char)(tp[i] >> 8);
		out[13 + 4 * i] = (unsigned char)tp[i];
		out[14 + 4 * i] = (unsigned char)(tc[i] >> 8);
		out[15 + 4 * i] = (unsigned char)tc[i];
	}
	memcpy(out + 12 + 4 * f->ntag, f->plain + 12, (size_t)(n - 12));
	return n + 4 * f->ntag;
}

/* The capture is what leaves the bridge.  Receive path, in order:
 * eth_type_trans() pulls 14; __netif_receive_skb_core() pops ONE tag
 * (skb_vlan_untag), sets skb->protocol to the next ethertype and
 * skb_reorder_vlan_header() moves the MACs forward by VLAN_HLEN.  So:
 *   no tag   -> captured = plain;
 *   one tag  -> the tag is in skb->vlan_all and veth reinserts nothing
 *               (HW_VLAN_*_TX set), captured = plain;
 *   two tags -> the outer tag is gone, the INNER one remains in the bytes,
 *               captured = MACs + inner tag + plain[12..].
 */
static void f562_build(struct f562_frame *f)
{
	int n = f->kind == FK33_ARP
		? build_arp(f->plain, 1, 0x0a010009, 0x0a090001, MAC_SRC, 6, 4, 1)
		: f556_frame(FK33_IP4, f->plain);

	f->plainlen = n;
	memcpy(f->cap, f->plain, 12);
	if (f->ntag >= 2) {
		f->cap[12] = (unsigned char)(f->tp2 >> 8);
		f->cap[13] = (unsigned char)f->tp2;
		f->cap[14] = (unsigned char)(f->tc2 >> 8);
		f->cap[15] = (unsigned char)f->tc2;
		memcpy(f->cap + 16, f->plain + 12, (size_t)(n - 12));
		f->caplen = n + 4;
	} else {
		memcpy(f->cap + 12, f->plain + 12, (size_t)(n - 12));
		f->caplen = n;
	}
	f->sproto = f->ntag ? (unsigned short)f->tp1 : f556_proto(f->kind);
	/* The capture is matched by content, not by being the next frame: the
	 * first frame on a fresh socket is ICMPv6 noise (F35).  The IPv4 frame
	 * carries 18 bytes of 0x77; the ARP frame carries none, so it is
	 * matched on its sender protocol address, which nothing else writes. */
	if (f->kind == FK33_ARP) {
		static const unsigned char arp_needle[4] = { 0x0a, 0x01, 0x00,
							     0x09 };

		memcpy(f->magic, arp_needle, 4);
		f->mlen = 4;
	} else {
		memcpy(f->magic, M561_77, 8);
		f->mlen = 8;
	}
}

/* A = the store's coordinate, B = nhoff==4, P = plain[14+off] (the value a
 * plain frame gives at this cell), T = the true transport header. */
static const unsigned char *f562_cand(const struct f562_frame *f, int which,
				      int off)
{
	switch (which) {
	case 1:
		return f->cap + 18 + off;
	case 2:
		return f->plain + 14 + off;
	case 3:
		return f->plain + 34 + off;
	}
	return f->cap + 14 + off;
}

static const char *f562_candname(int which)
{
	switch (which) {
	case 0: return "A";
	case 1: return "B";
	case 2: return "P";
	case 3: return "T";
	}
	return "?";
}

/* ---------- rule pieces ---------- */

#define F562_RD_DREG	NFT_REG32_08
#define F562_WR_SREG	NFT_REG32_00

static void f562_meta_proto(struct nlmsghdr *nlh)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "meta");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_META_KEY, NFT_META_PROTOCOL);
	put_be32(nlh, NFTA_META_DREG, F562_RD_DREG);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void f562_cmp(struct nlmsghdr *nlh, uint32_t sreg,
		     const unsigned char *val, int len)
{
	struct nlattr *e, *d, *cd;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "cmp");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_CMP_SREG, sreg);
	put_be32(nlh, NFTA_CMP_OP, NFT_CMP_EQ);
	cd = nest_start(nlh, NFTA_CMP_DATA);
	attr_put(nlh, NFTA_DATA_VALUE, val, len);
	nest_end(nlh, cd);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void f562_read(struct nlmsghdr *nlh, uint32_t base, uint32_t off,
		      uint32_t len)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "payload");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_PAYLOAD_DREG, F562_RD_DREG);
	put_be32(nlh, NFTA_PAYLOAD_BASE, base);
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
	put_be32(nlh, NFTA_PAYLOAD_LEN, len);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void f562_store(struct nlmsghdr *nlh, uint32_t base, uint32_t off,
		       uint32_t len, const unsigned char *imm)
{
	struct nlattr *e, *d;

	imm_value(nlh, F562_WR_SREG, imm, (int)len);
	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "payload");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_PAYLOAD_SREG, F562_WR_SREG);
	put_be32(nlh, NFTA_PAYLOAD_BASE, base);
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
	put_be32(nlh, NFTA_PAYLOAD_LEN, len);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* ---------- one arm ---------- */

static const char *F562_SEC = "-";

static void f562_arm(const char *env, const char *arm, const char *rep,
		     int gate, uint32_t base, int off, int len,
		     int do_rd, int cand, int do_wr, int wr_first,
		     const unsigned char *imm, const struct f562_frame *f,
		     const unsigned char *wire, int wlen,
		     int wfd, int rfd, const struct f559_out *ctl,
		     struct f559_out *out)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;
	struct f559_out o;
	char cw[1024], cr[1024], hw[512], hr[512], hc[512];
	const unsigned char *cv = f562_cand(f, cand, off);
	int kw = 0, kr = 0;

	cw[0] = 0;
	cr[0] = 0;
	memset(&o, 0, sizeof(o));
	snprintf(PRE57, sizeof(PRE57), "f62.%s.%s", env, arm);
	f557_flush(NFPROTO_BRIDGE, "p62", "g", &o.acks);

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_BRIDGE);
	put_str(nlh, NFTA_RULE_TABLE, "p62");
	put_str(nlh, NFTA_RULE_CHAIN, "g");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (gate)
		f562_meta_proto(nlh);
	if (do_rd && do_wr && !wr_first) {
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, cv, len);
		f562_store(nlh, base, (uint32_t)off, (uint32_t)len, imm);
	} else if (do_rd && do_wr && wr_first) {
		f562_store(nlh, base, (uint32_t)off, (uint32_t)len, imm);
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, cv, len);
	} else if (do_rd) {
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, cv, len);
	} else if (do_wr) {
		f562_store(nlh, base, (uint32_t)off, (uint32_t)len, imm);
	}
	log_expr(nlh, 5, PRE57);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	o.rc = f557_nft_one(opbuf, (int)nlh->nlmsg_len, &o.acks);

	nfl_drain(NFL59);
	o.cnt0 = f555_count(NFPROTO_BRIDGE, "p62", "g");
	{
		unsigned long long ip0 = f558_ipin();

		f560_send2("s0", f->sproto, wire, wlen, f->magic, f->mlen,
			   wfd, rfd, &o);
		usleep(20000);
		o.ipin = f558_ipin() - ip0;
	}
	o.cnt = f555_count(NFPROTO_BRIDGE, "p62", "g");
	if (ctl && o.wn > 0 && ctl->wn > 0)
		kw = f558_chg(cw, sizeof(cw), ctl->w, ctl->wn, o.w, o.wn);
	if (ctl && o.rn > 0 && ctl->rn > 0)
		kr = f558_chg(cr, sizeof(cr), ctl->r, ctl->rn, o.r, o.rn);
	printf("F562 R|env=%s.%s|rep=%s|gate=%d|base=%u|off=%d|len=%d|"
	       "rd=%d|cand=%s|cv=%s|wr=%d|first=%d|"
	       "rc=%d|acks=%d|snd=%d|cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|"
	       "wn=%d|wpt=%d|wchg=%d|wchgs=%s|whex=%s|"
	       "rn=%d|rpt=%d|rchg=%d|rchgs=%s|rhex=%s\n",
	       F562_SEC, env, rep, gate, (unsigned)base, off, len,
	       do_rd, do_rd ? f562_candname(cand) : "-",
	       do_rd ? f559_hexs(hc, sizeof(hc), cv, len) : "-",
	       do_wr, wr_first,
	       o.rc, o.acks, o.snd, o.cnt0, o.cnt, o.cnt - o.cnt0, o.ipin,
	       o.wn, o.wpt, kw, cw[0] ? cw : "-",
	       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn) : "-",
	       o.rn, o.rpt, kr, cr[0] ? cr : "-",
	       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn) : "-");
	if (out)
		memcpy(out, &o, sizeof(o));
}

/* ---------- ctl: the envelope arrives ---------- */

static void f562_sec_ctl(struct f562_frame *F, int n, int wfd, int rfd,
			 struct f559_out *ctls)
{
	unsigned char wire[256];
	int i;

	F562_SEC = "ctl";
	for (i = 0; i < n; i++) {
		int wlen = f562_wire(&F[i], wire);

		printf("F562 REP|rep=%s|plainlen=%d|caplen=%d|ntag=%d|"
		       "sproto=%04x|wlen=%d\n",
		       F[i].tag, F[i].plainlen, F[i].caplen, F[i].ntag,
		       F[i].sproto, wlen);
		memset(&ctls[i], 0, sizeof(ctls[i]));
		f562_arm(F[i].tag, "ctl", F[i].tag, 0,
			 NFT_PAYLOAD_NETWORK_HEADER, 0, 0, 0, 0, 0, 0, NULL,
			 &F[i], wire, wlen, wfd, rfd, NULL, &ctls[i]);
	}
}

/* ---------- rd: the read grid ---------- */

static void f562_sec_rd(struct f562_frame *F, int n, int wfd, int rfd,
			const struct f559_out *ctls)
{
	unsigned char wire[256];
	static const int reps[3] = { 0, 1, 2 };	/* p, w, q */
	int k, g, i, j, c;

	F562_SEC = "rd";
	for (k = 0; k < 3; k++) {
		int r = reps[k];
		int wlen = f562_wire(&F[r], wire);

		for (g = 0; g < 2; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (c = 0; c < 2; c++) {
				for (i = 0; i < G33_NOFF; i++) {
					for (j = 0; j < G33_NLEN; j++) {
						char arm[48];

						snprintf(arm, sizeof(arm),
							 "%s.g%d_%d", env,
							 G33_OFF[i], G33_LEN[j]);
						f562_arm(env, arm,
							 F[r].tag, g,
							 NFT_PAYLOAD_NETWORK_HEADER,
							 G33_OFF[i], G33_LEN[j],
							 1, c, 0, 0, NULL, &F[r],
							 wire, wlen, wfd, rfd,
							 &ctls[r], NULL);
					}
				}
				for (i = 0; i < G33_NEXT; i++) {
					char arm[48];

					snprintf(arm, sizeof(arm), "%s.x%d_%d",
						 env, G33_XOFF[i], G33_XLEN[i]);
					f562_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_NETWORK_HEADER,
						 G33_XOFF[i], G33_XLEN[i],
						 1, c, 0, 0, NULL, &F[r],
						 wire, wlen, wfd, rfd,
						 &ctls[r], NULL);
				}
			}
		}
	}
}

/* ---------- pair: one rule, one packet, two places ---------- */

static const struct {
	int off, len;
} F562_PAIR[2] = { { 8, 1 }, { 16, 4 } };

static void f562_sec_pair(struct f562_frame *F, int wfd, int rfd,
			  const struct f559_out *ctls)
{
	static const int reps[2] = { 0, 2 };	/* p, q */
	unsigned char wire[256], imm[16];
	int k, g, p, kind;

	F562_SEC = "pair";
	for (k = 0; k < 2; k++) {
		int r = reps[k];
		int wlen = f562_wire(&F[r], wire);

		for (g = 0; g < 2; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (p = 0; p < 2; p++) {
				for (kind = 0; kind < 3; kind++) {
					char arm[48];
					int i;

					for (i = 0; i < F562_PAIR[p].len; i++)
						imm[i] = (unsigned char)(0x90 + i);
					snprintf(arm, sizeof(arm),
						 "%s.%s_%d.%s", env,
						 kind == 0 ? "wr" :
						 kind == 1 ? "rdwr" : "wrrd",
						 F562_PAIR[p].off,
						 F562_PAIR[p].len == 1 ? "b" : "d");
					f562_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_NETWORK_HEADER,
						 F562_PAIR[p].off,
						 F562_PAIR[p].len,
						 kind != 0, 2, 1,
						 kind == 2, imm, &F[r], wire,
						 wlen, wfd, rfd, &ctls[r],
						 NULL);
				}
			}
		}
	}
}

/* ---------- ih: the transport base under the same repair ---------- */

static const struct {
	int off, len;
} F562_IH[5] = {
	{ 0, 2 }, { 0, 4 }, { 2, 2 }, { 2, 4 }, { 4, 2 },
};

static void f562_sec_ih(struct f562_frame *F, int wfd, int rfd,
			const struct f559_out *ctls)
{
	static const int reps[2] = { 0, 2 };	/* p, q */
	unsigned char wire[256], imm[16];
	int k, g, p, kind;

	F562_SEC = "ih";
	for (k = 0; k < 2; k++) {
		int r = reps[k];
		int wlen = f562_wire(&F[r], wire);

		for (g = 0; g < 2; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (p = 0; p < 5; p++) {
				for (kind = 0; kind < 3; kind++) {
					char arm[48];
					int i;

					for (i = 0; i < F562_IH[p].len; i++)
						imm[i] = (unsigned char)(0x90 + i);
					/* kind 0: cmp against T (the true
					 * transport header), kind 1: against
					 * data 0+off, kind 2: store only. */
					snprintf(arm, sizeof(arm),
						 "%s.%s_%d_%d", env,
						 kind == 0 ? "rdT" :
						 kind == 1 ? "rdW" : "wr",
						 F562_IH[p].off,
						 F562_IH[p].len);
					f562_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_TRANSPORT_HEADER,
						 F562_IH[p].off, F562_IH[p].len,
						 kind != 2, kind == 0 ? 3 : 0,
						 kind == 2, 0, imm, &F[r],
						 wire, wlen, wfd, rfd,
						 &ctls[r], NULL);
				}
			}
		}
	}
}

/* ---------- qarp: ARP in Q-in-Q, where the repair never happens ---------- */

static const struct {
	int off, len;
} F562_ARP[6] = {
	{ 0, 2 }, { 2, 2 }, { 4, 2 }, { 6, 2 }, { 8, 2 }, { 10, 2 },
};

static void f562_sec_qarp(struct f562_frame *F, int wfd, int rfd,
			  const struct f559_out *ctls)
{
	static const int reps[2] = { 3, 4 };	/* pa, qa */
	unsigned char wire[256], imm[16];
	int k, g, p, c;

	F562_SEC = "qarp";
	for (k = 0; k < 2; k++) {
		int r = reps[k];
		int wlen = f562_wire(&F[r], wire);

		for (g = 0; g < 2; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (p = 0; p < 6; p++) {
				for (c = 0; c < 2; c++) {
					char arm[48];

					snprintf(arm, sizeof(arm),
						 "%s.rd%s_%d", env,
						 f562_candname(c),
						 F562_ARP[p].off);
					f562_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_NETWORK_HEADER,
						 F562_ARP[p].off,
						 F562_ARP[p].len, 1, c, 0, 0,
						 NULL, &F[r], wire, wlen, wfd,
						 rfd, &ctls[r], NULL);
				}
				{
					char arm[48];
					int i;

					for (i = 0; i < F562_ARP[p].len; i++)
						imm[i] = (unsigned char)(0x90 + i);
					snprintf(arm, sizeof(arm), "%s.wr_%d",
						 env, F562_ARP[p].off);
					f562_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_NETWORK_HEADER,
						 F562_ARP[p].off,
						 F562_ARP[p].len, 0, 0, 1, 0,
						 imm, &F[r], wire, wlen, wfd,
						 rfd, &ctls[r], NULL);
				}
			}
		}
	}
}

/* ---------- val: the two cells whose verdict reads the packet ----------
 *
 * nft_nh_write_ok_ip4() does not only look at (offset,len):
 *   case 0:  requires len == 2 AND src[0] == the byte at data+0
 *   case 8:  with len == 2, requires src[1] == the byte at data+9
 * On a plain frame those bytes are the IPv4 version/ihl and the protocol
 * number.  On Q-in-Q with `meta protocol` in front they are the high byte of
 * the INNER tag's TCI and the low byte of the IP id -- so the value the guard
 * compares with is itself a byte of the envelope, and the cell becomes live
 * or dead depending on a byte that is not in the field the cell names.
 */
static void f562_sec_val(struct f562_frame *F, int wfd, int rfd,
			 const struct f559_out *ctls)
{
	static const int reps[2] = { 0, 2 };	/* p, q */
	unsigned char wire[256], imm[16];
	int k, g, p, v;

	F562_SEC = "val";
	for (k = 0; k < 2; k++) {
		int r = reps[k];
		int wlen = f562_wire(&F[r], wire);
		const unsigned char *data = F[r].cap + 14;

		for (g = 0; g < 2; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (p = 0; p < 2; p++) {
				for (v = 0; v < 2; v++) {
					char arm[48];
					int off = p ? 8 : 0;
					int i;

					for (i = 0; i < 2; i++)
						imm[i] = (unsigned char)(0x90 + i);
					if (!p)
						imm[0] = 0x45;	/* the ip4 way in */
					else
						imm[1] = 0x11;	/* keep proto */
					if (v) {
						/* the byte the guard actually
						 * reads, at data+off(+1) */
						if (!p)
							imm[0] = data[0];
						else
							imm[1] = data[9];
					}
					snprintf(arm, sizeof(arm), "%s.%s%d", env,
						 v ? "alt" : "std", off);
					f562_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_NETWORK_HEADER,
						 (uint32_t)off, 2, 0, 0, 1, 0,
						 imm, &F[r], wire, wlen, wfd,
						 rfd, &ctls[r], NULL);
				}
			}
		}
	}
}

/* ---------- main ---------- */

int main(int argc, char **argv)
{
	static struct f562_frame F[5];
	static struct f559_out ctls[5];
	const char *mode = argc > 1 ? argv[1] : "f562";
	int wfd, rfd;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F562 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F562 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F562 KERNEL|%s\n", "7.3.4-T558");
	f556_env_setup();
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL59 = nfl_open(5);
	printf("F562 NFL|%d\n", NFL59);

	memset(F, 0, sizeof(F));
	F[0].tag = "p";   F[0].kind = FK33_IP4; F[0].ntag = 0;
	F[1].tag = "w";   F[1].kind = FK33_IP4; F[1].ntag = 1;
	F[1].tp1 = 0x8100; F[1].tc1 = 0x0064;
	F[2].tag = "q";   F[2].kind = FK33_IP4; F[2].ntag = 2;
	F[2].tp1 = 0x88a8; F[2].tc1 = 0x0064;
	F[2].tp2 = 0x8100; F[2].tc2 = 0x00c8;
	F[3].tag = "pa";  F[3].kind = FK33_ARP; F[3].ntag = 0;
	F[4].tag = "qa";  F[4].kind = FK33_ARP; F[4].ntag = 2;
	F[4].tp1 = 0x88a8; F[4].tc1 = 0x0064;
	F[4].tp2 = 0x8100; F[4].tc2 = 0x00c8;
	{
		int i;

		for (i = 0; i < 5; i++)
			f562_build(&F[i]);
	}

	if (add_table(NFPROTO_BRIDGE, "p62") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p62", "g", 0, 0, 1, NULL)) {
		printf("F562 FAIL|chain\n");
		return 0;
	}
	wfd = cap_open("r1");
	rfd = cap_open("r0");
	printf("F562 SECTION|open|wfd=%d|rfd=%d\n", wfd, rfd);

	f562_sec_ctl(F, 5, wfd, rfd, ctls);
	if (!strcmp(mode, "f562ctl")) {
		goto done;
	} else if (!strcmp(mode, "f562rd")) {
		f562_sec_rd(F, 3, wfd, rfd, ctls);
	} else if (!strcmp(mode, "f562pair")) {
		f562_sec_pair(F, wfd, rfd, ctls);
	} else if (!strcmp(mode, "f562ih")) {
		f562_sec_ih(F, wfd, rfd, ctls);
	} else if (!strcmp(mode, "f562qarp")) {
		f562_sec_qarp(F, wfd, rfd, ctls);
	} else if (!strcmp(mode, "f562val")) {
		f562_sec_val(F, wfd, rfd, ctls);
	} else {
		f562_sec_rd(F, 3, wfd, rfd, ctls);
		f562_sec_pair(F, wfd, rfd, ctls);
		f562_sec_ih(F, wfd, rfd, ctls);
		f562_sec_qarp(F, wfd, rfd, ctls);
		f562_sec_val(F, wfd, rfd, ctls);
	}
done:
	sh("/nft flush ruleset");
	printf("F562 DONE\n");
	return 0;
}
