// SPDX-License-Identifier: GPL-2.0
/*
 * differ553.c -- turn 553 / F31: the write guard is keyed on the ENVELOPE,
 * and two of its four branches are compiled out of every image this project
 * has booted.
 *
 * F30 measured nft_nh_write_ok_ip4()/ip6() -- an offset whitelist.  The same
 * function has two more branches:
 *
 *     #ifdef CONFIG_NF_TABLES_NETDEV
 *     case NFPROTO_NETDEV:   nft_nh_write_ok_netdev()   default: return false
 *     #if IS_ENABLED(CONFIG_NF_TABLES_BRIDGE)
 *     case NFPROTO_BRIDGE:   nft_nh_write_ok_bridge()   switch (pkt->ethertype)
 *
 * and BOTH symbols are "not set" in every .config this project has booted
 * (7.2.15, 7.3, 7.3.4, P548, P549).  For the netdev family the branch is
 * unreachable even when compiled: nft_nh_write_ok() short-circuits
 *
 *     case NFPROTO_NETDEV:
 *             if (pkt->state->hook == NF_NETDEV_INGRESS)
 *                     return true;
 *             return nft_nh_write_ok_netdev(...);
 *
 * and netdev has exactly one hook, ingress.
 *
 * Three questions, each answered by the frame, the kernel's own counter or a
 * local socket -- never by reading the source:
 *
 *   A  the same arm in an ip forward chain and in a netdev ingress chain
 *   B  the same rule and the same frame bytes under three ethertypes
 *      (0x0800 / 0x8100 / 0x0806)
 *   C  where @nh actually points at ingress, measured from a delivered datagram
 *
 * output
 *   F553 <tag>|label=..|rule=..|cap=..|flen=..|nchg=..|chg=..|cnt=..|hex=..
 *   F553L <tag>|rule=..|p5000=..|p6000=..|sport=..|pay=..
 *   F553RC <tag>|<rc>
 *   F553X <tag>|<nft's own words>
 *   F553 SETUP|...
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sched.h>
#include <stdint.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <linux/if_link.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <linux/if_arp.h>
#include <linux/netfilter.h>
#include <linux/netfilter/nfnetlink.h>
#include <linux/netfilter/nf_tables.h>

#define NLA_ALIGN_(len) (((len) + 3) & ~3)
#ifndef VETH_INFO_PEER
#define VETH_INFO_PEER 1
#endif

/* ---------- netlink toolkit ---------- */

static char opbuf[2048];

static struct nlmsghdr *msg_start(char *buf, int bufsz, uint16_t type,
				  uint16_t flags, uint8_t family)
{
	struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
	struct nfgenmsg *nfg;

	memset(buf, 0, (size_t)bufsz);
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = type;
	nlh->nlmsg_flags = flags;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	return nlh;
}

static struct nlattr *attr_put(struct nlmsghdr *nlh, uint16_t type,
			       const void *payload, int len)
{
	struct nlattr *a = (struct nlattr *)((char *)nlh +
					     NLMSG_ALIGN(nlh->nlmsg_len));

	a->nla_type = type;
	a->nla_len = (uint16_t)(NLA_HDRLEN + len);
	if (len && payload)
		memcpy((char *)a + NLA_HDRLEN, payload, (size_t)len);
	nlh->nlmsg_len = NLMSG_ALIGN(nlh->nlmsg_len) + (uint32_t)NLA_ALIGN_(a->nla_len);
	return a;
}

static struct nlattr *nest_start(struct nlmsghdr *nlh, uint16_t type)
{
	return attr_put(nlh, (uint16_t)(type | NLA_F_NESTED), NULL, 0);
}

static void nest_end(struct nlmsghdr *nlh, struct nlattr *a)
{
	a->nla_len = (uint16_t)((char *)nlh + nlh->nlmsg_len - (char *)a);
}

static void put_str(struct nlmsghdr *nlh, uint16_t t, const char *s)
{
	attr_put(nlh, t, s, (int)strlen(s) + 1);
}

static void put_be32(struct nlmsghdr *nlh, uint16_t t, uint32_t v)
{
	uint32_t be = htonl(v);

	attr_put(nlh, t, &be, (int)sizeof(be));
}

static int nl_open(void)
{
	struct sockaddr_nl sa;
	struct timeval tv = { .tv_sec = 2, .tv_usec = 0 };
	int fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_NETFILTER);

	if (fd < 0)
		return -1;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -1;
	}
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return fd;
}

static int nl_send_ack(int fd, struct nlmsghdr *nlh)
{
	struct sockaddr_nl sa;
	char rbuf[4096];

	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	nlh->nlmsg_flags |= NLM_F_REQUEST | NLM_F_ACK;
	nlh->nlmsg_seq = 1;
	if (sendto(fd, nlh, nlh->nlmsg_len, 0, (struct sockaddr *)&sa,
		   sizeof(sa)) < 0)
		return -errno;
	for (;;) {
		int r = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (r <= 0)
			return -1000;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, r); h = NLMSG_NEXT(h, r)) {
			if (h->nlmsg_type == NLMSG_ERROR) {
				struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(h);

				return e->error;
			}
		}
	}
}

/* ---------- rtnetlink ---------- */

static int rtnl_open(void)
{
	struct sockaddr_nl sa;
	struct timeval tv = { .tv_sec = 2, .tv_usec = 0 };
	int fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);

	if (fd < 0)
		return -1;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -2;
	}
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return fd;
}

static int rtnl_talk(int fd, struct nlmsghdr *nlh)
{
	struct sockaddr_nl sa;
	char rbuf[4096];
	struct nlmsghdr *rh;
	int r;

	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	nlh->nlmsg_flags |= NLM_F_REQUEST | NLM_F_ACK;
	nlh->nlmsg_seq = 1;
	nlh->nlmsg_pid = 0;
	if (sendto(fd, nlh, nlh->nlmsg_len, 0, (struct sockaddr *)&sa,
		   sizeof(sa)) < 0)
		return -errno;
	r = (int)recv(fd, rbuf, sizeof(rbuf), 0);
	if (r < (int)(NLMSG_HDRLEN + sizeof(struct nlmsgerr)))
		return -1000;
	rh = (struct nlmsghdr *)rbuf;
	if (rh->nlmsg_type == NLMSG_ERROR) {
		struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(rh);

		return e->error;
	}
	return -1001;
}

static int f553_ifindex(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int idx = -1;

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFINDEX, &ifr) == 0)
		idx = ifr.ifr_ifindex;
	close(s);
	return idx;
}

static int mac_get(const char *dev, unsigned char *out)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFHWADDR, &ifr) < 0) {
		close(s);
		return -1;
	}
	memcpy(out, ifr.ifr_hwaddr.sa_data, 6);
	close(s);
	return 0;
}

static int set_up(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFFLAGS, &ifr) < 0) {
		close(s);
		return -1;
	}
	ifr.ifr_flags |= IFF_UP | IFF_RUNNING;
	if (ioctl(s, SIOCSIFFLAGS, &ifr) < 0) {
		close(s);
		return -1;
	}
	close(s);
	return 0;
}

static int link_add_veth(const char *a, const char *b)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[512];
	} req;
	struct ifinfomsg zifi;
	struct nlattr *li, *data, *peer;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, a, (int)strlen(a) + 1);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, "veth", 5);
	data = nest_start(&req.nlh, IFLA_INFO_DATA);
	memset(&zifi, 0, sizeof(zifi));
	zifi.ifi_family = AF_UNSPEC;
	peer = attr_put(&req.nlh, (uint16_t)(VETH_INFO_PEER | NLA_F_NESTED), &zifi,
			(int)sizeof(zifi));
	attr_put(&req.nlh, IFLA_IFNAME, b, (int)strlen(b) + 1);
	nest_end(&req.nlh, peer);
	nest_end(&req.nlh, data);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int link_add_kind(const char *name, const char *kind)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[256];
	} req;
	struct nlattr *li;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, name, (int)strlen(name) + 1);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, kind, (int)strlen(kind) + 1);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int link_enslave(const char *port, const char *master)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[128];
	} req;
	uint32_t midx = (uint32_t)f553_ifindex(master);
	int fd, rc;

	if ((int)midx < 0)
		return -10;
	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	req.ifi.ifi_index = f553_ifindex(port);
	attr_put(&req.nlh, IFLA_MASTER, &midx, 4);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f553_addr_add(const char *dev, uint32_t addr_be, int plen)
{
	struct {
		struct nlmsghdr nlh;
		struct ifaddrmsg ifa;
		char attrs[128];
	} req;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifaddrmsg));
	req.nlh.nlmsg_type = RTM_NEWADDR;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_REPLACE;
	req.nlh.nlmsg_seq = 1;
	req.ifa.ifa_family = AF_INET;
	req.ifa.ifa_prefixlen = (uint8_t)plen;
	req.ifa.ifa_scope = 0;
	req.ifa.ifa_index = (uint32_t)f553_ifindex(dev);
	attr_put(&req.nlh, IFA_LOCAL, &addr_be, 4);
	attr_put(&req.nlh, IFA_ADDRESS, &addr_be, 4);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f553_arp(const char *dev, uint32_t dst, const unsigned char *mac)
{
	struct arpreq req;
	struct sockaddr_in *sin;
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int rc;

	if (s < 0)
		return -1;
	memset(&req, 0, sizeof(req));
	sin = (struct sockaddr_in *)&req.arp_pa;
	sin->sin_family = AF_INET;
	sin->sin_addr.s_addr = htonl(dst);
	req.arp_ha.sa_family = ARPHRD_ETHER;
	memcpy(req.arp_ha.sa_data, mac, 6);
	req.arp_flags = ATF_PERM | ATF_COM;
	snprintf(req.arp_dev, sizeof(req.arp_dev), "%s", dev);
	rc = ioctl(s, SIOCSARP, &req);
	close(s);
	return rc;
}

static int f553_sysctl(const char *path, const char *val)
{
	int fd = open(path, O_WRONLY);
	int rc;

	if (fd < 0)
		return -1;
	rc = (int)write(fd, val, strlen(val));
	close(fd);
	return rc < 0 ? -1 : 0;
}

/* ---------- frames ---------- */

enum { FK_IPU = 0, FK_IPUV, FK_IP91, FK_ARPIP, FK_ARPPAD, FK_ARPRAW, FK_N };

static unsigned short f553_csum(const void *data, int len)
{
	const unsigned char *p = data;
	unsigned int sum = 0;

	while (len > 1) {
		sum += (unsigned int)((p[0] << 8) | p[1]);
		p += 2;
		len -= 2;
	}
	if (len)
		sum += (unsigned int)(p[0] << 8);
	while (sum >> 16)
		sum = (sum & 0xffff) + (sum >> 16);
	return (unsigned short)~sum;
}

#define F553_IPID 0x5531

static const unsigned char MAC_SRC[6] = { 0xaa, 0xbb, 0xcc, 0x00, 0x00, 0x66 };
static const unsigned char MAC_DST[6] = { 0xaa, 0xbb, 0xcc, 0x00, 0x00, 0x77 };
static const unsigned char MAC_NEI[6] = { 0xaa, 0xbb, 0xcc, 0x00, 0x00, 0x88 };

/* one frame; returns its length.  The IPv4 datagram body is identical for
 * FK_IPU / FK_IPUV / FK_ARPIP -- only the ethernet label differs. */
static int build_frame(int kind, const unsigned char *dstmac,
		       const unsigned char *srcmac, uint32_t sip, uint32_t dip,
		       int sport, int dport, int plen, unsigned char *out)
{
	unsigned char *eth = out;
	int hl, i;
	unsigned char *ip, *udp;

	memset(out, 0, 160);
	memcpy(eth, dstmac, 6);
	memcpy(eth + 6, srcmac, 6);
	switch (kind) {
	case FK_IPU:
		eth[12] = 0x08; eth[13] = 0x00;
		hl = 14;
		break;
	case FK_IPUV:			/* 802.1Q, VID 100 */
		eth[12] = 0x81; eth[13] = 0x00;
		eth[14] = 0x00; eth[15] = 0x64;
		eth[16] = 0x08; eth[17] = 0x00;
		hl = 18;
		break;
	case FK_IP91:			/* QinQ-ish label the vlan layer ignores */
		eth[12] = 0x91; eth[13] = 0x00;
		hl = 14;
		break;
	default:
		eth[12] = 0x08; eth[13] = 0x06;	/* label says ARP */
		hl = 14;
		break;
	}
	if (kind == FK_ARPPAD || kind == FK_ARPRAW) {
		unsigned char *a = out + hl;
		uint32_t be_s = htonl(sip), be_d = htonl(dip);

		a[0] = 0x00; a[1] = 0x01;
		a[2] = 0x08; a[3] = 0x00;
		a[4] = 6; a[5] = 4;
		a[6] = 0x00; a[7] = 0x01;
		memcpy(a + 8, srcmac, 6);
		memcpy(a + 14, &be_s, 4);
		memset(a + 18, 0x22, 6);
		memcpy(a + 24, &be_d, 4);
		return kind == FK_ARPPAD ? 60 : hl + 28;
	}
	ip = out + hl;
	ip[0] = 0x45;
	ip[1] = 0x00;
	ip[2] = (unsigned char)((20 + 8 + plen) >> 8);
	ip[3] = (unsigned char)((20 + 8 + plen) & 0xff);
	ip[4] = (unsigned char)(F553_IPID >> 8);
	ip[5] = (unsigned char)(F553_IPID & 0xff);
	ip[6] = ip[7] = 0;
	ip[8] = 64;
	ip[9] = IPPROTO_UDP;
	{
		uint32_t be_s = htonl(sip), be_d = htonl(dip);

		memcpy(ip + 12, &be_s, 4);
		memcpy(ip + 16, &be_d, 4);
	}
	*(unsigned short *)(ip + 10) = htons(f553_csum(ip, 20));
	udp = ip + 20;
	udp[0] = (unsigned char)(sport >> 8);
	udp[1] = (unsigned char)(sport & 0xff);
	udp[2] = (unsigned char)(dport >> 8);
	udp[3] = (unsigned char)(dport & 0xff);
	udp[4] = (unsigned char)((8 + plen) >> 8);
	udp[5] = (unsigned char)((8 + plen) & 0xff);
	udp[6] = udp[7] = 0;
	for (i = 0; i < plen; i++)
		udp[8 + i] = 0x77;
	return hl + 20 + 8 + plen;
}

static int pkt_send(const char *dev, const unsigned char *fr, int len)
{
	struct sockaddr_ll sll;
	int s, rc, idx = f553_ifindex(dev);

	if (idx < 0)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_ALL);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, fr, 6);
	rc = (int)sendto(s, fr, (size_t)len, 0, (struct sockaddr *)&sll, sizeof(sll));
	close(s);
	return rc < 0 ? -errno : 0;
}

static int cap_open(const char *dev)
{
	struct sockaddr_ll sll;
	int s, idx = f553_ifindex(dev);

	if (idx < 0)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_ALL);
	sll.sll_ifindex = idx;
	if (bind(s, (struct sockaddr *)&sll, sizeof(sll)) < 0) {
		close(s);
		return -3;
	}
	fcntl(s, F_SETFL, fcntl(s, F_GETFL, 0) | O_NONBLOCK);
	return s;
}

static void cap_drain(int s)
{
	unsigned char b[2048];

	while (recv(s, b, sizeof(b), 0) > 0)
		;
}

/* The first frame that belongs to this experiment, within ms.
 *
 * Filtering is not cosmetic: a bridge brings up IPv6 on br0 and the kernel
 * starts emitting neighbour solicitations, so "the first frame on the capture
 * socket" was, twice, a 70-byte ICMPv6 frame with nothing to do with the arm
 * (measured in the smoke run of this turn).  Ours are the only frames whose
 * source address is MAC_SRC (bridged) or whose destination is MAC_NEI
 * (forwarded). */
static int cap_one(int s, unsigned char *buf, int max, int ms,
		   const unsigned char *mac, int on_src)
{
	struct timeval tv = { .tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000 };
	struct timeval deadline = tv;
	struct timeval now0, now1;
	fd_set rfds;
	int r;

	gettimeofday(&now0, NULL);
	for (;;) {
		FD_ZERO(&rfds);
		FD_SET(s, &rfds);
		if (select(s + 1, &rfds, NULL, NULL, &deadline) <= 0)
			return 0;
		r = (int)recv(s, buf, (size_t)max, 0);
		if (r <= 0)
			return 0;
		if (r >= 12 &&
		    ((on_src && !memcmp(buf + 6, mac, 6)) ||
		     (!on_src && !memcmp(buf, mac, 6))))
			return r;
		gettimeofday(&now1, NULL);
		{
			long used = (now1.tv_sec - now0.tv_sec) * 1000 +
				    (now1.tv_usec - now0.tv_usec) / 1000;

			if (used >= ms)
				return 0;
			deadline.tv_sec = 0;
			deadline.tv_usec = (ms - used) * 1000;
			tv.tv_sec = 0;
			tv.tv_usec = (ms - used) * 1000;
		}
	}
}

/* ---------- rules over raw netlink ---------- */

static void imm_value(struct nlmsghdr *nlh, uint32_t dreg, const void *val, int len)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "immediate");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_IMMEDIATE_DREG, dreg);
	{
		struct nlattr *v = nest_start(nlh, NFTA_IMMEDIATE_DATA);

		attr_put(nlh, NFTA_DATA_VALUE, val, len);
		nest_end(nlh, v);
	}
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void counter_expr(struct nlmsghdr *nlh)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "counter");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void accept_expr(struct nlmsghdr *nlh)
{
	struct nlattr *e, *d;
	uint32_t code = htonl(NF_ACCEPT);

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "immediate");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_IMMEDIATE_DREG, NFT_REG_VERDICT);
	{
		struct nlattr *v = nest_start(nlh, NFTA_IMMEDIATE_DATA);
		struct nlattr *vd = nest_start(nlh, NFTA_DATA_VERDICT);

		attr_put(nlh, NFTA_VERDICT_CODE, &code, 4);
		nest_end(nlh, vd);
		nest_end(nlh, v);
	}
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* send a whole nfnetlink batch and return the first error the kernel reports
 * (0 = every message was acknowledged) */
static int batch_send(int fd, char *buf, int len)
{
	char rbuf[8192];
	int err = 0, acked = 0;

	if (send(fd, buf, (size_t)len, 0) != len)
		return -1000 - errno;
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			if (h->nlmsg_type != NLMSG_ERROR)
				continue;
			{
				struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(h);

				if (e->error && !err)
					err = e->error;
				acked++;
			}
		}
	}
	(void)acked;
	return err;
}

/* one rule: [store @network+off = imm][counter][accept?] */
static int install_store(int family, const char *table, const char *chain,
			 uint32_t off, uint32_t len, const unsigned char *imm,
			 int immlen, int verdict)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *e, *d;
	int fd, rc;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			(uint8_t)family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	imm_value(nlh, NFT_REG32_00, imm, immlen);
	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "payload");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00);
	put_be32(nlh, NFTA_PAYLOAD_BASE, NFT_PAYLOAD_NETWORK_HEADER);
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
	put_be32(nlh, NFTA_PAYLOAD_LEN, len);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
	nest_end(nlh, d);
	nest_end(nlh, e);
	counter_expr(nlh);
	if (verdict)
		accept_expr(nlh);
	nest_end(nlh, exprs);
	{
		char batch[4096];
		struct nlmsghdr *bn, *en;
		int off, len;

		len = (int)nlh->nlmsg_len;
		bn = msg_start(batch, (int)sizeof(batch), NFNL_MSG_BATCH_BEGIN,
			       NLM_F_REQUEST, 0);
		((struct nfgenmsg *)NLMSG_DATA(bn))->res_id =
			htons(NFNL_SUBSYS_NFTABLES);
		off = (int)NLMSG_ALIGN(bn->nlmsg_len);
		memcpy(batch + off, nlh, (size_t)NLMSG_ALIGN(len));
		off += (int)NLMSG_ALIGN(len);
		en = msg_start(batch + off, (int)(sizeof(batch) - off),
			       NFNL_MSG_BATCH_END, NLM_F_REQUEST, 0);
		((struct nfgenmsg *)NLMSG_DATA(en))->res_id =
			htons(NFNL_SUBSYS_NFTABLES);
		off += (int)NLMSG_ALIGN(en->nlmsg_len);
		fd = nl_open();
		if (fd < 0)
			return -1;
		rc = batch_send(fd, batch, off);
		close(fd);
		return rc;
	}
}

/* counter read-back without nft's printer (nft 1.1.7 aborts on some of these
 * rules -- F30 lost three arms to that) */
static unsigned long long f553_count(uint8_t family, const char *table,
				     const char *chain)
{
	char buf[1024], rbuf[16384];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	unsigned long long pkts = 0;
	int fd, sent;

	fd = nl_open();
	if (fd < 0)
		return 0;
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1);
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1);
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return 0;
	}
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			const char *p, *end;

			if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
				goto out;
			if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				continue;
			p = (const char *)h + NLMSG_HDRLEN + sizeof(*nfg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || p + alen > end)
					break;
				if ((a->nla_type & 0x3fff) == NFTA_RULE_EXPRESSIONS) {
					const char *q = (const char *)a + NLA_HDRLEN;
					const char *qe = (const char *)a + alen;

					for (; q + (int)sizeof(struct nlattr) <= qe; ) {
						const struct nlattr *el = (const struct nlattr *)q;
						int ell = (int)el->nla_len;
						const char *r, *re;
						int is_cnt = 0;

						if (ell < (int)sizeof(*el) || q + ell > qe)
							break;
						r = (const char *)el + NLA_HDRLEN;
						re = (const char *)el + ell;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int eal = (int)ea->nla_len;

							if (eal < (int)sizeof(*ea) || r + eal > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_NAME &&
							    !strcmp((const char *)ea + NLA_HDRLEN, "counter"))
								is_cnt = 1;
							r += NLA_ALIGN_(eal);
						}
						if (is_cnt) {
							r = (const char *)el + NLA_HDRLEN;
							for (; r + (int)sizeof(struct nlattr) <= re; ) {
								const struct nlattr *ea = (const struct nlattr *)r;
								int eal = (int)ea->nla_len;

								if (eal < (int)sizeof(*ea) || r + eal > re)
									break;
								if ((ea->nla_type & 0x3fff) == NFTA_EXPR_DATA) {
									const char *d = (const char *)ea + NLA_HDRLEN;
									const char *de = (const char *)ea + eal;

									for (; d + (int)sizeof(struct nlattr) <= de; ) {
										const struct nlattr *da = (const struct nlattr *)d;
										int dal = (int)da->nla_len;

										if (dal < (int)sizeof(*da) || d + dal > de)
											break;
										if ((da->nla_type & 0x3fff) == NFTA_COUNTER_PACKETS) {
											int k, bl = dal - NLA_HDRLEN;
											unsigned long long v = 0;
											const unsigned char *b =
												(const unsigned char *)da + NLA_HDRLEN;

											for (k = 0; k < bl && k < 8; k++)
												v = (v << 8) | b[k];
											pkts += v;
										}
										d += NLA_ALIGN_(dal);
									}
								}
								r += NLA_ALIGN_(eal);
							}
						}
						q += NLA_ALIGN_(ell);
					}
				}
				p += NLA_ALIGN_(alen);
			}
		}
	}
out:
	close(fd);
	return pkts;
}

/* ---------- diagnostic: what is actually in the chain ----------
 * F553D <table>.<chain>|rules=<n>|r0=<expr names>[|r1=...]
 * Each rule is printed as the list of its expression names, and a payload
 * expression prints base/off/len/sreg, so an inert rule is distinguishable
 * from a rule that is not there. */
static void dump_chain(uint8_t family, const char *table, const char *chain)
{
	char buf[1024], rbuf[16384];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	int fd, sent, nrules = 0;

	fd = nl_open();
	if (fd < 0)
		return;
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1);
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1);
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return;
	}
	printf("F553D %s.%s|", table, chain);
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			const char *p, *end;

			if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
				goto done;
			if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				continue;
			printf("r%d=[", nrules);
			p = (const char *)h + NLMSG_HDRLEN + sizeof(*nfg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || p + alen > end)
					break;
				if ((a->nla_type & 0x3fff) == NFTA_RULE_EXPRESSIONS) {
					const char *q = (const char *)a + NLA_HDRLEN;
					const char *qe = (const char *)a + alen;

					for (; q + (int)sizeof(struct nlattr) <= qe; ) {
						const struct nlattr *el = (const struct nlattr *)q;
						int ell = (int)el->nla_len;
						const char *r, *re;
						const char *name = "?";

						if (ell < (int)sizeof(*el) || q + ell > qe)
							break;
						r = (const char *)el + NLA_HDRLEN;
						re = (const char *)el + ell;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int eal = (int)ea->nla_len;

							if (eal < (int)sizeof(*ea) || r + eal > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_NAME)
								name = (const char *)ea + NLA_HDRLEN;
							r += NLA_ALIGN_(eal);
						}
						printf("%s", name);
						r = (const char *)el + NLA_HDRLEN;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int eal = (int)ea->nla_len;

							if (eal < (int)sizeof(*ea) || r + eal > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_DATA) {
								const char *d = (const char *)ea + NLA_HDRLEN;
								const char *de = (const char *)ea + eal;
								const char *nm2 = NULL;
								uint32_t base = 999, off = 999, len = 999,
									 sreg = 999, cst = 999, cso = 999;

								for (; d + (int)sizeof(struct nlattr) <= de; ) {
									const struct nlattr *da = (const struct nlattr *)d;
									int dal = (int)da->nla_len;

									if (dal < (int)sizeof(*da) || d + dal > de)
										break;
									switch (da->nla_type & 0x3fff) {
									case NFTA_PAYLOAD_BASE:
										base = ntohl(*(uint32_t *)((const char *)da + NLA_HDRLEN));
										break;
									case NFTA_PAYLOAD_OFFSET:
										off = ntohl(*(uint32_t *)((const char *)da + NLA_HDRLEN));
										break;
									case NFTA_PAYLOAD_LEN:
										len = ntohl(*(uint32_t *)((const char *)da + NLA_HDRLEN));
										break;
									case NFTA_PAYLOAD_SREG:
										sreg = ntohl(*(uint32_t *)((const char *)da + NLA_HDRLEN));
										break;
									case NFTA_PAYLOAD_CSUM_TYPE:
										cst = ntohl(*(uint32_t *)((const char *)da + NLA_HDRLEN));
										break;
									case NFTA_PAYLOAD_CSUM_OFFSET:
										cso = ntohl(*(uint32_t *)((const char *)da + NLA_HDRLEN));
										break;
									default:
										break;
									}
									(void)nm2;
									d += NLA_ALIGN_(dal);
								}
								if (base != 999)
									printf("(b%u,o%u,l%u,s%u,ct%u,co%u)",
									       base, off, len, sreg, cst, cso);
							}
							r += NLA_ALIGN_(eal);
						}
						printf(" ");
						q += NLA_ALIGN_(ell);
					}
				}
				p += NLA_ALIGN_(alen);
			}
			printf("] ");
			nrules++;
		}
	}
done:
	printf("|rules=%d\n", nrules);
	close(fd);
}

/* ---------- nft through the shell ---------- */

static int sh(const char *cmd)
{
	char full[2048];
	int rc;

	snprintf(full, sizeof(full), "%s >/tmp/f553o 2>&1", cmd);
	rc = system(full);
	return WIFEXITED(rc) ? WEXITSTATUS(rc) : 1000 + rc;
}

static void sh_out(const char *tag)
{
	FILE *f = fopen("/tmp/f553o", "r");
	char line[1024];

	if (!f)
		return;
	while (fgets(line, sizeof(line), f)) {
		char *nl = strchr(line, '\n');

		if (nl)
			*nl = 0;
		if (*line)
			printf("F553X %s|%s\n", tag, line);
	}
	fclose(f);
}

static int nft(const char *tag, const char *cmd)
{
	int rc = sh(cmd);

	printf("F553RC %s|%d\n", tag, rc);
	sh_out(tag);
	return rc;
}

/* ---------- arms ---------- */

struct armq {
	const char *tag;
	const char *label;
	const char *rule;
	uint8_t fam;
	const char *table;
	const char *chain;
	const char *flush;	/* nft flush chain ... (NULL: no flush) */
	int install;		/* 0 control, 1 raw netlink, 2 nft */
	const char *nftcmd;
	uint32_t off, len;
	unsigned char imm[16];
	int immlen, verdict;
	const unsigned char *cap_mac;	/* which address identifies our frame */
	int cap_on_src;			/* 1: match the source, 0: the destination */
};

static void report(const char *tag, const char *label, const char *rule,
		   const unsigned char *cap, int flen,
		   const unsigned char *ctl, int clen, unsigned long long cnt)
{
	char chg[1024];
	int i, nchg = 0;

	chg[0] = 0;
	if (flen > 0 && ctl && clen > 0) {
		for (i = 0; i < flen && i < clen; i++) {
			size_t at;

			if (cap[i] == ctl[i])
				continue;
			nchg++;
			at = strlen(chg);
			if (at < sizeof(chg) - 24)
				snprintf(chg + at, sizeof(chg) - at, "%s%d:%02x>%02x",
					 nchg > 1 ? "," : "", i, ctl[i], cap[i]);
		}
	}
	printf("F553 %s|label=%s|rule=%s|cap=%d|flen=%d|nchg=%d|chg=%s|cnt=%llu|hex=",
	       tag, label, rule ? rule : "none", flen > 0, flen, nchg,
	       chg[0] ? chg : "-", cnt);
	for (i = 0; i < flen && i < 200; i++)
		printf("%02x", cap[i]);
	printf("\n");
}

/* install -> send one frame -> capture -> read the kernel's counter -> print */
static void run_arm(const struct armq *a, const unsigned char *fr, int flen,
		    const char *senddev, int capfd, const unsigned char *ctl,
		    int clen)
{
	unsigned char cap[2048];
	unsigned long long cnt;
	int ncap, rc = 0;

	if (a->flush)
		sh(a->flush);
	if (a->install == 1)
		rc = install_store(a->fam, a->table, a->chain, a->off, a->len, a->imm,
				   a->immlen, a->verdict);
	else if (a->install == 2)
		rc = nft(a->tag, a->nftcmd);
	if (rc)
		printf("F553RC %s|%d\n", a->tag, rc);
	cap_drain(capfd);
	usleep(20000);
	{
		int s = pkt_send(senddev, fr, flen);

		if (s)
			printf("F553 SEND_FAIL|%s|%d\n", a->tag, s);
	}
	memset(cap, 0, sizeof(cap));
	ncap = cap_one(capfd, cap, (int)sizeof(cap), 500,
		       a->cap_mac ? a->cap_mac : MAC_SRC, a->cap_on_src);
	cnt = f553_count(a->fam, a->table, a->chain);
	report(a->tag, a->label, a->rule, cap, ncap, ctl, clen, cnt);
}

/* ---------- the environment ---------- */

static unsigned char MAC_I0[6], MAC_L0[6];
static int CAP_O1 = -1, CAP_R0 = -1;

static int env_setup(void)
{
	const char *pairs[][2] = {
		{ "i0", "i1" }, { "o0", "o1" }, { "l0", "l1" },
		{ "s0", "s1" }, { "r0", "r1" },
	};
	int i, rc = 0;

	for (i = 0; i < (int)(sizeof(pairs) / sizeof(pairs[0])); i++) {
		int r = link_add_veth(pairs[i][0], pairs[i][1]);

		if (r) {
			printf("F553 SETUP|veth=%s_%s|rc=%d\n", pairs[i][0],
			       pairs[i][1], r);
			rc |= 1;
		}
		if (set_up(pairs[i][0]) || set_up(pairs[i][1])) {
			printf("F553 SETUP|up=%s_%s|rc=-1\n", pairs[i][0], pairs[i][1]);
			rc |= 1;
		}
	}
	set_up("lo");
	f553_addr_add("i0", htonl(0x0a010001), 24);	/* 10.1.0.1 */
	f553_addr_add("o0", htonl(0x0a090001), 24);	/* 10.9.0.1 */
	f553_addr_add("l0", htonl(0x0a020001), 24);	/* 10.2.0.1 */
	f553_arp("o0", 0x0a090007, MAC_NEI);
	rc |= link_add_kind("br0", "bridge") ? 2 : 0;
	set_up("br0");
	rc |= link_enslave("s1", "br0") ? 4 : 0;
	rc |= link_enslave("r1", "br0") ? 8 : 0;
	f553_sysctl("/proc/sys/net/ipv4/ip_forward", "1");
	f553_sysctl("/proc/sys/net/ipv4/conf/all/rp_filter", "0");
	f553_sysctl("/proc/sys/net/ipv4/conf/default/rp_filter", "0");
	f553_sysctl("/proc/sys/net/ipv4/conf/i0/rp_filter", "0");
	f553_sysctl("/proc/sys/net/ipv4/conf/l0/rp_filter", "0");
	f553_sysctl("/proc/sys/net/ipv4/conf/o0/rp_filter", "0");
	mac_get("i0", MAC_I0);
	mac_get("l0", MAC_L0);
	CAP_O1 = cap_open("o1");
	CAP_R0 = cap_open("r0");
	printf("F553 SETUP|rc=%d|mac_i0=%02x:%02x:%02x:%02x:%02x:%02x|"
	       "mac_l0=%02x:%02x:%02x:%02x:%02x:%02x|cap_o1=%d|cap_r0=%d\n", rc,
	       MAC_I0[0], MAC_I0[1], MAC_I0[2], MAC_I0[3], MAC_I0[4], MAC_I0[5],
	       MAC_L0[0], MAC_L0[1], MAC_L0[2], MAC_L0[3], MAC_L0[4], MAC_L0[5],
	       CAP_O1, CAP_R0);
	return rc;
}

/* ---------- S0 ---------- */

static int HAVE_NETDEV, HAVE_BRIDGE;

static void sec_s0(void)
{
	int rc;

	sh("/nft flush ruleset");
	rc = nft("s0.netdev", "/nft add table netdev p553n");
	HAVE_NETDEV = (rc == 0);
	rc = nft("s0.bridge", "/nft add table bridge p553b");
	HAVE_BRIDGE = (rc == 0);
	rc = nft("s0.ip", "/nft add table ip p553f");
	printf("F553 FAM|netdev=%d|bridge=%d|ip=%d\n", HAVE_NETDEV, HAVE_BRIDGE,
	       rc == 0);
}

/* ---------- A/B: ip forward vs netdev ingress, one frame ---------- */

static void sec_forward(const unsigned char *base, int blen)
{
	unsigned char fr[160];
	int flen;
	struct armq a;

	flen = build_frame(FK_IPU, MAC_I0, MAC_SRC, 0x0a010009, 0x0a090007,
			   40000, 5000, 16, fr);

	/* A: the ip family, hook forward -- the guard F30 measured */
	nft("sa.table", "/nft add table ip p553f2");
	nft("sa.chain", "/nft add chain ip p553f2 c '{ type filter hook forward priority 0; policy accept; }'");
	memset(&a, 0, sizeof(a));
	a.fam = NFPROTO_IPV4;
	a.table = "p553f2";
	a.chain = "c";
	a.flush = "/nft flush chain ip p553f2 c";
	a.install = 1;
	a.cap_mac = MAC_NEI;
	a.cap_on_src = 0;
	a.label = "0x0800";
	/* forward the packet untouched: the store is in the udp payload */
	a.tag = "sa.raw42";
	a.rule = "@nh,336,16 set 0xcafe";
	a.off = 42; a.len = 2; a.immlen = 2;
	a.imm[0] = 0xca; a.imm[1] = 0xfe;
	run_arm(&a, fr, flen, "i1", CAP_O1, base, blen);
	/* a store the ip4 whitelist refuses: ttl+proto+cksum in one 4-byte write */
	a.tag = "sa.raw8";
	a.rule = "@nh,64,32 set 0x3e11aabb";
	a.off = 8; a.len = 4; a.immlen = 4;
	a.imm[0] = 0x3e; a.imm[1] = 0x11; a.imm[2] = 0xaa; a.imm[3] = 0xbb;
	run_arm(&a, fr, flen, "i1", CAP_O1, base, blen);
	/* allowed by the whitelist (ttl, len 1) and visible in the frame: the
	 * control that separates "store refused" from "chain not reached" */
	a.tag = "sa.raw8ttl";
	a.rule = "@nh,64,8 set 0x20";
	a.off = 8; a.len = 1; a.immlen = 1;
	a.imm[0] = 0x20;
	run_arm(&a, fr, flen, "i1", CAP_O1, base, blen);
	dump_chain(NFPROTO_IPV4, "p553f2", "c");
	/* allowed (daddr, len <= 4), same value: counter says the chain is live */
	a.tag = "sa.raw16";
	a.rule = "@nh,128,32 set 0x0a090007";
	a.off = 16; a.len = 4; a.immlen = 4;
	a.imm[0] = 0x0a; a.imm[1] = 0x09; a.imm[2] = 0x00; a.imm[3] = 0x07;
	run_arm(&a, fr, flen, "i1", CAP_O1, base, blen);
	/* the human spelling of the same thing */
	a.tag = "sa.kw.length";
	a.rule = "ip length set 0x0030";
	a.off = 2; a.len = 2; a.immlen = 2;
	a.imm[0] = 0x00; a.imm[1] = 0x30;
	a.install = 2;
	a.nftcmd = "/nft add rule ip p553f2 c 'ip length set 0x0030 counter'";
	run_arm(&a, fr, flen, "i1", CAP_O1, base, blen);
	/* the same chain, a spelling the whitelist allows */
	a.tag = "sa.kw.daddr";
	a.rule = "ip daddr set 10.9.0.7";
	a.nftcmd = "/nft add rule ip p553f2 c 'ip daddr set 10.9.0.7 counter'";
	run_arm(&a, fr, flen, "i1", CAP_O1, base, blen);
	sh("/nft flush ruleset");

	if (!HAVE_NETDEV) {
		static const char *sk[] = { "sb.raw42", "sb.raw8", "sb.raw8ttl",
					    "sb.raw16", "sb.kw.length", "sb.kw.daddr" };
		unsigned int q;

		for (q = 0; q < sizeof(sk) / sizeof(sk[0]); q++)
			printf("F553 %s|SKIP=no-netdev-family\n", sk[q]);
		return;
	}
	/* B: the same three arms at ingress, where the guard is not called */
	nft("sb.table", "/nft add table netdev p553n2");
	nft("sb.chain", "/nft add chain netdev p553n2 ing '{ type filter hook ingress device \"i0\" priority 0; policy accept; }'");
	memset(&a, 0, sizeof(a));
	a.fam = NFPROTO_NETDEV;
	a.table = "p553n2";
	a.chain = "ing";
	a.flush = "/nft flush chain netdev p553n2 ing";
	a.install = 1;
	a.cap_mac = MAC_NEI;
	a.cap_on_src = 0;
	a.label = "0x0800";
	a.tag = "sb.raw42";
	a.rule = "@nh,336,16 set 0xcafe";
	a.off = 42; a.len = 2; a.immlen = 2;
	a.imm[0] = 0xca; a.imm[1] = 0xfe;
	run_arm(&a, fr, flen, "i1", CAP_O1, base, blen);
	a.tag = "sb.raw8";
	a.rule = "@nh,64,32 set 0x3e11aabb";
	a.off = 8; a.len = 4; a.immlen = 4;
	a.imm[0] = 0x3e; a.imm[1] = 0x11; a.imm[2] = 0xaa; a.imm[3] = 0xbb;
	run_arm(&a, fr, flen, "i1", CAP_O1, base, blen);
	a.tag = "sb.raw8ttl";
	a.rule = "@nh,64,8 set 0x20";
	a.off = 8; a.len = 1; a.immlen = 1;
	a.imm[0] = 0x20;
	run_arm(&a, fr, flen, "i1", CAP_O1, base, blen);
	dump_chain(NFPROTO_NETDEV, "p553n2", "ing");
	a.tag = "sb.raw16";
	a.rule = "@nh,128,32 set 0x0a090007";
	a.off = 16; a.len = 4; a.immlen = 4;
	a.imm[0] = 0x0a; a.imm[1] = 0x09; a.imm[2] = 0x00; a.imm[3] = 0x07;
	run_arm(&a, fr, flen, "i1", CAP_O1, base, blen);
	a.tag = "sb.kw.length";
	a.rule = "ip length set 0x0030";
	a.off = 2; a.len = 2; a.immlen = 2;
	a.imm[0] = 0x00; a.imm[1] = 0x30;
	a.install = 2;
	a.nftcmd = "/nft add rule netdev p553n2 ing 'ip length set 0x0030 counter'";
	run_arm(&a, fr, flen, "i1", CAP_O1, base, blen);
	a.tag = "sb.kw.daddr";
	a.rule = "ip daddr set 10.9.0.7";
	a.nftcmd = "/nft add rule netdev p553n2 ing 'ip daddr set 10.9.0.7 counter'";
	run_arm(&a, fr, flen, "i1", CAP_O1, base, blen);
	sh("/nft flush ruleset");
}

/* ---------- C: what a store at ingress can do to a local socket ---------- */

static int udp_open(int port)
{
	struct sockaddr_in a;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	if (s < 0)
		return -1;
	memset(&a, 0, sizeof(a));
	a.sin_family = AF_INET;
	a.sin_port = htons((uint16_t)port);
	a.sin_addr.s_addr = htonl(INADDR_ANY);
	if (bind(s, (struct sockaddr *)&a, sizeof(a)) < 0) {
		close(s);
		return -1;
	}
	fcntl(s, F_SETFL, fcntl(s, F_GETFL, 0) | O_NONBLOCK);
	return s;
}

static void sec_local(void)
{
	unsigned char fr[160], pay[128];
	int flen, s5, s6, got5, got6, sport = 0, paylen = 0, i, r, k;
	struct armq a;

	if (!HAVE_NETDEV) {
		printf("F553 sd.ctl|SKIP=no-netdev-family\n");
		printf("F553 sd.nh22|SKIP=no-netdev-family\n");
		printf("F553 sd.nh36|SKIP=no-netdev-family\n");
		return;
	}
	flen = build_frame(FK_IPU, MAC_L0, MAC_SRC, 0x0a020009, 0x0a020001,
			   40000, 5000, 16, fr);
	s5 = udp_open(5000);
	s6 = udp_open(6000);
	if (s5 < 0 || s6 < 0) {
		printf("F553 sd|SKIP=no-sockets\n");
		return;
	}
	sh("/nft flush ruleset");
	nft("sd.table", "/nft add table netdev p553n3");
	nft("sd.chain", "/nft add chain netdev p553n3 loc '{ type filter hook ingress device \"l0\" priority 0; policy accept; }'");
	memset(&a, 0, sizeof(a));
	a.fam = NFPROTO_NETDEV;
	a.table = "p553n3";
	a.chain = "loc";
	a.flush = "/nft flush chain netdev p553n3 loc";
	a.install = 1;

	for (i = 0; i < 3; i++) {
		unsigned long long cnt;

		a.install = (i == 0) ? 0 : 1;
		if (i == 1) {
			a.tag = "sd.nh22";
			a.rule = "@nh,176,16 set 0x1770";
			a.off = 22; a.len = 2; a.immlen = 2;
			a.imm[0] = 0x17; a.imm[1] = 0x70;	/* dport 6000 */
		} else if (i == 2) {
			a.tag = "sd.nh36";
			a.rule = "@nh,288,16 set 0x1770";
			a.off = 36; a.len = 2; a.immlen = 2;
			a.imm[0] = 0x17; a.imm[1] = 0x70;
		} else {
			a.tag = "sd.ctl";
			a.rule = NULL;
		}
		if (a.flush)
			sh(a.flush);
		if (a.install) {
			r = install_store(a.fam, a.table, a.chain, a.off, a.len, a.imm,
					  a.immlen, 0);
			if (r)
				printf("F553RC %s|%d\n", a.tag, r);
		}
		usleep(20000);
		pkt_send("l1", fr, flen);
		got5 = got6 = 0;
		sport = 0;
		paylen = 0;
		{	/* one 600 ms window */
			struct timeval tv = { .tv_sec = 0, .tv_usec = 200000 };
			int k;

			for (k = 0; k < 3; k++) {
				fd_set rf;
				struct sockaddr_in from;
				socklen_t fl = sizeof(from);

				FD_ZERO(&rf);
				FD_SET(s5, &rf);
				FD_SET(s6, &rf);
				select((s5 > s6 ? s5 : s6) + 1, &rf, NULL, NULL, &tv);
				if (FD_ISSET(s5, &rf)) {
					r = (int)recvfrom(s5, pay, sizeof(pay), 0,
							  (struct sockaddr *)&from, &fl);
					if (r > 0) {
						got5++;
						sport = ntohs(from.sin_port);
						paylen = r;
					}
				}
				if (FD_ISSET(s6, &rf)) {
					r = (int)recvfrom(s6, pay, sizeof(pay), 0,
							  (struct sockaddr *)&from, &fl);
					if (r > 0) {
						got6++;
						sport = ntohs(from.sin_port);
						paylen = r;
					}
				}
			}
		}
		cnt = f553_count(a.fam, a.table, a.chain);
		printf("F553L %s|rule=%s|p5000=%d|p6000=%d|sport=%d|cnt=%llu|pay=",
		       a.tag, a.rule ? a.rule : "none", got5, got6, sport, cnt);
		for (k = 0; k < paylen && k < 32; k++)
			printf("%02x", pay[k]);
		printf("\n");
	}
	sh("/nft flush ruleset");
	close(s5);
	close(s6);
}

/* ---------- D: the bridge -- the label decides ---------- */

static void sec_bridge(void)
{
	static const int kinds[4] = { FK_IPU, FK_IPUV, FK_IP91, FK_ARPIP };
	static const char *labels[4] = { "0x0800", "0x8100", "0x9100", "0x0806" };
	unsigned char fr[160], base[4][2048];
	int blen[4], flen, k, i;
	struct armq a;
	unsigned char arpov[16];
	char tag[80];

	if (!HAVE_BRIDGE) {
		printf("F553 br|SKIP=no-bridge-family\n");
		return;
	}
	sh("/nft flush ruleset");
	nft("sb.table", "/nft add table bridge p553b2");
	nft("sb.acc", "/nft add chain bridge p553b2 acc '{ type filter hook prerouting priority 0; policy accept; }'");
	nft("sb.list", "/nft list chain bridge p553b2 acc");

	/* controls: the same IPv4 datagram under four ethernet labels, nothing
	 * installed.  0x8100 is here on purpose: the receive path untags 802.1Q
	 * before any bridge hook, so this cell also measures what is left of the
	 * label by the time the guard sees it. */
	for (k = 0; k < 4; k++) {
		flen = build_frame(kinds[k], MAC_DST, MAC_SRC, 0x0a010009, 0x0a090007,
				   40000, 5000, 16, fr);
		cap_drain(CAP_R0);
		usleep(20000);
		pkt_send("s0", fr, flen);
		memset(base[k], 0, sizeof(base[k]));
		blen[k] = cap_one(CAP_R0, base[k], (int)sizeof(base[k]), 500, MAC_SRC, 1);
		printf("F553 br.ctl.%s|label=%s|cap=%d|flen=%d|hex=", labels[k],
		       labels[k], blen[k] > 0, blen[k]);
		for (i = 0; i < blen[k] && i < 200; i++)
			printf("%02x", base[k][i]);
		printf("\n");
	}
	for (k = 0; k < 4; k++) {
		if (blen[k] <= 0) {
			printf("F553 br|SKIP=no-baseline-%s\n", labels[k]);
			return;
		}
	}

	memset(&a, 0, sizeof(a));
	a.fam = NFPROTO_BRIDGE;
	a.table = "p553b2";
	a.chain = "acc";
	a.flush = "/nft flush chain bridge p553b2 acc";
	a.install = 1;
	a.cap_mac = MAC_SRC;
	a.cap_on_src = 1;

	/* 1. daddr, len 4 at network offset 16 */
	a.off = 16; a.len = 4; a.immlen = 4;
	a.imm[0] = 0x0a; a.imm[1] = 0x09; a.imm[2] = 0x09; a.imm[3] = 0x09;
	a.rule = "@nh,128,32 set 0x0a090909";
	for (k = 0; k < 4; k++) {
		snprintf(tag, sizeof(tag), "br.raw16.%s", labels[k]);
		a.tag = tag;
		a.label = labels[k];
		flen = build_frame(kinds[k], MAC_DST, MAC_SRC, 0x0a010009, 0x0a090007,
				   40000, 5000, 16, fr);
		run_arm(&a, fr, flen, "s0", CAP_R0, base[k], blen[k]);
		if (k == 0)
			dump_chain(NFPROTO_BRIDGE, "p553b2", "acc");
	}
	/* 2. ttl+proto+cksum in one 4-byte store at network offset 8: refused by
	 *    the ipv4 whitelist (ttl must be 1 or 2 bytes), accepted by the ARP
	 *    branch (offset >= 8, len <= 20).  Same frame bytes, other label. */
	a.off = 8; a.len = 4; a.immlen = 4;
	a.imm[0] = 0x3e; a.imm[1] = 0x11; a.imm[2] = 0xaa; a.imm[3] = 0xbb;
	a.rule = "@nh,64,32 set 0x3e11aabb";
	for (k = 0; k < 4; k++) {
		snprintf(tag, sizeof(tag), "br.raw8.%s", labels[k]);
		a.tag = tag;
		a.label = labels[k];
		flen = build_frame(kinds[k], MAC_DST, MAC_SRC, 0x0a010009, 0x0a090007,
				   40000, 5000, 16, fr);
		run_arm(&a, fr, flen, "s0", CAP_R0, base[k], blen[k]);
	}
	/* 3. the human spelling -- nft adds a checksum fixup, and the same label
	 *    decides a second time in nft_payload_csum_nh_write_ok() */
	a.install = 2;
	a.rule = "ip daddr set 10.9.9.9";
	a.nftcmd = "/nft add rule bridge p553b2 acc 'ip daddr set 10.9.9.9 counter'";
	for (k = 0; k < 4; k++) {
		snprintf(tag, sizeof(tag), "br.kw.%s", labels[k]);
		a.tag = tag;
		a.label = labels[k];
		flen = build_frame(kinds[k], MAC_DST, MAC_SRC, 0x0a010009, 0x0a090007,
				   40000, 5000, 16, fr);
		run_arm(&a, fr, flen, "s0", CAP_R0, base[k], blen[k]);
	}
	/* 4. the field the guard switches on, read by the kernel's own counter */
	a.install = 2;
	a.label = "0x8100";
	a.tag = "br.meta.tag.q";
	a.rule = "meta protocol 8021q";
	a.nftcmd = "/nft add rule bridge p553b2 acc 'meta protocol 8021q counter'";
	flen = build_frame(FK_IPUV, MAC_DST, MAC_SRC, 0x0a010009, 0x0a090007,
			   40000, 5000, 16, fr);
	run_arm(&a, fr, flen, "s0", CAP_R0, base[1], blen[1]);
	a.tag = "br.meta.tag.ip";
	a.rule = "meta protocol ip";
	a.nftcmd = "/nft add rule bridge p553b2 acc 'meta protocol ip counter'";
	run_arm(&a, fr, flen, "s0", CAP_R0, base[1], blen[1]);
	a.label = "0x9100";
	a.tag = "br.meta.91.91";
	a.rule = "meta protocol 0x9100";
	a.nftcmd = "/nft add rule bridge p553b2 acc 'meta protocol 0x9100 counter'";
	flen = build_frame(FK_IP91, MAC_DST, MAC_SRC, 0x0a010009, 0x0a090007,
			   40000, 5000, 16, fr);
	run_arm(&a, fr, flen, "s0", CAP_R0, base[2], blen[2]);
	a.tag = "br.meta.91.ip";
	a.rule = "meta protocol ip";
	a.nftcmd = "/nft add rule bridge p553b2 acc 'meta protocol ip counter'";
	run_arm(&a, fr, flen, "s0", CAP_R0, base[2], blen[2]);
	a.label = "0x0800";
	a.tag = "br.meta.untag.ip";
	a.rule = "meta protocol ip";
	a.nftcmd = "/nft add rule bridge p553b2 acc 'meta protocol ip counter'";
	flen = build_frame(FK_IPU, MAC_DST, MAC_SRC, 0x0a010009, 0x0a090007,
			   40000, 5000, 16, fr);
	run_arm(&a, fr, flen, "s0", CAP_R0, base[0], blen[0]);
	a.label = "0x0806";
	a.tag = "br.meta.arpip.ip";
	a.rule = "meta protocol ip";
	a.nftcmd = "/nft add rule bridge p553b2 acc 'meta protocol ip counter'";
	flen = build_frame(FK_ARPIP, MAC_DST, MAC_SRC, 0x0a010009, 0x0a090007,
			   40000, 5000, 16, fr);
	run_arm(&a, fr, flen, "s0", CAP_R0, base[3], blen[3]);

	/* 5. the ARP branch's one-sided length check */
	for (i = 0; i < 16; i++)
		arpov[i] = (unsigned char)(0xa0 + i);
	{
		unsigned char bpad[2048], braw[2048];
		int lpad, lraw;

		flen = build_frame(FK_ARPPAD, MAC_DST, MAC_SRC, 0x0a010009,
				   0x0a090007, 40000, 5000, 16, fr);
		cap_drain(CAP_R0);
		usleep(20000);
		pkt_send("s0", fr, flen);
		lpad = cap_one(CAP_R0, bpad, (int)sizeof(bpad), 500, MAC_SRC, 1);
		flen = build_frame(FK_ARPRAW, MAC_DST, MAC_SRC, 0x0a010009,
				   0x0a090007, 40000, 5000, 16, fr);
		cap_drain(CAP_R0);
		usleep(20000);
		pkt_send("s0", fr, flen);
		lraw = cap_one(CAP_R0, braw, (int)sizeof(braw), 500, MAC_SRC, 1);
		printf("F553 br.ctl.pad|label=0x0806|cap=%d|flen=%d\n", lpad > 0, lpad);
		printf("F553 br.ctl.raw|label=0x0806|cap=%d|flen=%d\n", lraw > 0, lraw);
		if (lpad > 0 && lraw > 0) {
			memset(&a, 0, sizeof(a));
			a.fam = NFPROTO_BRIDGE;
			a.table = "p553b2";
			a.chain = "acc";
			a.flush = "/nft flush chain bridge p553b2 acc";
			a.install = 1;
			a.cap_mac = MAC_SRC;
			a.cap_on_src = 1;
			a.off = 20; a.len = 16; a.immlen = 16;
			memcpy(a.imm, arpov, 16);
			a.label = "0x0806";
			a.rule = "@nh,160,128 set a0..af";
			a.tag = "br.arpov.pad";
			flen = build_frame(FK_ARPPAD, MAC_DST, MAC_SRC, 0x0a010009,
					   0x0a090007, 40000, 5000, 16, fr);
			run_arm(&a, fr, flen, "s0", CAP_R0, bpad, lpad);
			a.tag = "br.arpov.raw";
			flen = build_frame(FK_ARPRAW, MAC_DST, MAC_SRC, 0x0a010009,
					   0x0a090007, 40000, 5000, 16, fr);
			run_arm(&a, fr, flen, "s0", CAP_R0, braw, lraw);
		}
	}

	/* 6. the verdict: a refused store swallows the rest of the rule.  The
	 * dropping chain is created HERE: a bridge prerouting chain with policy
	 * drop stops every bridged frame, so its existence would have made every
	 * control above look dead. */
	nft("sb.drp", "/nft add chain bridge p553b2 drp '{ type filter hook prerouting priority 10; policy drop; }'");
	/* the accept chain still holds the last arm's rule; a rule left behind
	 * would have written into every frame of the next section */
	sh("/nft flush chain bridge p553b2 acc");
	memset(&a, 0, sizeof(a));
	a.fam = NFPROTO_BRIDGE;
	a.table = "p553b2";
	a.chain = "drp";
	a.flush = "/nft flush chain bridge p553b2 drp";
	a.install = 1;
	a.cap_mac = MAC_SRC;
	a.cap_on_src = 1;
	a.verdict = 1;
	a.off = 8; a.len = 4; a.immlen = 4;
	a.imm[0] = 0x3e; a.imm[1] = 0x11; a.imm[2] = 0xaa; a.imm[3] = 0xbb;
	a.rule = "@nh,64,32 set 0x3e11aabb;counter;accept";
	a.label = "0x0806";
	a.tag = "br.drp.raw8.arpip";
	flen = build_frame(FK_ARPIP, MAC_DST, MAC_SRC, 0x0a010009, 0x0a090007,
			   40000, 5000, 16, fr);
	run_arm(&a, fr, flen, "s0", CAP_R0, base[3], blen[3]);
	a.label = "0x9100";
	a.tag = "br.drp.raw8.91";
	flen = build_frame(FK_IP91, MAC_DST, MAC_SRC, 0x0a010009, 0x0a090007,
			   40000, 5000, 16, fr);
	run_arm(&a, fr, flen, "s0", CAP_R0, base[2], blen[2]);
	a.install = 0;
	a.label = "0x0800";
	a.tag = "br.drp.ctl.untag";
	flen = build_frame(FK_IPU, MAC_DST, MAC_SRC, 0x0a010009, 0x0a090007,
			   40000, 5000, 16, fr);
	run_arm(&a, fr, flen, "s0", CAP_R0, base[0], blen[0]);
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f553";
	unsigned char fr[160], base[2048];
	int flen, blen;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F553 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F553 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	sec_s0();
	if (!strcmp(mode, "f553bare"))
		return 0;
	env_setup();

	/* the ip-family baseline frame: forward i0 -> o0 */
	flen = build_frame(FK_IPU, MAC_I0, MAC_SRC, 0x0a010009, 0x0a090007,
			   40000, 5000, 16, fr);
	cap_drain(CAP_O1);
	usleep(20000);
	pkt_send("i1", fr, flen);
	memset(base, 0, sizeof(base));
	blen = cap_one(CAP_O1, base, (int)sizeof(base), 500, MAC_NEI, 0);
	printf("F553 fwd.ctl|cap=%d|flen=%d|hex=", blen > 0, blen);
	{
		int i;

		for (i = 0; i < blen && i < 200; i++)
			printf("%02x", base[i]);
		printf("\n");
	}
	if (blen <= 0) {
		printf("F553 ABORT|no-forwarded-baseline\n");
		return 0;
	}
	sec_forward(base, blen);
	sec_local();
	sec_bridge();
	printf("F553 DONE\n");
	return 0;
}
