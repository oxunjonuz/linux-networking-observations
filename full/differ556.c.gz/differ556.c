// SPDX-License-Identifier: GPL-2.0
/*
 * differ555.c -- turn 555 / F32: the native `arp` envelope.
 *
 * F30 measured the IPv4/IPv6 branches of nft_nh_write_ok(); F31 measured the
 * netdev and bridge branches and, inside the bridge, the ARP branch
 *     static bool nft_nh_write_ok_arp(const struct nft_payload_set *priv)
 *     {
 *             const unsigned int eth_ip = 2 * (ETH_ALEN + 4);
 *             switch (priv->offset) {
 *             case offsetof(struct arphdr, ar_op):  return priv->len == 2;
 *             }
 *             return priv->offset >= sizeof(struct arphdr) && priv->len <= eth_ip;
 *     }
 * -- reached from a frame whose ETHERNET LABEL said 0x0806.
 *
 * The native envelope is `case NFPROTO_ARP: return nft_nh_write_ok_arp(priv)`
 * in nft_nh_write_ok(), i.e. the nft family `arp`, and that family has never
 * been reachable in this project: CONFIG_NF_TABLES_ARP is "not set" in every
 * config we have booted.  Two kernels are built for this turn with that one
 * symbol on (A553 = 7.3.4, AM553 = 7.2.15) and nothing else changed.
 *
 * Questions, each answered by a counter, a byte or a socket -- never by reading
 * the source:
 *
 *   A  does the family exist?  (`nft add table arp`)
 *   B  which hooks does its filter chain type accept?
 *   C  which of the nine fields nft itself can name are alive, which are dead?
 *   D  what is the guard's predicate at the INPUT hook, as a function of
 *      (offset,len) -- measured over a grid, not read off the switch
 *   E  the same grid at the OUTPUT hook, where the kernel's own ARP skb is
 *      exactly 28 bytes long
 *   F  what a rule in this family does to the host: neighbour table, replies
 *   G  does anything here read hlen/plen out of the message?
 *
 * output
 *   F555 A|<tag>|hook=..|src=..|g=off,len|rule=..|rc=..|cnt=..|nfl=..|chg=..|
 *          nhex=..|ci1=..|ihex=..|co1=..|ohex=..
 *   F555 ARP|<tag>|<ip>|flags=..|mac=..
 *   F555 FAM|<family>|<rc>
 *   F555 HOOK|<hook>|<rc>
 *   F555RC <tag>|<rc>          (nft exit code)
 *   F555X  <tag>|<nft's own words>
 *   F555 SETUP|...
 *
 * Byte evidence at INPUT can only come from NFLOG: an AF_PACKET tap sees the
 * frame on receive before arp_rcv() is called, and arp_rcv() is where the
 * netfilter ARP hook lives.  So every rule logs the packet after the store
 * (`log group 5 prefix "f555.<tag>"`), and the payload is matched back by
 * prefix -- a per-arm string, so no arm can consume another arm's message.
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sched.h>
#include <stdint.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <linux/if_link.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <linux/if_arp.h>
#include <linux/netfilter.h>
#include <linux/netfilter/nfnetlink.h>
#include <linux/netfilter/nf_tables.h>

#define NLA_ALIGN_(len) (((len) + 3) & ~3)
#ifndef VETH_INFO_PEER
#define VETH_INFO_PEER 1
#endif
#define NFNL_SUBSYS_ULOG_	4
#define NFULNL_MSG_PACKET_	0
#define NFULNL_MSG_CONFIG_	1
#define NFULA_PACKET_HDR_	1
#define NFULA_PAYLOAD_		9
#define NFULA_PREFIX_		10
#define NFULA_CFG_CMD_		1
#define NFULA_CFG_MODE_		2
#define NFULA_CFG_TIMEOUT_	4
#define NFULA_CFG_QTHRESH_	5
#define NFULNL_CFG_CMD_BIND_	1
#define NFULNL_COPY_PACKET_	0x02

/* NFTA_LOG_GROUP / _PREFIX / _QTHRESHOLD come from <linux/netfilter/nf_tables.h>
 * as ENUM constants -- and #ifndef does not protect an enum constant, which is
 * how this file carried `#define NFTA_LOG_PREFIX 3` for one smoke run and sent
 * every prefix as NFTA_LOG_SNAPLEN.  Rules installed fine, counters counted, and
 * the NFLOG messages arrived with an empty prefix.  These two assertions make
 * that failure a compile error instead of a silent one. */
_Static_assert(NFTA_LOG_GROUP == 1, "NFTA_LOG_GROUP moved");
_Static_assert(NFTA_LOG_PREFIX == 2, "NFTA_LOG_PREFIX moved");
_Static_assert(NFTA_LOG_QTHRESHOLD == 4, "NFTA_LOG_QTHRESHOLD moved");

/* ---------- netlink toolkit ---------- */

static char opbuf[4096];

static struct nlmsghdr *msg_start(char *buf, int bufsz, uint16_t type,
				  uint16_t flags, uint8_t family)
{
	struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
	struct nfgenmsg *nfg;

	memset(buf, 0, (size_t)bufsz);
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = type;
	nlh->nlmsg_flags = flags;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	return nlh;
}

static struct nlattr *attr_put(struct nlmsghdr *nlh, uint16_t type,
			       const void *payload, int len)
{
	struct nlattr *a = (struct nlattr *)((char *)nlh +
					     NLMSG_ALIGN(nlh->nlmsg_len));

	a->nla_type = type;
	a->nla_len = (uint16_t)(NLA_HDRLEN + len);
	if (len && payload)
		memcpy((char *)a + NLA_HDRLEN, payload, (size_t)len);
	nlh->nlmsg_len = NLMSG_ALIGN(nlh->nlmsg_len) + (uint32_t)NLA_ALIGN_(a->nla_len);
	return a;
}

static struct nlattr *nest_start(struct nlmsghdr *nlh, uint16_t type)
{
	return attr_put(nlh, (uint16_t)(type | NLA_F_NESTED), NULL, 0);
}

static void nest_end(struct nlmsghdr *nlh, struct nlattr *a)
{
	a->nla_len = (uint16_t)((char *)nlh + nlh->nlmsg_len - (char *)a);
}

static void put_str(struct nlmsghdr *nlh, uint16_t t, const char *s)
{
	attr_put(nlh, t, s, (int)strlen(s) + 1);
}

static void put_be32(struct nlmsghdr *nlh, uint16_t t, uint32_t v)
{
	uint32_t be = htonl(v);

	attr_put(nlh, t, &be, (int)sizeof(be));
}

static int nl_open(void)
{
	struct sockaddr_nl sa;
	struct timeval tv = { .tv_sec = 2, .tv_usec = 0 };
	int fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_NETFILTER);

	if (fd < 0)
		return -1;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -1;
	}
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return fd;
}

static int batch_send(int fd, char *buf, int len)
{
	char rbuf[8192];
	int err = 0;

	if (send(fd, buf, (size_t)len, 0) != len)
		return -1000 - errno;
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			if (h->nlmsg_type != NLMSG_ERROR)
				continue;
			{
				struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(h);

				if (e->error && !err)
					err = e->error;
			}
		}
	}
	return err;
}

/* one nfnetlink message, wrapped in BEGIN/END, sent as a batch */
static int nft_one(char *msgbuf, int msglen)
{
	char batch[8192];
	struct nlmsghdr *bn, *en;
	int off, fd, rc;

	bn = msg_start(batch, (int)sizeof(batch), NFNL_MSG_BATCH_BEGIN,
		       NLM_F_REQUEST, 0);
	((struct nfgenmsg *)NLMSG_DATA(bn))->res_id = htons(NFNL_SUBSYS_NFTABLES);
	off = (int)NLMSG_ALIGN(bn->nlmsg_len);
	memcpy(batch + off, msgbuf, (size_t)NLMSG_ALIGN(msglen));
	off += (int)NLMSG_ALIGN(msglen);
	en = msg_start(batch + off, (int)(sizeof(batch) - off), NFNL_MSG_BATCH_END,
		       NLM_F_REQUEST, 0);
	((struct nfgenmsg *)NLMSG_DATA(en))->res_id = htons(NFNL_SUBSYS_NFTABLES);
	off += (int)NLMSG_ALIGN(en->nlmsg_len);
	fd = nl_open();
	if (fd < 0)
		return -1;
	rc = batch_send(fd, batch, off);
	close(fd);
	return rc;
}

/* ---------- rtnetlink ---------- */

static int rtnl_open(void)
{
	struct sockaddr_nl sa;
	struct timeval tv = { .tv_sec = 2, .tv_usec = 0 };
	int fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);

	if (fd < 0)
		return -1;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -2;
	}
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return fd;
}

static int rtnl_talk(int fd, struct nlmsghdr *nlh)
{
	struct sockaddr_nl sa;
	char rbuf[4096];
	struct nlmsghdr *rh;
	int r;

	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	nlh->nlmsg_flags |= NLM_F_REQUEST | NLM_F_ACK;
	nlh->nlmsg_seq = 1;
	nlh->nlmsg_pid = 0;
	if (sendto(fd, nlh, nlh->nlmsg_len, 0, (struct sockaddr *)&sa,
		   sizeof(sa)) < 0)
		return -errno;
	r = (int)recv(fd, rbuf, sizeof(rbuf), 0);
	if (r < (int)(NLMSG_HDRLEN + sizeof(struct nlmsgerr)))
		return -1000;
	rh = (struct nlmsghdr *)rbuf;
	if (rh->nlmsg_type == NLMSG_ERROR) {
		struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(rh);

		return e->error;
	}
	return -1001;
}

static int f555_ifindex(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int idx = -1;

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFINDEX, &ifr) == 0)
		idx = ifr.ifr_ifindex;
	close(s);
	return idx;
}

static int mac_get(const char *dev, unsigned char *out)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFHWADDR, &ifr) < 0) {
		close(s);
		return -1;
	}
	memcpy(out, ifr.ifr_hwaddr.sa_data, 6);
	close(s);
	return 0;
}

static int set_up(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFFLAGS, &ifr) < 0) {
		close(s);
		return -1;
	}
	ifr.ifr_flags |= IFF_UP | IFF_RUNNING;
	if (ioctl(s, SIOCSIFFLAGS, &ifr) < 0) {
		close(s);
		return -1;
	}
	close(s);
	return 0;
}

static int link_add_veth(const char *a, const char *b)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[512];
	} req;
	struct ifinfomsg zifi;
	struct nlattr *li, *data, *peer;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, a, (int)strlen(a) + 1);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, "veth", 5);
	data = nest_start(&req.nlh, IFLA_INFO_DATA);
	memset(&zifi, 0, sizeof(zifi));
	zifi.ifi_family = AF_UNSPEC;
	peer = attr_put(&req.nlh, (uint16_t)(VETH_INFO_PEER | NLA_F_NESTED), &zifi,
			(int)sizeof(zifi));
	attr_put(&req.nlh, IFLA_IFNAME, b, (int)strlen(b) + 1);
	nest_end(&req.nlh, peer);
	nest_end(&req.nlh, data);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f555_addr_add(const char *dev, uint32_t addr_be, int plen)
{
	struct {
		struct nlmsghdr nlh;
		struct ifaddrmsg ifa;
		char attrs[128];
	} req;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifaddrmsg));
	req.nlh.nlmsg_type = RTM_NEWADDR;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_REPLACE;
	req.nlh.nlmsg_seq = 1;
	req.ifa.ifa_family = AF_INET;
	req.ifa.ifa_prefixlen = (uint8_t)plen;
	req.ifa.ifa_scope = 0;
	req.ifa.ifa_index = (uint32_t)f555_ifindex(dev);
	attr_put(&req.nlh, IFA_LOCAL, &addr_be, 4);
	attr_put(&req.nlh, IFA_ADDRESS, &addr_be, 4);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f555_neigh_del(const char *dev, uint32_t dst_be)
{
	struct {
		struct nlmsghdr nlh;
		struct ndmsg ndm;
		char attrs[64];
	} req;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ndmsg));
	req.nlh.nlmsg_type = RTM_DELNEIGH;
	req.nlh.nlmsg_flags = NLM_F_REQUEST;
	req.nlh.nlmsg_seq = 1;
	req.ndm.ndm_family = AF_INET;
	req.ndm.ndm_ifindex = f555_ifindex(dev);
	attr_put(&req.nlh, NDA_DST, &dst_be, 4);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f555_sysctl(const char *path, const char *val)
{
	int fd = open(path, O_WRONLY);
	int rc;

	if (fd < 0)
		return -1;
	rc = (int)write(fd, val, strlen(val));
	close(fd);
	return rc < 0 ? -1 : 0;
}

/* ---------- /proc/net/arp: the host's own view of what it learned ---------- */

static int arp_flags(const char *ip, char *mac, int macsz)
{
	FILE *f = fopen("/proc/net/arp", "r");
	char line[256];

	if (!f)
		return -1;
	if (!fgets(line, sizeof(line), f)) {
		fclose(f);
		return -1;
	}
	while (fgets(line, sizeof(line), f)) {
		char a[64] = "", hw[32] = "", fl[32] = "", m[64] = "";
		char msk[32] = "", dev[32] = "";

		if (sscanf(line, "%63s %31s %31s %63s %31s %31s", a, hw, fl, m, msk, dev) != 6)
			continue;
		if (strcmp(a, ip))
			continue;
		if (mac && macsz > 0)
			snprintf(mac, (size_t)macsz, "%s", m);
		fclose(f);
		return (int)strtol(fl, NULL, 16);
	}
	fclose(f);
	return -1;		/* no entry at all */
}

static void arp_row(const char *tag, const char *ip)
{
	char mac[64] = "-";
	int fl = arp_flags(ip, mac, (int)sizeof(mac));

	if (fl < 0)
		printf("F555 ARP|%s|%s|flags=none|mac=-\n", tag, ip);
	else
		printf("F555 ARP|%s|%s|flags=0x%x|mac=%s\n", tag, ip, fl, mac);
}

/* ---------- nft through the shell ---------- */

static int sh(const char *cmd)
{
	char full[2048];
	int rc;

	snprintf(full, sizeof(full), "%s >/tmp/f555o 2>&1", cmd);
	rc = system(full);
	return WIFEXITED(rc) ? WEXITSTATUS(rc) : 1000 + rc;
}

static void sh_out(const char *tag)
{
	FILE *f = fopen("/tmp/f555o", "r");
	char line[1024];

	if (!f)
		return;
	while (fgets(line, sizeof(line), f)) {
		char *nl = strchr(line, '\n');

		if (nl)
			*nl = 0;
		if (*line)
			printf("F555X %s|%s\n", tag, line);
	}
	fclose(f);
}

static int nft(const char *tag, const char *cmd)
{
	int rc = sh(cmd);

	printf("F555RC %s|%d\n", tag, rc);
	sh_out(tag);
	return rc;
}

/* ---------- NFLOG: the only way to see the packet AFTER the hook ---------- */

static int nfl_open(int group)
{
	char msg[512], rbuf[2048];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	struct sockaddr_nl sa;
	int fd, rcv = 1 << 21;

	fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_NETFILTER);
	if (fd < 0)
		return -1;
	setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcv, sizeof(rcv));
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -2;
	}
	memset(msg, 0, sizeof(msg));
	nlh = (struct nlmsghdr *)msg;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (uint16_t)((NFNL_SUBSYS_ULOG_ << 8) | NFULNL_MSG_CONFIG_);
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = 0;
	nfg->version = 0;
	nfg->res_id = htons((uint16_t)group);
	{
		uint8_t cmd = NFULNL_CFG_CMD_BIND_;

		attr_put(nlh, NFULA_CFG_CMD_, &cmd, 1);
	}
	{
		struct {
			uint32_t range;
			uint8_t mode;
			uint8_t pad;
		} __attribute__((packed)) cm;

		cm.range = htonl(0);
		cm.mode = NFULNL_COPY_PACKET_;
		cm.pad = 0;
		attr_put(nlh, NFULA_CFG_MODE_, &cm, (int)sizeof(cm));
	}
	{
		uint32_t q = htonl(1);
		uint32_t t = htonl(2);

		attr_put(nlh, NFULA_CFG_QTHRESH_, &q, 4);
		attr_put(nlh, NFULA_CFG_TIMEOUT_, &t, 4);
	}
	if (send(fd, msg, nlh->nlmsg_len, 0) != (ssize_t)nlh->nlmsg_len) {
		close(fd);
		return -3;
	}
	if (recv(fd, rbuf, sizeof(rbuf), 0) > 0) {
		struct nlmsghdr *rh = (struct nlmsghdr *)rbuf;

		if (rh->nlmsg_type == NLMSG_ERROR) {
			struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(rh);

			if (e->error) {
				printf("F555 SETUP|nflog_bind|%d\n", e->error);
				close(fd);
				return -5;
			}
		}
	}
	fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
	return fd;
}

/* one packet message -> prefix + payload.  Returns 1 if a message was parsed. */
static int nfl_one(const unsigned char *buf, int len, char *prefix, int psz,
		   unsigned char *pay, int *paylen)
{
	const struct nlmsghdr *nlh = (const struct nlmsghdr *)buf;
	int rem = len;

	prefix[0] = 0;
	*paylen = 0;
	while (NLMSG_OK(nlh, rem)) {
		if (nlh->nlmsg_type == (uint16_t)((NFNL_SUBSYS_ULOG_ << 8) |
						  NFULNL_MSG_PACKET_)) {
			const unsigned char *p = (const unsigned char *)NLMSG_DATA(nlh);
			int plen = (int)nlh->nlmsg_len - NLMSG_HDRLEN;
			int off = 4;	/* nfgenmsg */

			while (off + (int)sizeof(struct nlattr) <= plen) {
				const struct nlattr *a = (const struct nlattr *)(p + off);
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || off + alen > plen)
					break;
				if ((a->nla_type & 0x3fff) == NFULA_PREFIX_)
					snprintf(prefix, (size_t)psz, "%s",
						 (const char *)a + NLA_HDRLEN);
				else if ((a->nla_type & 0x3fff) == NFULA_PAYLOAD_) {
					int n = alen - NLA_HDRLEN;

					if (n > 128)
						n = 128;
					memcpy(pay, (const char *)a + NLA_HDRLEN, (size_t)n);
					*paylen = n;
				}
				off += (int)NLA_ALIGN_(alen);
			}
			return 1;
		}
		nlh = NLMSG_NEXT(nlh, rem);
	}
	return 0;
}

/* read until a message with exactly this prefix arrives (or the deadline) */
static int nfl_wait(int fd, const char *want, unsigned char *pay, int max,
		    int ms)
{
	struct timeval tv = { .tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000 };
	struct timeval now0, now1;
	fd_set rfds;
	int got = 0, seen = 0;
	char seenpre[2][64] = { "-", "-" };
	int seenlen[2] = { 0, 0 };

	gettimeofday(&now0, NULL);
	for (;;) {
		unsigned char b[4096];
		int r;

		FD_ZERO(&rfds);
		FD_SET(fd, &rfds);
		if (select(fd + 1, &rfds, NULL, NULL, &tv) <= 0)
			break;
		r = (int)recv(fd, b, sizeof(b), 0);
		if (r <= 0)
			break;
		{
			char pre[64];
			unsigned char p[128];
			int pl = 0;

			if (nfl_one(b, r, pre, (int)sizeof(pre), p, &pl)) {
				seen++;
				if (seen <= 2) {
					snprintf(seenpre[seen - 1], sizeof(seenpre[0]),
						 "%s", pre);
					seenlen[seen - 1] = pl;
				}
				if (pl > 0 && (!want || !strcmp(pre, want))) {
					if (pl > max)
						pl = max;
					memcpy(pay, p, (size_t)pl);
					got = pl;
					break;
				}
			}
		}
		gettimeofday(&now1, NULL);
		{
			long used = (now1.tv_sec - now0.tv_sec) * 1000 +
				    (now1.tv_usec - now0.tv_usec) / 1000;

			if (used >= ms)
				break;
			tv.tv_sec = 0;
			tv.tv_usec = (ms - used) * 1000;
		}
	}
	if (!got)
		printf("F555X nfl|want=%s|seen=%d|p1=%s,%d|p2=%s,%d\n",
		       want ? want : "-", seen, seenpre[0], seenlen[0],
		       seenpre[1], seenlen[1]);
	return got;
}

static void nfl_drain(int fd)
{
	unsigned char b[4096];

	while (recv(fd, b, sizeof(b), 0) > 0)
		;
}

/* ---------- frames ---------- */

static const unsigned char MAC_SRC[6] = { 0xaa, 0xbb, 0xcc, 0x00, 0x00, 0x66 };
static const unsigned char MAC_DST[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
static const unsigned char MAC_THA[6] = { 0x22, 0x22, 0x22, 0x22, 0x22, 0x22 };

static void be32_out(unsigned char *p, uint32_t v)
{
	p[0] = (unsigned char)(v >> 24);
	p[1] = (unsigned char)(v >> 16);
	p[2] = (unsigned char)(v >> 8);
	p[3] = (unsigned char)v;
}

/* ethernet + ARP.  hlen/plen are the message's OWN address sizes; the standard
 * ethernet/IPv4 message is hlen=6 plen=4 and is 28 bytes long.  `pad` pads the
 * frame to the 60-byte ethernet minimum, the way a real sender does. */
static int build_arp(unsigned char *out, int op, uint32_t spa, uint32_t tpa,
		     const unsigned char *sha, int hlen, int plen, int pad)
{
	int hl = 14, mlen = 8 + 2 * hlen + 2 * plen;

	memset(out, 0, 160);
	memcpy(out, MAC_DST, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x08;
	out[13] = 0x06;
	out[hl + 0] = 0x00; out[hl + 1] = 0x01;	/* htype: ethernet */
	out[hl + 2] = 0x08; out[hl + 3] = 0x00;	/* ptype: IPv4 */
	out[hl + 4] = (unsigned char)hlen;
	out[hl + 5] = (unsigned char)plen;
	out[hl + 6] = (unsigned char)(op >> 8);
	out[hl + 7] = (unsigned char)op;
	memcpy(out + hl + 8, sha, (size_t)(hlen < 6 ? hlen : 6));
	be32_out(out + hl + 8 + hlen, spa);
	memcpy(out + hl + 8 + hlen + plen, MAC_THA, (size_t)(hlen < 6 ? hlen : 6));
	be32_out(out + hl + 8 + 2 * hlen + plen, tpa);
	if (pad && hl + mlen < 60)
		return 60;		/* memset already zeroed the padding */
	return hl + mlen;
}

static int pkt_send(const char *dev, const unsigned char *fr, int len)
{
	struct sockaddr_ll sll;
	int s, rc, idx = f555_ifindex(dev);

	if (idx < 0)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_ALL);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, fr, 6);
	rc = (int)sendto(s, fr, (size_t)len, 0, (struct sockaddr *)&sll, sizeof(sll));
	close(s);
	return rc < 0 ? -errno : 0;
}

static int cap_open(const char *dev)
{
	struct sockaddr_ll sll;
	int s, idx = f555_ifindex(dev);

	if (idx < 0)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_ALL);
	sll.sll_ifindex = idx;
	if (bind(s, (struct sockaddr *)&sll, sizeof(sll)) < 0) {
		close(s);
		return -3;
	}
	fcntl(s, F_SETFL, fcntl(s, F_GETFL, 0) | O_NONBLOCK);
	return s;
}

static void cap_drain(int s)
{
	unsigned char b[2048];

	while (recv(s, b, sizeof(b), 0) > 0)
		;
}

/* first ARP frame from `mac` on this socket within ms.  ARP only: the arms also
 * push UDP datagrams out of the same device (the poke that triggers the kernel's
 * own ARP request), and the first frame was twice the wrong one in the smoke run
 * of F31 -- once an ICMPv6 solicitation from the bridge, once our own datagram. */
static int cap_arp_t(int s, unsigned char *buf, int max, int ms,
		     const unsigned char *mac, int on_src, uint32_t tpa_be)
{
	struct timeval tv = { .tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000 };
	struct timeval now0, now1;
	fd_set rfds;

	gettimeofday(&now0, NULL);
	for (;;) {
		int r;

		FD_ZERO(&rfds);
		FD_SET(s, &rfds);
		if (select(s + 1, &rfds, NULL, NULL, &tv) <= 0)
			return 0;
		r = (int)recv(s, buf, (size_t)max, 0);
		if (r <= 0)
			return 0;
		if (r >= 42 && buf[12] == 0x08 && buf[13] == 0x06 &&
		    (tpa_be == 0 ||
		     (buf[38] == (unsigned char)(tpa_be >> 24) &&
		      buf[39] == (unsigned char)(tpa_be >> 16) &&
		      buf[40] == (unsigned char)(tpa_be >> 8) &&
		      buf[41] == (unsigned char)tpa_be)) &&
		    ((on_src && !memcmp(buf + 6, mac, 6)) ||
		     (!on_src && !memcmp(buf, mac, 6))))
			return r;
		gettimeofday(&now1, NULL);
		{
			long used = (now1.tv_sec - now0.tv_sec) * 1000 +
				    (now1.tv_usec - now0.tv_usec) / 1000;

			if (used >= ms)
				return 0;
			tv.tv_sec = 0;
			tv.tv_usec = (ms - used) * 1000;
		}
	}
}

static int cap_arp(int s, unsigned char *buf, int max, int ms,
		   const unsigned char *mac, int on_src)
{
	return cap_arp_t(s, buf, max, ms, mac, on_src, 0);
}

static int udp_poke(uint32_t dst_be)
{
	struct sockaddr_in sin;
	char b = 'x';
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int rc;

	if (s < 0)
		return -1;
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = dst_be;
	sin.sin_port = htons(9999);
	rc = (int)sendto(s, &b, 1, 0, (struct sockaddr *)&sin, sizeof(sin));
	close(s);
	return rc < 0 ? -errno : 0;
}

/* ---------- rules over raw netlink ---------- */

static void imm_value(struct nlmsghdr *nlh, uint32_t dreg, const void *val, int len)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "immediate");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_IMMEDIATE_DREG, dreg);
	{
		struct nlattr *v = nest_start(nlh, NFTA_IMMEDIATE_DATA);

		attr_put(nlh, NFTA_DATA_VALUE, val, len);
		nest_end(nlh, v);
	}
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void counter_expr(struct nlmsghdr *nlh)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "counter");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void log_expr(struct nlmsghdr *nlh, int group, const char *prefix)
{
	struct nlattr *e, *d;
	uint16_t g = htons((uint16_t)group);

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "log");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	attr_put(nlh, NFTA_LOG_GROUP, &g, 2);
	put_str(nlh, NFTA_LOG_PREFIX, prefix);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void accept_expr(struct nlmsghdr *nlh)
{
	struct nlattr *e, *d;
	uint32_t code = htonl(NF_ACCEPT);

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "immediate");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_IMMEDIATE_DREG, NFT_REG_VERDICT);
	{
		struct nlattr *v = nest_start(nlh, NFTA_IMMEDIATE_DATA);
		struct nlattr *vd = nest_start(nlh, NFTA_DATA_VERDICT);

		attr_put(nlh, NFTA_VERDICT_CODE, &code, 4);
		nest_end(nlh, vd);
		nest_end(nlh, v);
	}
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* one rule: [store @network+off = imm][log][counter][accept?] */
static int install_store(int family, const char *table, const char *chain,
			 uint32_t off, uint32_t len, const unsigned char *imm,
			 int immlen, int verdict, int loggroup, const char *prefix)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *e, *d;
	int rc;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			(uint8_t)family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	imm_value(nlh, NFT_REG32_00, imm, immlen);
	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "payload");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00);
	put_be32(nlh, NFTA_PAYLOAD_BASE, NFT_PAYLOAD_NETWORK_HEADER);
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
	put_be32(nlh, NFTA_PAYLOAD_LEN, len);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
	nest_end(nlh, d);
	nest_end(nlh, e);
	if (loggroup)
		log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	if (verdict)
		accept_expr(nlh);
	nest_end(nlh, exprs);
	rc = nft_one(opbuf, (int)nlh->nlmsg_len);
	return rc;
}

/* a rule that only logs and counts: the control for byte-level diffing */
static int install_ctl(int family, const char *table, const char *chain,
		       int loggroup, const char *prefix)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			(uint8_t)family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

/* NFT_MSG_DELRULE with table+chain and no handle flushes the chain.  Cheaper
 * than forking nft 130 times, and it cannot fail on a chain that is empty. */
static int flush_chain(int family, const char *table, const char *chain)
{
	struct nlmsghdr *nlh;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_DELRULE,
			NLM_F_REQUEST | NLM_F_ACK, (uint8_t)family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

static int add_table(int family, const char *table)
{
	struct nlmsghdr *nlh;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWTABLE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE, (uint8_t)family);
	put_str(nlh, NFTA_TABLE_NAME, table);
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

/* base chain: hook 0=input 2=output (NF_ARP_*), policy 1=accept 0=drop */
static int add_chain(int family, const char *table, const char *chain,
		     uint32_t hook, uint32_t prio, uint32_t policy)
{
	struct nlmsghdr *nlh;
	struct nlattr *h, *d;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWCHAIN,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE, (uint8_t)family);
	put_str(nlh, NFTA_CHAIN_TABLE, table);
	put_str(nlh, NFTA_CHAIN_NAME, chain);
	h = nest_start(nlh, NFTA_CHAIN_HOOK);
	put_be32(nlh, NFTA_HOOK_HOOKNUM, hook);
	put_be32(nlh, NFTA_HOOK_PRIORITY, prio);
	nest_end(nlh, h);
	put_be32(nlh, NFTA_CHAIN_POLICY, policy);
	put_str(nlh, NFTA_CHAIN_TYPE, "filter");
	(void)d;
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

/* counter read-back without nft's printer */
static unsigned long long f555_count(uint8_t family, const char *table,
				     const char *chain)
{
	char buf[1024], rbuf[16384];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	unsigned long long pkts = 0;
	int fd, sent;

	fd = nl_open();
	if (fd < 0)
		return 0;
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1);
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1);
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return 0;
	}
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			const char *p, *end;

			if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
				goto out;
			if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				continue;
			p = (const char *)h + NLMSG_HDRLEN + sizeof(*nfg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || p + alen > end)
					break;
				if ((a->nla_type & 0x3fff) == NFTA_RULE_EXPRESSIONS) {
					const char *q = (const char *)a + NLA_HDRLEN;
					const char *qe = (const char *)a + alen;

					for (; q + (int)sizeof(struct nlattr) <= qe; ) {
						const struct nlattr *el = (const struct nlattr *)q;
						int ell = (int)el->nla_len;
						const char *r, *re;
						int is_cnt = 0;

						if (ell < (int)sizeof(*el) || q + ell > qe)
							break;
						r = (const char *)el + NLA_HDRLEN;
						re = (const char *)el + ell;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int eal = (int)ea->nla_len;

							if (eal < (int)sizeof(*ea) || r + eal > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_NAME &&
							    !strcmp((const char *)ea + NLA_HDRLEN, "counter"))
								is_cnt = 1;
							r += NLA_ALIGN_(eal);
						}
						if (is_cnt) {
							r = (const char *)el + NLA_HDRLEN;
							for (; r + (int)sizeof(struct nlattr) <= re; ) {
								const struct nlattr *ea = (const struct nlattr *)r;
								int eal = (int)ea->nla_len;

								if (eal < (int)sizeof(*ea) || r + eal > re)
									break;
								if ((ea->nla_type & 0x3fff) == NFTA_EXPR_DATA) {
									const char *d = (const char *)ea + NLA_HDRLEN;
									const char *de = (const char *)ea + eal;

									for (; d + (int)sizeof(struct nlattr) <= de; ) {
										const struct nlattr *da = (const struct nlattr *)d;
										int dal = (int)da->nla_len;

										if (dal < (int)sizeof(*da) || d + dal > de)
											break;
										if ((da->nla_type & 0x3fff) == NFTA_COUNTER_PACKETS) {
											int k, bl = dal - NLA_HDRLEN;
											unsigned long long v = 0;
											const unsigned char *b =
												(const unsigned char *)da + NLA_HDRLEN;

											for (k = 0; k < bl && k < 8; k++)
												v = (v << 8) | b[k];
											pkts += v;
										}
										d += NLA_ALIGN_(dal);
									}
								}
								r += NLA_ALIGN_(eal);
							}
						}
						q += NLA_ALIGN_(ell);
					}
				}
				p += NLA_ALIGN_(alen);
			}
		}
	}
out:
	close(fd);
	return pkts;
}

/* ---------- the row ---------- */

static int hexcopy(char *dst, int dstsz, const unsigned char *src, int len)
{
	int i, at = 0;

	if (len <= 0 || !src) {
		snprintf(dst, (size_t)dstsz, "-");
		return 0;
	}
	for (i = 0; i < len && i < 64; i++)
		at += snprintf(dst + at, (size_t)(dstsz - at), "%02x", src[i]);
	return len;
}

static void chglist(char *dst, int dstsz,
		    const unsigned char *cap, int clen,
		    const unsigned char *ctl, int ctl_len)
{
	int i, n = 0;
	size_t at = 0;

	dst[0] = 0;
	if (!cap || !ctl || clen <= 0 || ctl_len <= 0) {
		snprintf(dst, (size_t)dstsz, "-");
		return;
	}
	for (i = 0; i < clen && i < ctl_len; i++) {
		if (cap[i] == ctl[i])
			continue;
		n++;
		if (at < (size_t)dstsz - 24)
			at += (size_t)snprintf(dst + at, (size_t)(dstsz - (int)at),
					       "%s%d:%02x>%02x", n > 1 ? "," : "",
					       i, ctl[i], cap[i]);
	}
	if (!n)
		snprintf(dst, (size_t)dstsz, "-");
}

/* ---------- environment ---------- */

static unsigned char MAC_I0[6];
static int CAP_I1 = -1, CAP_O1 = -1, CAP_I0 = -1, NFL = -1;

static int env_setup(void)
{
	int rc = 0;

	if (link_add_veth("i0", "i1"))
		rc |= 1;
	if (link_add_veth("o0", "o1"))
		rc |= 2;
	set_up("i0");
	set_up("i1");
	set_up("o0");
	set_up("o1");
	set_up("lo");
	f555_addr_add("i0", htonl(0x0a010001), 24);	/* 10.1.0.1 */
	f555_addr_add("o0", htonl(0x0a090001), 24);	/* 10.9.0.1 */
	f555_sysctl("/proc/sys/net/ipv4/ip_forward", "0");
	mac_get("i0", MAC_I0);
	CAP_I1 = cap_open("i1");
	CAP_I0 = cap_open("i0");
	CAP_O1 = cap_open("o1");
	NFL = nfl_open(5);
	printf("F555 SETUP|rc=%d|mac_i0=%02x:%02x:%02x:%02x:%02x:%02x|cap_i1=%d|"
	       "cap_o1=%d|cap_i0=%d|nflog=%d\n", rc, MAC_I0[0], MAC_I0[1],
	       MAC_I0[2], MAC_I0[3], MAC_I0[4], MAC_I0[5], CAP_I1, CAP_O1,
	       CAP_I0, NFL);
	return rc;
}

/* ---------- A: does the family exist ---------- */

static int HAVE_ARP;

static void sec_a(void)
{
	struct { const char *n; uint8_t f; } fams[] = {
		{ "ip", NFPROTO_IPV4 },
		{ "arp", NFPROTO_ARP },
		{ "bridge", NFPROTO_BRIDGE },
		{ "netdev", NFPROTO_NETDEV },
	};
	char cmd[256], tag[64];
	int i;

	sh("/nft flush ruleset");
	for (i = 0; i < (int)(sizeof(fams) / sizeof(fams[0])); i++) {
		int rc;

		snprintf(tag, sizeof(tag), "a.%s", fams[i].n);
		snprintf(cmd, sizeof(cmd), "/nft add table %s p555f", fams[i].n);
		rc = nft(tag, cmd);
		printf("F555 FAM|%s|%d\n", fams[i].n, rc);
		if (rc == 0) {
			snprintf(cmd, sizeof(cmd), "/nft delete table %s p555f",
				 fams[i].n);
			sh(cmd);
		}
	}
	HAVE_ARP = (nft("a.arp2", "/nft add table arp p555a") == 0);
	printf("F555 HAVE|arp=%d\n", HAVE_ARP);
}

/* ---------- B: which hooks does the arp filter chain type accept ---------- */

static void sec_b(void)
{
	static const char *hs[][2] = {
		{ "input",      "type filter hook input priority 0; policy accept;" },
		{ "output",     "type filter hook output priority 0; policy accept;" },
		{ "forward",    "type filter hook forward priority 0; policy accept;" },
		{ "prerouting", "type filter hook prerouting priority 0; policy accept;" },
		{ "postrouting","type filter hook postrouting priority 0; policy accept;" },
		{ "ingress",    "type filter hook ingress priority 0; policy accept;" },
	};
	char cmd[512], tag[64];
	int i, rc;

	if (!HAVE_ARP) {
		printf("F555 HOOK|SKIP=no-arp-family\n");
		return;
	}
	for (i = 0; i < (int)(sizeof(hs) / sizeof(hs[0])); i++) {
		snprintf(tag, sizeof(tag), "b.%s", hs[i][0]);
		snprintf(cmd, sizeof(cmd), "/nft add chain arp p555a %s '{ %s }'",
			 hs[i][0], hs[i][1]);
		rc = nft(tag, cmd);
		printf("F555 HOOK|%s|%d\n", hs[i][0], rc);
	}
	sh("/nft delete table arp p555a");
}

/* ---------- diagnostic: what is actually in the rule ----------
 * F555D <table>.<chain>|r<N>=[expr(attr=val)...]
 * For a `log` expression both byte orders of NFTA_LOG_GROUP are printed, plus
 * the prefix, because "the rule counts but nothing arrives" has exactly one
 * cheap explanation to rule out first. */
static void dump_exprs(uint8_t family, const char *table, const char *chain)
{
	char buf[1024], rbuf[16384];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	int fd, sent, nrules = 0;

	fd = nl_open();
	if (fd < 0)
		return;
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1);
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1);
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return;
	}
	printf("F555D %s.%s|", table, chain);
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			const char *p, *end;

			if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
				goto done;
			if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				continue;
			printf("r%d=[", nrules);
			p = (const char *)h + NLMSG_HDRLEN + sizeof(*nfg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || p + alen > end)
					break;
				if ((a->nla_type & 0x3fff) == NFTA_RULE_EXPRESSIONS) {
					const char *q = (const char *)a + NLA_HDRLEN;
					const char *qe = (const char *)a + alen;
					int first = 1;

					for (; q + (int)sizeof(struct nlattr) <= qe; ) {
						const struct nlattr *el = (const struct nlattr *)q;
						int ell = (int)el->nla_len;
						const char *r, *re;
						const char *name = "?";
						char extra[128] = "";

						if (ell < (int)sizeof(*el) || q + ell > qe)
							break;
						r = (const char *)el + NLA_HDRLEN;
						re = (const char *)el + ell;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int eal = (int)ea->nla_len;

							if (eal < (int)sizeof(*ea) || r + eal > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_NAME)
								name = (const char *)ea + NLA_HDRLEN;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_DATA &&
							    !strcmp(name, "log")) {
								const char *dd = (const char *)ea + NLA_HDRLEN;
								const char *de = (const char *)ea + eal;
								char pfx[48] = "";
								int g_le = -1, g_be = -1;

								for (; dd + (int)sizeof(struct nlattr) <= de; ) {
									const struct nlattr *da = (const struct nlattr *)dd;
									int dal = (int)da->nla_len;

									if (dal < (int)sizeof(*da) || dd + dal > de)
										break;
									if ((da->nla_type & 0x3fff) == NFTA_LOG_GROUP &&
									    dal - NLA_HDRLEN >= 2) {
										const unsigned char *b =
											(const unsigned char *)da + NLA_HDRLEN;

										g_be = (b[0] << 8) | b[1];
										g_le = (b[1] << 8) | b[0];
									}
									if ((da->nla_type & 0x3fff) == NFTA_LOG_PREFIX)
										snprintf(pfx, sizeof(pfx), "%s",
											 (const char *)da + NLA_HDRLEN);
									dd += NLA_ALIGN_(dal);
								}
								snprintf(extra, sizeof(extra),
									 "{grp_be=%d,grp_le=%d,pfx=%s}",
									 g_be, g_le, pfx);
							}
							r += NLA_ALIGN_(eal);
						}
						printf("%s%s%s", first ? "" : ",", name, extra);
						first = 0;
						q += NLA_ALIGN_(ell);
					}
				}
				p += NLA_ALIGN_(alen);
			}
			printf("]");
			nrules++;
		}
	}
done:
	printf("|rules=%d\n", nrules);
	close(fd);
}

/* ---------- arm plumbing ---------- */

static void imm_pat(unsigned char *imm, int len)
{
	static const unsigned char pat[16] = {
		0xa5, 0x5a, 0x3c, 0xc3, 0x0f, 0xf0, 0x96, 0x69,
		0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88
	};
	int i;

	for (i = 0; i < len && i < 16; i++)
		imm[i] = pat[i];
}


struct rowres {
	int rc;
	int nfl;
	unsigned char nb[128];
	unsigned long long cnt;
	int ci1, co1, ilen, olen;
	unsigned char ib[248], ob[248];
};

static void row(const char *tag, const char *hook, const char *src,
		const char *rule, const char *g,
		const char *table, const char *chain,
		const unsigned char *ctl, int clen, int trig_out, uint32_t tpa,
		struct rowres *rs)
{
	char pre[80], h[160], chg[600];
	int nfl, ni1, no1;
	unsigned long long cnt;

	snprintf(pre, sizeof(pre), "f555.%s", tag);
	nfl = nfl_wait(NFL, pre, rs->nb, (int)sizeof(rs->nb), trig_out ? 600 : 300);
	ni1 = cap_arp_t(CAP_I1, rs->ib, (int)sizeof(rs->ib), trig_out ? 300 : 120,
			MAC_I0, 1, tpa);
	no1 = trig_out ? 0 : cap_arp_t(CAP_O1, rs->ob, (int)sizeof(rs->ob), 30,
				       MAC_I0, 1, 0);
	cnt = f555_count(NFPROTO_ARP, table, chain);
	rs->nfl = nfl;
	rs->cnt = cnt;
	rs->ci1 = ni1 > 0;
	rs->co1 = no1 > 0;
	rs->ilen = ni1;
	rs->olen = no1;
	hexcopy(h, (int)sizeof(h), rs->nb, nfl);
	chglist(chg, (int)sizeof(chg), rs->nb, nfl, ctl, clen);
	printf("F555 A|%s|hook=%s|src=%s|g=%s|rule=%s|rc=%d|cnt=%llu|nfl=%d|"
	       "chg=%s|nhex=%s|ci1=%d|ihex=",
	       tag, hook, src, g, rule, rs->rc, cnt, nfl, chg, h, ni1 > 0);
	hexcopy(h, (int)sizeof(h), rs->ib, ni1);
	printf("%s|co1=%d|ohex=", h, no1 > 0);
	hexcopy(h, (int)sizeof(h), rs->ob, no1);
	printf("%s\n", h);
}

static void arm_in_raw(const char *tag, const char *table, const char *chain,
		       uint32_t off, uint32_t len,
		       const unsigned char *fr, int flen,
		       const unsigned char *ctl, int clen, struct rowres *rs)
{
	unsigned char imm[32];
	char pre[80], g[32];

	memset(imm, 0, sizeof(imm));
	imm_pat(imm, (int)len);
	snprintf(pre, sizeof(pre), "f555.%s", tag);
	flush_chain(NFPROTO_ARP, table, chain);
	rs->rc = install_store(NFPROTO_ARP, table, chain, off, len, imm, (int)len,
			       1, 5, pre);
	cap_drain(CAP_I1);
	cap_drain(CAP_O1);
	nfl_drain(NFL);
	usleep(10000);
	pkt_send("i1", fr, flen);
	snprintf(g, sizeof(g), "%u,%u", off, len);
	row(tag, "in", "raw", "@nh,+", g, table, chain, ctl, clen, 0, 0, rs);
}

static void arm_in_nft(const char *tag, const char *table, const char *chain,
		       const char *ruletext, const char *g,
		       const unsigned char *fr, int flen,
		       const unsigned char *ctl, int clen, struct rowres *rs)
{
	char cmd[700], pre[80];

	snprintf(pre, sizeof(pre), "f555.%s", tag);
	flush_chain(NFPROTO_ARP, table, chain);
	snprintf(cmd, sizeof(cmd),
		 "/nft --debug=netlink add rule arp %s %s '%s log group 5 prefix \"%s\" counter accept'",
		 table, chain, ruletext, pre);
	rs->rc = nft(tag, cmd);
	cap_drain(CAP_I1);
	cap_drain(CAP_O1);
	nfl_drain(NFL);
	usleep(10000);
	pkt_send("i1", fr, flen);
	row(tag, "in", "nft", ruletext, g, table, chain, ctl, clen, 0, 0, rs);
}

static void arm_out_raw(const char *tag, const char *table, const char *chain,
			uint32_t off, uint32_t len, uint32_t poke,
			const unsigned char *ctl, int clen, struct rowres *rs)
{
	unsigned char imm[32];
	char pre[80], g[32];

	memset(imm, 0, sizeof(imm));
	imm_pat(imm, (int)len);
	snprintf(pre, sizeof(pre), "f555.%s", tag);
	flush_chain(NFPROTO_ARP, table, chain);
	rs->rc = install_store(NFPROTO_ARP, table, chain, off, len, imm, (int)len,
			       1, 5, pre);
	cap_drain(CAP_I1);
	nfl_drain(NFL);
	usleep(10000);
	f555_neigh_del("i0", htonl(poke));
	udp_poke(htonl(poke));
	snprintf(g, sizeof(g), "%u,%u", off, len);
	row(tag, "out", "raw", "@nh,+", g, table, chain, ctl, clen, 1, htonl(poke),
	    rs);
}

/* ---------- a control arm for a given table.chain ---------- */

static void arm_ctl(const char *tag, const char *hook, const char *table,
		    const char *chain, int trig_out, uint32_t poke,
		    const unsigned char *fr, int flen, struct rowres *rs)
{
	char pre[80];

	snprintf(pre, sizeof(pre), "f555.%s", tag);
	flush_chain(NFPROTO_ARP, table, chain);
	rs->rc = install_ctl(NFPROTO_ARP, table, chain, 5, pre);
	cap_drain(CAP_I1);
	cap_drain(CAP_O1);
	nfl_drain(NFL);
	usleep(20000);
	if (trig_out) {
		f555_neigh_del("i0", htonl(poke));
		udp_poke(htonl(poke));
	} else {
		pkt_send("i1", fr, flen);
	}
	row(tag, hook, "raw", "log+counter", "-", table, chain, NULL, 0,
	    trig_out, trig_out ? htonl(poke) : 0, rs);
}

/* ---------- C: the nine fields nft itself can name ---------- */

static void sec_c(unsigned char *fr, int flen)
{
	static const char *names[] = {
		"htype", "ptype", "hlen", "plen", "operation",
		"saddr_ether", "saddr_ip", "daddr_ether", "daddr_ip",
	};
	static const char *rules[] = {
		"arp htype set 0x00ab",
		"arp ptype set 0x86dd",
		"arp hlen set 8",
		"arp plen set 16",
		"arp operation set 2",
		"arp saddr ether set aa:bb:cc:00:00:99",
		"arp saddr ip set 10.1.0.66",
		"arp daddr ether set aa:bb:cc:00:00:88",
		"arp daddr ip set 10.9.0.1",
	};
	static const char *geoms[] = {
		"0,2", "2,2", "4,1", "5,1", "6,2", "8,6", "14,4", "18,6", "24,4",
	};
	struct rowres ctl, rs;
	char tag[64];
	int i;

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC c.table|%d\n", add_table(NFPROTO_ARP, "p555c"));
	printf("F555RC c.chain|%d\n", add_chain(NFPROTO_ARP, "p555c", "in", 0, 0, 1));
	arm_ctl("c.ctl", "in", "p555c", "in", 0, 0, fr, flen, &ctl);
	ctl = rs = ctl;
	for (i = 0; i < 9; i++) {
		snprintf(tag, sizeof(tag), "c.%s", names[i]);
		arm_in_nft(tag, "p555c", "in", rules[i], geoms[i], fr, flen,
			   ctl.nb, ctl.nfl, &rs);
	}
	/* C2: the raw escape, in the family nft could never reach before */
	arm_in_nft("c2.spill2016", "p555c", "in",
		   "@nh,160,128 set 0x00112233445566778899aabbccddeeff", "20,16",
		   fr, flen, ctl.nb, ctl.nfl, &rs);
	arm_in_nft("c2.pad288", "p555c", "in",
		   "@nh,224,64 set 0x0102030405060708", "28,8",
		   fr, flen, ctl.nb, ctl.nfl, &rs);
	arm_in_nft("c2.op71", "p555c", "in", "@nh,56,8 set 0xab", "7,1",
		   fr, flen, ctl.nb, ctl.nfl, &rs);
	sh("/nft delete table arp p555c");
}

/* ---------- D: the guard as a function of (offset,len), input hook ---------- */

static const int GRID_OFF[] = { 0, 1, 2, 4, 5, 6, 7, 8, 10, 14, 18, 20, 24, 26, 28, 30 };
static const int GRID_LEN[] = { 1, 2, 4, 6, 8, 16 };

static void sec_d(unsigned char *fr, int flen)
{
	struct rowres ctl, rs;
	int i, j;
	char tag[64];

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC d.table|%d\n", add_table(NFPROTO_ARP, "p555d"));
	printf("F555RC d.chain|%d\n", add_chain(NFPROTO_ARP, "p555d", "in", 0, 0, 1));
	arm_ctl("d.ctl", "in", "p555d", "in", 0, 0, fr, flen, &ctl);
	for (i = 0; i < (int)(sizeof(GRID_OFF) / sizeof(GRID_OFF[0])); i++) {
		for (j = 0; j < (int)(sizeof(GRID_LEN) / sizeof(GRID_LEN[0])); j++) {
			int off = GRID_OFF[i], len = GRID_LEN[j];

			if (off + len > 46)	/* past the padded frame: not the guard */
				continue;
			snprintf(tag, sizeof(tag), "d.%d.%d", off, len);
			arm_in_raw(tag, "p555d", "in", (uint32_t)off, (uint32_t)len,
				   fr, flen, ctl.nb, ctl.nfl, &rs);
		}
	}
	sh("/nft delete table arp p555d");
}

/* ---------- E: the same grid at the OUTPUT hook ---------- */

static void sec_e(unsigned char *fr, int flen)
{
	static const int EOFF[] = { 0, 4, 6, 8, 14, 18, 20, 24, 24, 26, 28, 30 };
	static const int ELEN[] = { 2, 1, 2, 6, 4, 6, 16, 4, 6, 4, 8, 16 };
	struct rowres ctl, rs;
	int i;
	char tag[64];
	(void)fr;
	(void)flen;

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC e.table|%d\n", add_table(NFPROTO_ARP, "p555e"));
	/* NF_ARP_OUT is 1 -- NF_ARP_FORWARD is 2 (netfilter_arp.h), and the first
	 * smoke of this turn asked for hook 2 and got -EOPNOTSUPP for every arm. */
	printf("F555RC e.chain|%d\n", add_chain(NFPROTO_ARP, "p555e", "out", 1, 0, 1));
	arm_ctl("e.ctl", "out", "p555e", "out", 1, 0x0a0100c0, NULL, 0, &ctl);
	for (i = 0; i < (int)(sizeof(EOFF) / sizeof(EOFF[0])); i++) {
		snprintf(tag, sizeof(tag), "e.%d.%d", EOFF[i], ELEN[i]);
		arm_out_raw(tag, "p555e", "out", (uint32_t)EOFF[i],
			    (uint32_t)ELEN[i], 0x0a0100c0,
			    ctl.nb, ctl.nfl, &rs);
	}
	sh("/nft delete table arp p555e");
}

/* ---------- F: what a rule in this family does to the host ---------- */

static void sec_f(void)
{
	struct {
		const char *tag;
		const char *rule;
		uint32_t spa;
		const char *spa_s;
		const char *moved_s;	/* the address a live rewrite would produce */
	} fa[] = {
		{ "f.norule", NULL,                       0x0a010091, "10.1.0.91", "10.5.5.5" },
		{ "f.alive",  "arp saddr ip set 10.5.5.5", 0x0a010092, "10.1.0.92", "10.5.5.5" },
		{ "f.dead",   "arp htype set 2",           0x0a010093, "10.1.0.93", "10.5.5.6" },
		{ "f.op",     "arp operation set 2",       0x0a010094, "10.1.0.94", "10.5.5.7" },
	};
	unsigned char fr[160];
	int flen, i;
	char cmd[700], tag[64];

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC f.table|%d\n", add_table(NFPROTO_ARP, "p555f"));
	printf("F555RC f.chain|%d\n", add_chain(NFPROTO_ARP, "p555f", "in2", 0, 0, 0));
	for (i = 0; i < (int)(sizeof(fa) / sizeof(fa[0])); i++) {
		int rc = 0, ni1, no1;
		unsigned long long cnt;

		flush_chain(NFPROTO_ARP, "p555f", "in2");
		if (fa[i].rule) {
			snprintf(tag, sizeof(tag), "%s.i", fa[i].tag);
			snprintf(cmd, sizeof(cmd),
				 "/nft add rule arp p555f in2 '%s counter accept'",
				 fa[i].rule);
			rc = nft(tag, cmd);
		}
		flen = build_arp(fr, 1, fa[i].spa, 0x0a010001, MAC_SRC, 6, 4, 1);
		cap_drain(CAP_I1);
		cap_drain(CAP_O1);
		usleep(20000);
		pkt_send("i1", fr, flen);
		ni1 = cap_arp(CAP_I1, fr, 248, 300, MAC_I0, 1);
		no1 = cap_arp(CAP_O1, fr, 248, 40, MAC_I0, 1);
		cnt = f555_count(NFPROTO_ARP, "p555f", "in2");
		printf("F555 F|%s|rule=%s|rc=%d|cnt=%llu|reply_i=%d|reply_o=%d\n",
		       fa[i].tag, fa[i].rule ? fa[i].rule : "none", rc, cnt,
		       ni1 > 0, no1 > 0);
		arp_row(fa[i].tag, fa[i].spa_s);
		arp_row(fa[i].tag, fa[i].moved_s);
	}
	sh("/nft delete table arp p555f");
}

/* ---------- G: what the receive path refuses before nft sees the packet ---------- */

static void sec_g(void)
{
	struct {
		const char *tag;
		int hlen, plen;
		uint32_t spa;
	} ga[] = {
		{ "g.h6p4",  6, 4,  0x0a0100b0 },
		{ "g.h8p16", 8, 16, 0x0a0100b1 },
		{ "g.h6p8",  6, 8,  0x0a0100b2 },
	};
	unsigned char fr[160], pay[128];
	int i, flen;
	char tag[64], pre[80];

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC g.table|%d\n", add_table(NFPROTO_ARP, "p555g"));
	printf("F555RC g.chain|%d\n", add_chain(NFPROTO_ARP, "p555g", "in", 0, 0, 1));
	for (i = 0; i < 3; i++) {
		int rc, nfl, rx;
		unsigned long long cnt;

		flush_chain(NFPROTO_ARP, "p555g", "in");
		snprintf(pre, sizeof(pre), "f555.%s", ga[i].tag);
		rc = install_ctl(NFPROTO_ARP, "p555g", "in", 5, pre);
		flen = build_arp(fr, 1, ga[i].spa, 0x0a010001, MAC_SRC,
				 ga[i].hlen, ga[i].plen, 1);
		cap_drain(CAP_I1);
		nfl_drain(NFL);
		usleep(20000);
		pkt_send("i1", fr, flen);
		nfl = nfl_wait(NFL, pre, pay, (int)sizeof(pay), 300);
		rx = cap_arp(CAP_I0, fr, 248, 200, MAC_SRC, 1) > 0;
		cnt = f555_count(NFPROTO_ARP, "p555g", "in");
		snprintf(tag, sizeof(tag), "%s", ga[i].tag);
		printf("F555 G|%s|hlen=%d|plen=%d|flen=%d|rc=%d|rx_i0=%d|cnt=%llu|"
		       "nfl=%d\n", tag, ga[i].hlen, ga[i].plen, flen, rc, rx, cnt, nfl);
	}
	sh("/nft delete table arp p555g");
}

/* ---------- focused experiment (mode f555log): where does the prefix go ---------- */

static void dump_log_hex(uint8_t family, const char *table, const char *chain,
			 const char *tag)
{
	char buf[1024], rbuf[16384];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	int fd, sent;

	fd = nl_open();
	if (fd < 0)
		return;
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1);
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1);
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return;
	}
	printf("F555H %s|", tag);
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			const char *p, *end;

			if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
				goto done;
			if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				continue;
			p = (const char *)h + NLMSG_HDRLEN + sizeof(*nfg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || p + alen > end)
					break;
				if ((a->nla_type & 0x3fff) == NFTA_RULE_EXPRESSIONS) {
					const char *q = (const char *)a + NLA_HDRLEN;
					const char *qe = (const char *)a + alen;

					for (; q + (int)sizeof(struct nlattr) <= qe; ) {
						const struct nlattr *el = (const struct nlattr *)q;
						int ell = (int)el->nla_len;
						const char *r, *re;
						const char *name = "?";

						if (ell < (int)sizeof(*el) || q + ell > qe)
							break;
						r = (const char *)el + NLA_HDRLEN;
						re = (const char *)el + ell;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int eal = (int)ea->nla_len;
							int k;

							if (eal < (int)sizeof(*ea) || r + eal > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_NAME)
								name = (const char *)ea + NLA_HDRLEN;
							r += NLA_ALIGN_(eal);
						}
						if (!strcmp(name, "log")) {
							r = (const char *)el + NLA_HDRLEN;
							for (; r + (int)sizeof(struct nlattr) <= re; ) {
								const struct nlattr *ea = (const struct nlattr *)r;
								int eal = (int)ea->nla_len;

								if (eal < (int)sizeof(*ea) || r + eal > re)
									break;
								if ((ea->nla_type & 0x3fff) == NFTA_EXPR_DATA) {
									const unsigned char *b =
										(const unsigned char *)ea + NLA_HDRLEN;
									int n = eal - NLA_HDRLEN, k;

									printf("logdata[%d]=", n);
									for (k = 0; k < n; k++)
										printf("%02x", b[k]);
									printf("|");
								}
								r += NLA_ALIGN_(eal);
							}
						}
						q += NLA_ALIGN_(ell);
					}
				}
				p += NLA_ALIGN_(alen);
			}
		}
	}
done:
	printf("|end\n");
	close(fd);
}

static void nfl_readall(int fd, int ms, const char *tag)
{
	struct timeval tv = { .tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000 };
	int n = 0;

	for (;;) {
		unsigned char b[4096];
		int r;

		FD_ZERO(&(fd_set){0});
		{
			fd_set rfds;

			FD_ZERO(&rfds);
			FD_SET(fd, &rfds);
			if (select(fd + 1, &rfds, NULL, NULL, &tv) <= 0)
				break;
		}
		r = (int)recv(fd, b, sizeof(b), 0);
		if (r <= 0)
			break;
		{
			struct nlmsghdr *h = (struct nlmsghdr *)b;
			int rem = r;

			for (; NLMSG_OK(h, rem); h = NLMSG_NEXT(h, rem)) {
				const unsigned char *p;
				int plen, off;
				char pre[64] = "";
				unsigned char pay[128];
				int paylen = 0, k;

				if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_ULOG_ << 8) |
								NFULNL_MSG_PACKET_))
					continue;
				p = (const unsigned char *)NLMSG_DATA(h);
				plen = (int)h->nlmsg_len - NLMSG_HDRLEN;
				for (off = 4; off + (int)sizeof(struct nlattr) <= plen; ) {
					const struct nlattr *a = (const struct nlattr *)(p + off);
					int alen = (int)a->nla_len;

					if (alen < (int)sizeof(*a) || off + alen > plen)
						break;
					if ((a->nla_type & 0x3fff) == NFULA_PREFIX_)
						snprintf(pre, sizeof(pre), "%s",
							 (const char *)a + NLA_HDRLEN);
					if ((a->nla_type & 0x3fff) == NFULA_PAYLOAD_) {
						int m = alen - NLA_HDRLEN;

						if (m > 128)
							m = 128;
						memcpy(pay, (const char *)a + NLA_HDRLEN, (size_t)m);
						paylen = m;
					}
					off += (int)NLA_ALIGN_(alen);
				}
				n++;
				printf("F555N %s|n=%d|pre=%s|len=%d|pay=", tag, n, pre, paylen);
				for (k = 0; k < paylen && k < 48; k++)
					printf("%02x", pay[k]);
				printf("\n");
			}
		}
	}
	if (!n)
		printf("F555N %s|n=0\n", tag);
}

/* four variants of the same question, one boot */
static void sec_log(void)
{
	unsigned char fr[160], imm[16];
	char pre[64];
	int flen, i;
	static const struct { const char *tag; const char *pre; int store; } v[] = {
		{ "l.ctl",   "abc.def", 0 },
		{ "l.store", "ghi.jkl", 1 },
	};

	sh("/nft flush ruleset");
	printf("F555RC l.table|%d\n", add_table(NFPROTO_ARP, "p555l"));
	printf("F555RC l.chain|%d\n", add_chain(NFPROTO_ARP, "p555l", "in", 0, 0, 1));
	flen = build_arp(fr, 1, 0x0a010009, 0x0a010001, MAC_SRC, 6, 4, 1);
	memset(imm, 0, sizeof(imm));
	imm_pat(imm, 2);
	for (i = 0; i < 2; i++) {
		int rc;

		snprintf(pre, sizeof(pre), "f555.%s", v[i].tag);
		flush_chain(NFPROTO_ARP, "p555l", "in");
		if (v[i].store)
			rc = install_store(NFPROTO_ARP, "p555l", "in", 8, 2, imm, 2, 1,
					   5, v[i].pre);
		else
			rc = install_ctl(NFPROTO_ARP, "p555l", "in", 5, v[i].pre);
		printf("F555RC %s|%d\n", v[i].tag, rc);
		dump_log_hex(NFPROTO_ARP, "p555l", "in", v[i].tag);
		cap_drain(CAP_I1);
		nfl_drain(NFL);
		usleep(20000);
		pkt_send("i1", fr, flen);
		{
			unsigned long long cnt = f555_count(NFPROTO_ARP, "p555l", "in");

			printf("F555C %s|cnt=%llu\n", v[i].tag, cnt);
		}
		nfl_readall(NFL, 400, v[i].tag);
	}
	/* the same rule, installed by nft */
	flush_chain(NFPROTO_ARP, "p555l", "in");
	printf("F555RC l.nft|%d\n",
	       nft("l.nft", "/nft add rule arp p555l in 'log group 5 prefix \"mno.pqr\" counter accept'"));
	dump_log_hex(NFPROTO_ARP, "p555l", "in", "l.nft");
	cap_drain(CAP_I1);
	nfl_drain(NFL);
	usleep(20000);
	pkt_send("i1", fr, flen);
	nfl_readall(NFL, 400, "l.nft");
	sh("/nft delete table arp p555l");
}
/* ---------- /proc/net/arp sanity + main ---------- */

int f555_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f555";
	unsigned char fr[160];
	int flen;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F555 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F555 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	sec_a();
	sec_b();
	if (!strcmp(mode, "f555bare")) {
		printf("F555 DONE\n");
		return 0;
	}
	env_setup();
	flen = build_arp(fr, 1, 0x0a010009, 0x0a010001, MAC_SRC, 6, 4, 1);
	printf("F555 FRAME|len=%d|hex=", flen);
	{
		int i;

		for (i = 0; i < 60; i++)
			printf("%02x", fr[i]);
		printf("\n");
	}
	if (!strcmp(mode, "f555log")) {
		sec_log();
		printf("F555 DONE\n");
		return 0;
	}
	sec_c(fr, flen);
	sec_d(fr, flen);
	sec_e(fr, flen);
	sec_f();
	sec_g();
	printf("F555 DONE\n");
	return 0;
}
/* differ556_add.c -- turn 556 / F33: one guard, four types, one grid.
 *
 * F30/F31/F32 measured the four branches of nft_nh_write_ok() one at a time,
 * on three DIFFERENT images:
 *
 *   ip4/ip6     stock 7.3.4-B19           (F30)
 *   bridge      src/linux-7.3.4-C553      (F31, ethertype 0x0800 / 0x0806)
 *   netdev      src/linux-7.3.4-C553      (F31, dead code at ingress)
 *   arp         src/linux-7.3.4-A553      (F32)
 *
 * F33 asks a different question: not "does branch X guard byte Y", but "what
 * KIND of function is each branch".  The answer is the SHAPE of the set of
 * (offset,len) pairs it accepts, and a shape measured in three different boots
 * on three different images is not a shape.  So: one kernel (T556) with all
 * four branches live, one boot, and ONE identical 40-cell grid shipped through
 * every envelope:
 *
 *   ip4   family ip,     base nh, chain prerouting   (nft_nh_write_ok_ip4)
 *   ip6   family ip6,    base nh, chain prerouting   (nft_nh_write_ok_ip6)
 *   nd    family netdev, base nh, chain ingress i1   (nft_nh_write_ok -> true)
 *   br4   family bridge, base nh, chain prerouting, ethertype 0x0800
 *   brA   family bridge, base nh, chain prerouting, ethertype 0x0806
 *   arp   family arp,    base nh, chain input        (nft_nh_write_ok_arp)
 *   ll4   family ip,     base ll, chain prerouting   (nft_ll_write_ok)
 *   llN   family netdev, base ll, chain ingress i1
 *   llB   family bridge, base ll, chain prerouting
 *
 * Oracle per arm: the kernel's own counter, placed AFTER the store in the same
 * rule -- cnt=1 means "the guard let the store through and the rest of the
 * rule ran", cnt=0 means the store was refused and the remaining expressions
 * (log, counter, verdict) never ran.  The NFLOG message carries the frame as
 * it looks at the log point, i.e. after the store, so every alive cell also
 * gets its bytes checked against the control arm of the same envelope.
 *
 * This file is appended to a renamed copy of differ555.c (see
 * vm/build_f33_differ.sh); all helpers above it -- netlink toolkit, veth,
 * rtnetlink, NFLOG, build_arp, f555_count -- are the F32 ones, unchanged.
 */

/* ---------- bridge device helpers (same code as differ553.c) ---------- */

static int f556_link_add_kind(const char *name, const char *kind)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[256];
	} req;
	struct nlattr *li;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, name, (int)strlen(name) + 1);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, kind, (int)strlen(kind) + 1);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f556_link_enslave(const char *port, const char *master)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[128];
	} req;
	uint32_t midx = (uint32_t)f555_ifindex(master);
	int fd, rc;

	if ((int)midx < 0)
		return -10;
	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	req.ifi.ifi_index = f555_ifindex(port);
	attr_put(&req.nlh, IFLA_MASTER, &midx, 4);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

/* ---------- one chain, with a device when the hook needs one ---------- */

/* base chain: family, hook number, priority, policy; dev != NULL only for the
 * netdev ingress hook, whose NFTA_HOOK_DEV is a STRING (nf_tables_api.c reads
 * it with nla_get_string()). */
static int f556_add_chain(uint8_t family, const char *table, const char *chain,
			  uint32_t hook, uint32_t prio, uint32_t policy,
			  const char *dev)
{
	struct nlmsghdr *nlh;
	struct nlattr *h;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWCHAIN,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE, family);
	put_str(nlh, NFTA_CHAIN_TABLE, table);
	put_str(nlh, NFTA_CHAIN_NAME, chain);
	h = nest_start(nlh, NFTA_CHAIN_HOOK);
	put_be32(nlh, NFTA_HOOK_HOOKNUM, hook);
	put_be32(nlh, NFTA_HOOK_PRIORITY, prio);
	if (dev)
		put_str(nlh, NFTA_HOOK_DEV, dev);
	nest_end(nlh, h);
	put_be32(nlh, NFTA_CHAIN_POLICY, policy);
	put_str(nlh, NFTA_CHAIN_TYPE, "filter");
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

/* ---------- the store, with an explicit payload BASE ---------- */

/* one rule: [store <base>+off = imm][log][counter][accept] */
static int f556_install_store(uint8_t family, const char *table, const char *chain,
			      uint32_t base, uint32_t off, uint32_t len,
			      const unsigned char *imm, int immlen,
			      int loggroup, const char *prefix)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *e, *d;
	int rc;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	imm_value(nlh, NFT_REG32_00, imm, immlen);
	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "payload");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00);
	put_be32(nlh, NFTA_PAYLOAD_BASE, base);
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
	put_be32(nlh, NFTA_PAYLOAD_LEN, len);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
	nest_end(nlh, d);
	nest_end(nlh, e);
	log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	rc = nft_one(opbuf, (int)nlh->nlmsg_len);
	return rc;
}

/* ---------- frames ---------- */

static const unsigned char M33_BC[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

static unsigned short f556_csum(const void *data, int len)
{
	const unsigned char *p = data;
	unsigned int sum = 0;

	while (len > 1) {
		sum += (unsigned int)((p[0] << 8) | p[1]);
		p += 2;
		len -= 2;
	}
	if (len)
		sum += (unsigned int)(p[0] << 8);
	while (sum >> 16)
		sum = (sum & 0xffff) + (sum >> 16);
	return (unsigned short)~sum;
}

/* frame kinds */
#define FK33_IP4	0	/* ethernet + IPv4 (ihl 5, proto 17) + UDP */
#define FK33_IP6	1	/* ethernet + IPv6 + UDP                     */
#define FK33_ARP	2	/* ethernet + ARP request, padded to 60      */
#define FK33_IP4_IHL6	3	/* the same datagram with ihl 6 -> byte 14 = 0x46 */
#define FK33_IP4_P6	4	/* the same datagram with proto 6 (byte 23 = 0x06) */
#define FK33_IP6_B	5	/* a different IPv6 frame (tc/hop differ)    */

/* Ethernet + IPv4 + UDP.  ihl4 is the header length in 32-bit words; the
 * checksum is computed over exactly ihl4*4 bytes, so an ihl-6 frame is a
 * VALID datagram -- ip_rcv must not drop it before the hook, or the guard
 * would never be asked. */
static int f556_mk_ip4(unsigned char *out, int ihl4, int proto, int ttl)
{
	int hl = ihl4 * 4, tot = hl + 8 + 18;
	unsigned char *ip = out + 14;
	unsigned char *u = out + 14 + hl;
	unsigned short c;

	memset(out, 0, 200);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x08;
	out[13] = 0x00;
	ip[0] = (unsigned char)(0x40 | ihl4);
	ip[1] = 0x00;
	ip[2] = (unsigned char)(tot >> 8);
	ip[3] = (unsigned char)tot;
	ip[4] = 0x12;
	ip[5] = 0x34;
	ip[6] = 0x00;
	ip[7] = 0x00;
	ip[8] = (unsigned char)ttl;
	ip[9] = (unsigned char)proto;
	ip[10] = 0x00;
	ip[11] = 0x00;
	ip[12] = 0x0a; ip[13] = 0x01; ip[14] = 0x00; ip[15] = 0x01;	/* 10.1.0.1 */
	ip[16] = 0x0a; ip[17] = 0x09; ip[18] = 0x00; ip[19] = 0x07;	/* 10.9.0.7 */
	c = f556_csum(ip, hl);
	ip[10] = (unsigned char)(c >> 8);
	ip[11] = (unsigned char)c;
	u[0] = 0x9c; u[1] = 0x40;	/* sport 40000 */
	u[2] = 0x13; u[3] = 0x88;	/* dport 5000  */
	u[4] = 0x00; u[5] = 26;		/* 8 + 18      */
	u[6] = 0x00; u[7] = 0x00;	/* checksum 0 (legal for IPv4) */
	memset(u + 8, 0x77, 18);
	return 14 + tot;
}

/* Ethernet + IPv6 + UDP.  `tc` goes into the traffic-class nibbles of bytes
 * 14..15, `hop` into byte 21 -- the two bytes FK33_IP6_B changes, so the same
 * rule over two IPv6 frames tests whether that branch reads the packet. */
static int f556_mk_ip6(unsigned char *out, int tc, int hop)
{
	int pay = 8 + 18;
	unsigned char *ip = out + 14;
	unsigned char *u = out + 14 + 40;
	static const unsigned char src[16] = { 0xfd, 0, 0, 0, 0, 0, 0, 0,
					       0, 0, 0, 0, 0, 0x98, 0, 1 };
	static const unsigned char dst[16] = { 0xfd, 0, 0, 0, 0, 0, 0, 0,
					       0, 0, 0, 0, 0, 0x99, 0, 9 };

	memset(out, 0, 200);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x86;
	out[13] = 0xdd;
	ip[0] = 0x60 | (unsigned char)((tc >> 4) & 0x0f);
	ip[1] = (unsigned char)((tc << 4) & 0xf0);
	ip[4] = (unsigned char)(pay >> 8);
	ip[5] = (unsigned char)pay;
	ip[6] = 17;
	ip[7] = (unsigned char)hop;
	memcpy(ip + 8, src, 16);
	memcpy(ip + 24, dst, 16);
	u[0] = 0x9c; u[1] = 0x40;
	u[2] = 0x13; u[3] = 0x88;
	u[4] = 0x00; u[5] = 26;
	u[6] = 0x00; u[7] = 0x00;
	memset(u + 8, 0x77, 18);
	return 14 + 40 + pay;
}

static int f556_frame(int kind, unsigned char *out)
{
	switch (kind) {
	case FK33_IP4:
		return f556_mk_ip4(out, 5, 17, 64);
	case FK33_IP4_IHL6:
		return f556_mk_ip4(out, 6, 17, 64);
	case FK33_IP4_P6:
		return f556_mk_ip4(out, 5, 6, 64);
	case FK33_IP6:
		return f556_mk_ip6(out, 0x00, 64);
	case FK33_IP6_B:
		return f556_mk_ip6(out, 0x2e, 33);
	case FK33_ARP:
		return build_arp(out, 1, 0x0a010009, 0x0a090001, MAC_SRC, 6, 4, 1);
	}
	return f556_mk_ip4(out, 5, 17, 64);
}

/* pkt_send() above sets sll_protocol = ETH_P_ALL.  That is what
 * packet_snd() copies into skb->protocol, and at the netdev EGRESS hook the
 * guard switches on exactly that field -- so an egress arm sent with
 * ETH_P_ALL would be judged as "unknown protocol" and every cell would look
 * refused.  This variant sends the frame's own ethertype. */
static int pkt_send_p(const char *dev, const unsigned char *fr, int len,
		      unsigned short proto)
{
	struct sockaddr_ll sll;
	int s, rc, idx = f555_ifindex(dev);

	if (idx < 0)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(proto);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, fr, 6);
	rc = (int)sendto(s, fr, (size_t)len, 0, (struct sockaddr *)&sll, sizeof(sll));
	close(s);
	return rc < 0 ? -errno : 0;
}

static unsigned short f556_proto(int kind)
{
	if (kind == FK33_ARP)
		return 0x0806;
	if (kind == FK33_IP6 || kind == FK33_IP6_B)
		return 0x86dd;
	return 0x0800;
}

/* ---------- the shared grid ---------- */

#define G33_NOFF 12
#define G33_NLEN 3
#define G33_NEXT 4
#define G33_N (G33_NOFF * G33_NLEN + G33_NEXT)

static const int G33_OFF[G33_NOFF] = { 0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24 };
static const int G33_LEN[G33_NLEN] = { 1, 2, 4 };
static const int G33_XOFF[G33_NEXT] = { 0, 8, 16, 20 };
static const int G33_XLEN[G33_NEXT] = { 8, 16, 16, 16 };

/* The value a cell writes.  Where a branch compares a written byte with the
 * frame (ip4 offset 0 and offset 8 + len 2), the value is chosen equal to what
 * the frame carries, so that the LENGTH is what the cell measures and not the
 * value.  The value-dependence itself is measured separately, by the E arms. */
static void f556_imm(int kind, int off, int len, unsigned char *imm)
{
	int i;

	memset(imm, 0, 16);
	for (i = 0; i < len && i < 16; i++)
		imm[i] = (unsigned char)(0x90 + i);
	if (off == 0)
		imm[0] = (kind == FK33_IP6 || kind == FK33_IP6_B) ? 0x60 : 0x45;
	if (off == 8 && len >= 2)
		imm[1] = 0x11;	/* keep byte 9 (protocol) as the frame has it */
}

/* ---------- one envelope ---------- */

struct f556_env {
	const char *tag;
	uint8_t fam;
	const char *table;
	const char *chain;
	uint32_t hook;
	uint32_t base;
	const char *dev;	/* where the frame is injected */
	const char *rule_dev;	/* NFTA_HOOK_DEV, netdev only */
	int kind;		/* default frame kind */
};

static int NFL33 = -1;
static char PRE33[96];

static long f33_ms(void)
{
	struct timeval tv;

	gettimeofday(&tv, NULL);
	return tv.tv_sec * 1000L + tv.tv_usec / 1000;
}

static unsigned long long f556_arm(const struct f556_env *e, const char *tag,
				   int off, int len, const unsigned char *imm,
				   int immlen, int kind)
{
	unsigned char fr[256], pay[192];
	unsigned long long cnt, cnt0;
	int flen, n = 0, rc, i;
	long t0, t1, t2, t3, t4;

	flen = f556_frame(kind, fr);
	snprintf(PRE33, sizeof(PRE33), "f33.%s.%s", e->tag, tag);
	t0 = f33_ms();
	flush_chain(e->fam, e->table, e->chain);
	t1 = f33_ms();
	rc = f556_install_store(e->fam, e->table, e->chain, e->base,
				(uint32_t)off, (uint32_t)len, imm, immlen,
				5, PRE33);
	t2 = f33_ms();
	nfl_drain(NFL33);
	cnt0 = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	if (rc == 0) {
		usleep(15000);
		pkt_send_p(e->dev, fr, flen, f556_proto(kind));
		n = nfl_wait(NFL33, PRE33, pay, (int)sizeof(pay), 200);
	}
	t3 = f33_ms();
	cnt = f555_count(e->fam, e->table, e->chain);
	t4 = f33_ms();
	printf("F556 R|env=%s|arm=%s|off=%d|len=%d|kind=%d|rc=%d|cnt=%llu|cnt0=%llu|"
	       "nfl=%d|ms=%ld,%ld,%ld,%ld|hex=",
	       e->tag, tag, off, len, kind, rc, cnt, cnt0, n, t1 - t0, t2 - t1,
	       t3 - t2, t4 - t3);
	for (i = 0; i < n && i < 96; i++)
		printf("%02x", pay[i]);
	printf("\n");
	return cnt;
}

static void f556_ctl(const struct f556_env *e, int kind)
{
	unsigned char fr[256], pay[192];
	unsigned long long cnt, cnt0;
	int flen, n, rc, i;

	flen = f556_frame(kind, fr);
	snprintf(PRE33, sizeof(PRE33), "f33.%s.ctl", e->tag);
	flush_chain(e->fam, e->table, e->chain);
	rc = install_ctl(e->fam, e->table, e->chain, 5, PRE33);
	nfl_drain(NFL33);
	n = 0;
	cnt0 = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	if (rc == 0) {
		usleep(15000);
		pkt_send_p(e->dev, fr, flen, f556_proto(kind));
		n = nfl_wait(NFL33, PRE33, pay, (int)sizeof(pay), 300);
	}
	cnt = f555_count(e->fam, e->table, e->chain);
	printf("F556 CTL|env=%s|kind=%d|rc=%d|cnt=%llu|cnt0=%llu|nfl=%d|hex=",
	       e->tag, kind, rc, cnt, cnt0, n);
	for (i = 0; i < n && i < 96; i++)
		printf("%02x", pay[i]);
	printf("\n");
}

/* create the table and the one chain this envelope owns */
static int f556_chain(const struct f556_env *e)
{
	int rc, rc2;

	rc = add_table(e->fam, e->table);
	rc2 = f556_add_chain(e->fam, e->table, e->chain, e->hook, 0, 1,
			     e->rule_dev);
	printf("F556 CHAIN|env=%s|table=%d|chain=%d\n", e->tag, rc, rc2);
	return rc || rc2;
}

static void f556_env_run(const struct f556_env *e)
{
	unsigned char imm[16];
	char tag[32];
	int i, j;

	f556_ctl(e, e->kind);
	for (i = 0; i < G33_NOFF; i++) {
		for (j = 0; j < G33_NLEN; j++) {
			f556_imm(e->kind, G33_OFF[i], G33_LEN[j], imm);
			snprintf(tag, sizeof(tag), "g%d_%d", G33_OFF[i], G33_LEN[j]);
			f556_arm(e, tag, G33_OFF[i], G33_LEN[j], imm, G33_LEN[j],
				 e->kind);
		}
	}
	for (i = 0; i < G33_NEXT; i++) {
		f556_imm(e->kind, G33_XOFF[i], G33_XLEN[i], imm);
		snprintf(tag, sizeof(tag), "x%d_%d", G33_XOFF[i], G33_XLEN[i]);
		f556_arm(e, tag, G33_XOFF[i], G33_XLEN[i], imm, G33_XLEN[i],
			 e->kind);
	}
	sh("/nft flush ruleset");
}

/* ---------- environment ---------- */

static int HAVE33_IP, HAVE33_IP6, HAVE33_NETDEV, HAVE33_BRIDGE, HAVE33_ARP;

static void f556_fams(void)
{
	struct { const char *n; uint8_t f; int *have; } fams[] = {
		{ "ip",     NFPROTO_IPV4,   &HAVE33_IP },
		{ "ip6",    NFPROTO_IPV6,   &HAVE33_IP6 },
		{ "netdev", NFPROTO_NETDEV, &HAVE33_NETDEV },
		{ "bridge", NFPROTO_BRIDGE, &HAVE33_BRIDGE },
		{ "arp",    NFPROTO_ARP,    &HAVE33_ARP },
	};
	char cmd[256];
	int i;

	sh("/nft flush ruleset");
	for (i = 0; i < (int)(sizeof(fams) / sizeof(fams[0])); i++) {
		int rc = add_table(fams[i].f, "p33probe");

		*fams[i].have = (rc == 0);
		printf("F556 FAM|%s|%d\n", fams[i].n, rc);
		if (rc == 0) {
			snprintf(cmd, sizeof(cmd), "/nft delete table %s p33probe",
				 fams[i].n);
			sh(cmd);
		}
	}
}

static int f556_env_setup(void)
{
	int rc = 0;

	if (link_add_veth("i0", "i1"))
		rc |= 1;
	if (link_add_veth("s0", "s1"))
		rc |= 2;
	if (link_add_veth("r0", "r1"))
		rc |= 4;
	set_up("i0"); set_up("i1");
	set_up("s0"); set_up("s1");
	set_up("r0"); set_up("r1");
	set_up("lo");
	if (f556_link_add_kind("br0", "bridge"))
		rc |= 8;
	set_up("br0");
	if (f556_link_enslave("s1", "br0") || f556_link_enslave("r1", "br0"))
		rc |= 16;
	printf("F556 SETUP|rc=%d|i1=%d|s1=%d|r1=%d|br0=%d\n", rc,
	       f555_ifindex("i1"), f555_ifindex("s1"), f555_ifindex("r1"),
	       f555_ifindex("br0"));
	return rc;
}

/* ---------- the nine envelopes ---------- */

static void f556_sec(const char *only)
{
	struct f556_env e;

	/* ---- 1. family ip, base nh: nft_nh_write_ok_ip4() ---- */
	if (!only || !strcmp(only, "ip4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "ip4"; e.fam = NFPROTO_IPV4; e.table = "p33f";
		e.chain = "pre"; e.hook = 0;	/* NF_INET_PRE_ROUTING */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 2. family ip6, base nh: nft_nh_write_ok_ip6() ---- */
	if (!only || !strcmp(only, "ip6")) {
		memset(&e, 0, sizeof(e));
		e.tag = "ip6"; e.fam = NFPROTO_IPV6; e.table = "p33g";
		e.chain = "pre"; e.hook = 0;
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0"; e.kind = FK33_IP6;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 3. family netdev, ingress: NFPROTO_NETDEV + ingress -> true ---- */
	if (!only || !strcmp(only, "nd")) {
		memset(&e, 0, sizeof(e));
		e.tag = "nd"; e.fam = NFPROTO_NETDEV; e.table = "p33n";
		e.chain = "ing"; e.hook = 0;	/* NF_NETDEV_INGRESS */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0";
		e.rule_dev = "i1"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 3b. family netdev, EGRESS: nft_nh_write_ok_netdev() ----
	 * F31 called this branch dead code because "netdev has only the
	 * ingress hook".  uapi/linux/netfilter.h has NF_NETDEV_INGRESS then
	 * NF_NETDEV_EGRESS, and nft_chain_filter_netdev's hook_mask has BOTH,
	 * so the branch is reachable -- and at egress the guard is the
	 * switch on skb->protocol, not the constant.  Two labels, two
	 * shapes, same chain. */
	if (!only || !strcmp(only, "eg4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "eg4"; e.fam = NFPROTO_NETDEV; e.table = "p33q";
		e.chain = "egr"; e.hook = 1;	/* NF_NETDEV_EGRESS */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0";
		e.rule_dev = "i0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	if (!only || !strcmp(only, "egA")) {
		memset(&e, 0, sizeof(e));
		e.tag = "egA"; e.fam = NFPROTO_NETDEV; e.table = "p33r";
		e.chain = "egr"; e.hook = 1;
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0";
		e.rule_dev = "i0"; e.kind = FK33_ARP;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 4. family bridge, ethertype 0x0800 ---- */
	if (!only || !strcmp(only, "br4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "br4"; e.fam = NFPROTO_BRIDGE; e.table = "p33b";
		e.chain = "pre"; e.hook = 0;	/* NF_BR_PRE_ROUTING */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "s0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 5. family bridge, ethertype 0x0806 ---- */
	if (!only || !strcmp(only, "brA")) {
		memset(&e, 0, sizeof(e));
		e.tag = "brA"; e.fam = NFPROTO_BRIDGE; e.table = "p33c";
		e.chain = "pre"; e.hook = 0;
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "s0"; e.kind = FK33_ARP;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 6. family arp, hook input: nft_nh_write_ok_arp() ---- */
	if (!only || !strcmp(only, "arp")) {
		memset(&e, 0, sizeof(e));
		e.tag = "arp"; e.fam = NFPROTO_ARP; e.table = "p33a";
		e.chain = "in"; e.hook = 0;	/* NF_ARP_IN */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0"; e.kind = FK33_ARP;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 7..9. base ll in three envelopes: nft_ll_write_ok() ---- */
	if (!only || !strcmp(only, "ll4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "ll4"; e.fam = NFPROTO_IPV4; e.table = "p33h";
		e.chain = "pre"; e.hook = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	if (!only || !strcmp(only, "llN")) {
		memset(&e, 0, sizeof(e));
		e.tag = "llN"; e.fam = NFPROTO_NETDEV; e.table = "p33i";
		e.chain = "ing"; e.hook = 0;	/* NF_NETDEV_INGRESS */
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.rule_dev = "i1";
		e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	if (!only || !strcmp(only, "llE")) {
		memset(&e, 0, sizeof(e));
		e.tag = "llE"; e.fam = NFPROTO_NETDEV; e.table = "p33s";
		e.chain = "egr"; e.hook = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.rule_dev = "i0";
		e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	if (!only || !strcmp(only, "llB")) {
		memset(&e, 0, sizeof(e));
		e.tag = "llB"; e.fam = NFPROTO_BRIDGE; e.table = "p33j";
		e.chain = "pre"; e.hook = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
}

/* ---------- E arms: does the branch read the PACKET, or the VALUE? ---------- */

static void f556_sec_e(void)
{
	struct f556_env e;
	unsigned char imm[16];

	/* ip4, offset 0, len 2: the guard compares the WRITTEN first byte with
	 * the one in the packet (nft_nh_write_ok_ip4 case 0, skb_copy_bits).
	 * Same rule, two valid datagrams: ihl 5 (0x45) and ihl 6 (0x46). */
	f556_imm(FK33_IP4, 0, 2, imm);
	imm[0] = 0x45;
	memset(&e, 0, sizeof(e));
	e.tag = "e4"; e.fam = NFPROTO_IPV4; e.table = "p33k";
	e.chain = "pre"; e.hook = 0; e.base = NFT_PAYLOAD_NETWORK_HEADER;
	e.dev = "i0"; e.kind = FK33_IP4;
	if (f556_chain(&e)) {
		printf("F556 E|SKIP=e4-chain\n");
		return;
	}
	f556_arm(&e, "ip4_0_2_ihl5", 0, 2, imm, 2, FK33_IP4);
	f556_arm(&e, "ip4_0_2_ihl6", 0, 2, imm, 2, FK33_IP4_IHL6);
	/* ip4, offset 8, len 2: the guard compares the written SECOND byte with
	 * the protocol byte of the packet.  imm[1] = 0x11, so a proto-17 frame
	 * passes and a proto-6 frame does not -- same rule, other frame. */
	f556_imm(FK33_IP4, 8, 2, imm);
	f556_arm(&e, "ip4_8_2_p17", 8, 2, imm, 2, FK33_IP4);
	f556_arm(&e, "ip4_8_2_p6", 8, 2, imm, 2, FK33_IP4_P6);
	sh("/nft flush ruleset");

	/* ip6, offset 0: nft_nh_write_ok_ip6 case 0 tests ih->version of the
	 * WRITTEN data, not of the packet.  So the VALUE must decide and the
	 * FRAME must not: 0x60 alive on both frames, 0x40 dead on both. */
	memset(&e, 0, sizeof(e));
	e.tag = "e6"; e.fam = NFPROTO_IPV6; e.table = "p33l";
	e.chain = "pre"; e.hook = 0; e.base = NFT_PAYLOAD_NETWORK_HEADER;
	e.dev = "i0"; e.kind = FK33_IP6;
	if (f556_chain(&e)) {
		printf("F556 E|SKIP=e6-chain\n");
		return;
	}
	memset(imm, 0, sizeof(imm));
	imm[0] = 0x60; imm[1] = 0x11; imm[2] = 0x22; imm[3] = 0x33;
	f556_arm(&e, "ip6_0_4_v6_a", 0, 4, imm, 4, FK33_IP6);
	f556_arm(&e, "ip6_0_4_v6_b", 0, 4, imm, 4, FK33_IP6_B);
	imm[0] = 0x40;
	f556_arm(&e, "ip6_0_4_v4_a", 0, 4, imm, 4, FK33_IP6);
	f556_arm(&e, "ip6_0_4_v4_b", 0, 4, imm, 4, FK33_IP6_B);
	sh("/nft flush ruleset");

	/* the envelope decides before the guard: an ARP-family chain never sees
	 * an IPv4 frame at all (arp_rcv is not on that path). */
	memset(&e, 0, sizeof(e));
	e.tag = "ea"; e.fam = NFPROTO_ARP; e.table = "p33m";
	e.chain = "in"; e.hook = 0; e.base = NFT_PAYLOAD_NETWORK_HEADER;
	e.dev = "i0"; e.kind = FK33_ARP;
	if (f556_chain(&e)) {
		printf("F556 E|SKIP=ea-chain\n");
		return;
	}
	f556_imm(FK33_ARP, 8, 2, imm);
	f556_arm(&e, "arp_fam_arpframe", 8, 2, imm, 2, FK33_ARP);
	f556_arm(&e, "arp_fam_ipv4frame", 8, 2, imm, 2, FK33_IP4);
	sh("/nft flush ruleset");

	/* the switch, measured by the same cell under two labels: (6,2) is in
	 * the ARP predicate and in none of the IPv4 case labels. */
	memset(&e, 0, sizeof(e));
	e.tag = "eb"; e.fam = NFPROTO_BRIDGE; e.table = "p33o";
	e.chain = "pre"; e.hook = 0; e.base = NFT_PAYLOAD_NETWORK_HEADER;
	e.dev = "s0"; e.kind = FK33_IP4;
	if (f556_chain(&e)) {
		printf("F556 E|SKIP=eb-chain\n");
		return;
	}
	f556_imm(FK33_IP4, 6, 2, imm);
	f556_arm(&e, "br_6_2_ip", 6, 2, imm, 2, FK33_IP4);
	f556_arm(&e, "br_6_2_arp", 6, 2, imm, 2, FK33_ARP);
	f556_arm(&e, "br_6_4_arp", 6, 4, imm, 4, FK33_ARP);
	sh("/nft flush ruleset");
}

/* ---------- diagnostic: why does the ingress chain not count ---------- */

static void f556_diag_nd(void)
{
	unsigned char fr[256];
	unsigned long long cnt;
	int flen, rc;

	flen = f556_frame(FK33_IP4, fr);
	sh("/nft flush ruleset");

	/* D1: ingress (NF_NETDEV_INGRESS = 0) on i1, frame sent from i0 */
	printf("F556 DN|table_i|%d\n", add_table(NFPROTO_NETDEV, "p33di"));
	rc = f556_add_chain(NFPROTO_NETDEV, "p33di", "ing", 0, 0, 1, "i1");
	printf("F556 DN|chain_ingress|%d\n", rc);
	nft("dn.list_ing", "/nft list chain netdev p33di ing");
	printf("F556 DN|ctl_ing|%d\n",
	       install_ctl(NFPROTO_NETDEV, "p33di", "ing", 5, "dn.ing"));
	nfl_drain(NFL33);
	usleep(20000);
	pkt_send_p("i0", fr, flen, 0x0800);
	cnt = f555_count(NFPROTO_NETDEV, "p33di", "ing");
	printf("F556 DN|ctl_ingress_cnt|%llu\n", cnt);

	/* D2: egress (NF_NETDEV_EGRESS = 1) on i0, frame sent from i0 */
	sh("/nft flush ruleset");
	printf("F556 DN|table_e|%d\n", add_table(NFPROTO_NETDEV, "p33de"));
	rc = f556_add_chain(NFPROTO_NETDEV, "p33de", "egr", 1, 0, 1, "i0");
	printf("F556 DN|chain_egress|%d\n", rc);
	nft("dn.list_egr", "/nft list chain netdev p33de egr");
	printf("F556 DN|ctl_egr|%d\n",
	       install_ctl(NFPROTO_NETDEV, "p33de", "egr", 5, "dn.egr"));
	nfl_drain(NFL33);
	usleep(20000);
	pkt_send_p("i0", fr, flen, 0x0800);
	cnt = f555_count(NFPROTO_NETDEV, "p33de", "egr");
	printf("F556 DN|ctl_egress_cnt|%llu\n", cnt);

	/* D3: the same egress chain written by nft itself, for comparison */
	sh("/nft flush ruleset");
	nft("dn.table_nft", "/nft add table netdev p33df");
	nft("dn.chain_nft", "/nft add chain netdev p33df egr '{ type filter hook egress device i0 priority 0; }'");
	nft("dn.rule_nft", "/nft add rule netdev p33df egr 'counter accept'");
	usleep(20000);
	pkt_send_p("i0", fr, flen, 0x0800);
	nft("dn.after_egr", "/nft list chain netdev p33df egr");

	/* D4: and the ingress chain written by nft, as F31 did */
	sh("/nft flush ruleset");
	nft("dn.table_nft2", "/nft add table netdev p33dg");
	nft("dn.chain_nft2", "/nft add chain netdev p33dg ing '{ type filter hook ingress device i1 priority 0; }'");
	nft("dn.rule_nft2", "/nft add rule netdev p33dg ing 'counter accept'");
	usleep(20000);
	pkt_send_p("i0", fr, flen, 0x0800);
	nft("dn.after_ing", "/nft list chain netdev p33dg ing");
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f556";
	const char *only = argc > 2 ? argv[2] : NULL;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F556 BEGIN|mode=%s|only=%s\n", mode, only ? only : "-");
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F556 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	if (!strcmp(mode, "f556bare")) {
		printf("F556 DONE\n");
		return 0;
	}
	if (!HAVE33_IP || !HAVE33_IP6 || !HAVE33_NETDEV || !HAVE33_BRIDGE ||
	    !HAVE33_ARP)
		printf("F556 WARN|missing_family|ip=%d|ip6=%d|nd=%d|br=%d|arp=%d\n",
		       HAVE33_IP, HAVE33_IP6, HAVE33_NETDEV, HAVE33_BRIDGE,
		       HAVE33_ARP);
	f556_env_setup();
	NFL33 = nfl_open(5);
	printf("F556 NFL|%d\n", NFL33);
	if (!strncmp(mode, "f556one:", 8)) {
		f556_sec(mode + 8);
		printf("F556 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f556nd")) {
		f556_diag_nd();
		printf("F556 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f556e")) {
		f556_sec("ip4");
		f556_sec_e();
		printf("F556 DONE\n");
		return 0;
	}
	f556_sec(only);
	if (!only)
		f556_sec_e();
	printf("F556 DONE\n");
	return 0;
}
