// SPDX-License-Identifier: GPL-2.0
/*
 * differ555.c -- turn 555 / F32: the native `arp` envelope.
 *
 * F30 measured the IPv4/IPv6 branches of nft_nh_write_ok(); F31 measured the
 * netdev and bridge branches and, inside the bridge, the ARP branch
 *     static bool nft_nh_write_ok_arp(const struct nft_payload_set *priv)
 *     {
 *             const unsigned int eth_ip = 2 * (ETH_ALEN + 4);
 *             switch (priv->offset) {
 *             case offsetof(struct arphdr, ar_op):  return priv->len == 2;
 *             }
 *             return priv->offset >= sizeof(struct arphdr) && priv->len <= eth_ip;
 *     }
 * -- reached from a frame whose ETHERNET LABEL said 0x0806.
 *
 * The native envelope is `case NFPROTO_ARP: return nft_nh_write_ok_arp(priv)`
 * in nft_nh_write_ok(), i.e. the nft family `arp`, and that family has never
 * been reachable in this project: CONFIG_NF_TABLES_ARP is "not set" in every
 * config we have booted.  Two kernels are built for this turn with that one
 * symbol on (A553 = 7.3.4, AM553 = 7.2.15) and nothing else changed.
 *
 * Questions, each answered by a counter, a byte or a socket -- never by reading
 * the source:
 *
 *   A  does the family exist?  (`nft add table arp`)
 *   B  which hooks does its filter chain type accept?
 *   C  which of the nine fields nft itself can name are alive, which are dead?
 *   D  what is the guard's predicate at the INPUT hook, as a function of
 *      (offset,len) -- measured over a grid, not read off the switch
 *   E  the same grid at the OUTPUT hook, where the kernel's own ARP skb is
 *      exactly 28 bytes long
 *   F  what a rule in this family does to the host: neighbour table, replies
 *   G  does anything here read hlen/plen out of the message?
 *
 * output
 *   F555 A|<tag>|hook=..|src=..|g=off,len|rule=..|rc=..|cnt=..|nfl=..|chg=..|
 *          nhex=..|ci1=..|ihex=..|co1=..|ohex=..
 *   F555 ARP|<tag>|<ip>|flags=..|mac=..
 *   F555 FAM|<family>|<rc>
 *   F555 HOOK|<hook>|<rc>
 *   F555RC <tag>|<rc>          (nft exit code)
 *   F555X  <tag>|<nft's own words>
 *   F555 SETUP|...
 *
 * Byte evidence at INPUT can only come from NFLOG: an AF_PACKET tap sees the
 * frame on receive before arp_rcv() is called, and arp_rcv() is where the
 * netfilter ARP hook lives.  So every rule logs the packet after the store
 * (`log group 5 prefix "f555.<tag>"`), and the payload is matched back by
 * prefix -- a per-arm string, so no arm can consume another arm's message.
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sched.h>
#include <stdint.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <linux/if_link.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <linux/if_arp.h>
#include <linux/netfilter.h>
#include <linux/netfilter/nfnetlink.h>
#include <linux/netfilter/nf_tables.h>

#define NLA_ALIGN_(len) (((len) + 3) & ~3)
#ifndef VETH_INFO_PEER
#define VETH_INFO_PEER 1
#endif
#define NFNL_SUBSYS_ULOG_	4
#define NFULNL_MSG_PACKET_	0
#define NFULNL_MSG_CONFIG_	1
#define NFULA_PACKET_HDR_	1
#define NFULA_PAYLOAD_		9
#define NFULA_PREFIX_		10
#define NFULA_CFG_CMD_		1
#define NFULA_CFG_MODE_		2
#define NFULA_CFG_TIMEOUT_	4
#define NFULA_CFG_QTHRESH_	5
#define NFULNL_CFG_CMD_BIND_	1
#define NFULNL_COPY_PACKET_	0x02

/* NFTA_LOG_GROUP / _PREFIX / _QTHRESHOLD come from <linux/netfilter/nf_tables.h>
 * as ENUM constants -- and #ifndef does not protect an enum constant, which is
 * how this file carried `#define NFTA_LOG_PREFIX 3` for one smoke run and sent
 * every prefix as NFTA_LOG_SNAPLEN.  Rules installed fine, counters counted, and
 * the NFLOG messages arrived with an empty prefix.  These two assertions make
 * that failure a compile error instead of a silent one. */
_Static_assert(NFTA_LOG_GROUP == 1, "NFTA_LOG_GROUP moved");
_Static_assert(NFTA_LOG_PREFIX == 2, "NFTA_LOG_PREFIX moved");
_Static_assert(NFTA_LOG_QTHRESHOLD == 4, "NFTA_LOG_QTHRESHOLD moved");

/* ---------- netlink toolkit ---------- */

static char opbuf[4096];

static struct nlmsghdr *msg_start(char *buf, int bufsz, uint16_t type,
				  uint16_t flags, uint8_t family)
{
	struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
	struct nfgenmsg *nfg;

	memset(buf, 0, (size_t)bufsz);
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = type;
	nlh->nlmsg_flags = flags;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	return nlh;
}

static struct nlattr *attr_put(struct nlmsghdr *nlh, uint16_t type,
			       const void *payload, int len)
{
	struct nlattr *a = (struct nlattr *)((char *)nlh +
					     NLMSG_ALIGN(nlh->nlmsg_len));

	a->nla_type = type;
	a->nla_len = (uint16_t)(NLA_HDRLEN + len);
	if (len && payload)
		memcpy((char *)a + NLA_HDRLEN, payload, (size_t)len);
	nlh->nlmsg_len = NLMSG_ALIGN(nlh->nlmsg_len) + (uint32_t)NLA_ALIGN_(a->nla_len);
	return a;
}

static struct nlattr *nest_start(struct nlmsghdr *nlh, uint16_t type)
{
	return attr_put(nlh, (uint16_t)(type | NLA_F_NESTED), NULL, 0);
}

static void nest_end(struct nlmsghdr *nlh, struct nlattr *a)
{
	a->nla_len = (uint16_t)((char *)nlh + nlh->nlmsg_len - (char *)a);
}

static void put_str(struct nlmsghdr *nlh, uint16_t t, const char *s)
{
	attr_put(nlh, t, s, (int)strlen(s) + 1);
}

static void put_be32(struct nlmsghdr *nlh, uint16_t t, uint32_t v)
{
	uint32_t be = htonl(v);

	attr_put(nlh, t, &be, (int)sizeof(be));
}

static int nl_open(void)
{
	struct sockaddr_nl sa;
	struct timeval tv = { .tv_sec = 2, .tv_usec = 0 };
	int fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_NETFILTER);

	if (fd < 0)
		return -1;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -1;
	}
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return fd;
}

static int batch_send(int fd, char *buf, int len)
{
	char rbuf[8192];
	int err = 0;

	if (send(fd, buf, (size_t)len, 0) != len)
		return -1000 - errno;
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			if (h->nlmsg_type != NLMSG_ERROR)
				continue;
			{
				struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(h);

				if (e->error && !err)
					err = e->error;
			}
		}
	}
	return err;
}

/* one nfnetlink message, wrapped in BEGIN/END, sent as a batch */
static int nft_one(char *msgbuf, int msglen)
{
	char batch[8192];
	struct nlmsghdr *bn, *en;
	int off, fd, rc;

	bn = msg_start(batch, (int)sizeof(batch), NFNL_MSG_BATCH_BEGIN,
		       NLM_F_REQUEST, 0);
	((struct nfgenmsg *)NLMSG_DATA(bn))->res_id = htons(NFNL_SUBSYS_NFTABLES);
	off = (int)NLMSG_ALIGN(bn->nlmsg_len);
	memcpy(batch + off, msgbuf, (size_t)NLMSG_ALIGN(msglen));
	off += (int)NLMSG_ALIGN(msglen);
	en = msg_start(batch + off, (int)(sizeof(batch) - off), NFNL_MSG_BATCH_END,
		       NLM_F_REQUEST, 0);
	((struct nfgenmsg *)NLMSG_DATA(en))->res_id = htons(NFNL_SUBSYS_NFTABLES);
	off += (int)NLMSG_ALIGN(en->nlmsg_len);
	fd = nl_open();
	if (fd < 0)
		return -1;
	rc = batch_send(fd, batch, off);
	close(fd);
	return rc;
}

/* ---------- rtnetlink ---------- */

static int rtnl_open(void)
{
	struct sockaddr_nl sa;
	struct timeval tv = { .tv_sec = 2, .tv_usec = 0 };
	int fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);

	if (fd < 0)
		return -1;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -2;
	}
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return fd;
}

static int rtnl_talk(int fd, struct nlmsghdr *nlh)
{
	struct sockaddr_nl sa;
	char rbuf[4096];
	struct nlmsghdr *rh;
	int r;

	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	nlh->nlmsg_flags |= NLM_F_REQUEST | NLM_F_ACK;
	nlh->nlmsg_seq = 1;
	nlh->nlmsg_pid = 0;
	if (sendto(fd, nlh, nlh->nlmsg_len, 0, (struct sockaddr *)&sa,
		   sizeof(sa)) < 0)
		return -errno;
	r = (int)recv(fd, rbuf, sizeof(rbuf), 0);
	if (r < (int)(NLMSG_HDRLEN + sizeof(struct nlmsgerr)))
		return -1000;
	rh = (struct nlmsghdr *)rbuf;
	if (rh->nlmsg_type == NLMSG_ERROR) {
		struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(rh);

		return e->error;
	}
	return -1001;
}

static int f555_ifindex(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int idx = -1;

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFINDEX, &ifr) == 0)
		idx = ifr.ifr_ifindex;
	close(s);
	return idx;
}

static int mac_get(const char *dev, unsigned char *out)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFHWADDR, &ifr) < 0) {
		close(s);
		return -1;
	}
	memcpy(out, ifr.ifr_hwaddr.sa_data, 6);
	close(s);
	return 0;
}

static int set_up(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	if (s < 0)
		return -1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", dev);
	if (ioctl(s, SIOCGIFFLAGS, &ifr) < 0) {
		close(s);
		return -1;
	}
	ifr.ifr_flags |= IFF_UP | IFF_RUNNING;
	if (ioctl(s, SIOCSIFFLAGS, &ifr) < 0) {
		close(s);
		return -1;
	}
	close(s);
	return 0;
}

static int link_add_veth(const char *a, const char *b)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[512];
	} req;
	struct ifinfomsg zifi;
	struct nlattr *li, *data, *peer;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, a, (int)strlen(a) + 1);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, "veth", 5);
	data = nest_start(&req.nlh, IFLA_INFO_DATA);
	memset(&zifi, 0, sizeof(zifi));
	zifi.ifi_family = AF_UNSPEC;
	peer = attr_put(&req.nlh, (uint16_t)(VETH_INFO_PEER | NLA_F_NESTED), &zifi,
			(int)sizeof(zifi));
	attr_put(&req.nlh, IFLA_IFNAME, b, (int)strlen(b) + 1);
	nest_end(&req.nlh, peer);
	nest_end(&req.nlh, data);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f555_addr_add(const char *dev, uint32_t addr_be, int plen)
{
	struct {
		struct nlmsghdr nlh;
		struct ifaddrmsg ifa;
		char attrs[128];
	} req;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifaddrmsg));
	req.nlh.nlmsg_type = RTM_NEWADDR;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_REPLACE;
	req.nlh.nlmsg_seq = 1;
	req.ifa.ifa_family = AF_INET;
	req.ifa.ifa_prefixlen = (uint8_t)plen;
	req.ifa.ifa_scope = 0;
	req.ifa.ifa_index = (uint32_t)f555_ifindex(dev);
	attr_put(&req.nlh, IFA_LOCAL, &addr_be, 4);
	attr_put(&req.nlh, IFA_ADDRESS, &addr_be, 4);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f555_neigh_del(const char *dev, uint32_t dst_be)
{
	struct {
		struct nlmsghdr nlh;
		struct ndmsg ndm;
		char attrs[64];
	} req;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ndmsg));
	req.nlh.nlmsg_type = RTM_DELNEIGH;
	req.nlh.nlmsg_flags = NLM_F_REQUEST;
	req.nlh.nlmsg_seq = 1;
	req.ndm.ndm_family = AF_INET;
	req.ndm.ndm_ifindex = f555_ifindex(dev);
	attr_put(&req.nlh, NDA_DST, &dst_be, 4);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f555_sysctl(const char *path, const char *val)
{
	int fd = open(path, O_WRONLY);
	int rc;

	if (fd < 0)
		return -1;
	rc = (int)write(fd, val, strlen(val));
	close(fd);
	return rc < 0 ? -1 : 0;
}

/* ---------- /proc/net/arp: the host's own view of what it learned ---------- */

static int arp_flags(const char *ip, char *mac, int macsz)
{
	FILE *f = fopen("/proc/net/arp", "r");
	char line[256];

	if (!f)
		return -1;
	if (!fgets(line, sizeof(line), f)) {
		fclose(f);
		return -1;
	}
	while (fgets(line, sizeof(line), f)) {
		char a[64] = "", hw[32] = "", fl[32] = "", m[64] = "";
		char msk[32] = "", dev[32] = "";

		if (sscanf(line, "%63s %31s %31s %63s %31s %31s", a, hw, fl, m, msk, dev) != 6)
			continue;
		if (strcmp(a, ip))
			continue;
		if (mac && macsz > 0)
			snprintf(mac, (size_t)macsz, "%s", m);
		fclose(f);
		return (int)strtol(fl, NULL, 16);
	}
	fclose(f);
	return -1;		/* no entry at all */
}

static void arp_row(const char *tag, const char *ip)
{
	char mac[64] = "-";
	int fl = arp_flags(ip, mac, (int)sizeof(mac));

	if (fl < 0)
		printf("F555 ARP|%s|%s|flags=none|mac=-\n", tag, ip);
	else
		printf("F555 ARP|%s|%s|flags=0x%x|mac=%s\n", tag, ip, fl, mac);
}

/* ---------- nft through the shell ---------- */

static int sh(const char *cmd)
{
	char full[2048];
	int rc;

	snprintf(full, sizeof(full), "%s >/tmp/f555o 2>&1", cmd);
	rc = system(full);
	return WIFEXITED(rc) ? WEXITSTATUS(rc) : 1000 + rc;
}

static void sh_out(const char *tag)
{
	FILE *f = fopen("/tmp/f555o", "r");
	char line[1024];

	if (!f)
		return;
	while (fgets(line, sizeof(line), f)) {
		char *nl = strchr(line, '\n');

		if (nl)
			*nl = 0;
		if (*line)
			printf("F555X %s|%s\n", tag, line);
	}
	fclose(f);
}

static int nft(const char *tag, const char *cmd)
{
	int rc = sh(cmd);

	printf("F555RC %s|%d\n", tag, rc);
	sh_out(tag);
	return rc;
}

/* ---------- NFLOG: the only way to see the packet AFTER the hook ---------- */

static int nfl_open(int group)
{
	char msg[512], rbuf[2048];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	struct sockaddr_nl sa;
	int fd, rcv = 1 << 21;

	fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_NETFILTER);
	if (fd < 0)
		return -1;
	setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcv, sizeof(rcv));
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -2;
	}
	memset(msg, 0, sizeof(msg));
	nlh = (struct nlmsghdr *)msg;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (uint16_t)((NFNL_SUBSYS_ULOG_ << 8) | NFULNL_MSG_CONFIG_);
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = 0;
	nfg->version = 0;
	nfg->res_id = htons((uint16_t)group);
	{
		uint8_t cmd = NFULNL_CFG_CMD_BIND_;

		attr_put(nlh, NFULA_CFG_CMD_, &cmd, 1);
	}
	{
		struct {
			uint32_t range;
			uint8_t mode;
			uint8_t pad;
		} __attribute__((packed)) cm;

		cm.range = htonl(0);
		cm.mode = NFULNL_COPY_PACKET_;
		cm.pad = 0;
		attr_put(nlh, NFULA_CFG_MODE_, &cm, (int)sizeof(cm));
	}
	{
		uint32_t q = htonl(1);
		uint32_t t = htonl(2);

		attr_put(nlh, NFULA_CFG_QTHRESH_, &q, 4);
		attr_put(nlh, NFULA_CFG_TIMEOUT_, &t, 4);
	}
	if (send(fd, msg, nlh->nlmsg_len, 0) != (ssize_t)nlh->nlmsg_len) {
		close(fd);
		return -3;
	}
	if (recv(fd, rbuf, sizeof(rbuf), 0) > 0) {
		struct nlmsghdr *rh = (struct nlmsghdr *)rbuf;

		if (rh->nlmsg_type == NLMSG_ERROR) {
			struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(rh);

			if (e->error) {
				printf("F555 SETUP|nflog_bind|%d\n", e->error);
				close(fd);
				return -5;
			}
		}
	}
	fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
	return fd;
}

/* one packet message -> prefix + payload.  Returns 1 if a message was parsed. */
static int nfl_one(const unsigned char *buf, int len, char *prefix, int psz,
		   unsigned char *pay, int *paylen)
{
	const struct nlmsghdr *nlh = (const struct nlmsghdr *)buf;
	int rem = len;

	prefix[0] = 0;
	*paylen = 0;
	while (NLMSG_OK(nlh, rem)) {
		if (nlh->nlmsg_type == (uint16_t)((NFNL_SUBSYS_ULOG_ << 8) |
						  NFULNL_MSG_PACKET_)) {
			const unsigned char *p = (const unsigned char *)NLMSG_DATA(nlh);
			int plen = (int)nlh->nlmsg_len - NLMSG_HDRLEN;
			int off = 4;	/* nfgenmsg */

			while (off + (int)sizeof(struct nlattr) <= plen) {
				const struct nlattr *a = (const struct nlattr *)(p + off);
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || off + alen > plen)
					break;
				if ((a->nla_type & 0x3fff) == NFULA_PREFIX_)
					snprintf(prefix, (size_t)psz, "%s",
						 (const char *)a + NLA_HDRLEN);
				else if ((a->nla_type & 0x3fff) == NFULA_PAYLOAD_) {
					int n = alen - NLA_HDRLEN;

					if (n > 128)
						n = 128;
					memcpy(pay, (const char *)a + NLA_HDRLEN, (size_t)n);
					*paylen = n;
				}
				off += (int)NLA_ALIGN_(alen);
			}
			return 1;
		}
		nlh = NLMSG_NEXT(nlh, rem);
	}
	return 0;
}

/* read until a message with exactly this prefix arrives (or the deadline) */
static int nfl_wait(int fd, const char *want, unsigned char *pay, int max,
		    int ms)
{
	struct timeval tv = { .tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000 };
	struct timeval now0, now1;
	fd_set rfds;
	int got = 0, seen = 0;
	char seenpre[2][64] = { "-", "-" };
	int seenlen[2] = { 0, 0 };

	gettimeofday(&now0, NULL);
	for (;;) {
		unsigned char b[4096];
		int r;

		FD_ZERO(&rfds);
		FD_SET(fd, &rfds);
		if (select(fd + 1, &rfds, NULL, NULL, &tv) <= 0)
			break;
		r = (int)recv(fd, b, sizeof(b), 0);
		if (r <= 0)
			break;
		{
			char pre[64];
			unsigned char p[128];
			int pl = 0;

			if (nfl_one(b, r, pre, (int)sizeof(pre), p, &pl)) {
				seen++;
				if (seen <= 2) {
					snprintf(seenpre[seen - 1], sizeof(seenpre[0]),
						 "%s", pre);
					seenlen[seen - 1] = pl;
				}
				if (pl > 0 && (!want || !strcmp(pre, want))) {
					if (pl > max)
						pl = max;
					memcpy(pay, p, (size_t)pl);
					got = pl;
					break;
				}
			}
		}
		gettimeofday(&now1, NULL);
		{
			long used = (now1.tv_sec - now0.tv_sec) * 1000 +
				    (now1.tv_usec - now0.tv_usec) / 1000;

			if (used >= ms)
				break;
			tv.tv_sec = 0;
			tv.tv_usec = (ms - used) * 1000;
		}
	}
	if (!got)
		printf("F555X nfl|want=%s|seen=%d|p1=%s,%d|p2=%s,%d\n",
		       want ? want : "-", seen, seenpre[0], seenlen[0],
		       seenpre[1], seenlen[1]);
	return got;
}

static void nfl_drain(int fd)
{
	unsigned char b[4096];

	while (recv(fd, b, sizeof(b), 0) > 0)
		;
}

/* ---------- frames ---------- */

static const unsigned char MAC_SRC[6] = { 0xaa, 0xbb, 0xcc, 0x00, 0x00, 0x66 };
static const unsigned char MAC_DST[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
static const unsigned char MAC_THA[6] = { 0x22, 0x22, 0x22, 0x22, 0x22, 0x22 };

static void be32_out(unsigned char *p, uint32_t v)
{
	p[0] = (unsigned char)(v >> 24);
	p[1] = (unsigned char)(v >> 16);
	p[2] = (unsigned char)(v >> 8);
	p[3] = (unsigned char)v;
}

/* ethernet + ARP.  hlen/plen are the message's OWN address sizes; the standard
 * ethernet/IPv4 message is hlen=6 plen=4 and is 28 bytes long.  `pad` pads the
 * frame to the 60-byte ethernet minimum, the way a real sender does. */
static int build_arp(unsigned char *out, int op, uint32_t spa, uint32_t tpa,
		     const unsigned char *sha, int hlen, int plen, int pad)
{
	int hl = 14, mlen = 8 + 2 * hlen + 2 * plen;

	memset(out, 0, 160);
	memcpy(out, MAC_DST, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x08;
	out[13] = 0x06;
	out[hl + 0] = 0x00; out[hl + 1] = 0x01;	/* htype: ethernet */
	out[hl + 2] = 0x08; out[hl + 3] = 0x00;	/* ptype: IPv4 */
	out[hl + 4] = (unsigned char)hlen;
	out[hl + 5] = (unsigned char)plen;
	out[hl + 6] = (unsigned char)(op >> 8);
	out[hl + 7] = (unsigned char)op;
	memcpy(out + hl + 8, sha, (size_t)(hlen < 6 ? hlen : 6));
	be32_out(out + hl + 8 + hlen, spa);
	memcpy(out + hl + 8 + hlen + plen, MAC_THA, (size_t)(hlen < 6 ? hlen : 6));
	be32_out(out + hl + 8 + 2 * hlen + plen, tpa);
	if (pad && hl + mlen < 60)
		return 60;		/* memset already zeroed the padding */
	return hl + mlen;
}

static int pkt_send(const char *dev, const unsigned char *fr, int len)
{
	struct sockaddr_ll sll;
	int s, rc, idx = f555_ifindex(dev);

	if (idx < 0)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_ALL);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, fr, 6);
	rc = (int)sendto(s, fr, (size_t)len, 0, (struct sockaddr *)&sll, sizeof(sll));
	close(s);
	return rc < 0 ? -errno : 0;
}

static int cap_open(const char *dev)
{
	struct sockaddr_ll sll;
	int s, idx = f555_ifindex(dev);

	if (idx < 0)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_ALL);
	sll.sll_ifindex = idx;
	if (bind(s, (struct sockaddr *)&sll, sizeof(sll)) < 0) {
		close(s);
		return -3;
	}
	fcntl(s, F_SETFL, fcntl(s, F_GETFL, 0) | O_NONBLOCK);
	return s;
}

static void cap_drain(int s)
{
	unsigned char b[2048];

	while (recv(s, b, sizeof(b), 0) > 0)
		;
}

/* first ARP frame from `mac` on this socket within ms.  ARP only: the arms also
 * push UDP datagrams out of the same device (the poke that triggers the kernel's
 * own ARP request), and the first frame was twice the wrong one in the smoke run
 * of F31 -- once an ICMPv6 solicitation from the bridge, once our own datagram. */
static int cap_arp_t(int s, unsigned char *buf, int max, int ms,
		     const unsigned char *mac, int on_src, uint32_t tpa_be)
{
	struct timeval tv = { .tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000 };
	struct timeval now0, now1;
	fd_set rfds;

	gettimeofday(&now0, NULL);
	for (;;) {
		int r;

		FD_ZERO(&rfds);
		FD_SET(s, &rfds);
		if (select(s + 1, &rfds, NULL, NULL, &tv) <= 0)
			return 0;
		r = (int)recv(s, buf, (size_t)max, 0);
		if (r <= 0)
			return 0;
		if (r >= 42 && buf[12] == 0x08 && buf[13] == 0x06 &&
		    (tpa_be == 0 ||
		     (buf[38] == (unsigned char)(tpa_be >> 24) &&
		      buf[39] == (unsigned char)(tpa_be >> 16) &&
		      buf[40] == (unsigned char)(tpa_be >> 8) &&
		      buf[41] == (unsigned char)tpa_be)) &&
		    ((on_src && !memcmp(buf + 6, mac, 6)) ||
		     (!on_src && !memcmp(buf, mac, 6))))
			return r;
		gettimeofday(&now1, NULL);
		{
			long used = (now1.tv_sec - now0.tv_sec) * 1000 +
				    (now1.tv_usec - now0.tv_usec) / 1000;

			if (used >= ms)
				return 0;
			tv.tv_sec = 0;
			tv.tv_usec = (ms - used) * 1000;
		}
	}
}

static int cap_arp(int s, unsigned char *buf, int max, int ms,
		   const unsigned char *mac, int on_src)
{
	return cap_arp_t(s, buf, max, ms, mac, on_src, 0);
}

static int udp_poke(uint32_t dst_be)
{
	struct sockaddr_in sin;
	char b = 'x';
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	int rc;

	if (s < 0)
		return -1;
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = dst_be;
	sin.sin_port = htons(9999);
	rc = (int)sendto(s, &b, 1, 0, (struct sockaddr *)&sin, sizeof(sin));
	close(s);
	return rc < 0 ? -errno : 0;
}

/* ---------- rules over raw netlink ---------- */

static void imm_value(struct nlmsghdr *nlh, uint32_t dreg, const void *val, int len)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "immediate");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_IMMEDIATE_DREG, dreg);
	{
		struct nlattr *v = nest_start(nlh, NFTA_IMMEDIATE_DATA);

		attr_put(nlh, NFTA_DATA_VALUE, val, len);
		nest_end(nlh, v);
	}
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void counter_expr(struct nlmsghdr *nlh)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "counter");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void log_expr(struct nlmsghdr *nlh, int group, const char *prefix)
{
	struct nlattr *e, *d;
	uint16_t g = htons((uint16_t)group);

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "log");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	attr_put(nlh, NFTA_LOG_GROUP, &g, 2);
	put_str(nlh, NFTA_LOG_PREFIX, prefix);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void accept_expr(struct nlmsghdr *nlh)
{
	struct nlattr *e, *d;
	uint32_t code = htonl(NF_ACCEPT);

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "immediate");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_IMMEDIATE_DREG, NFT_REG_VERDICT);
	{
		struct nlattr *v = nest_start(nlh, NFTA_IMMEDIATE_DATA);
		struct nlattr *vd = nest_start(nlh, NFTA_DATA_VERDICT);

		attr_put(nlh, NFTA_VERDICT_CODE, &code, 4);
		nest_end(nlh, vd);
		nest_end(nlh, v);
	}
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* one rule: [store @network+off = imm][log][counter][accept?] */
static int install_store(int family, const char *table, const char *chain,
			 uint32_t off, uint32_t len, const unsigned char *imm,
			 int immlen, int verdict, int loggroup, const char *prefix)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *e, *d;
	int rc;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			(uint8_t)family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	imm_value(nlh, NFT_REG32_00, imm, immlen);
	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "payload");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00);
	put_be32(nlh, NFTA_PAYLOAD_BASE, NFT_PAYLOAD_NETWORK_HEADER);
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
	put_be32(nlh, NFTA_PAYLOAD_LEN, len);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
	nest_end(nlh, d);
	nest_end(nlh, e);
	if (loggroup)
		log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	if (verdict)
		accept_expr(nlh);
	nest_end(nlh, exprs);
	rc = nft_one(opbuf, (int)nlh->nlmsg_len);
	return rc;
}

/* a rule that only logs and counts: the control for byte-level diffing */
static int install_ctl(int family, const char *table, const char *chain,
		       int loggroup, const char *prefix)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			(uint8_t)family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

/* NFT_MSG_DELRULE with table+chain and no handle flushes the chain.  Cheaper
 * than forking nft 130 times, and it cannot fail on a chain that is empty. */
static int flush_chain(int family, const char *table, const char *chain)
{
	struct nlmsghdr *nlh;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_DELRULE,
			NLM_F_REQUEST | NLM_F_ACK, (uint8_t)family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

static int add_table(int family, const char *table)
{
	struct nlmsghdr *nlh;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWTABLE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE, (uint8_t)family);
	put_str(nlh, NFTA_TABLE_NAME, table);
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

/* base chain: hook 0=input 2=output (NF_ARP_*), policy 1=accept 0=drop */
static int add_chain(int family, const char *table, const char *chain,
		     uint32_t hook, uint32_t prio, uint32_t policy)
{
	struct nlmsghdr *nlh;
	struct nlattr *h, *d;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWCHAIN,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE, (uint8_t)family);
	put_str(nlh, NFTA_CHAIN_TABLE, table);
	put_str(nlh, NFTA_CHAIN_NAME, chain);
	h = nest_start(nlh, NFTA_CHAIN_HOOK);
	put_be32(nlh, NFTA_HOOK_HOOKNUM, hook);
	put_be32(nlh, NFTA_HOOK_PRIORITY, prio);
	nest_end(nlh, h);
	put_be32(nlh, NFTA_CHAIN_POLICY, policy);
	put_str(nlh, NFTA_CHAIN_TYPE, "filter");
	(void)d;
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

/* counter read-back without nft's printer */
static unsigned long long f555_count(uint8_t family, const char *table,
				     const char *chain)
{
	char buf[1024], rbuf[16384];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	unsigned long long pkts = 0;
	int fd, sent;

	fd = nl_open();
	if (fd < 0)
		return 0;
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1);
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1);
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return 0;
	}
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			const char *p, *end;

			if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
				goto out;
			if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				continue;
			p = (const char *)h + NLMSG_HDRLEN + sizeof(*nfg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || p + alen > end)
					break;
				if ((a->nla_type & 0x3fff) == NFTA_RULE_EXPRESSIONS) {
					const char *q = (const char *)a + NLA_HDRLEN;
					const char *qe = (const char *)a + alen;

					for (; q + (int)sizeof(struct nlattr) <= qe; ) {
						const struct nlattr *el = (const struct nlattr *)q;
						int ell = (int)el->nla_len;
						const char *r, *re;
						int is_cnt = 0;

						if (ell < (int)sizeof(*el) || q + ell > qe)
							break;
						r = (const char *)el + NLA_HDRLEN;
						re = (const char *)el + ell;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int eal = (int)ea->nla_len;

							if (eal < (int)sizeof(*ea) || r + eal > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_NAME &&
							    !strcmp((const char *)ea + NLA_HDRLEN, "counter"))
								is_cnt = 1;
							r += NLA_ALIGN_(eal);
						}
						if (is_cnt) {
							r = (const char *)el + NLA_HDRLEN;
							for (; r + (int)sizeof(struct nlattr) <= re; ) {
								const struct nlattr *ea = (const struct nlattr *)r;
								int eal = (int)ea->nla_len;

								if (eal < (int)sizeof(*ea) || r + eal > re)
									break;
								if ((ea->nla_type & 0x3fff) == NFTA_EXPR_DATA) {
									const char *d = (const char *)ea + NLA_HDRLEN;
									const char *de = (const char *)ea + eal;

									for (; d + (int)sizeof(struct nlattr) <= de; ) {
										const struct nlattr *da = (const struct nlattr *)d;
										int dal = (int)da->nla_len;

										if (dal < (int)sizeof(*da) || d + dal > de)
											break;
										if ((da->nla_type & 0x3fff) == NFTA_COUNTER_PACKETS) {
											int k, bl = dal - NLA_HDRLEN;
											unsigned long long v = 0;
											const unsigned char *b =
												(const unsigned char *)da + NLA_HDRLEN;

											for (k = 0; k < bl && k < 8; k++)
												v = (v << 8) | b[k];
											pkts += v;
										}
										d += NLA_ALIGN_(dal);
									}
								}
								r += NLA_ALIGN_(eal);
							}
						}
						q += NLA_ALIGN_(ell);
					}
				}
				p += NLA_ALIGN_(alen);
			}
		}
	}
out:
	close(fd);
	return pkts;
}

/* ---------- the row ---------- */

static int hexcopy(char *dst, int dstsz, const unsigned char *src, int len)
{
	int i, at = 0;

	if (len <= 0 || !src) {
		snprintf(dst, (size_t)dstsz, "-");
		return 0;
	}
	for (i = 0; i < len && i < 64; i++)
		at += snprintf(dst + at, (size_t)(dstsz - at), "%02x", src[i]);
	return len;
}

static void chglist(char *dst, int dstsz,
		    const unsigned char *cap, int clen,
		    const unsigned char *ctl, int ctl_len)
{
	int i, n = 0;
	size_t at = 0;

	dst[0] = 0;
	if (!cap || !ctl || clen <= 0 || ctl_len <= 0) {
		snprintf(dst, (size_t)dstsz, "-");
		return;
	}
	for (i = 0; i < clen && i < ctl_len; i++) {
		if (cap[i] == ctl[i])
			continue;
		n++;
		if (at < (size_t)dstsz - 24)
			at += (size_t)snprintf(dst + at, (size_t)(dstsz - (int)at),
					       "%s%d:%02x>%02x", n > 1 ? "," : "",
					       i, ctl[i], cap[i]);
	}
	if (!n)
		snprintf(dst, (size_t)dstsz, "-");
}

/* ---------- environment ---------- */

static unsigned char MAC_I0[6];
static int CAP_I1 = -1, CAP_O1 = -1, CAP_I0 = -1, NFL = -1;

static int env_setup(void)
{
	int rc = 0;

	if (link_add_veth("i0", "i1"))
		rc |= 1;
	if (link_add_veth("o0", "o1"))
		rc |= 2;
	set_up("i0");
	set_up("i1");
	set_up("o0");
	set_up("o1");
	set_up("lo");
	f555_addr_add("i0", htonl(0x0a010001), 24);	/* 10.1.0.1 */
	f555_addr_add("o0", htonl(0x0a090001), 24);	/* 10.9.0.1 */
	f555_sysctl("/proc/sys/net/ipv4/ip_forward", "0");
	mac_get("i0", MAC_I0);
	CAP_I1 = cap_open("i1");
	CAP_I0 = cap_open("i0");
	CAP_O1 = cap_open("o1");
	NFL = nfl_open(5);
	printf("F555 SETUP|rc=%d|mac_i0=%02x:%02x:%02x:%02x:%02x:%02x|cap_i1=%d|"
	       "cap_o1=%d|cap_i0=%d|nflog=%d\n", rc, MAC_I0[0], MAC_I0[1],
	       MAC_I0[2], MAC_I0[3], MAC_I0[4], MAC_I0[5], CAP_I1, CAP_O1,
	       CAP_I0, NFL);
	return rc;
}

/* ---------- A: does the family exist ---------- */

static int HAVE_ARP;

static void sec_a(void)
{
	struct { const char *n; uint8_t f; } fams[] = {
		{ "ip", NFPROTO_IPV4 },
		{ "arp", NFPROTO_ARP },
		{ "bridge", NFPROTO_BRIDGE },
		{ "netdev", NFPROTO_NETDEV },
	};
	char cmd[256], tag[64];
	int i;

	sh("/nft flush ruleset");
	for (i = 0; i < (int)(sizeof(fams) / sizeof(fams[0])); i++) {
		int rc;

		snprintf(tag, sizeof(tag), "a.%s", fams[i].n);
		snprintf(cmd, sizeof(cmd), "/nft add table %s p555f", fams[i].n);
		rc = nft(tag, cmd);
		printf("F555 FAM|%s|%d\n", fams[i].n, rc);
		if (rc == 0) {
			snprintf(cmd, sizeof(cmd), "/nft delete table %s p555f",
				 fams[i].n);
			sh(cmd);
		}
	}
	HAVE_ARP = (nft("a.arp2", "/nft add table arp p555a") == 0);
	printf("F555 HAVE|arp=%d\n", HAVE_ARP);
}

/* ---------- B: which hooks does the arp filter chain type accept ---------- */

static void sec_b(void)
{
	static const char *hs[][2] = {
		{ "input",      "type filter hook input priority 0; policy accept;" },
		{ "output",     "type filter hook output priority 0; policy accept;" },
		{ "forward",    "type filter hook forward priority 0; policy accept;" },
		{ "prerouting", "type filter hook prerouting priority 0; policy accept;" },
		{ "postrouting","type filter hook postrouting priority 0; policy accept;" },
		{ "ingress",    "type filter hook ingress priority 0; policy accept;" },
	};
	char cmd[512], tag[64];
	int i, rc;

	if (!HAVE_ARP) {
		printf("F555 HOOK|SKIP=no-arp-family\n");
		return;
	}
	for (i = 0; i < (int)(sizeof(hs) / sizeof(hs[0])); i++) {
		snprintf(tag, sizeof(tag), "b.%s", hs[i][0]);
		snprintf(cmd, sizeof(cmd), "/nft add chain arp p555a %s '{ %s }'",
			 hs[i][0], hs[i][1]);
		rc = nft(tag, cmd);
		printf("F555 HOOK|%s|%d\n", hs[i][0], rc);
	}
	sh("/nft delete table arp p555a");
}

/* ---------- diagnostic: what is actually in the rule ----------
 * F555D <table>.<chain>|r<N>=[expr(attr=val)...]
 * For a `log` expression both byte orders of NFTA_LOG_GROUP are printed, plus
 * the prefix, because "the rule counts but nothing arrives" has exactly one
 * cheap explanation to rule out first. */
static void dump_exprs(uint8_t family, const char *table, const char *chain)
{
	char buf[1024], rbuf[16384];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	int fd, sent, nrules = 0;

	fd = nl_open();
	if (fd < 0)
		return;
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1);
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1);
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return;
	}
	printf("F555D %s.%s|", table, chain);
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			const char *p, *end;

			if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
				goto done;
			if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				continue;
			printf("r%d=[", nrules);
			p = (const char *)h + NLMSG_HDRLEN + sizeof(*nfg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || p + alen > end)
					break;
				if ((a->nla_type & 0x3fff) == NFTA_RULE_EXPRESSIONS) {
					const char *q = (const char *)a + NLA_HDRLEN;
					const char *qe = (const char *)a + alen;
					int first = 1;

					for (; q + (int)sizeof(struct nlattr) <= qe; ) {
						const struct nlattr *el = (const struct nlattr *)q;
						int ell = (int)el->nla_len;
						const char *r, *re;
						const char *name = "?";
						char extra[128] = "";

						if (ell < (int)sizeof(*el) || q + ell > qe)
							break;
						r = (const char *)el + NLA_HDRLEN;
						re = (const char *)el + ell;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int eal = (int)ea->nla_len;

							if (eal < (int)sizeof(*ea) || r + eal > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_NAME)
								name = (const char *)ea + NLA_HDRLEN;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_DATA &&
							    !strcmp(name, "log")) {
								const char *dd = (const char *)ea + NLA_HDRLEN;
								const char *de = (const char *)ea + eal;
								char pfx[48] = "";
								int g_le = -1, g_be = -1;

								for (; dd + (int)sizeof(struct nlattr) <= de; ) {
									const struct nlattr *da = (const struct nlattr *)dd;
									int dal = (int)da->nla_len;

									if (dal < (int)sizeof(*da) || dd + dal > de)
										break;
									if ((da->nla_type & 0x3fff) == NFTA_LOG_GROUP &&
									    dal - NLA_HDRLEN >= 2) {
										const unsigned char *b =
											(const unsigned char *)da + NLA_HDRLEN;

										g_be = (b[0] << 8) | b[1];
										g_le = (b[1] << 8) | b[0];
									}
									if ((da->nla_type & 0x3fff) == NFTA_LOG_PREFIX)
										snprintf(pfx, sizeof(pfx), "%s",
											 (const char *)da + NLA_HDRLEN);
									dd += NLA_ALIGN_(dal);
								}
								snprintf(extra, sizeof(extra),
									 "{grp_be=%d,grp_le=%d,pfx=%s}",
									 g_be, g_le, pfx);
							}
							r += NLA_ALIGN_(eal);
						}
						printf("%s%s%s", first ? "" : ",", name, extra);
						first = 0;
						q += NLA_ALIGN_(ell);
					}
				}
				p += NLA_ALIGN_(alen);
			}
			printf("]");
			nrules++;
		}
	}
done:
	printf("|rules=%d\n", nrules);
	close(fd);
}

/* ---------- arm plumbing ---------- */

static void imm_pat(unsigned char *imm, int len)
{
	static const unsigned char pat[16] = {
		0xa5, 0x5a, 0x3c, 0xc3, 0x0f, 0xf0, 0x96, 0x69,
		0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88
	};
	int i;

	for (i = 0; i < len && i < 16; i++)
		imm[i] = pat[i];
}


struct rowres {
	int rc;
	int nfl;
	unsigned char nb[128];
	unsigned long long cnt;
	int ci1, co1, ilen, olen;
	unsigned char ib[248], ob[248];
};

static void row(const char *tag, const char *hook, const char *src,
		const char *rule, const char *g,
		const char *table, const char *chain,
		const unsigned char *ctl, int clen, int trig_out, uint32_t tpa,
		struct rowres *rs)
{
	char pre[80], h[160], chg[600];
	int nfl, ni1, no1;
	unsigned long long cnt;

	snprintf(pre, sizeof(pre), "f555.%s", tag);
	nfl = nfl_wait(NFL, pre, rs->nb, (int)sizeof(rs->nb), trig_out ? 600 : 300);
	ni1 = cap_arp_t(CAP_I1, rs->ib, (int)sizeof(rs->ib), trig_out ? 300 : 120,
			MAC_I0, 1, tpa);
	no1 = trig_out ? 0 : cap_arp_t(CAP_O1, rs->ob, (int)sizeof(rs->ob), 30,
				       MAC_I0, 1, 0);
	cnt = f555_count(NFPROTO_ARP, table, chain);
	rs->nfl = nfl;
	rs->cnt = cnt;
	rs->ci1 = ni1 > 0;
	rs->co1 = no1 > 0;
	rs->ilen = ni1;
	rs->olen = no1;
	hexcopy(h, (int)sizeof(h), rs->nb, nfl);
	chglist(chg, (int)sizeof(chg), rs->nb, nfl, ctl, clen);
	printf("F555 A|%s|hook=%s|src=%s|g=%s|rule=%s|rc=%d|cnt=%llu|nfl=%d|"
	       "chg=%s|nhex=%s|ci1=%d|ihex=",
	       tag, hook, src, g, rule, rs->rc, cnt, nfl, chg, h, ni1 > 0);
	hexcopy(h, (int)sizeof(h), rs->ib, ni1);
	printf("%s|co1=%d|ohex=", h, no1 > 0);
	hexcopy(h, (int)sizeof(h), rs->ob, no1);
	printf("%s\n", h);
}

static void arm_in_raw(const char *tag, const char *table, const char *chain,
		       uint32_t off, uint32_t len,
		       const unsigned char *fr, int flen,
		       const unsigned char *ctl, int clen, struct rowres *rs)
{
	unsigned char imm[32];
	char pre[80], g[32];

	memset(imm, 0, sizeof(imm));
	imm_pat(imm, (int)len);
	snprintf(pre, sizeof(pre), "f555.%s", tag);
	flush_chain(NFPROTO_ARP, table, chain);
	rs->rc = install_store(NFPROTO_ARP, table, chain, off, len, imm, (int)len,
			       1, 5, pre);
	cap_drain(CAP_I1);
	cap_drain(CAP_O1);
	nfl_drain(NFL);
	usleep(10000);
	pkt_send("i1", fr, flen);
	snprintf(g, sizeof(g), "%u,%u", off, len);
	row(tag, "in", "raw", "@nh,+", g, table, chain, ctl, clen, 0, 0, rs);
}

static void arm_in_nft(const char *tag, const char *table, const char *chain,
		       const char *ruletext, const char *g,
		       const unsigned char *fr, int flen,
		       const unsigned char *ctl, int clen, struct rowres *rs)
{
	char cmd[700], pre[80];

	snprintf(pre, sizeof(pre), "f555.%s", tag);
	flush_chain(NFPROTO_ARP, table, chain);
	snprintf(cmd, sizeof(cmd),
		 "/nft --debug=netlink add rule arp %s %s '%s log group 5 prefix \"%s\" counter accept'",
		 table, chain, ruletext, pre);
	rs->rc = nft(tag, cmd);
	cap_drain(CAP_I1);
	cap_drain(CAP_O1);
	nfl_drain(NFL);
	usleep(10000);
	pkt_send("i1", fr, flen);
	row(tag, "in", "nft", ruletext, g, table, chain, ctl, clen, 0, 0, rs);
}

static void arm_out_raw(const char *tag, const char *table, const char *chain,
			uint32_t off, uint32_t len, uint32_t poke,
			const unsigned char *ctl, int clen, struct rowres *rs)
{
	unsigned char imm[32];
	char pre[80], g[32];

	memset(imm, 0, sizeof(imm));
	imm_pat(imm, (int)len);
	snprintf(pre, sizeof(pre), "f555.%s", tag);
	flush_chain(NFPROTO_ARP, table, chain);
	rs->rc = install_store(NFPROTO_ARP, table, chain, off, len, imm, (int)len,
			       1, 5, pre);
	cap_drain(CAP_I1);
	nfl_drain(NFL);
	usleep(10000);
	f555_neigh_del("i0", htonl(poke));
	udp_poke(htonl(poke));
	snprintf(g, sizeof(g), "%u,%u", off, len);
	row(tag, "out", "raw", "@nh,+", g, table, chain, ctl, clen, 1, htonl(poke),
	    rs);
}

/* ---------- a control arm for a given table.chain ---------- */

static void arm_ctl(const char *tag, const char *hook, const char *table,
		    const char *chain, int trig_out, uint32_t poke,
		    const unsigned char *fr, int flen, struct rowres *rs)
{
	char pre[80];

	snprintf(pre, sizeof(pre), "f555.%s", tag);
	flush_chain(NFPROTO_ARP, table, chain);
	rs->rc = install_ctl(NFPROTO_ARP, table, chain, 5, pre);
	cap_drain(CAP_I1);
	cap_drain(CAP_O1);
	nfl_drain(NFL);
	usleep(20000);
	if (trig_out) {
		f555_neigh_del("i0", htonl(poke));
		udp_poke(htonl(poke));
	} else {
		pkt_send("i1", fr, flen);
	}
	row(tag, hook, "raw", "log+counter", "-", table, chain, NULL, 0,
	    trig_out, trig_out ? htonl(poke) : 0, rs);
}

/* ---------- C: the nine fields nft itself can name ---------- */

static void sec_c(unsigned char *fr, int flen)
{
	static const char *names[] = {
		"htype", "ptype", "hlen", "plen", "operation",
		"saddr_ether", "saddr_ip", "daddr_ether", "daddr_ip",
	};
	static const char *rules[] = {
		"arp htype set 0x00ab",
		"arp ptype set 0x86dd",
		"arp hlen set 8",
		"arp plen set 16",
		"arp operation set 2",
		"arp saddr ether set aa:bb:cc:00:00:99",
		"arp saddr ip set 10.1.0.66",
		"arp daddr ether set aa:bb:cc:00:00:88",
		"arp daddr ip set 10.9.0.1",
	};
	static const char *geoms[] = {
		"0,2", "2,2", "4,1", "5,1", "6,2", "8,6", "14,4", "18,6", "24,4",
	};
	struct rowres ctl, rs;
	char tag[64];
	int i;

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC c.table|%d\n", add_table(NFPROTO_ARP, "p555c"));
	printf("F555RC c.chain|%d\n", add_chain(NFPROTO_ARP, "p555c", "in", 0, 0, 1));
	arm_ctl("c.ctl", "in", "p555c", "in", 0, 0, fr, flen, &ctl);
	ctl = rs = ctl;
	for (i = 0; i < 9; i++) {
		snprintf(tag, sizeof(tag), "c.%s", names[i]);
		arm_in_nft(tag, "p555c", "in", rules[i], geoms[i], fr, flen,
			   ctl.nb, ctl.nfl, &rs);
	}
	/* C2: the raw escape, in the family nft could never reach before */
	arm_in_nft("c2.spill2016", "p555c", "in",
		   "@nh,160,128 set 0x00112233445566778899aabbccddeeff", "20,16",
		   fr, flen, ctl.nb, ctl.nfl, &rs);
	arm_in_nft("c2.pad288", "p555c", "in",
		   "@nh,224,64 set 0x0102030405060708", "28,8",
		   fr, flen, ctl.nb, ctl.nfl, &rs);
	arm_in_nft("c2.op71", "p555c", "in", "@nh,56,8 set 0xab", "7,1",
		   fr, flen, ctl.nb, ctl.nfl, &rs);
	sh("/nft delete table arp p555c");
}

/* ---------- D: the guard as a function of (offset,len), input hook ---------- */

static const int GRID_OFF[] = { 0, 1, 2, 4, 5, 6, 7, 8, 10, 14, 18, 20, 24, 26, 28, 30 };
static const int GRID_LEN[] = { 1, 2, 4, 6, 8, 16 };

static void sec_d(unsigned char *fr, int flen)
{
	struct rowres ctl, rs;
	int i, j;
	char tag[64];

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC d.table|%d\n", add_table(NFPROTO_ARP, "p555d"));
	printf("F555RC d.chain|%d\n", add_chain(NFPROTO_ARP, "p555d", "in", 0, 0, 1));
	arm_ctl("d.ctl", "in", "p555d", "in", 0, 0, fr, flen, &ctl);
	for (i = 0; i < (int)(sizeof(GRID_OFF) / sizeof(GRID_OFF[0])); i++) {
		for (j = 0; j < (int)(sizeof(GRID_LEN) / sizeof(GRID_LEN[0])); j++) {
			int off = GRID_OFF[i], len = GRID_LEN[j];

			if (off + len > 46)	/* past the padded frame: not the guard */
				continue;
			snprintf(tag, sizeof(tag), "d.%d.%d", off, len);
			arm_in_raw(tag, "p555d", "in", (uint32_t)off, (uint32_t)len,
				   fr, flen, ctl.nb, ctl.nfl, &rs);
		}
	}
	sh("/nft delete table arp p555d");
}

/* ---------- E: the same grid at the OUTPUT hook ---------- */

static void sec_e(unsigned char *fr, int flen)
{
	static const int EOFF[] = { 0, 4, 6, 8, 14, 18, 20, 24, 24, 26, 28, 30 };
	static const int ELEN[] = { 2, 1, 2, 6, 4, 6, 16, 4, 6, 4, 8, 16 };
	struct rowres ctl, rs;
	int i;
	char tag[64];
	(void)fr;
	(void)flen;

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC e.table|%d\n", add_table(NFPROTO_ARP, "p555e"));
	/* NF_ARP_OUT is 1 -- NF_ARP_FORWARD is 2 (netfilter_arp.h), and the first
	 * smoke of this turn asked for hook 2 and got -EOPNOTSUPP for every arm. */
	printf("F555RC e.chain|%d\n", add_chain(NFPROTO_ARP, "p555e", "out", 1, 0, 1));
	arm_ctl("e.ctl", "out", "p555e", "out", 1, 0x0a0100c0, NULL, 0, &ctl);
	for (i = 0; i < (int)(sizeof(EOFF) / sizeof(EOFF[0])); i++) {
		snprintf(tag, sizeof(tag), "e.%d.%d", EOFF[i], ELEN[i]);
		arm_out_raw(tag, "p555e", "out", (uint32_t)EOFF[i],
			    (uint32_t)ELEN[i], 0x0a0100c0,
			    ctl.nb, ctl.nfl, &rs);
	}
	sh("/nft delete table arp p555e");
}

/* ---------- F: what a rule in this family does to the host ---------- */

static void sec_f(void)
{
	struct {
		const char *tag;
		const char *rule;
		uint32_t spa;
		const char *spa_s;
		const char *moved_s;	/* the address a live rewrite would produce */
	} fa[] = {
		{ "f.norule", NULL,                       0x0a010091, "10.1.0.91", "10.5.5.5" },
		{ "f.alive",  "arp saddr ip set 10.5.5.5", 0x0a010092, "10.1.0.92", "10.5.5.5" },
		{ "f.dead",   "arp htype set 2",           0x0a010093, "10.1.0.93", "10.5.5.6" },
		{ "f.op",     "arp operation set 2",       0x0a010094, "10.1.0.94", "10.5.5.7" },
	};
	unsigned char fr[160];
	int flen, i;
	char cmd[700], tag[64];

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC f.table|%d\n", add_table(NFPROTO_ARP, "p555f"));
	printf("F555RC f.chain|%d\n", add_chain(NFPROTO_ARP, "p555f", "in2", 0, 0, 0));
	for (i = 0; i < (int)(sizeof(fa) / sizeof(fa[0])); i++) {
		int rc = 0, ni1, no1;
		unsigned long long cnt;

		flush_chain(NFPROTO_ARP, "p555f", "in2");
		if (fa[i].rule) {
			snprintf(tag, sizeof(tag), "%s.i", fa[i].tag);
			snprintf(cmd, sizeof(cmd),
				 "/nft add rule arp p555f in2 '%s counter accept'",
				 fa[i].rule);
			rc = nft(tag, cmd);
		}
		flen = build_arp(fr, 1, fa[i].spa, 0x0a010001, MAC_SRC, 6, 4, 1);
		cap_drain(CAP_I1);
		cap_drain(CAP_O1);
		usleep(20000);
		pkt_send("i1", fr, flen);
		ni1 = cap_arp(CAP_I1, fr, 248, 300, MAC_I0, 1);
		no1 = cap_arp(CAP_O1, fr, 248, 40, MAC_I0, 1);
		cnt = f555_count(NFPROTO_ARP, "p555f", "in2");
		printf("F555 F|%s|rule=%s|rc=%d|cnt=%llu|reply_i=%d|reply_o=%d\n",
		       fa[i].tag, fa[i].rule ? fa[i].rule : "none", rc, cnt,
		       ni1 > 0, no1 > 0);
		arp_row(fa[i].tag, fa[i].spa_s);
		arp_row(fa[i].tag, fa[i].moved_s);
	}
	sh("/nft delete table arp p555f");
}

/* ---------- G: what the receive path refuses before nft sees the packet ---------- */

static void sec_g(void)
{
	struct {
		const char *tag;
		int hlen, plen;
		uint32_t spa;
	} ga[] = {
		{ "g.h6p4",  6, 4,  0x0a0100b0 },
		{ "g.h8p16", 8, 16, 0x0a0100b1 },
		{ "g.h6p8",  6, 8,  0x0a0100b2 },
	};
	unsigned char fr[160], pay[128];
	int i, flen;
	char tag[64], pre[80];

	if (!HAVE_ARP)
		return;
	sh("/nft flush ruleset");
	printf("F555RC g.table|%d\n", add_table(NFPROTO_ARP, "p555g"));
	printf("F555RC g.chain|%d\n", add_chain(NFPROTO_ARP, "p555g", "in", 0, 0, 1));
	for (i = 0; i < 3; i++) {
		int rc, nfl, rx;
		unsigned long long cnt;

		flush_chain(NFPROTO_ARP, "p555g", "in");
		snprintf(pre, sizeof(pre), "f555.%s", ga[i].tag);
		rc = install_ctl(NFPROTO_ARP, "p555g", "in", 5, pre);
		flen = build_arp(fr, 1, ga[i].spa, 0x0a010001, MAC_SRC,
				 ga[i].hlen, ga[i].plen, 1);
		cap_drain(CAP_I1);
		nfl_drain(NFL);
		usleep(20000);
		pkt_send("i1", fr, flen);
		nfl = nfl_wait(NFL, pre, pay, (int)sizeof(pay), 300);
		rx = cap_arp(CAP_I0, fr, 248, 200, MAC_SRC, 1) > 0;
		cnt = f555_count(NFPROTO_ARP, "p555g", "in");
		snprintf(tag, sizeof(tag), "%s", ga[i].tag);
		printf("F555 G|%s|hlen=%d|plen=%d|flen=%d|rc=%d|rx_i0=%d|cnt=%llu|"
		       "nfl=%d\n", tag, ga[i].hlen, ga[i].plen, flen, rc, rx, cnt, nfl);
	}
	sh("/nft delete table arp p555g");
}

/* ---------- focused experiment (mode f555log): where does the prefix go ---------- */

static void dump_log_hex(uint8_t family, const char *table, const char *chain,
			 const char *tag)
{
	char buf[1024], rbuf[16384];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	int fd, sent;

	fd = nl_open();
	if (fd < 0)
		return;
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1);
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1);
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return;
	}
	printf("F555H %s|", tag);
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			const char *p, *end;

			if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
				goto done;
			if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				continue;
			p = (const char *)h + NLMSG_HDRLEN + sizeof(*nfg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int alen = (int)a->nla_len;

				if (alen < (int)sizeof(*a) || p + alen > end)
					break;
				if ((a->nla_type & 0x3fff) == NFTA_RULE_EXPRESSIONS) {
					const char *q = (const char *)a + NLA_HDRLEN;
					const char *qe = (const char *)a + alen;

					for (; q + (int)sizeof(struct nlattr) <= qe; ) {
						const struct nlattr *el = (const struct nlattr *)q;
						int ell = (int)el->nla_len;
						const char *r, *re;
						const char *name = "?";

						if (ell < (int)sizeof(*el) || q + ell > qe)
							break;
						r = (const char *)el + NLA_HDRLEN;
						re = (const char *)el + ell;
						for (; r + (int)sizeof(struct nlattr) <= re; ) {
							const struct nlattr *ea = (const struct nlattr *)r;
							int eal = (int)ea->nla_len;
							int k;

							if (eal < (int)sizeof(*ea) || r + eal > re)
								break;
							if ((ea->nla_type & 0x3fff) == NFTA_EXPR_NAME)
								name = (const char *)ea + NLA_HDRLEN;
							r += NLA_ALIGN_(eal);
						}
						if (!strcmp(name, "log")) {
							r = (const char *)el + NLA_HDRLEN;
							for (; r + (int)sizeof(struct nlattr) <= re; ) {
								const struct nlattr *ea = (const struct nlattr *)r;
								int eal = (int)ea->nla_len;

								if (eal < (int)sizeof(*ea) || r + eal > re)
									break;
								if ((ea->nla_type & 0x3fff) == NFTA_EXPR_DATA) {
									const unsigned char *b =
										(const unsigned char *)ea + NLA_HDRLEN;
									int n = eal - NLA_HDRLEN, k;

									printf("logdata[%d]=", n);
									for (k = 0; k < n; k++)
										printf("%02x", b[k]);
									printf("|");
								}
								r += NLA_ALIGN_(eal);
							}
						}
						q += NLA_ALIGN_(ell);
					}
				}
				p += NLA_ALIGN_(alen);
			}
		}
	}
done:
	printf("|end\n");
	close(fd);
}

static void nfl_readall(int fd, int ms, const char *tag)
{
	struct timeval tv = { .tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000 };
	int n = 0;

	for (;;) {
		unsigned char b[4096];
		int r;

		FD_ZERO(&(fd_set){0});
		{
			fd_set rfds;

			FD_ZERO(&rfds);
			FD_SET(fd, &rfds);
			if (select(fd + 1, &rfds, NULL, NULL, &tv) <= 0)
				break;
		}
		r = (int)recv(fd, b, sizeof(b), 0);
		if (r <= 0)
			break;
		{
			struct nlmsghdr *h = (struct nlmsghdr *)b;
			int rem = r;

			for (; NLMSG_OK(h, rem); h = NLMSG_NEXT(h, rem)) {
				const unsigned char *p;
				int plen, off;
				char pre[64] = "";
				unsigned char pay[128];
				int paylen = 0, k;

				if (h->nlmsg_type != (uint16_t)((NFNL_SUBSYS_ULOG_ << 8) |
								NFULNL_MSG_PACKET_))
					continue;
				p = (const unsigned char *)NLMSG_DATA(h);
				plen = (int)h->nlmsg_len - NLMSG_HDRLEN;
				for (off = 4; off + (int)sizeof(struct nlattr) <= plen; ) {
					const struct nlattr *a = (const struct nlattr *)(p + off);
					int alen = (int)a->nla_len;

					if (alen < (int)sizeof(*a) || off + alen > plen)
						break;
					if ((a->nla_type & 0x3fff) == NFULA_PREFIX_)
						snprintf(pre, sizeof(pre), "%s",
							 (const char *)a + NLA_HDRLEN);
					if ((a->nla_type & 0x3fff) == NFULA_PAYLOAD_) {
						int m = alen - NLA_HDRLEN;

						if (m > 128)
							m = 128;
						memcpy(pay, (const char *)a + NLA_HDRLEN, (size_t)m);
						paylen = m;
					}
					off += (int)NLA_ALIGN_(alen);
				}
				n++;
				printf("F555N %s|n=%d|pre=%s|len=%d|pay=", tag, n, pre, paylen);
				for (k = 0; k < paylen && k < 48; k++)
					printf("%02x", pay[k]);
				printf("\n");
			}
		}
	}
	if (!n)
		printf("F555N %s|n=0\n", tag);
}

/* four variants of the same question, one boot */
static void sec_log(void)
{
	unsigned char fr[160], imm[16];
	char pre[64];
	int flen, i;
	static const struct { const char *tag; const char *pre; int store; } v[] = {
		{ "l.ctl",   "abc.def", 0 },
		{ "l.store", "ghi.jkl", 1 },
	};

	sh("/nft flush ruleset");
	printf("F555RC l.table|%d\n", add_table(NFPROTO_ARP, "p555l"));
	printf("F555RC l.chain|%d\n", add_chain(NFPROTO_ARP, "p555l", "in", 0, 0, 1));
	flen = build_arp(fr, 1, 0x0a010009, 0x0a010001, MAC_SRC, 6, 4, 1);
	memset(imm, 0, sizeof(imm));
	imm_pat(imm, 2);
	for (i = 0; i < 2; i++) {
		int rc;

		snprintf(pre, sizeof(pre), "f555.%s", v[i].tag);
		flush_chain(NFPROTO_ARP, "p555l", "in");
		if (v[i].store)
			rc = install_store(NFPROTO_ARP, "p555l", "in", 8, 2, imm, 2, 1,
					   5, v[i].pre);
		else
			rc = install_ctl(NFPROTO_ARP, "p555l", "in", 5, v[i].pre);
		printf("F555RC %s|%d\n", v[i].tag, rc);
		dump_log_hex(NFPROTO_ARP, "p555l", "in", v[i].tag);
		cap_drain(CAP_I1);
		nfl_drain(NFL);
		usleep(20000);
		pkt_send("i1", fr, flen);
		{
			unsigned long long cnt = f555_count(NFPROTO_ARP, "p555l", "in");

			printf("F555C %s|cnt=%llu\n", v[i].tag, cnt);
		}
		nfl_readall(NFL, 400, v[i].tag);
	}
	/* the same rule, installed by nft */
	flush_chain(NFPROTO_ARP, "p555l", "in");
	printf("F555RC l.nft|%d\n",
	       nft("l.nft", "/nft add rule arp p555l in 'log group 5 prefix \"mno.pqr\" counter accept'"));
	dump_log_hex(NFPROTO_ARP, "p555l", "in", "l.nft");
	cap_drain(CAP_I1);
	nfl_drain(NFL);
	usleep(20000);
	pkt_send("i1", fr, flen);
	nfl_readall(NFL, 400, "l.nft");
	sh("/nft delete table arp p555l");
}
/* ---------- /proc/net/arp sanity + main ---------- */

int f555_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f555";
	unsigned char fr[160];
	int flen;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F555 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F555 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	sec_a();
	sec_b();
	if (!strcmp(mode, "f555bare")) {
		printf("F555 DONE\n");
		return 0;
	}
	env_setup();
	flen = build_arp(fr, 1, 0x0a010009, 0x0a010001, MAC_SRC, 6, 4, 1);
	printf("F555 FRAME|len=%d|hex=", flen);
	{
		int i;

		for (i = 0; i < 60; i++)
			printf("%02x", fr[i]);
		printf("\n");
	}
	if (!strcmp(mode, "f555log")) {
		sec_log();
		printf("F555 DONE\n");
		return 0;
	}
	sec_c(fr, flen);
	sec_d(fr, flen);
	sec_e(fr, flen);
	sec_f();
	sec_g();
	printf("F555 DONE\n");
	return 0;
}
/* differ556_add.c -- turn 556 / F33: one guard, four types, one grid.
 *
 * F30/F31/F32 measured the four branches of nft_nh_write_ok() one at a time,
 * on three DIFFERENT images:
 *
 *   ip4/ip6     stock 7.3.4-B19           (F30)
 *   bridge      src/linux-7.3.4-C553      (F31, ethertype 0x0800 / 0x0806)
 *   netdev      src/linux-7.3.4-C553      (F31, dead code at ingress)
 *   arp         src/linux-7.3.4-A553      (F32)
 *
 * F33 asks a different question: not "does branch X guard byte Y", but "what
 * KIND of function is each branch".  The answer is the SHAPE of the set of
 * (offset,len) pairs it accepts, and a shape measured in three different boots
 * on three different images is not a shape.  So: one kernel (T556) with all
 * four branches live, one boot, and ONE identical 40-cell grid shipped through
 * every envelope:
 *
 *   ip4   family ip,     base nh, chain prerouting   (nft_nh_write_ok_ip4)
 *   ip6   family ip6,    base nh, chain prerouting   (nft_nh_write_ok_ip6)
 *   nd    family netdev, base nh, chain ingress i1   (nft_nh_write_ok -> true)
 *   br4   family bridge, base nh, chain prerouting, ethertype 0x0800
 *   brA   family bridge, base nh, chain prerouting, ethertype 0x0806
 *   arp   family arp,    base nh, chain input        (nft_nh_write_ok_arp)
 *   ll4   family ip,     base ll, chain prerouting   (nft_ll_write_ok)
 *   llN   family netdev, base ll, chain ingress i1
 *   llB   family bridge, base ll, chain prerouting
 *
 * Oracle per arm: the kernel's own counter, placed AFTER the store in the same
 * rule -- cnt=1 means "the guard let the store through and the rest of the
 * rule ran", cnt=0 means the store was refused and the remaining expressions
 * (log, counter, verdict) never ran.  The NFLOG message carries the frame as
 * it looks at the log point, i.e. after the store, so every alive cell also
 * gets its bytes checked against the control arm of the same envelope.
 *
 * This file is appended to a renamed copy of differ555.c (see
 * vm/build_f33_differ.sh); all helpers above it -- netlink toolkit, veth,
 * rtnetlink, NFLOG, build_arp, f555_count -- are the F32 ones, unchanged.
 */

/* ---------- bridge device helpers (same code as differ553.c) ---------- */

static int f556_link_add_kind(const char *name, const char *kind)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[256];
	} req;
	struct nlattr *li;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, name, (int)strlen(name) + 1);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, kind, (int)strlen(kind) + 1);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f556_link_enslave(const char *port, const char *master)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[128];
	} req;
	uint32_t midx = (uint32_t)f555_ifindex(master);
	int fd, rc;

	if ((int)midx < 0)
		return -10;
	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	req.ifi.ifi_index = f555_ifindex(port);
	attr_put(&req.nlh, IFLA_MASTER, &midx, 4);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

/* ---------- one chain, with a device when the hook needs one ---------- */

/* base chain: family, hook number, priority, policy; dev != NULL only for the
 * netdev ingress hook, whose NFTA_HOOK_DEV is a STRING (nf_tables_api.c reads
 * it with nla_get_string()). */
static int f556_add_chain(uint8_t family, const char *table, const char *chain,
			  uint32_t hook, uint32_t prio, uint32_t policy,
			  const char *dev)
{
	struct nlmsghdr *nlh;
	struct nlattr *h;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWCHAIN,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE, family);
	put_str(nlh, NFTA_CHAIN_TABLE, table);
	put_str(nlh, NFTA_CHAIN_NAME, chain);
	h = nest_start(nlh, NFTA_CHAIN_HOOK);
	put_be32(nlh, NFTA_HOOK_HOOKNUM, hook);
	put_be32(nlh, NFTA_HOOK_PRIORITY, prio);
	if (dev)
		put_str(nlh, NFTA_HOOK_DEV, dev);
	nest_end(nlh, h);
	put_be32(nlh, NFTA_CHAIN_POLICY, policy);
	put_str(nlh, NFTA_CHAIN_TYPE, "filter");
	return nft_one(opbuf, (int)nlh->nlmsg_len);
}

/* ---------- the store, with an explicit payload BASE ---------- */

/* one rule: [store <base>+off = imm][log][counter][accept] */
static int f556_install_store(uint8_t family, const char *table, const char *chain,
			      uint32_t base, uint32_t off, uint32_t len,
			      const unsigned char *imm, int immlen,
			      int loggroup, const char *prefix)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *e, *d;
	int rc;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			family);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	imm_value(nlh, NFT_REG32_00, imm, immlen);
	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "payload");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00);
	put_be32(nlh, NFTA_PAYLOAD_BASE, base);
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
	put_be32(nlh, NFTA_PAYLOAD_LEN, len);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
	nest_end(nlh, d);
	nest_end(nlh, e);
	log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	rc = nft_one(opbuf, (int)nlh->nlmsg_len);
	return rc;
}

/* ---------- frames ---------- */

static const unsigned char M33_BC[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

static unsigned short f556_csum(const void *data, int len)
{
	const unsigned char *p = data;
	unsigned int sum = 0;

	while (len > 1) {
		sum += (unsigned int)((p[0] << 8) | p[1]);
		p += 2;
		len -= 2;
	}
	if (len)
		sum += (unsigned int)(p[0] << 8);
	while (sum >> 16)
		sum = (sum & 0xffff) + (sum >> 16);
	return (unsigned short)~sum;
}

/* frame kinds */
#define FK33_IP4	0	/* ethernet + IPv4 (ihl 5, proto 17) + UDP */
#define FK33_IP6	1	/* ethernet + IPv6 + UDP                     */
#define FK33_ARP	2	/* ethernet + ARP request, padded to 60      */
#define FK33_IP4_IHL6	3	/* the same datagram with ihl 6 -> byte 14 = 0x46 */
#define FK33_IP4_P6	4	/* the same datagram with proto 6 (byte 23 = 0x06) */
#define FK33_IP6_B	5	/* a different IPv6 frame (tc/hop differ)    */

/* Ethernet + IPv4 + UDP.  ihl4 is the header length in 32-bit words; the
 * checksum is computed over exactly ihl4*4 bytes, so an ihl-6 frame is a
 * VALID datagram -- ip_rcv must not drop it before the hook, or the guard
 * would never be asked. */
static int f556_mk_ip4(unsigned char *out, int ihl4, int proto, int ttl)
{
	int hl = ihl4 * 4, tot = hl + 8 + 18;
	unsigned char *ip = out + 14;
	unsigned char *u = out + 14 + hl;
	unsigned short c;

	memset(out, 0, 200);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x08;
	out[13] = 0x00;
	ip[0] = (unsigned char)(0x40 | ihl4);
	ip[1] = 0x00;
	ip[2] = (unsigned char)(tot >> 8);
	ip[3] = (unsigned char)tot;
	ip[4] = 0x12;
	ip[5] = 0x34;
	ip[6] = 0x00;
	ip[7] = 0x00;
	ip[8] = (unsigned char)ttl;
	ip[9] = (unsigned char)proto;
	ip[10] = 0x00;
	ip[11] = 0x00;
	ip[12] = 0x0a; ip[13] = 0x01; ip[14] = 0x00; ip[15] = 0x01;	/* 10.1.0.1 */
	ip[16] = 0x0a; ip[17] = 0x09; ip[18] = 0x00; ip[19] = 0x07;	/* 10.9.0.7 */
	c = f556_csum(ip, hl);
	ip[10] = (unsigned char)(c >> 8);
	ip[11] = (unsigned char)c;
	u[0] = 0x9c; u[1] = 0x40;	/* sport 40000 */
	u[2] = 0x13; u[3] = 0x88;	/* dport 5000  */
	u[4] = 0x00; u[5] = 26;		/* 8 + 18      */
	u[6] = 0x00; u[7] = 0x00;	/* checksum 0 (legal for IPv4) */
	memset(u + 8, 0x77, 18);
	return 14 + tot;
}

/* Ethernet + IPv6 + UDP.  `tc` goes into the traffic-class nibbles of bytes
 * 14..15, `hop` into byte 21 -- the two bytes FK33_IP6_B changes, so the same
 * rule over two IPv6 frames tests whether that branch reads the packet. */
static int f556_mk_ip6(unsigned char *out, int tc, int hop)
{
	int pay = 8 + 18;
	unsigned char *ip = out + 14;
	unsigned char *u = out + 14 + 40;
	static const unsigned char src[16] = { 0xfd, 0, 0, 0, 0, 0, 0, 0,
					       0, 0, 0, 0, 0, 0x98, 0, 1 };
	static const unsigned char dst[16] = { 0xfd, 0, 0, 0, 0, 0, 0, 0,
					       0, 0, 0, 0, 0, 0x99, 0, 9 };

	memset(out, 0, 200);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x86;
	out[13] = 0xdd;
	ip[0] = 0x60 | (unsigned char)((tc >> 4) & 0x0f);
	ip[1] = (unsigned char)((tc << 4) & 0xf0);
	ip[4] = (unsigned char)(pay >> 8);
	ip[5] = (unsigned char)pay;
	ip[6] = 17;
	ip[7] = (unsigned char)hop;
	memcpy(ip + 8, src, 16);
	memcpy(ip + 24, dst, 16);
	u[0] = 0x9c; u[1] = 0x40;
	u[2] = 0x13; u[3] = 0x88;
	u[4] = 0x00; u[5] = 26;
	u[6] = 0x00; u[7] = 0x00;
	memset(u + 8, 0x77, 18);
	return 14 + 40 + pay;
}

static int f556_frame(int kind, unsigned char *out)
{
	switch (kind) {
	case FK33_IP4:
		return f556_mk_ip4(out, 5, 17, 64);
	case FK33_IP4_IHL6:
		return f556_mk_ip4(out, 6, 17, 64);
	case FK33_IP4_P6:
		return f556_mk_ip4(out, 5, 6, 64);
	case FK33_IP6:
		return f556_mk_ip6(out, 0x00, 64);
	case FK33_IP6_B:
		return f556_mk_ip6(out, 0x2e, 33);
	case FK33_ARP:
		return build_arp(out, 1, 0x0a010009, 0x0a090001, MAC_SRC, 6, 4, 1);
	}
	return f556_mk_ip4(out, 5, 17, 64);
}

/* pkt_send() above sets sll_protocol = ETH_P_ALL.  That is what
 * packet_snd() copies into skb->protocol, and at the netdev EGRESS hook the
 * guard switches on exactly that field -- so an egress arm sent with
 * ETH_P_ALL would be judged as "unknown protocol" and every cell would look
 * refused.  This variant sends the frame's own ethertype. */
static int pkt_send_p(const char *dev, const unsigned char *fr, int len,
		      unsigned short proto)
{
	struct sockaddr_ll sll;
	int s, rc, idx = f555_ifindex(dev);

	if (idx < 0)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(proto);
	sll.sll_ifindex = idx;
	sll.sll_halen = 6;
	memcpy(sll.sll_addr, fr, 6);
	rc = (int)sendto(s, fr, (size_t)len, 0, (struct sockaddr *)&sll, sizeof(sll));
	close(s);
	return rc < 0 ? -errno : 0;
}

static unsigned short f556_proto(int kind)
{
	if (kind == FK33_ARP)
		return 0x0806;
	if (kind == FK33_IP6 || kind == FK33_IP6_B)
		return 0x86dd;
	return 0x0800;
}

/* ---------- the shared grid ---------- */

#define G33_NOFF 12
#define G33_NLEN 3
#define G33_NEXT 4
#define G33_N (G33_NOFF * G33_NLEN + G33_NEXT)

static const int G33_OFF[G33_NOFF] = { 0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24 };
static const int G33_LEN[G33_NLEN] = { 1, 2, 4 };
static const int G33_XOFF[G33_NEXT] = { 0, 8, 16, 20 };
static const int G33_XLEN[G33_NEXT] = { 8, 16, 16, 16 };

/* The value a cell writes.  Where a branch compares a written byte with the
 * frame (ip4 offset 0 and offset 8 + len 2), the value is chosen equal to what
 * the frame carries, so that the LENGTH is what the cell measures and not the
 * value.  The value-dependence itself is measured separately, by the E arms. */
static void f556_imm(int kind, int off, int len, unsigned char *imm)
{
	int i;

	memset(imm, 0, 16);
	for (i = 0; i < len && i < 16; i++)
		imm[i] = (unsigned char)(0x90 + i);
	if (off == 0)
		imm[0] = (kind == FK33_IP6 || kind == FK33_IP6_B) ? 0x60 : 0x45;
	if (off == 8 && len >= 2)
		imm[1] = 0x11;	/* keep byte 9 (protocol) as the frame has it */
}

/* ---------- one envelope ---------- */

struct f556_env {
	const char *tag;
	uint8_t fam;
	const char *table;
	const char *chain;
	uint32_t hook;
	uint32_t base;
	const char *dev;	/* where the frame is injected */
	const char *rule_dev;	/* NFTA_HOOK_DEV, netdev only */
	int kind;		/* default frame kind */
};

static int NFL33 = -1;
static char PRE33[96];

static long f33_ms(void)
{
	struct timeval tv;

	gettimeofday(&tv, NULL);
	return tv.tv_sec * 1000L + tv.tv_usec / 1000;
}

static unsigned long long f556_arm(const struct f556_env *e, const char *tag,
				   int off, int len, const unsigned char *imm,
				   int immlen, int kind)
{
	unsigned char fr[256], pay[192];
	unsigned long long cnt, cnt0;
	int flen, n = 0, rc, i;
	long t0, t1, t2, t3, t4;

	flen = f556_frame(kind, fr);
	snprintf(PRE33, sizeof(PRE33), "f33.%s.%s", e->tag, tag);
	t0 = f33_ms();
	flush_chain(e->fam, e->table, e->chain);
	t1 = f33_ms();
	rc = f556_install_store(e->fam, e->table, e->chain, e->base,
				(uint32_t)off, (uint32_t)len, imm, immlen,
				5, PRE33);
	t2 = f33_ms();
	nfl_drain(NFL33);
	cnt0 = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	if (rc == 0) {
		usleep(15000);
		pkt_send_p(e->dev, fr, flen, f556_proto(kind));
		n = nfl_wait(NFL33, PRE33, pay, (int)sizeof(pay), 200);
	}
	t3 = f33_ms();
	cnt = f555_count(e->fam, e->table, e->chain);
	t4 = f33_ms();
	printf("F556 R|env=%s|arm=%s|off=%d|len=%d|kind=%d|rc=%d|cnt=%llu|cnt0=%llu|"
	       "nfl=%d|ms=%ld,%ld,%ld,%ld|hex=",
	       e->tag, tag, off, len, kind, rc, cnt, cnt0, n, t1 - t0, t2 - t1,
	       t3 - t2, t4 - t3);
	for (i = 0; i < n && i < 96; i++)
		printf("%02x", pay[i]);
	printf("\n");
	return cnt;
}

static void f556_ctl(const struct f556_env *e, int kind)
{
	unsigned char fr[256], pay[192];
	unsigned long long cnt, cnt0;
	int flen, n, rc, i;

	flen = f556_frame(kind, fr);
	snprintf(PRE33, sizeof(PRE33), "f33.%s.ctl", e->tag);
	flush_chain(e->fam, e->table, e->chain);
	rc = install_ctl(e->fam, e->table, e->chain, 5, PRE33);
	nfl_drain(NFL33);
	n = 0;
	cnt0 = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	if (rc == 0) {
		usleep(15000);
		pkt_send_p(e->dev, fr, flen, f556_proto(kind));
		n = nfl_wait(NFL33, PRE33, pay, (int)sizeof(pay), 300);
	}
	cnt = f555_count(e->fam, e->table, e->chain);
	printf("F556 CTL|env=%s|kind=%d|rc=%d|cnt=%llu|cnt0=%llu|nfl=%d|hex=",
	       e->tag, kind, rc, cnt, cnt0, n);
	for (i = 0; i < n && i < 96; i++)
		printf("%02x", pay[i]);
	printf("\n");
}

/* create the table and the one chain this envelope owns */
static int f556_chain(const struct f556_env *e)
{
	int rc, rc2;

	rc = add_table(e->fam, e->table);
	rc2 = f556_add_chain(e->fam, e->table, e->chain, e->hook, 0, 1,
			     e->rule_dev);
	printf("F556 CHAIN|env=%s|table=%d|chain=%d\n", e->tag, rc, rc2);
	return rc || rc2;
}

static void f556_env_run(const struct f556_env *e)
{
	unsigned char imm[16];
	char tag[32];
	int i, j;

	f556_ctl(e, e->kind);
	for (i = 0; i < G33_NOFF; i++) {
		for (j = 0; j < G33_NLEN; j++) {
			f556_imm(e->kind, G33_OFF[i], G33_LEN[j], imm);
			snprintf(tag, sizeof(tag), "g%d_%d", G33_OFF[i], G33_LEN[j]);
			f556_arm(e, tag, G33_OFF[i], G33_LEN[j], imm, G33_LEN[j],
				 e->kind);
		}
	}
	for (i = 0; i < G33_NEXT; i++) {
		f556_imm(e->kind, G33_XOFF[i], G33_XLEN[i], imm);
		snprintf(tag, sizeof(tag), "x%d_%d", G33_XOFF[i], G33_XLEN[i]);
		f556_arm(e, tag, G33_XOFF[i], G33_XLEN[i], imm, G33_XLEN[i],
			 e->kind);
	}
	sh("/nft flush ruleset");
}

/* ---------- environment ---------- */

static int HAVE33_IP, HAVE33_IP6, HAVE33_NETDEV, HAVE33_BRIDGE, HAVE33_ARP;

static void f556_fams(void)
{
	struct { const char *n; uint8_t f; int *have; } fams[] = {
		{ "ip",     NFPROTO_IPV4,   &HAVE33_IP },
		{ "ip6",    NFPROTO_IPV6,   &HAVE33_IP6 },
		{ "netdev", NFPROTO_NETDEV, &HAVE33_NETDEV },
		{ "bridge", NFPROTO_BRIDGE, &HAVE33_BRIDGE },
		{ "arp",    NFPROTO_ARP,    &HAVE33_ARP },
	};
	char cmd[256];
	int i;

	sh("/nft flush ruleset");
	for (i = 0; i < (int)(sizeof(fams) / sizeof(fams[0])); i++) {
		int rc = add_table(fams[i].f, "p33probe");

		*fams[i].have = (rc == 0);
		printf("F556 FAM|%s|%d\n", fams[i].n, rc);
		if (rc == 0) {
			snprintf(cmd, sizeof(cmd), "/nft delete table %s p33probe",
				 fams[i].n);
			sh(cmd);
		}
	}
}

static int f556_env_setup(void)
{
	int rc = 0;

	if (link_add_veth("i0", "i1"))
		rc |= 1;
	if (link_add_veth("s0", "s1"))
		rc |= 2;
	if (link_add_veth("r0", "r1"))
		rc |= 4;
	set_up("i0"); set_up("i1");
	set_up("s0"); set_up("s1");
	set_up("r0"); set_up("r1");
	set_up("lo");
	if (f556_link_add_kind("br0", "bridge"))
		rc |= 8;
	set_up("br0");
	if (f556_link_enslave("s1", "br0") || f556_link_enslave("r1", "br0"))
		rc |= 16;
	printf("F556 SETUP|rc=%d|i1=%d|s1=%d|r1=%d|br0=%d\n", rc,
	       f555_ifindex("i1"), f555_ifindex("s1"), f555_ifindex("r1"),
	       f555_ifindex("br0"));
	return rc;
}

/* ---------- the nine envelopes ---------- */

static void f556_sec(const char *only)
{
	struct f556_env e;

	/* ---- 1. family ip, base nh: nft_nh_write_ok_ip4() ---- */
	if (!only || !strcmp(only, "ip4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "ip4"; e.fam = NFPROTO_IPV4; e.table = "p33f";
		e.chain = "pre"; e.hook = 0;	/* NF_INET_PRE_ROUTING */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 2. family ip6, base nh: nft_nh_write_ok_ip6() ---- */
	if (!only || !strcmp(only, "ip6")) {
		memset(&e, 0, sizeof(e));
		e.tag = "ip6"; e.fam = NFPROTO_IPV6; e.table = "p33g";
		e.chain = "pre"; e.hook = 0;
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0"; e.kind = FK33_IP6;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 3. family netdev, ingress: NFPROTO_NETDEV + ingress -> true ---- */
	if (!only || !strcmp(only, "nd")) {
		memset(&e, 0, sizeof(e));
		e.tag = "nd"; e.fam = NFPROTO_NETDEV; e.table = "p33n";
		e.chain = "ing"; e.hook = 0;	/* NF_NETDEV_INGRESS */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0";
		e.rule_dev = "i1"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 3b. family netdev, EGRESS: nft_nh_write_ok_netdev() ----
	 * F31 called this branch dead code because "netdev has only the
	 * ingress hook".  uapi/linux/netfilter.h has NF_NETDEV_INGRESS then
	 * NF_NETDEV_EGRESS, and nft_chain_filter_netdev's hook_mask has BOTH,
	 * so the branch is reachable -- and at egress the guard is the
	 * switch on skb->protocol, not the constant.  Two labels, two
	 * shapes, same chain. */
	if (!only || !strcmp(only, "eg4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "eg4"; e.fam = NFPROTO_NETDEV; e.table = "p33q";
		e.chain = "egr"; e.hook = 1;	/* NF_NETDEV_EGRESS */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0";
		e.rule_dev = "i0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	if (!only || !strcmp(only, "egA")) {
		memset(&e, 0, sizeof(e));
		e.tag = "egA"; e.fam = NFPROTO_NETDEV; e.table = "p33r";
		e.chain = "egr"; e.hook = 1;
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0";
		e.rule_dev = "i0"; e.kind = FK33_ARP;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 4. family bridge, ethertype 0x0800 ---- */
	if (!only || !strcmp(only, "br4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "br4"; e.fam = NFPROTO_BRIDGE; e.table = "p33b";
		e.chain = "pre"; e.hook = 0;	/* NF_BR_PRE_ROUTING */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "s0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 5. family bridge, ethertype 0x0806 ---- */
	if (!only || !strcmp(only, "brA")) {
		memset(&e, 0, sizeof(e));
		e.tag = "brA"; e.fam = NFPROTO_BRIDGE; e.table = "p33c";
		e.chain = "pre"; e.hook = 0;
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "s0"; e.kind = FK33_ARP;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 6. family arp, hook input: nft_nh_write_ok_arp() ---- */
	if (!only || !strcmp(only, "arp")) {
		memset(&e, 0, sizeof(e));
		e.tag = "arp"; e.fam = NFPROTO_ARP; e.table = "p33a";
		e.chain = "in"; e.hook = 0;	/* NF_ARP_IN */
		e.base = NFT_PAYLOAD_NETWORK_HEADER; e.dev = "i0"; e.kind = FK33_ARP;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	/* ---- 7..9. base ll in three envelopes: nft_ll_write_ok() ---- */
	if (!only || !strcmp(only, "ll4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "ll4"; e.fam = NFPROTO_IPV4; e.table = "p33h";
		e.chain = "pre"; e.hook = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	if (!only || !strcmp(only, "llN")) {
		memset(&e, 0, sizeof(e));
		e.tag = "llN"; e.fam = NFPROTO_NETDEV; e.table = "p33i";
		e.chain = "ing"; e.hook = 0;	/* NF_NETDEV_INGRESS */
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.rule_dev = "i1";
		e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	if (!only || !strcmp(only, "llE")) {
		memset(&e, 0, sizeof(e));
		e.tag = "llE"; e.fam = NFPROTO_NETDEV; e.table = "p33s";
		e.chain = "egr"; e.hook = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.rule_dev = "i0";
		e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
	if (!only || !strcmp(only, "llB")) {
		memset(&e, 0, sizeof(e));
		e.tag = "llB"; e.fam = NFPROTO_BRIDGE; e.table = "p33j";
		e.chain = "pre"; e.hook = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0"; e.kind = FK33_IP4;
		if (!f556_chain(&e))
			f556_env_run(&e);
	}
}

/* ---------- E arms: does the branch read the PACKET, or the VALUE? ---------- */

static void f556_sec_e(void)
{
	struct f556_env e;
	unsigned char imm[16];

	/* ip4, offset 0, len 2: the guard compares the WRITTEN first byte with
	 * the one in the packet (nft_nh_write_ok_ip4 case 0, skb_copy_bits).
	 * Same rule, two valid datagrams: ihl 5 (0x45) and ihl 6 (0x46). */
	f556_imm(FK33_IP4, 0, 2, imm);
	imm[0] = 0x45;
	memset(&e, 0, sizeof(e));
	e.tag = "e4"; e.fam = NFPROTO_IPV4; e.table = "p33k";
	e.chain = "pre"; e.hook = 0; e.base = NFT_PAYLOAD_NETWORK_HEADER;
	e.dev = "i0"; e.kind = FK33_IP4;
	if (f556_chain(&e)) {
		printf("F556 E|SKIP=e4-chain\n");
		return;
	}
	f556_arm(&e, "ip4_0_2_ihl5", 0, 2, imm, 2, FK33_IP4);
	f556_arm(&e, "ip4_0_2_ihl6", 0, 2, imm, 2, FK33_IP4_IHL6);
	/* ip4, offset 8, len 2: the guard compares the written SECOND byte with
	 * the protocol byte of the packet.  imm[1] = 0x11, so a proto-17 frame
	 * passes and a proto-6 frame does not -- same rule, other frame. */
	f556_imm(FK33_IP4, 8, 2, imm);
	f556_arm(&e, "ip4_8_2_p17", 8, 2, imm, 2, FK33_IP4);
	f556_arm(&e, "ip4_8_2_p6", 8, 2, imm, 2, FK33_IP4_P6);
	sh("/nft flush ruleset");

	/* ip6, offset 0: nft_nh_write_ok_ip6 case 0 tests ih->version of the
	 * WRITTEN data, not of the packet.  So the VALUE must decide and the
	 * FRAME must not: 0x60 alive on both frames, 0x40 dead on both. */
	memset(&e, 0, sizeof(e));
	e.tag = "e6"; e.fam = NFPROTO_IPV6; e.table = "p33l";
	e.chain = "pre"; e.hook = 0; e.base = NFT_PAYLOAD_NETWORK_HEADER;
	e.dev = "i0"; e.kind = FK33_IP6;
	if (f556_chain(&e)) {
		printf("F556 E|SKIP=e6-chain\n");
		return;
	}
	memset(imm, 0, sizeof(imm));
	imm[0] = 0x60; imm[1] = 0x11; imm[2] = 0x22; imm[3] = 0x33;
	f556_arm(&e, "ip6_0_4_v6_a", 0, 4, imm, 4, FK33_IP6);
	f556_arm(&e, "ip6_0_4_v6_b", 0, 4, imm, 4, FK33_IP6_B);
	imm[0] = 0x40;
	f556_arm(&e, "ip6_0_4_v4_a", 0, 4, imm, 4, FK33_IP6);
	f556_arm(&e, "ip6_0_4_v4_b", 0, 4, imm, 4, FK33_IP6_B);
	sh("/nft flush ruleset");

	/* the envelope decides before the guard: an ARP-family chain never sees
	 * an IPv4 frame at all (arp_rcv is not on that path). */
	memset(&e, 0, sizeof(e));
	e.tag = "ea"; e.fam = NFPROTO_ARP; e.table = "p33m";
	e.chain = "in"; e.hook = 0; e.base = NFT_PAYLOAD_NETWORK_HEADER;
	e.dev = "i0"; e.kind = FK33_ARP;
	if (f556_chain(&e)) {
		printf("F556 E|SKIP=ea-chain\n");
		return;
	}
	f556_imm(FK33_ARP, 8, 2, imm);
	f556_arm(&e, "arp_fam_arpframe", 8, 2, imm, 2, FK33_ARP);
	f556_arm(&e, "arp_fam_ipv4frame", 8, 2, imm, 2, FK33_IP4);
	sh("/nft flush ruleset");

	/* the switch, measured by the same cell under two labels: (6,2) is in
	 * the ARP predicate and in none of the IPv4 case labels. */
	memset(&e, 0, sizeof(e));
	e.tag = "eb"; e.fam = NFPROTO_BRIDGE; e.table = "p33o";
	e.chain = "pre"; e.hook = 0; e.base = NFT_PAYLOAD_NETWORK_HEADER;
	e.dev = "s0"; e.kind = FK33_IP4;
	if (f556_chain(&e)) {
		printf("F556 E|SKIP=eb-chain\n");
		return;
	}
	f556_imm(FK33_IP4, 6, 2, imm);
	f556_arm(&e, "br_6_2_ip", 6, 2, imm, 2, FK33_IP4);
	f556_arm(&e, "br_6_2_arp", 6, 2, imm, 2, FK33_ARP);
	f556_arm(&e, "br_6_4_arp", 6, 4, imm, 4, FK33_ARP);
	sh("/nft flush ruleset");
}

/* ---------- diagnostic: why does the ingress chain not count ---------- */

static void f556_diag_nd(void)
{
	unsigned char fr[256];
	unsigned long long cnt;
	int flen, rc;

	flen = f556_frame(FK33_IP4, fr);
	sh("/nft flush ruleset");

	/* D1: ingress (NF_NETDEV_INGRESS = 0) on i1, frame sent from i0 */
	printf("F556 DN|table_i|%d\n", add_table(NFPROTO_NETDEV, "p33di"));
	rc = f556_add_chain(NFPROTO_NETDEV, "p33di", "ing", 0, 0, 1, "i1");
	printf("F556 DN|chain_ingress|%d\n", rc);
	nft("dn.list_ing", "/nft list chain netdev p33di ing");
	printf("F556 DN|ctl_ing|%d\n",
	       install_ctl(NFPROTO_NETDEV, "p33di", "ing", 5, "dn.ing"));
	nfl_drain(NFL33);
	usleep(20000);
	pkt_send_p("i0", fr, flen, 0x0800);
	cnt = f555_count(NFPROTO_NETDEV, "p33di", "ing");
	printf("F556 DN|ctl_ingress_cnt|%llu\n", cnt);

	/* D2: egress (NF_NETDEV_EGRESS = 1) on i0, frame sent from i0 */
	sh("/nft flush ruleset");
	printf("F556 DN|table_e|%d\n", add_table(NFPROTO_NETDEV, "p33de"));
	rc = f556_add_chain(NFPROTO_NETDEV, "p33de", "egr", 1, 0, 1, "i0");
	printf("F556 DN|chain_egress|%d\n", rc);
	nft("dn.list_egr", "/nft list chain netdev p33de egr");
	printf("F556 DN|ctl_egr|%d\n",
	       install_ctl(NFPROTO_NETDEV, "p33de", "egr", 5, "dn.egr"));
	nfl_drain(NFL33);
	usleep(20000);
	pkt_send_p("i0", fr, flen, 0x0800);
	cnt = f555_count(NFPROTO_NETDEV, "p33de", "egr");
	printf("F556 DN|ctl_egress_cnt|%llu\n", cnt);

	/* D3: the same egress chain written by nft itself, for comparison */
	sh("/nft flush ruleset");
	nft("dn.table_nft", "/nft add table netdev p33df");
	nft("dn.chain_nft", "/nft add chain netdev p33df egr '{ type filter hook egress device i0 priority 0; }'");
	nft("dn.rule_nft", "/nft add rule netdev p33df egr 'counter accept'");
	usleep(20000);
	pkt_send_p("i0", fr, flen, 0x0800);
	nft("dn.after_egr", "/nft list chain netdev p33df egr");

	/* D4: and the ingress chain written by nft, as F31 did */
	sh("/nft flush ruleset");
	nft("dn.table_nft2", "/nft add table netdev p33dg");
	nft("dn.chain_nft2", "/nft add chain netdev p33dg ing '{ type filter hook ingress device i1 priority 0; }'");
	nft("dn.rule_nft2", "/nft add rule netdev p33dg ing 'counter accept'");
	usleep(20000);
	pkt_send_p("i0", fr, flen, 0x0800);
	nft("dn.after_ing", "/nft list chain netdev p33dg ing");
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int f556_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f556";
	const char *only = argc > 2 ? argv[2] : NULL;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F556 BEGIN|mode=%s|only=%s\n", mode, only ? only : "-");
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F556 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	if (!strcmp(mode, "f556bare")) {
		printf("F556 DONE\n");
		return 0;
	}
	if (!HAVE33_IP || !HAVE33_IP6 || !HAVE33_NETDEV || !HAVE33_BRIDGE ||
	    !HAVE33_ARP)
		printf("F556 WARN|missing_family|ip=%d|ip6=%d|nd=%d|br=%d|arp=%d\n",
		       HAVE33_IP, HAVE33_IP6, HAVE33_NETDEV, HAVE33_BRIDGE,
		       HAVE33_ARP);
	f556_env_setup();
	NFL33 = nfl_open(5);
	printf("F556 NFL|%d\n", NFL33);
	if (!strncmp(mode, "f556one:", 8)) {
		f556_sec(mode + 8);
		printf("F556 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f556nd")) {
		f556_diag_nd();
		printf("F556 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f556e")) {
		f556_sec("ip4");
		f556_sec_e();
		printf("F556 DONE\n");
		return 0;
	}
	f556_sec(only);
	if (!only)
		f556_sec_e();
	printf("F556 DONE\n");
	return 0;
}
/* differ557_add.c -- turn 557 / F35: is the ll boundary a property of the
 * WRITE or of the ENVELOPE?
 *
 * F33 measured the shape of nft_ll_write_ok() on ethernet frames and found a
 * boundary at 14 -- exactly the ethernet header length.  The guard is
 *
 *	static bool nft_ll_write_ok(pkt, int offset)
 *	{
 *		if (nft_in_ingress(pkt->state)) return true;
 *		return offset <= skb_network_offset(pkt->skb);
 *	}
 *
 * called as `nft_ll_write_ok(pkt, priv->len + priv->offset + offset)` where
 * `offset = skb_mac_header(skb) - skb->data - vlan_hlen`, and in 7.3
 * `skb_network_offset()` is `skb_network_header() - skb->data` (NOT relative
 * to the mac header -- that changed long ago and the guard's arithmetic
 * depends on it).  Substituting, the condition is
 *
 *	priv->offset + priv->len  <=  skb_network_header - skb_mac_header + vlan_hlen
 *
 * i.e. "the write ends at or before the network header", where the right
 * side is the length of the LINK HEADER OF THIS ENVELOPE, plus vlan_hlen.
 * On ethernet that is 14.  This differ asks what it is when the envelope is
 *
 *   VLAN    an 802.1Q frame whose tag the receive path pulled into skb
 *           metadata (skb_vlan_tag_present): vlan_hlen = 4 for stores at
 *           offset >= 16, and mac_header was advanced by 4 by
 *           skb_reorder_vlan_header().  The two do NOT cancel: the right
 *           side becomes 18 (prediction).
 *
 *   ipip    an L3 tunnel: ipip_tunnel_rcv() calls skb_reset_mac_header()
 *           right after iptunnel_pull_header(), so mac_header == data and
 *           the right side is 0 (prediction): EVERY ll store dies.
 *
 *   vxlan   an L2 tunnel: vxlan_set_mac() calls skb_reset_mac_header() and
 *           then eth_type_trans(), so the inner packet looks exactly like a
 *           received ethernet frame and the right side is 14 again
 *           (prediction).
 *
 * Sections
 *   A  the 40-cell grid of F33 on plain and VLAN frames, in the ip family
 *      (prerouting) and the bridge family (prerouting).  p4s is the SAME
 *      grid through the OLD (2 s ACK window) helper, as a calibration of the
 *      fast helper used everywhere else in this file.
 *   B  the verdict: chain policy drop, `@ll,... counter accept`.  On an
 *      untagged frame cell (12,1) is alive and (16,2) is dead; on a tagged
 *      frame the same two cells must swap (prediction).
 *   C  the tunnels: the same grid on the packet that comes OUT of an ipip
 *      device and out of a vxlan device, with the rule gated on `meta iif`
 *      so the OUTER packet is not counted.  The control arm (no store) is
 *      the proof that the inner packet really reaches the chain.
 *
 * Oracle per arm: the kernel's own counter, placed AFTER the store in the
 * same rule (cnt=1: the guard passed and the rest of the rule ran, cnt=0: the
 * store was refused and log/counter/verdict never ran).  NFLOG carries the
 * frame as it looks at the log point, so every alive cell also gets its bytes
 * against the control arm.
 */

#include <linux/if_tunnel.h>

/* ---------- fast nfnetlink: same batch, a 250 ms ACK window ----------
 *
 * nl_open() in differ555.c sets SO_RCVTIMEO to 2 s and batch_send() drains
 * ACKs until recv() times out, so every single-message transaction costs the
 * full 2 s (the F33 arm timings show ms=2009,2048,...).  This differ needs
 * ~200 arms per boot, so the wait is shortened to 250 ms and the number of
 * ACKs is PRINTED in every arm, which is what makes the speed-up auditable:
 * a transaction that was not acknowledged shows up as acks=0.
 */
static int f557_nl_open(int tmo_ms)
{
	struct sockaddr_nl sa;
	struct timeval tv;
	int fd;

	tv.tv_sec = tmo_ms / 1000;
	tv.tv_usec = (tmo_ms % 1000) * 1000;
	fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_NETFILTER);
	if (fd < 0)
		return -1;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	if (bind(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
		close(fd);
		return -2;
	}
	setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return fd;
}

static int f557_batch(char *buf, int len, int *acks)
{
	char rbuf[8192];
	int fd, err = 0, n = 0;

	*acks = 0;
	fd = f557_nl_open(250);
	if (fd < 0)
		return -1;
	if (send(fd, buf, (size_t)len, 0) != len) {
		close(fd);
		return -2;
	}
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl);
		     h = NLMSG_NEXT(h, rl)) {
			if (h->nlmsg_type != NLMSG_ERROR)
				continue;
			{
				struct nlmsgerr *e = (struct nlmsgerr *)NLMSG_DATA(h);

				n++;
				if (e->error && !err)
					err = e->error;
			}
		}
	}
	close(fd);
	*acks = n;
	return err;
}

static int f557_nft_one(char *msgbuf, int msglen, int *acks)
{
	char batch[8192];
	struct nlmsghdr *bn, *en;
	int off;

	bn = msg_start(batch, (int)sizeof(batch), NFNL_MSG_BATCH_BEGIN,
		       NLM_F_REQUEST, 0);
	((struct nfgenmsg *)NLMSG_DATA(bn))->res_id = htons(NFNL_SUBSYS_NFTABLES);
	off = (int)NLMSG_ALIGN(bn->nlmsg_len);
	memcpy(batch + off, msgbuf, (size_t)NLMSG_ALIGN(msglen));
	off += (int)NLMSG_ALIGN(msglen);
	en = msg_start(batch + off, (int)(sizeof(batch) - off),
		       NFNL_MSG_BATCH_END, NLM_F_REQUEST, 0);
	((struct nfgenmsg *)NLMSG_DATA(en))->res_id = htons(NFNL_SUBSYS_NFTABLES);
	off += (int)NLMSG_ALIGN(en->nlmsg_len);
	return f557_batch(batch, off, acks);
}

static int f557_flush(uint8_t fam, const char *table, const char *chain,
		      int *acks)
{
	struct nlmsghdr *nlh;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_DELRULE,
			NLM_F_REQUEST | NLM_F_ACK, fam);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, acks);
}

/* one rule: [meta iif == iif ][store <base>+off = imm][log][counter][accept]
 * iif == 0 means: no match, the rule sees every packet that reaches the
 * chain (this is how every non-tunnel arm runs). */
static int f557_install(uint8_t fam, const char *table, const char *chain,
			uint32_t iif, uint32_t base, uint32_t off, uint32_t len,
			const unsigned char *imm, int immlen, int do_store,
			int loggroup, const char *prefix, int *acks)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *e, *d, *cd;
	/* nft_meta_store_ifindex() writes the index with *dest = ifindex,
	 * i.e. NATIVE order -- comparing against htonl() never matches
	 * (measured: every gated arm was 0, including a gate on the device
	 * the frame demonstrably arrives on). */
	uint32_t iif_be = iif;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			fam);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (iif) {
		e = nest_start(nlh, NFTA_LIST_ELEM);
		put_str(nlh, NFTA_EXPR_NAME, "meta");
		d = nest_start(nlh, NFTA_EXPR_DATA);
		put_be32(nlh, NFTA_META_KEY, NFT_META_IIF);
		put_be32(nlh, NFTA_META_DREG, NFT_REG32_00);
		nest_end(nlh, d);
		nest_end(nlh, e);

		e = nest_start(nlh, NFTA_LIST_ELEM);
		put_str(nlh, NFTA_EXPR_NAME, "cmp");
		d = nest_start(nlh, NFTA_EXPR_DATA);
		put_be32(nlh, NFTA_CMP_SREG, NFT_REG32_00);
		put_be32(nlh, NFTA_CMP_OP, NFT_CMP_EQ);
		cd = nest_start(nlh, NFTA_CMP_DATA);
		attr_put(nlh, NFTA_DATA_VALUE, &iif_be, 4);
		nest_end(nlh, cd);
		nest_end(nlh, d);
		nest_end(nlh, e);
	}
	if (do_store) {
		imm_value(nlh, NFT_REG32_00, imm, immlen);
		e = nest_start(nlh, NFTA_LIST_ELEM);
		put_str(nlh, NFTA_EXPR_NAME, "payload");
		d = nest_start(nlh, NFTA_EXPR_DATA);
		put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00);
		put_be32(nlh, NFTA_PAYLOAD_BASE, base);
		put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
		put_be32(nlh, NFTA_PAYLOAD_LEN, len);
		put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
		put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
		nest_end(nlh, d);
		nest_end(nlh, e);
	}
	log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, acks);
}

/* ---------- frames ---------- */

enum { F557_PLAIN = 0, F557_VLAN, F557_IPIP, F557_VXLAN };

/* the plain ethernet + IPv4 + UDP frame, unchanged from F33 */
static int f557_mk_plain(unsigned char *out)
{
	return f556_frame(FK33_IP4, out);
}

/* the SAME datagram inside an 802.1Q frame: dst, src, 0x8100, TCI 0x0064,
 * inner ethertype 0x0800, then the identical IPv4 header and payload.  The
 * receive path will pull the 4 tag bytes into skb metadata, which is the
 * envelope this arm is about. */
static int f557_mk_vlan(unsigned char *out)
{
	unsigned char tmp[256];
	int n = f556_frame(FK33_IP4, tmp);

	memset(out, 0, 256);
	memcpy(out, M33_BC, 6);		/* dst */
	memcpy(out + 6, MAC_SRC, 6);		/* src */
	out[12] = 0x81; out[13] = 0x00;		/* 802.1Q */
	out[14] = 0x00; out[15] = 0x64;		/* TCI: prio 0, vlan 100 */
	out[16] = 0x08; out[17] = 0x00;		/* inner ethertype */
	memcpy(out + 18, tmp + 14, (size_t)(n - 14));
	return n + 4;
}

/* ethernet + IPv4(proto 4) + IPv4(proto 17) + UDP, outer dst = the guest's
 * own address on i1, so the frame is delivered locally and ipip_tunnel_rcv()
 * decapsulates it into the ipip device. */
static int f557_mk_ipip(unsigned char *out)
{
	unsigned char *oip = out + 14;
	unsigned char *iip = oip + 20;
	unsigned char *u = iip + 20;
	int tot = 20 + 20 + 8 + 18;
	unsigned short c;

	memset(out, 0, 512);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x08; out[13] = 0x00;
	oip[0] = 0x45;
	oip[2] = (unsigned char)(tot >> 8);
	oip[3] = (unsigned char)tot;
	oip[4] = 0x12; oip[5] = 0x35;
	oip[8] = 64; oip[9] = 4;
	oip[12] = 0x0a; oip[13] = 0x01; oip[14] = 0x00; oip[15] = 0x01;
	oip[16] = 0x0a; oip[17] = 0x09; oip[18] = 0x00; oip[19] = 0x07;
	c = f556_csum(oip, 20);
	oip[10] = (unsigned char)(c >> 8); oip[11] = (unsigned char)c;

	iip[0] = 0x45;
	iip[2] = 0; iip[3] = 20 + 8 + 18;
	iip[4] = 0x12; iip[5] = 0x36;
	iip[8] = 63; iip[9] = 17;
	iip[12] = 0x0a; iip[13] = 0x42; iip[14] = 0x01; iip[15] = 0x01;	/* 10.66.1.1 */
	iip[16] = 0x0a; iip[17] = 0x42; iip[18] = 0x01; iip[19] = 0x02;	/* 10.66.1.2 */
	c = f556_csum(iip, 20);
	iip[10] = (unsigned char)(c >> 8); iip[11] = (unsigned char)c;

	u[0] = 0x9c; u[1] = 0x41; u[2] = 0x13; u[3] = 0x89;
	u[4] = 0x00; u[5] = 26;
	memset(u + 8, 0x77, 18);
	return 14 + tot;
}

/* ethernet + IPv4(proto 17) + UDP:4789 + VXLAN(VNI 557) + ethernet +
 * IPv4(proto 17) + UDP.  The outer destination is the guest's address on i1,
 * the vxlan device is bound to it, and the inner frame is a completely
 * ordinary ethernet frame -- that is the L2 envelope. */
static int f557_mk_vxlan(unsigned char *out)
{
	unsigned char *oip = out + 14;
	unsigned char *u = oip + 20;
	unsigned char *vx = u + 8;
	unsigned char *ieh = vx + 8;
	unsigned char *iip = ieh + 14;
	unsigned char *iu = iip + 20;
	int udp_len = 8 + 8 + 14 + 20 + 8 + 18;
	int tot = 20 + udp_len;
	unsigned short c;

	memset(out, 0, 512);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x08; out[13] = 0x00;

	oip[0] = 0x45;
	oip[2] = (unsigned char)(tot >> 8);
	oip[3] = (unsigned char)tot;
	oip[4] = 0x12; oip[5] = 0x37;
	oip[8] = 64; oip[9] = 17;
	oip[12] = 0x0a; oip[13] = 0x01; oip[14] = 0x00; oip[15] = 0x01;
	oip[16] = 0x0a; oip[17] = 0x09; oip[18] = 0x00; oip[19] = 0x07;
	c = f556_csum(oip, 20);
	oip[10] = (unsigned char)(c >> 8); oip[11] = (unsigned char)c;

	u[0] = 0x9c; u[1] = 0x42;			/* sport 40002 */
	u[2] = 0x12; u[3] = 0xb5;			/* dport 4789 */
	u[4] = (unsigned char)(udp_len >> 8);
	u[5] = (unsigned char)udp_len;
	u[6] = 0; u[7] = 0;				/* checksum 0: legal v4 */

	vx[0] = 0x08;					/* VNI valid */
	vx[4] = 0x00; vx[5] = 0x02; vx[6] = 0x2d;	/* VNI 557 */
	vx[7] = 0x00;

	memcpy(ieh, M33_BC, 6);
	memcpy(ieh + 6, MAC_SRC, 6);
	ieh[12] = 0x08; ieh[13] = 0x00;

	iip[0] = 0x45;
	iip[2] = 0; iip[3] = 20 + 8 + 18;
	iip[4] = 0x12; iip[5] = 0x38;
	iip[8] = 63; iip[9] = 17;
	iip[12] = 0x0a; iip[13] = 0x42; iip[14] = 0x02; iip[15] = 0x01;	/* 10.66.2.1 */
	iip[16] = 0x0a; iip[17] = 0x42; iip[18] = 0x02; iip[19] = 0x02;	/* 10.66.2.2 */
	c = f556_csum(iip, 20);
	iip[10] = (unsigned char)(c >> 8); iip[11] = (unsigned char)c;

	iu[0] = 0x9c; iu[1] = 0x43; iu[2] = 0x13; iu[3] = 0x8a;
	iu[4] = 0x00; iu[5] = 26;
	memset(iu + 8, 0x77, 18);
	return 14 + tot;
}

static int f557_frame(int kind, unsigned char *out)
{
	switch (kind) {
	case F557_PLAIN:
		return f557_mk_plain(out);
	case F557_VLAN:
		return f557_mk_vlan(out);
	case F557_IPIP:
		return f557_mk_ipip(out);
	case F557_VXLAN:
		return f557_mk_vxlan(out);
	}
	return 0;
}

static unsigned short f557_proto(int kind)
{
	return kind == F557_VLAN ? 0x8100 : 0x0800;
}

/* ---------- one envelope ---------- */

struct f557_env {
	const char *tag;
	uint8_t fam;
	const char *table;
	const char *chain;
	uint32_t hook;
	uint32_t base;
	const char *dev;
	const char *rule_dev;
	uint32_t iif;
	int kind;
	int policy;		/* 1 = accept, 0 = drop */
	int send_raw;		/* 0 = ethernet frame, 4 = ipip outer,
				 * 17 = vxlan outer, both via a raw socket */
};

static int NFL57 = -1;
static char PRE57[96];
static int f557_raw_send(int proto, const unsigned char *payload, int plen);
static int f557_inner_only(unsigned char *out);
static int f557_vxlan_payload(unsigned char *out);

static void f557_imm(int off, int len, unsigned char *imm)
{
	int i;

	memset(imm, 0, 16);
	for (i = 0; i < len && i < 16; i++)
		imm[i] = (unsigned char)(0x90 + i);
}

static unsigned long long f557_ctl(const struct f557_env *e, const char *tag,
				   int fast)
{
	unsigned char fr[512], pay[192];
	unsigned long long cnt, cnt0;
	int flen, n = 0, rc, acks = -1, i;

	flen = f557_frame(e->kind, fr);
	snprintf(PRE57, sizeof(PRE57), "f57.%s.%s", e->tag, tag);
	if (fast) {
		f557_flush(e->fam, e->table, e->chain, &acks);
		rc = f557_install(e->fam, e->table, e->chain, e->iif, 0, 0, 0,
				  NULL, 0, 0, 5, PRE57, &acks);
	} else {
		flush_chain(e->fam, e->table, e->chain);
		rc = install_ctl(e->fam, e->table, e->chain, 5, PRE57);
	}
	nfl_drain(NFL57);
	cnt0 = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	if (rc == 0) {
		usleep(15000);
		if (e->send_raw) {
			unsigned char inner[512];
			int il = e->send_raw == 17 ? f557_vxlan_payload(inner)
						   : f557_inner_only(inner);

			f557_raw_send(e->send_raw, inner, il);
		} else {
			pkt_send_p(e->dev, fr, flen, f557_proto(e->kind));
		}
		n = nfl_wait(NFL57, PRE57, pay, (int)sizeof(pay), 300);
	}
	cnt = f555_count(e->fam, e->table, e->chain);
	printf("F557 CTL|env=%s|kind=%d|fast=%d|rc=%d|acks=%d|cnt=%llu|cnt0=%llu|nfl=%d|hex=",
	       e->tag, e->kind, fast, rc, acks, cnt, cnt0, n);
	for (i = 0; i < n && i < 96; i++)
		printf("%02x", pay[i]);
	printf("\n");
	return cnt;
}

static unsigned long long f557_arm(const struct f557_env *e, const char *tag,
				   int off, int len, const unsigned char *imm,
				   int immlen, int fast)
{
	unsigned char fr[512], pay[192];
	unsigned long long cnt, cnt0;
	int flen, n = 0, rc, acks = -1, i;
	long t0, t1;

	flen = f557_frame(e->kind, fr);
	snprintf(PRE57, sizeof(PRE57), "f57.%s.%s", e->tag, tag);
	t0 = f33_ms();
	if (fast) {
		f557_flush(e->fam, e->table, e->chain, &acks);
		rc = f557_install(e->fam, e->table, e->chain, e->iif, e->base,
				  (uint32_t)off, (uint32_t)len, imm, immlen, 1,
				  5, PRE57, &acks);
	} else {
		flush_chain(e->fam, e->table, e->chain);
		rc = f556_install_store(e->fam, e->table, e->chain, e->base, off,
					len, imm, immlen, 5, PRE57);
	}
	t1 = f33_ms();
	nfl_drain(NFL57);
	cnt0 = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	if (rc == 0) {
		usleep(15000);
		if (e->send_raw) {
			unsigned char inner[512];
			int il = e->send_raw == 17 ? f557_vxlan_payload(inner)
						   : f557_inner_only(inner);

			f557_raw_send(e->send_raw, inner, il);
		} else {
			pkt_send_p(e->dev, fr, flen, f557_proto(e->kind));
		}
		n = nfl_wait(NFL57, PRE57, pay, (int)sizeof(pay), 200);
	}
	cnt = f555_count(e->fam, e->table, e->chain);
	printf("F557 R|env=%s|arm=%s|off=%d|len=%d|kind=%d|fast=%d|rc=%d|acks=%d|"
	       "cnt=%llu|cnt0=%llu|nfl=%d|ms=%ld|hex=",
	       e->tag, tag, off, len, e->kind, fast, rc, acks, cnt, cnt0, n,
	       t1 - t0);
	for (i = 0; i < n && i < 96; i++)
		printf("%02x", pay[i]);
	printf("\n");
	return cnt;
}

/* create table + one chain */
static int f557_chain(const struct f557_env *e)
{
	int rc, rc2;

	rc = add_table(e->fam, e->table);
	rc2 = f556_add_chain(e->fam, e->table, e->chain, e->hook, 0,
			     (uint32_t)e->policy, e->rule_dev);
	printf("F557 CHAIN|env=%s|table=%d|chain=%d|policy=%d\n", e->tag, rc, rc2,
	       e->policy);
	return rc || rc2;
}

static const int G57_OFF[12] = { 0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24 };
static const int G57_LEN[3] = { 1, 2, 4 };
static const int T57_OFF[7] = { 0, 6, 10, 12, 14, 16, 20 };

static void f557_grid(const struct f557_env *e, const int *offs, int noff,
		      const int *lens, int nlen, int fast)
{
	unsigned char imm[16];
	char tag[32];
	int i, j;

	for (i = 0; i < noff; i++) {
		for (j = 0; j < nlen; j++) {
			f557_imm(offs[i], lens[j], imm);
			snprintf(tag, sizeof(tag), "g%d_%d", offs[i], lens[j]);
			f557_arm(e, tag, offs[i], lens[j], imm, lens[j], fast);
		}
	}
}


/* ---------- A: plain vs VLAN, in the ip family and in the bridge ---------- */

static void f557_sec_grid(const char *only)
{
	struct f557_env e;
	struct f556_env e33;
	unsigned char imm[16];
	char tag[32];
	int i, j;

	/* p4s: the F33 cell-for-cell reference, through the OLD helper
	 * (2 s ACK window), plain ethernet frame, ip family prerouting.
	 * Whatever the fast helper says in p4 has to match this. */
	if (!only || !strcmp(only, "p4s")) {
		memset(&e33, 0, sizeof(e33));
		e33.tag = "p4s"; e33.fam = NFPROTO_IPV4; e33.table = "p57s";
		e33.chain = "pre"; e33.hook = 0;
		e33.base = NFT_PAYLOAD_LL_HEADER; e33.dev = "i0";
		e33.kind = FK33_IP4;
		if (!f556_chain(&e33)) {
			f556_ctl(&e33, FK33_IP4);
			for (i = 0; i < 12; i++) {
				for (j = 0; j < 3; j++) {
					f556_imm(FK33_IP4, G57_OFF[i],
						 G57_LEN[j], imm);
					snprintf(tag, sizeof(tag), "g%d_%d",
						 G57_OFF[i], G57_LEN[j]);
					f556_arm(&e33, tag, G57_OFF[i],
						 G57_LEN[j], imm, G57_LEN[j],
						 FK33_IP4);
				}
			}
			sh("/nft flush ruleset");
		}
	}
	/* p4: the same grid, same envelope, FAST helper */
	if (!only || !strcmp(only, "p4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "p4"; e.fam = NFPROTO_IPV4; e.table = "p57a";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_PLAIN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			f557_grid(&e, G57_OFF, 12, G57_LEN, 3, 1);
		}
	}
	/* v4: 802.1Q frame, same family, same hook, same grid */
	if (!only || !strcmp(only, "v4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "v4"; e.fam = NFPROTO_IPV4; e.table = "p57b";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			f557_grid(&e, G57_OFF, 12, G57_LEN, 3, 1);
		}
	}
	/* pB: plain frame at the bridge prerouting hook -- NFLOG here logs
	 * the L2 frame, so this envelope carries the BYTE evidence */
	if (!only || !strcmp(only, "pB")) {
		memset(&e, 0, sizeof(e));
		e.tag = "pB"; e.fam = NFPROTO_BRIDGE; e.table = "p57c";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0";
		e.kind = F557_PLAIN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			f557_grid(&e, G57_OFF, 12, G57_LEN, 3, 1);
		}
	}
	/* vB: the same, tagged */
	if (!only || !strcmp(only, "vB")) {
		memset(&e, 0, sizeof(e));
		e.tag = "vB"; e.fam = NFPROTO_BRIDGE; e.table = "p57d";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			f557_grid(&e, G57_OFF, 12, G57_LEN, 3, 1);
		}
	}
}

/* ---------- B: the verdict, under policy drop ---------- */

/* Chain policy is DROP and the rule ends in accept, so the kernel's counter
 * answers two questions at once: did the guard pass the store (cnt=1), and
 * did the packet get accepted (cnt=1 for the same reason).  The control arm
 * has the same rule with no store and must be 1 on both frames -- otherwise
 * "cnt=0" would not distinguish "the store was refused" from "the frame never
 * reached this chain". */
static void f557_sec_verdict(const char *only)
{
	static const struct {
		const char *tag;
		int off, len;
		unsigned char v[2];
	} arms[] = {
		{ "b12_1", 12, 1, { 0x90, 0x00 } },
		{ "b14_2", 14, 2, { 0x00, 0x64 } },
		{ "b16_2", 16, 2, { 0x08, 0x06 } },
	};
	struct f557_env e;
	unsigned char imm[16];
	unsigned int k;

	if (!only || !strcmp(only, "verdict")) {
		/* plain frame */
		memset(&e, 0, sizeof(e));
		e.tag = "vp"; e.fam = NFPROTO_IPV4; e.table = "p57e";
		e.chain = "pre"; e.hook = 0; e.policy = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_PLAIN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			for (k = 0; k < 3; k++) {
				memset(imm, 0, sizeof(imm));
				memcpy(imm, arms[k].v, 2);
				f557_arm(&e, arms[k].tag, arms[k].off,
					 arms[k].len, imm, arms[k].len, 1);
			}
		}
		/* tagged frame, same three arms */
		memset(&e, 0, sizeof(e));
		e.tag = "vv"; e.fam = NFPROTO_IPV4; e.table = "p57f";
		e.chain = "pre"; e.hook = 0; e.policy = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			for (k = 0; k < 3; k++) {
				memset(imm, 0, sizeof(imm));
				memcpy(imm, arms[k].v, 2);
				f557_arm(&e, arms[k].tag, arms[k].off,
					 arms[k].len, imm, arms[k].len, 1);
			}
		}
		/* the same three arms in the BRIDGE family, where the tagged
		 * frame demonstrably arrives (T557 has no CONFIG_VLAN_8021Q,
		 * so the ip family never sees it: measured, see DIAG9) */
		memset(&e, 0, sizeof(e));
		e.tag = "bp"; e.fam = NFPROTO_BRIDGE; e.table = "p57g";
		e.chain = "pre"; e.hook = 0; e.policy = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0";
		e.kind = F557_PLAIN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			for (k = 0; k < 3; k++) {
				memset(imm, 0, sizeof(imm));
				memcpy(imm, arms[k].v, 2);
				f557_arm(&e, arms[k].tag, arms[k].off,
					 arms[k].len, imm, arms[k].len, 1);
			}
		}
		memset(&e, 0, sizeof(e));
		e.tag = "bv"; e.fam = NFPROTO_BRIDGE; e.table = "p57i";
		e.chain = "pre"; e.hook = 0; e.policy = 0;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			for (k = 0; k < 3; k++) {
				memset(imm, 0, sizeof(imm));
				memcpy(imm, arms[k].v, 2);
				f557_arm(&e, arms[k].tag, arms[k].off,
					 arms[k].len, imm, arms[k].len, 1);
			}
		}
		sh("/nft flush ruleset");
	}
}

/* ---------- C: the tunnels ---------- */

static int f557_link_add_vxlan(const char *name, uint32_t vni,
			       uint32_t local_be, uint16_t port, uint8_t learn)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[512];
	} req;
	struct nlattr *li, *data;
	uint32_t v = vni;		/* IFLA_VXLAN_ID is read with nla_get_u32() */
	uint16_t p = htons(port);
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, name, (int)strlen(name) + 1);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, "vxlan", 6);
	data = nest_start(&req.nlh, IFLA_INFO_DATA);
	attr_put(&req.nlh, IFLA_VXLAN_ID, &v, 4);
	if (local_be)
		attr_put(&req.nlh, IFLA_VXLAN_LOCAL, &local_be, 4);
	if (port)
		attr_put(&req.nlh, IFLA_VXLAN_PORT, &p, 2);
	attr_put(&req.nlh, IFLA_VXLAN_LEARNING, &learn, 1);
	nest_end(&req.nlh, data);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static void f557_sec_tunnel(const char *only)
{
	struct f557_env e;
	int rc, idx;

	if (only && strcmp(only, "tunnel"))
		return;
	/* the outer datagram is addressed to the guest's own i1, so it is
	 * delivered locally and the tunnel device decapsulates it */
	f555_addr_add("i1", htonl(0x0a090007), 24);
	f555_addr_add("i0", htonl(0x0a010001), 24);

	/* ---- ipip: an L3 tunnel ----
	 * Not created here: ipip_init_net() already made the fallback device
	 * tunl0 in this netns (it is in /proc/net/dev before any code of
	 * this differ runs), with all-zero params, i.e. exactly the wildcard
	 * tunnel a decapsulation needs.  Creating a second one with the same
	 * params returns -EEXIST from ip_tunnel_newlink() -- measured, see
	 * the f557diag arms. */
	rc = set_up("tunl0");
	f555_addr_add("tunl0", htonl(0x0a420102), 32);	/* 10.66.1.2 */
	idx = f555_ifindex("tunl0");
	printf("F557 TUN|ipip|link=%d|ifindex=%d\n", rc, idx);
	memset(&e, 0, sizeof(e));
	e.tag = "ipip"; e.fam = NFPROTO_IPV4; e.table = "p57t";
	e.chain = "pre"; e.hook = 0; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
	e.iif = (uint32_t)idx; e.kind = F557_IPIP; e.send_raw = 4;
	if (!f557_chain(&e)) {
		unsigned long long c = f557_ctl(&e, "ctl", 1);

		printf("F557 TUNCTL|ipip|cnt=%llu\n", c);
		if (c)
			f557_grid(&e, T57_OFF, 7, G57_LEN, 3, 1);
	}

	/* ---- vxlan: an L2 tunnel ---- */
	rc = f557_link_add_vxlan("v557", 557, htonl(0x0a090007), 4789, 1);
	set_up("v557");
	f555_addr_add("v557", htonl(0x0a420202), 24);	/* 10.66.2.2 */
	idx = f555_ifindex("v557");
	printf("F557 TUN|vxlan|link=%d|ifindex=%d\n", rc, idx);
	memset(&e, 0, sizeof(e));
	e.tag = "vxlan"; e.fam = NFPROTO_IPV4; e.table = "p57u";
	e.chain = "pre"; e.hook = 0; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
	e.iif = (uint32_t)idx; e.kind = F557_VXLAN; e.send_raw = 17;
	if (!f557_chain(&e)) {
		unsigned long long c = f557_ctl(&e, "ctl", 1);

		printf("F557 TUNCTL|vxlan|cnt=%llu\n", c);
		if (c)
			f557_grid(&e, T57_OFF, 7, G57_LEN, 3, 1);
	}
	sh("/nft flush ruleset");
}


/* ---------- D: why a tunnel device does not come up ---------- */

static void f557_devlist(void)
{
	int fd = open("/proc/net/dev", O_RDONLY);
	char buf[2048];
	int n;

	if (fd < 0) {
		printf("F557 DEV|open_failed|%d\n", errno);
		return;
	}
	n = (int)read(fd, buf, sizeof(buf) - 1);
	close(fd);
	if (n <= 0) {
		printf("F557 DEV|read_failed|%d\n", n);
		return;
	}
	buf[n] = 0;
	{
		char *l = buf;
		char *nl;

		while ((nl = strchr(l, '\n')) != NULL) {
			*nl = 0;
			if (strchr(l, ':'))
				printf("F557 DEV|%s\n", l);
			l = nl + 1;
		}
	}
}

static void f557_diag(const char *only)
{
	int rc;

	(void)only;
	rc = f556_link_add_kind("t557", "ipip");
	printf("F557 DIAG|ipip_bare|%d|ifindex=%d\n", rc, f555_ifindex("t557"));
	f555_addr_add("i1", htonl(0x0a090007), 24);
	printf("F557 DIAG|tunl0_ifindex|%d|up=%d\n",
	       f555_ifindex("tunl0"), set_up("tunl0"));
	rc = f556_link_add_kind("p557", "ipip");
	printf("F557 DIAG|ipip_second_name|%d|ifindex=%d\n", rc,
	       f555_ifindex("p557"));
	rc = f556_link_add_kind("g557", "gretap");
	printf("F557 DIAG|gretap_bare|%d|ifindex=%d\n", rc, f555_ifindex("g557"));
	rc = f557_link_add_vxlan("x557", 557, 0, 0, 1);
	printf("F557 DIAG|vxlan_id_only|%d|ifindex=%d\n", rc, f555_ifindex("x557"));
	rc = f557_link_add_vxlan("y557", 557, htonl(0x0a090007), 4789, 1);
	printf("F557 DIAG|vxlan_full|%d|ifindex=%d\n", rc, f555_ifindex("y557"));
	f557_devlist();
}


/* ---------- E: does the tunnel decapsulate at all? ----------
 *
 * A chain at ip prerouting with NO meta-iif gate sees the outer packet and,
 * if the tunnel device decapsulated it, the inner packet too: cnt=2 means
 * decapsulation happened, cnt=1 means only the outer packet arrived.  The
 * /proc/net/dev counters of the tunnel device say the same thing from the
 * other side.
 */
static void f557_devline(const char *name)
{
	int fd = open("/proc/net/dev", O_RDONLY);
	char buf[4096];
	int n;

	if (fd < 0)
		return;
	n = (int)read(fd, buf, sizeof(buf) - 1);
	close(fd);
	if (n <= 0)
		return;
	buf[n] = 0;
	{
		char *l = buf;

		while (l && *l) {
			char *nl = strchr(l, '\n');
			char *colon;

			if (nl)
				*nl = 0;
			colon = strchr(l, ':');
			if (colon && strstr(l, name) == l + (colon - l) -
			    (int)strlen(name)) {
				printf("F557 DEVLINE|%s|%s\n", name, colon + 1);
				break;
			}
			l = nl ? nl + 1 : NULL;
		}
	}
}

static void f557_diag2(void)
{
	struct f557_env e;
	unsigned char fr[512];
	unsigned long long cnt;
	int flen;

	f555_addr_add("i1", htonl(0x0a090007), 24);
	f555_addr_add("i0", htonl(0x0a010001), 24);
	set_up("tunl0");
	f555_addr_add("tunl0", htonl(0x0a420102), 32);

	/* --- ipip --- */
	memset(&e, 0, sizeof(e));
	e.tag = "d2ip"; e.fam = NFPROTO_IPV4; e.table = "p57x";
	e.chain = "pre"; e.hook = 0; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.iif = 0;
	e.kind = F557_IPIP;
	if (!f557_chain(&e)) {
		f557_ctl(&e, "ctl", 1);
		cnt = f557_ctl(&e, "ctl2", 1);
		printf("F557 DIAG2|ipip|no_iif_gate|cnt=%llu\n", cnt);
	}
	f557_devline("tunl0");

	/* --- vxlan: the device must exist BEFORE the arm that measures --- */
	{
		int rc = f557_link_add_vxlan("v557", 557, htonl(0x0a090007),
					     4789, 1);

		set_up("v557");
		f555_addr_add("v557", htonl(0x0a420202), 24);
		printf("F557 DIAG2|vxlan_create|%d|ifindex=%d\n", rc,
		       f555_ifindex("v557"));
	}
	memset(&e, 0, sizeof(e));
	e.tag = "d2vx"; e.fam = NFPROTO_IPV4; e.table = "p57y";
	e.chain = "pre"; e.hook = 0; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.iif = 0;
	e.kind = F557_VXLAN;
	if (!f557_chain(&e)) {
		f557_ctl(&e, "ctl", 1);
		cnt = f557_ctl(&e, "ctl2", 1);
		printf("F557 DIAG2|vxlan|no_iif_gate|cnt=%llu\n", cnt);
	}
	f557_devline("v557");

	(void)flen; (void)fr;
}


/* ---------- F: where does the tunnel packet go? ---------- */

static void f557_sysline(const char *path)
{
	int fd = open(path, O_RDONLY);
	char buf[128];
	int n;

	if (fd < 0) {
		printf("F557 SYS|%s|open_failed|%d\n", path, errno);
		return;
	}
	n = (int)read(fd, buf, sizeof(buf) - 1);
	close(fd);
	if (n <= 0) {
		printf("F557 SYS|%s|read_failed\n", path);
		return;
	}
	buf[n] = 0;
	if (buf[n - 1] == '\n')
		buf[n - 1] = 0;
	printf("F557 SYS|%s|%s\n", path, buf);
}

static int f557_link_add_ipip(const char *name, uint32_t local_be,
			      uint32_t remote_be)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[256];
	} req;
	struct nlattr *li, *data;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, name, (int)strlen(name) + 1);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, "ipip", 5);
	data = nest_start(&req.nlh, IFLA_INFO_DATA);
	attr_put(&req.nlh, IFLA_IPTUN_LOCAL, &local_be, 4);
	attr_put(&req.nlh, IFLA_IPTUN_REMOTE, &remote_be, 4);
	nest_end(&req.nlh, data);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

/* counters at three hooks of the ip family, one frame, then the numbers */
static char TBL57[32];

static unsigned long long f557_hookcount(uint32_t hook, const char *tag)
{
	struct f557_env e;
	unsigned long long c;

	memset(&e, 0, sizeof(e));
	e.tag = tag; e.fam = NFPROTO_IPV4;
	snprintf(TBL57, sizeof(TBL57), "p57h%d", hook);
	e.table = TBL57;
	e.chain = "c"; e.hook = hook; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.iif = 0;
	e.kind = F557_IPIP;
	if (f557_chain(&e))
		return 0;
	f555_count(e.fam, e.table, e.chain);
	c = f557_ctl(&e, "c1", 1);
	return c;
}

static void f557_diag3(void)
{
	int rc1, rc2, rc3;
	unsigned char fr[512];
	int flen;

	rc1 = f555_addr_add("i1", htonl(0x0a090007), 24);
	rc2 = f555_addr_add("i0", htonl(0x0a010001), 24);
	rc3 = set_up("tunl0");
	printf("F557 DIAG3|addr_i1=%d|addr_i0=%d|tunl0_up=%d|tunl0_ifindex=%d\n",
	       rc1, rc2, rc3, f555_ifindex("tunl0"));
	f555_addr_add("tunl0", htonl(0x0a420102), 32);
	f557_sysline("/sys/class/net/tunl0/flags");

	printf("F557 DIAG3|prerouting_cnt=%llu\n", f557_hookcount(0, "p0"));
	printf("F557 DIAG3|local_in_cnt=%llu\n", f557_hookcount(1, "p1"));
	printf("F557 DIAG3|forward_cnt=%llu\n", f557_hookcount(2, "p2"));

	/* an explicit tunnel with named endpoints, if the fallback is the
	 * problem: same frame, the same three probes */
	rc1 = f557_link_add_ipip("t557", htonl(0x0a090007), htonl(0x0a010001));
	set_up("t557");
	f555_addr_add("t557", htonl(0x0a420102), 32);
	printf("F557 DIAG3|explicit_tunnel|link=%d|ifindex=%d\n", rc1,
	       f555_ifindex("t557"));
	f557_sysline("/sys/class/net/t557/flags");

	f557_sysline("/sys/class/net/i0/flags");
	f557_sysline("/sys/class/net/tunl0/operstate");
	f557_sysline("/sys/class/net/tunl0/type");
	if (f555_ifindex("t557") >= 0) {
		char path[64];
		int idx = f555_ifindex("t557");

		snprintf(path, sizeof(path), "/sys/class/net/t557/uevent");
		f557_sysline(path);
		printf("F557 DIAG3|t557_index=%d\n", idx);
	}
	f557_devlist();
	flen = f557_frame(F557_IPIP, fr);
	printf("F557 DIAG3|frame_len=%d\n", flen);
}


/* ---------- G: routing, rp_filter, and a plain frame as a control ---------- */

static void f557_syswrite(const char *path, const char *val)
{
	int fd = open(path, O_WRONLY);
	int rc = -1;

	if (fd >= 0) {
		rc = (int)write(fd, val, strlen(val));
		close(fd);
	}
	printf("F557 SYSW|%s|%s|rc=%d\n", path, val, rc);
}

static unsigned long long f557_hookcnt_kind(uint32_t hook, const char *tag,
					    int kind)
{
	struct f557_env e;
	char tbl[32];

	memset(&e, 0, sizeof(e));
	snprintf(tbl, sizeof(tbl), "p57k%d_%d", hook, kind);
	e.tag = tag; e.fam = NFPROTO_IPV4; e.table = tbl;
	e.chain = "c"; e.hook = hook; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0"; e.iif = 0;
	e.kind = kind;
	if (f557_chain(&e))
		return 0;
	f555_count(e.fam, e.table, e.chain);
	return f557_ctl(&e, "c1", 1);
}

static void f557_diag4(void)
{
	f555_addr_add("i1", htonl(0x0a090007), 24);
	f555_addr_add("i0", htonl(0x0a010001), 24);
	set_up("tunl0");
	f555_addr_add("tunl0", htonl(0x0a420102), 32);

	f557_sysline("/proc/sys/net/ipv4/conf/all/rp_filter");
	f557_sysline("/proc/sys/net/ipv4/conf/default/rp_filter");
	f557_sysline("/proc/sys/net/ipv4/conf/i1/rp_filter");
	f557_sysline("/proc/sys/net/ipv4/ip_forward");
	f557_sysline("/proc/sys/net/ipv4/conf/all/accept_local");

	/* control: an ordinary UDP frame to the same destination address */
	printf("F557 DIAG4|plain_local_in=%llu\n",
	       f557_hookcnt_kind(1, "gpl", F557_PLAIN));
	printf("F557 DIAG4|plain_prerouting=%llu\n",
	       f557_hookcnt_kind(0, "gpp", F557_PLAIN));

	/* ipip frame, before and after rp_filter is forced off */
	printf("F557 DIAG4|ipip_local_in_before=%llu\n",
	       f557_hookcnt_kind(1, "gil0", F557_IPIP));
	f557_syswrite("/proc/sys/net/ipv4/conf/all/rp_filter", "0");
	f557_syswrite("/proc/sys/net/ipv4/conf/default/rp_filter", "0");
	f557_syswrite("/proc/sys/net/ipv4/conf/i1/rp_filter", "0");
	printf("F557 DIAG4|ipip_local_in_after=%llu\n",
	       f557_hookcnt_kind(1, "gil1", F557_IPIP));
	printf("F557 DIAG4|ipip_prerouting=%llu\n",
	       f557_hookcnt_kind(0, "gip", F557_IPIP));
	f557_devline("tunl0");
}


/* ---------- H: is the address really there? ---------- */

static void f557_procgrep(const char *path, const char *needle)
{
	int fd = open(path, O_RDONLY);
	char *buf;
	int n, total = 0;

	buf = (char *)malloc(1 << 16);
	if (!buf)
		return;
	if (fd < 0) {
		free(buf);
		printf("F557 PROC|%s|open_failed|%d\n", path, errno);
		return;
	}
	while (total < (1 << 16) - 1) {
		n = (int)read(fd, buf + total, (1 << 16) - 1 - total);
		if (n <= 0)
			break;
		total += n;
	}
	close(fd);
	buf[total] = 0;
	{
		char *l = buf;

		while (l && *l) {
			char *nl = strchr(l, '\n');

			if (nl)
				*nl = 0;
			if (strstr(l, needle))
				printf("F557 PROC|%s|%s\n", path, l);
			l = nl ? nl + 1 : NULL;
		}
	}
	free(buf);
}

static void f557_diag5(void)
{
	int rc1 = f555_addr_add("i1", htonl(0x0a090007), 24);
	int rc2 = f555_addr_add("i0", htonl(0x0a010001), 24);

	printf("F557 DIAG5|addr_rc|i1=%d|i0=%d\n", rc1, rc2);
	f557_procgrep("/proc/net/fib_trie", "10.9.0");
	f557_procgrep("/proc/net/fib_trie", "10.1.0");
	f557_procgrep("/proc/net/route", "i1");
	f557_procgrep("/proc/net/fib_trie", "LOCAL");
}


/* ---------- I: WHY does the frame not arrive locally? ---------- */

static void f557_snmp(const char *tag)
{
	int fd = open("/proc/net/snmp", O_RDONLY);
	char buf[8192];
	int n;

	if (fd < 0)
		return;
	n = (int)read(fd, buf, sizeof(buf) - 1);
	close(fd);
	if (n <= 0)
		return;
	buf[n] = 0;
	{
		char *l = buf;
		int seen = 0;

		while (l && *l && seen < 2) {
			char *nl = strchr(l, '\n');

			if (nl)
				*nl = 0;
			if (!strncmp(l, "Ip:", 3)) {
				printf("F557 SNMP|%s|%s\n", tag, l);
				seen++;
			}
			l = nl ? nl + 1 : NULL;
		}
	}
}

static void f557_diag6(void)
{
	struct f557_env e;
	unsigned char fr[512];
	unsigned long long cnt;

	f555_addr_add("i1", htonl(0x0a090007), 24);
	f555_addr_add("i0", htonl(0x0a010001), 24);
	set_up("tunl0");

	/* local_in chain on a plain frame */
	printf("F557 DIAG6|plain_local_in=%llu\n",
	       f557_hookcnt_kind(1, "h0", F557_PLAIN));

	/* what does the stack say about the plain frame? */
	memset(&e, 0, sizeof(e));
	e.tag = "h1"; e.fam = NFPROTO_IPV4; e.table = "p57m"; e.chain = "c";
	e.hook = 0; e.policy = 1; e.base = NFT_PAYLOAD_LL_HEADER;
	e.dev = "i0"; e.kind = F557_PLAIN;
	if (!f557_chain(&e)) {
		f557_snmp("before");
		f557_ctl(&e, "c1", 1);
		f557_snmp("after_plain");
	}

	/* and the ipip frame */
	memset(&e, 0, sizeof(e));
	e.tag = "h2"; e.fam = NFPROTO_IPV4; e.table = "p57n"; e.chain = "c";
	e.hook = 0; e.policy = 1; e.base = NFT_PAYLOAD_LL_HEADER;
	e.dev = "i0"; e.kind = F557_IPIP;
	if (!f557_chain(&e)) {
		f557_ctl(&e, "c1", 1);
		f557_snmp("after_ipip");
	}
	(void)fr; (void)cnt;
}


/* ---------- J: inject the outer datagram with a raw socket ----------
 *
 * The hand-built ethernet frame reaches ip prerouting and then disappears
 * without incrementing a single IP counter (measured: IpInReceives +1,
 * InDelivers/ForwDatagrams/InAddrErrors all +0), so the outer datagram is
 * never handed to the tunnel's protocol handler.  A UDP/IP datagram the
 * kernel itself addresses to 10.9.0.7 IS delivered locally (loopback path),
 * so the same outer header -- protocol 4, source 10.1.0.1, destination
 * 10.9.0.7 -- is sent here with IP_HDRINCL and the kernel's own routing.
 * The INNER packet, which is the envelope this turn measures, is built by
 * iptunnel_pull_header()/netif_rx() either way.
 */
static int f557_raw_send(int proto, const unsigned char *payload, int plen)
{
	unsigned char pkt[512];
	unsigned char *ip = pkt;
	struct sockaddr_in dst;
	int s, hl = 20, tot = hl + plen, one = 1;
	unsigned short c;

	memset(pkt, 0, sizeof(pkt));
	ip[0] = 0x45;
	ip[2] = (unsigned char)(tot >> 8);
	ip[3] = (unsigned char)tot;
	ip[4] = 0x12; ip[5] = 0x39;
	ip[8] = 64;
	ip[9] = (unsigned char)proto;
	ip[12] = 0x0a; ip[13] = 0x01; ip[14] = 0x00; ip[15] = 0x01;
	ip[16] = 0x0a; ip[17] = 0x09; ip[18] = 0x00; ip[19] = 0x07;
	c = f556_csum(ip, hl);
	ip[10] = (unsigned char)(c >> 8); ip[11] = (unsigned char)c;
	memcpy(ip + hl, payload, (size_t)plen);

	s = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
	if (s < 0)
		return -errno;
	setsockopt(s, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));
	memset(&dst, 0, sizeof(dst));
	dst.sin_family = AF_INET;
	dst.sin_addr.s_addr = htonl(0x0a090007);
	if (sendto(s, pkt, (size_t)tot, 0, (struct sockaddr *)&dst,
		   sizeof(dst)) != tot) {
		int e = errno;

		close(s);
		return -e;
	}
	close(s);
	return 0;
}

/* the inner datagram of the ipip probe: IPv4 + UDP + payload, no ethernet */
static int f557_inner_only(unsigned char *out)
{
	unsigned char *iip = out;
	unsigned char *u = out + 20;
	unsigned short c;

	memset(out, 0, 128);
	iip[0] = 0x45;
	iip[2] = 0;
	iip[3] = 20 + 8 + 18;
	iip[4] = 0x12; iip[5] = 0x36;
	iip[8] = 63; iip[9] = 17;
	iip[12] = 0x0a; iip[13] = 0x42; iip[14] = 0x01; iip[15] = 0x01;
	iip[16] = 0x0a; iip[17] = 0x42; iip[18] = 0x01; iip[19] = 0x02;
	c = f556_csum(iip, 20);
	iip[10] = (unsigned char)(c >> 8); iip[11] = (unsigned char)c;
	u[0] = 0x9c; u[1] = 0x41; u[2] = 0x13; u[3] = 0x89;
	u[4] = 0x00; u[5] = 26;
	memset(u + 8, 0x77, 18);
	return 20 + 8 + 18;
}

/* UDP + VXLAN + inner ethernet frame, i.e. everything after the outer IPv4
 * header -- the outer header is built by f557_raw_send(17, ...) */
static int f557_vxlan_payload(unsigned char *out)
{
	unsigned char full[512];
	int n = f557_mk_vxlan(full);

	memcpy(out, full + 14 + 20, (size_t)(n - 34));
	return n - 34;
}

static void f557_diag7(void)
{
	struct f557_env e;
	unsigned char inner[128];
	unsigned long long cnt;
	int rc, n;

	f555_addr_add("i1", htonl(0x0a090007), 24);
	f555_addr_add("i0", htonl(0x0a010001), 24);
	set_up("tunl0");
	f555_addr_add("tunl0", htonl(0x0a420102), 32);

	n = f557_inner_only(inner);
	rc = f557_raw_send(4, inner, n);
	printf("F557 DIAG7|raw_send|rc=%d|len=%d\n", rc, n);

	/* prerouting, no gate: outer (if routed) + inner (if decapsulated) */
	printf("F557 DIAG7|prerouting_cnt=%llu\n",
	       f557_hookcnt_kind(0, "j0", F557_IPIP));
	rc = f557_raw_send(4, inner, n);
	printf("F557 DIAG7|raw_send2|rc=%d\n", rc);
	{
		struct f557_env e2;
		char tbl[32];

		memset(&e2, 0, sizeof(e2));
		snprintf(tbl, sizeof(tbl), "p57jp");
		e2.tag = "j1"; e2.fam = NFPROTO_IPV4; e2.table = tbl;
		e2.chain = "c"; e2.hook = 0; e2.policy = 1;
		e2.base = NFT_PAYLOAD_LL_HEADER; e2.dev = "i0"; e2.iif = 0;
		e2.kind = F557_IPIP;
		if (!f557_chain(&e2)) {
			cnt = f557_ctl(&e2, "c1", 1);
			printf("F557 DIAG7|with_own_send_cnt=%llu\n", cnt);
		}
	}
	f557_devline("tunl0");
	(void)e;
}


/* ---------- K: does the meta-iif gate work, and does the inner packet
 * reach ip prerouting at all? ---------- */

static unsigned long long f557_gate_ctl(uint32_t iif, int send_raw,
					const char *tag)
{
	struct f557_env e;
	char tbl[40];

	memset(&e, 0, sizeof(e));
	snprintf(tbl, sizeof(tbl), "p57g_%u_%d", iif, send_raw);
	e.tag = tag; e.fam = NFPROTO_IPV4; e.table = tbl; e.chain = "c";
	e.hook = 0; e.policy = 1; e.base = NFT_PAYLOAD_LL_HEADER;
	e.dev = "i0"; e.iif = iif; e.kind = F557_IPIP; e.send_raw = send_raw;
	if (f557_chain(&e))
		return 0;
	f555_count(e.fam, e.table, e.chain);
	return f557_ctl(&e, "c1", 1);
}

static void f557_diag8(void)
{
	int lo, tl, i1;

	f555_addr_add("i1", htonl(0x0a090007), 24);
	f555_addr_add("i0", htonl(0x0a010001), 24);
	set_up("tunl0");
	f555_addr_add("tunl0", htonl(0x0a420102), 32);
	lo = f555_ifindex("lo");
	tl = f555_ifindex("tunl0");
	i1 = f555_ifindex("i1");
	printf("F557 DIAG8|idx|lo=%d|tunl0=%d|i1=%d\n", lo, tl, i1);

	printf("F557 DIAG8|raw_nogate=%llu\n", f557_gate_ctl(0, 1, "k0"));
	printf("F557 DIAG8|raw_iif_lo=%llu\n", f557_gate_ctl((uint32_t)lo, 1, "k1"));
	printf("F557 DIAG8|raw_iif_tunl0=%llu\n", f557_gate_ctl((uint32_t)tl, 1, "k2"));
	printf("F557 DIAG8|raw_iif_i1=%llu\n", f557_gate_ctl((uint32_t)i1, 1, "k3"));
	printf("F557 DIAG8|frame_iif_lo=%llu\n", f557_gate_ctl((uint32_t)lo, 0, "k4"));
	/* the gate itself, on a packet whose path is known: the hand-built
	 * frame arrives on i1, so a gate on i1 must count it and a gate on
	 * tunl0 must not */
	printf("F557 DIAG8|frame_iif_tunl0=%llu\n", f557_gate_ctl((uint32_t)tl, 0, "k5"));
	printf("F557 DIAG8|frame_iif_i1=%llu\n", f557_gate_ctl((uint32_t)i1, 0, "k6"));
	f557_devline("tunl0");
}


/* ---------- L: where does the 802.1Q frame go? ---------- */

static unsigned long long f557_env_ctl(uint8_t fam, uint32_t hook,
				       const char *rule_dev, int kind,
				       const char *tag)
{
	struct f557_env e;
	char tbl[40];

	memset(&e, 0, sizeof(e));
	snprintf(tbl, sizeof(tbl), "p57q_%u_%d", hook, kind);
	e.tag = tag; e.fam = fam; e.table = tbl; e.chain = "c";
	e.hook = hook; e.policy = 1; e.base = NFT_PAYLOAD_LL_HEADER;
	e.dev = "i0"; e.rule_dev = rule_dev; e.kind = kind;
	if (f557_chain(&e))
		return 0;
	f555_count(e.fam, e.table, e.chain);
	return f557_ctl(&e, "c1", 1);
}

static void f557_diag9(void)
{
	int i1 = f555_ifindex("i1");

	printf("F557 DIAG9|idx_i1=%d\n", i1);
	f557_snmp("before_vlan");
	printf("F557 DIAG9|ip_pre_plain=%llu\n",
	       f557_env_ctl(NFPROTO_IPV4, 0, NULL, F557_PLAIN, "l0"));
	f557_snmp("after_plain");
	printf("F557 DIAG9|ip_pre_vlan=%llu\n",
	       f557_env_ctl(NFPROTO_IPV4, 0, NULL, F557_VLAN, "l1"));
	f557_snmp("after_vlan");
	printf("F557 DIAG9|nd_ing_vlan=%llu\n",
	       f557_env_ctl(NFPROTO_NETDEV, 0, "i1", F557_VLAN, "l2"));
	f557_snmp("after_nd_vlan");
}


/* ---------- M: does the sender's sll_protocol decide it? ---------- */

static unsigned long long f557_ctl_proto(int kind, unsigned short proto,
					 const char *tag)
{
	struct f557_env e;
	unsigned char fr[512], pay[192];
	unsigned long long cnt, cnt0;
	char tbl[40];
	int flen, n = 0, rc, acks = -1;

	flen = f557_frame(kind, fr);
	memset(&e, 0, sizeof(e));
	snprintf(tbl, sizeof(tbl), "p57r_%04x_%d", proto, kind);
	e.tag = tag; e.fam = NFPROTO_IPV4; e.table = tbl; e.chain = "c";
	e.hook = 0; e.policy = 1; e.base = NFT_PAYLOAD_LL_HEADER;
	e.dev = "i0"; e.kind = kind;
	if (f557_chain(&e))
		return 0;
	snprintf(PRE57, sizeof(PRE57), "f57.%s.ctl", tag);
	f557_flush(e.fam, e.table, e.chain, &acks);
	rc = f557_install(e.fam, e.table, e.chain, 0, 0, 0, 0, NULL, 0, 0, 5,
			  PRE57, &acks);
	nfl_drain(NFL57);
	cnt0 = (rc == 0) ? f555_count(e.fam, e.table, e.chain) : 0;
	if (rc == 0) {
		usleep(15000);
		pkt_send_p(e.dev, fr, flen, proto);
		n = nfl_wait(NFL57, PRE57, pay, (int)sizeof(pay), 300);
	}
	cnt = f555_count(e.fam, e.table, e.chain);
	printf("F557 R|env=%s|arm=ctl|off=0|len=0|kind=%d|fast=1|rc=%d|acks=%d|"
	       "cnt=%llu|cnt0=%llu|nfl=%d|ms=0|hex=", tag, kind, rc, acks, cnt,
	       cnt0, n);
	printf("\n");
	return cnt;
}

static void f557_diag10(void)
{
	printf("F557 DIAG10|vlan_sll_8100=%llu\n",
	       f557_ctl_proto(F557_VLAN, 0x8100, "m0"));
	printf("F557 DIAG10|vlan_sll_all=%llu\n",
	       f557_ctl_proto(F557_VLAN, 0x0003, "m1"));
	printf("F557 DIAG10|vlan_sll_0800=%llu\n",
	       f557_ctl_proto(F557_VLAN, 0x0800, "m2"));
	printf("F557 DIAG10|plain_sll_all=%llu\n",
	       f557_ctl_proto(F557_PLAIN, 0x0003, "m3"));
}


/* ---------- N: is the AF_PACKET tap what kills the tagged frame? ---------- */

static void f557_diag11(void)
{
	printf("F557 DIAG11|vlan_ip_pre_with_taps=%llu\n",
	       f557_ctl_proto(F557_VLAN, 0x8100, "n0"));
	/* the differ keeps AF_PACKET taps open on i0/i1/o1 for the byte
	 * evidence of other envelopes; every frame those sockets see is a
	 * CLONE, i.e. skb_shared().  Close them and repeat the same arm. */
	if (CAP_I0 >= 0) { close(CAP_I0); CAP_I0 = -1; }
	if (CAP_I1 >= 0) { close(CAP_I1); CAP_I1 = -1; }
	if (CAP_O1 >= 0) { close(CAP_O1); CAP_O1 = -1; }
	printf("F557 DIAG11|vlan_ip_pre_without_taps=%llu\n",
	       f557_ctl_proto(F557_VLAN, 0x8100, "n1"));
	printf("F557 DIAG11|plain_ip_pre_without_taps=%llu\n",
	       f557_ctl_proto(F557_PLAIN, 0x0800, "n2"));
}


/* ---------- O: the BYTES the accepted store leaves on the wire ----------
 *
 * The counter says the guard passed the store; it does not say what the store
 * wrote.  NFLOG at the bridge hook logs from the network header (the hex of
 * every arm starts with 45 00), so the L2 frame is captured on the other
 * bridge port instead: the frame arrives on s1 and leaves towards r1.
 */
static int f557_cap_first(const char *dev, unsigned char *buf, int max, int ms)
{
	int s = cap_open(dev);
	int n = -1, waited = 0;

	if (s < 0)
		return -1;
	/* cap_open() sets O_NONBLOCK, and veth delivers through NAPI, so the
	 * frame is not in the socket buffer when sendto() returns: poll. */
	while (waited < ms) {
		n = (int)recv(s, buf, (size_t)max, 0);
		if (n > 0)
			break;
		usleep(5000);
		waited += 5;
	}
	close(s);
	return n;
}

static void f557_sec_bytes(const char *only)
{
	struct f557_env e;
	unsigned char fr[512], cap[256];
	unsigned char imm[16];
	int flen, n, i;

	if (only && strcmp(only, "bytes"))
		return;
	memset(&e, 0, sizeof(e));
	e.tag = "by"; e.fam = NFPROTO_BRIDGE; e.table = "p57z";
	e.chain = "pre"; e.hook = 0; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0"; e.kind = F557_VLAN;
	flen = f557_frame(e.kind, fr);
	if (f557_chain(&e))
		return;

	printf("F557 BYTES|idx|s0=%d|s1=%d|r0=%d|r1=%d|br0=%d\n",
	       f555_ifindex("s0"), f555_ifindex("s1"), f555_ifindex("r0"),
	       f555_ifindex("r1"), f555_ifindex("br0"));
	/* control A: a PLAIN frame through the same bridge, no store at all */
	{
		int acks = -1;
		unsigned char frp[256];
		int flp = f557_frame(F557_PLAIN, frp);

		f557_flush(e.fam, e.table, e.chain, &acks);
		f557_install(e.fam, e.table, e.chain, 0, 0, 0, 0, NULL, 0, 0, 5,
			     "f57.by.ctlp", &acks);
		usleep(15000);
		n = f557_cap_first("r0", cap, (int)sizeof(cap), 400);
		pkt_send_p(e.dev, frp, flp, 0x0800);
		n = f557_cap_first("r0", cap, (int)sizeof(cap), 400);
		printf("F557 BYTES|ctl_plain|n=%d|hex=", n);
		for (i = 0; i < n && i < 40; i++)
			printf("%02x", cap[i]);
		printf("\n");
	}
	/* control: no store */
	{
		int acks = -1;

		f557_flush(e.fam, e.table, e.chain, &acks);
		f557_install(e.fam, e.table, e.chain, 0, 0, 0, 0, NULL, 0, 0, 5,
			     "f57.by.ctl", &acks);
		usleep(15000);
		n = f557_cap_first("r0", cap, (int)sizeof(cap), 400);	/* drain */
		pkt_send_p(e.dev, fr, flen, 0x8100);
		n = f557_cap_first("r0", cap, (int)sizeof(cap), 400);
		printf("F557 BYTES|ctl|n=%d|hex=", n);
		for (i = 0; i < n && i < 40; i++)
			printf("%02x", cap[i]);
		printf("\n");
	}
	/* the accepted store: off 16 len 2 = the inner ethertype, value 0x0806 */
	{
		int acks = -1;

		memset(imm, 0, sizeof(imm));
		imm[0] = 0x08;
		imm[1] = 0x06;
		f557_flush(e.fam, e.table, e.chain, &acks);
		f557_install(e.fam, e.table, e.chain, 0, NFT_PAYLOAD_LL_HEADER,
			     16, 2, imm, 2, 1, 5, "f57.by.s16", &acks);
		usleep(15000);
		n = f557_cap_first("r0", cap, (int)sizeof(cap), 400);
		pkt_send_p(e.dev, fr, flen, 0x8100);
		n = f557_cap_first("r0", cap, (int)sizeof(cap), 400);
		printf("F557 BYTES|s16_2|n=%d|hex=", n);
		for (i = 0; i < n && i < 40; i++)
			printf("%02x", cap[i]);
		printf("\n");
	}
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int f557_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f557";
	const char *only = argc > 2 ? argv[2] : NULL;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F557 BEGIN|mode=%s|only=%s\n", mode, only ? only : "-");
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F557 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F557 KERNEL|%s\n", "7.3.4-T557");
	f556_env_setup();
	NFL57 = nfl_open(5);
	printf("F557 NFL|%d\n", NFL57);
	if (!strcmp(mode, "f557diag11")) {
		f557_diag11();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag10")) {
		f557_diag10();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag9")) {
		f557_diag9();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag8")) {
		f557_diag8();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag7")) {
		f557_diag7();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag6")) {
		f557_diag6();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag5")) {
		f557_diag5();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag4")) {
		f557_diag4();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag3")) {
		f557_diag3();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag2")) {
		f557_diag2();
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557diag")) {
		f557_diag(only);
		printf("F557 DONE\n");
		return 0;
	}
	if (!strcmp(mode, "f557grid")) {
		f557_sec_grid(NULL);
	} else if (!strcmp(mode, "f557verdict")) {
		f557_sec_verdict(NULL);
	} else if (!strcmp(mode, "f557tun")) {
		f557_sec_tunnel(NULL);
	} else if (!strcmp(mode, "f557bytes")) {
		f557_sec_bytes(NULL);
	} else if (!strncmp(mode, "f557one:", 8)) {
		f557_sec_grid(mode + 8);
	} else {
		f557_sec_grid(only);
		f557_sec_verdict(only);
		f557_sec_bytes(only);
		f557_sec_tunnel(only);
	}
	printf("F557 DONE\n");
	return 0;
}
/* differ558_add.c -- turn 558.
 *
 * Three debts that F35 left as readings, and one config line to pay for:
 *
 *  A. `why`  -- F35's far-side capture returned n=-1 on every arm but one, and
 *     the one frame it caught was an ICMPv6 report from the bridge.  The first
 *     smoke with this instrument found the reason and two instrument facts
 *     worth keeping: (1) matching on the payload instead of taking the first
 *     frame is enough to see our frame at r0 (PACKET_HOST) and at r1
 *     (PACKET_OUTGOING); (2) a veth pair advertises NETIF_F_HW_VLAN_CTAG_TX/RX
 *     (drivers/net/veth.c VETH_FEATURES), so validate_xmit_vlan() never puts
 *     the tag back into the frame: on a veth the 802.1Q tag travels as skb
 *     METADATA and the frame is 60 bytes on both taps.  "The bytes of the tag
 *     on the wire" therefore cannot be measured with AF_PACKET here at all --
 *     but the tag's EFFECT can, at the far side, because vid 0 is delivered to
 *     IPv4 and vid != 0 is marked PACKET_OTHERHOST and dropped.
 *
 *  B. `bytes` -- the store F35 could describe only from the source.  Four arms
 *     on one tagged frame through the bridge, each read twice (TX tap on r1,
 *     RX tap on r0) and once at the far side (IpInReceives):
 *       (16,2) = 0x0806  writes the frame buffer at data-2 = the ethertype
 *       (14,2) = 0x0099  assigns skb->vlan_tci raw: bit 0x1000 (PRESENT) is
 *                        gone, so the frame stops being tagged at all
 *       (14,2) = 0x1064  the same store keeping the PRESENT bit: vid 100
 *       (12,4) = 0x8100 0x0000  full tag through __vlan_hwaccel_put_tag()
 *
 *  C. `vlan` -- the ip family never sees a tagged frame on any image this
 *     project has booted, and F35 recorded that as a config line:
 *     `# CONFIG_VLAN_8021Q is not set`.  T558 is T557 + that symbol, so the
 *     same tagged frame can now arrive through a real vlan device.  Four
 *     envelopes in one boot: plain (p4), tagged without a vlan device (novd,
 *     measured on T557 and on T558), tagged through v1 (vd), and a
 *     priority-tagged frame with vid 0 (v0), which needs no device at all.
 *
 * Instrument note: /sys/class/net is NOT netns-aware here -- the guest mounts
 * sysfs as init and the reproducer unshares CLONE_NEWNET afterwards, so every
 * /sys/class/net/<dev> read is ENOENT while /proc/net/dev is correct.
 */

/* ---------- frames ---------- */

/* f557_mk_vlan() with the TCI as a parameter: vid 100 and vid 0 are then the
 * SAME frame with one 12-bit field different, which is the whole point of the
 * `v0` envelope. */
static int f558_mk_vlan_tci(unsigned char *out, unsigned short tci)
{
	unsigned char tmp[256];
	int n = f556_frame(FK33_IP4, tmp);

	memset(out, 0, 256);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x81; out[13] = 0x00;
	out[14] = (unsigned char)(tci >> 8);
	out[15] = (unsigned char)tci;
	out[16] = 0x08; out[17] = 0x00;
	memcpy(out + 18, tmp + 14, (size_t)(n - 14));
	return n + 4;
}

/* ---------- rtnetlink: a vlan device, and deletion ---------- */

static int f558_link_add_vlan(const char *name, const char *parent,
			      unsigned short vid)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[256];
	} req;
	struct nlattr *li, *data;
	uint32_t pidx = (uint32_t)f555_ifindex(parent);
	int fd, rc;

	if ((int)pidx < 0)
		return -10;
	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, name, (int)strlen(name) + 1);
	attr_put(&req.nlh, IFLA_LINK, &pidx, 4);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, "vlan", 5);
	data = nest_start(&req.nlh, IFLA_INFO_DATA);
	attr_put(&req.nlh, IFLA_VLAN_ID, &vid, 2);	/* u16, native order */
	nest_end(&req.nlh, data);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f558_link_del(const char *name)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[64];
	} req;
	int fd, rc, idx = f555_ifindex(name);

	if (idx < 0)
		return -10;
	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_DELLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	req.ifi.ifi_index = idx;
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

/* ---------- capture: match on the payload, not on being first ---------- */

/* F35's f557_cap_first() opened a fresh socket per arm and took whatever
 * arrived first; on every arm but one that was ICMPv6 noise from the bridge.
 * This one opens once, drains once, and looks for the 0x77 payload the
 * instrument's own datagram carries -- printing how many frames it skipped,
 * so "no frame" and "someone else's frame" cannot be confused. */
static int f558_cap_match(int s, unsigned char *buf, int max, int ms,
			  const unsigned char *needle, int nlen,
			  int *skipped, int *pkttype)
{
	struct timeval now0, now1;
	struct timeval tv;
	fd_set rfds;
	int r, i;

	*skipped = 0;
	*pkttype = -1;
	if (s < 0)
		return -1;
	gettimeofday(&now0, NULL);
	tv.tv_sec = 0;
	tv.tv_usec = ms * 1000;
	for (;;) {
		struct sockaddr_ll from;
		socklen_t fl = sizeof(from);

		FD_ZERO(&rfds);
		FD_SET(s, &rfds);
		if (select(s + 1, &rfds, NULL, NULL, &tv) <= 0)
			return -1;
		memset(&from, 0, sizeof(from));
		r = (int)recvfrom(s, buf, (size_t)max, 0,
				  (struct sockaddr *)&from, &fl);
		if (r <= 0)
			return -1;
		for (i = 0; i + nlen <= r; i++) {
			if (!memcmp(buf + i, needle, (size_t)nlen)) {
				*pkttype = (int)from.sll_pkttype;
				return r;
			}
		}
		(*skipped)++;
		gettimeofday(&now1, NULL);
		{
			long used = (now1.tv_sec - now0.tv_sec) * 1000 +
				    (now1.tv_usec - now0.tv_usec) / 1000;

			if (used >= ms)
				return -1;
			tv.tv_sec = 0;
			tv.tv_usec = (ms - used) * 1000;
		}
	}
}

static void f558_hex(const unsigned char *b, int n)
{
	int i;

	for (i = 0; i < n; i++)
		printf("%02x", b[i]);
}

/* diff of two frames, "index:ctl>got" */
static int f558_chg(char *out, size_t osz, const unsigned char *ctl, int clen,
		    const unsigned char *got, int glen)
{
	int i, n = 0;

	out[0] = 0;
	if (clen <= 0 || glen <= 0)
		return 0;
	for (i = 0; i < glen && i < clen; i++) {
		size_t at;

		if (got[i] == ctl[i])
			continue;
		n++;
		at = strlen(out);
		if (at < osz - 24)
			snprintf(out + at, osz - at, "%s%d:%02x>%02x",
				 n > 1 ? "," : "", i, ctl[i], got[i]);
	}
	if (glen != clen) {
		size_t at = strlen(out);

		if (at < osz - 24)
			snprintf(out + at, osz - at, "%slen:%d>%d",
				 n ? "," : "", clen, glen);
		n++;
	}
	return n;
}

/* IpInReceives of the whole netns.  This is the far side's own decision about
 * our frame: a tagged frame with vid != 0 is PACKET_OTHERHOST by the time
 * ip_rcv() runs and is dropped there, a tag with vid 0 (or no tag at all) is
 * received.  Nothing else in this guest speaks IPv4, so the delta is ours. */
static unsigned long long f558_ipin(void)
{
	FILE *f = fopen("/proc/net/snmp", "r");
	char line[1024];
	unsigned long long fw, ttl, in;

	if (!f)
		return 0;
	while (fgets(line, sizeof(line), f)) {
		if (strncmp(line, "Ip: ", 4))
			continue;
		if (strstr(line, "Forwarding"))
			continue;
		if (sscanf(line, "Ip: %llu %llu %llu", &fw, &ttl, &in) == 3) {
			fclose(f);
			return in;
		}
	}
	fclose(f);
	return 0;
}

/* one capture view: a socket, the control frame it saw, and its length */
struct f558_view {
	const char *tag;		/* "tx" or "rx" */
	int fd;
	unsigned char ctl[2048];
	int clen;
};

static void f558_view_report(const char *env, const char *arm,
			     struct f558_view *v, const unsigned char *cap,
			     int n, int skip, int pt)
{
	char chg[512];
	int k = 0;

	printf("F558 VIEW|env=%s|arm=%s|view=%s|n=%d|skip=%d|pt=%d|",
	       env, arm, v->tag, n, skip, pt);
	if (n > 0 && v->clen > 0) {
		k = f558_chg(chg, sizeof(chg), v->ctl, v->clen, cap, n);
		printf("nchg=%d|chg=%s|", k, chg[0] ? chg : "-");
	} else {
		printf("nchg=-|chg=-|");
	}
	printf("hex=");
	if (n > 0)
		f558_hex(cap, n > 96 ? 96 : n);
	printf("\n");
}

/* ---------- one arm: install, send, capture twice, count three ---------- */

/* off < 0 => control arm (no store at all).  Each view may be inactive. */
static unsigned long long f558_run(const struct f557_env *e, const char *tag,
				   int off, int len, const unsigned char *imm,
				   int immlen, const unsigned char *fr, int flen,
				   struct f558_view *tx, struct f558_view *rx)
{
	static const unsigned char magic[8] = { 0x77, 0x77, 0x77, 0x77,
						0x77, 0x77, 0x77, 0x77 };
	unsigned char cap[2048];
	unsigned char pay[192];
	unsigned long long cnt, cnt0, ip0, ip1;
	int rc, acks = -1, snd = 0, nfl = 0, i;

	snprintf(PRE57, sizeof(PRE57), "f57.%s.%s", e->tag, tag);
	f557_flush(e->fam, e->table, e->chain, &acks);
	if (off < 0)
		rc = f557_install(e->fam, e->table, e->chain, e->iif, 0, 0, 0,
				  NULL, 0, 0, 5, PRE57, &acks);
	else
		rc = f557_install(e->fam, e->table, e->chain, e->iif, e->base,
				  (uint32_t)off, (uint32_t)len, imm, immlen, 1,
				  5, PRE57, &acks);
	if (tx && tx->fd >= 0)
		cap_drain(tx->fd);
	if (rx && rx->fd >= 0)
		cap_drain(rx->fd);
	usleep(20000);
	nfl_drain(NFL57);
	cnt0 = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	ip0 = f558_ipin();
	if (rc == 0 && !e->send_raw) {
		usleep(15000);
		/* drain HERE, immediately before the send: the whole payload of
		 * every arm is identical, so a frame left over from the previous
		 * arm would be indistinguishable from this one and would be
		 * reported as this arm's bytes.  (A second base chain at the same
		 * hook, left over from an earlier section, is the other way the
		 * same mistake shows up: it rewrites every later frame.) */
		if (tx && tx->fd >= 0)
			cap_drain(tx->fd);
		if (rx && rx->fd >= 0)
			cap_drain(rx->fd);
		snd = pkt_send_p(e->dev, fr, flen, f557_proto(e->kind));
		if (tx && tx->fd >= 0) {
			int n, skip = 0, pt = -1;

			memset(cap, 0, sizeof(cap));
			n = f558_cap_match(tx->fd, cap, (int)sizeof(cap), 800,
					   magic, 8, &skip, &pt);
			f558_view_report(e->tag, tag, tx, cap, n, skip, pt);
			if (off < 0 && n > 0) {
				memcpy(tx->ctl, cap, (size_t)n);
				tx->clen = n;
			}
		}
		if (rx && rx->fd >= 0) {
			int n, skip = 0, pt = -1;

			memset(cap, 0, sizeof(cap));
			n = f558_cap_match(rx->fd, cap, (int)sizeof(cap), 500,
					   magic, 8, &skip, &pt);
			f558_view_report(e->tag, tag, rx, cap, n, skip, pt);
			if (off < 0 && n > 0) {
				memcpy(rx->ctl, cap, (size_t)n);
				rx->clen = n;
			}
		}
	}
	usleep(20000);
	ip1 = f558_ipin();
	cnt = (rc == 0) ? f555_count(e->fam, e->table, e->chain) : 0;
	/* the second witness: the rule's own log, read back by prefix.  It tells
	 * "our frame" from "some other frame crossed this chain", which the bare
	 * counter cannot: an ICMPv6 report through the bridge increments the
	 * same counter as our IPv4 datagram. */
	if (rc == 0 && !e->send_raw)
		nfl = nfl_wait(NFL57, PRE57, pay, (int)sizeof(pay), 250);
	printf("F558 RUN|env=%s|arm=%s|off=%d|len=%d|rc=%d|acks=%d|snd=%d|"
	       "cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|nfl=%d|nflhex=", e->tag,
	       tag, off, len, rc, acks, snd, cnt0, cnt, cnt - cnt0, ip1 - ip0,
	       nfl);
	for (i = 0; i < nfl && i < 24; i++)
		printf("%02x", pay[i]);
	printf("\n");
	return cnt - cnt0;
}

static unsigned long long f558_gframe(const struct f557_env *e,
				      const unsigned char *fr, int flen)
{
	static const int offs[12] = { 0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24 };
	static const int lens[3] = { 1, 2, 4 };
	unsigned char imm[16];
	char tag[32];
	int i, j;
	unsigned long long live = 0;

	for (i = 0; i < 12; i++) {
		for (j = 0; j < 3; j++) {
			f557_imm(offs[i], lens[j], imm);
			snprintf(tag, sizeof(tag), "g%d_%d", offs[i], lens[j]);
			if (f558_run(e, tag, offs[i], lens[j], imm, lens[j], fr,
				     flen, NULL, NULL))
				live++;
		}
	}
	printf("F558 GRID|env=%s|live=%llu|of=36\n", e->tag, live);
	return live;
}

/* ---------- A: why did the far side show nothing ---------- */

static void f558_sec_why(void)
{
	unsigned char fr[512], vl[512];
	int c0 = cap_open("r0"), c1 = cap_open("r1");
	int fl, n, pt = -1, rc, sk = 0;

	/* the two tagged-frame builders must agree: f557_mk_vlan() is the one
	 * F35 measured, f558_mk_vlan_tci() is the parameterised one. */
	fl = f557_frame(F557_VLAN, fr);
	n = f558_mk_vlan_tci(vl, 100);
	printf("F558 WHY|frame_same=%d|len557=%d|len558=%d\n",
	       n == fl && !memcmp(fr, vl, (size_t)fl), fl, n);
	printf("F558 WHY|cap_r0=%d|cap_r1=%d|s0=%d|s1=%d|r0=%d|r1=%d|br0=%d\n",
	       c0, c1, f555_ifindex("s0"), f555_ifindex("s1"),
	       f555_ifindex("r0"), f555_ifindex("r1"), f555_ifindex("br0"));
	/* sysfs is not netns-aware here; this is the evidence, not noise */
	f557_sysline("/sys/class/net/br0/flags");
	f557_devline("s1");
	f557_devline("r1");
	f557_devline("r0");

	/* no nft rules at all: does the bridge forward our frame? */
	sh("/nft flush ruleset");
	fl = f557_frame(F557_PLAIN, fr);
	if (c0 >= 0)
		cap_drain(c0);
	if (c1 >= 0)
		cap_drain(c1);
	usleep(20000);
	rc = pkt_send_p("s0", fr, fl, 0x0800);
	{
		unsigned char cap[2048];

		n = f558_cap_match(c0, cap, (int)sizeof(cap), 800,
				   (const unsigned char *)"\x77\x77\x77\x77\x77\x77\x77\x77",
				   8, &sk, &pt);
		printf("F558 WHY|plain|arm=rx_r0|send_rc=%d|flen=%d|n=%d|skip=%d|pt=%d|hex=",
		       rc, fl, n, sk, pt);
		if (n > 0)
			f558_hex(cap, n > 96 ? 96 : n);
		printf("\n");
		sk = 0;
		pt = -1;
		n = f558_cap_match(c1, cap, (int)sizeof(cap), 400,
				   (const unsigned char *)"\x77\x77\x77\x77\x77\x77\x77\x77",
				   8, &sk, &pt);
		printf("F558 WHY|plain|arm=tx_r1|n=%d|skip=%d|pt=%d|hex=", n, sk, pt);
		if (n > 0)
			f558_hex(cap, n > 96 ? 96 : n);
		printf("\n");
	}
	/* the same frame TAGGED, still with no rule: both views */
	fl = f558_mk_vlan_tci(fr, 100);
	if (c0 >= 0)
		cap_drain(c0);
	if (c1 >= 0)
		cap_drain(c1);
	usleep(20000);
	rc = pkt_send_p("s0", fr, fl, 0x8100);
	{
		unsigned char cap[2048], pl[512];
		int plen = f557_frame(F557_PLAIN, pl);
		char chg[512];

		n = f558_cap_match(c1, cap, (int)sizeof(cap), 800,
				   (const unsigned char *)"\x77\x77\x77\x77\x77\x77\x77\x77",
				   8, &sk, &pt);
		f558_chg(chg, sizeof(chg), pl, plen, cap, n);
		printf("F558 WHY|tagged|arm=tx_r1|send_rc=%d|flen=%d|n=%d|skip=%d|pt=%d|vs_plain=%s|hex=",
		       rc, fl, n, sk, pt, chg[0] ? chg : "-");
		if (n > 0)
			f558_hex(cap, n > 96 ? 96 : n);
		printf("\n");
		sk = 0;
		pt = -1;
		n = f558_cap_match(c0, cap, (int)sizeof(cap), 500,
				   (const unsigned char *)"\x77\x77\x77\x77\x77\x77\x77\x77",
				   8, &sk, &pt);
		f558_chg(chg, sizeof(chg), pl, plen, cap, n);
		printf("F558 WHY|tagged|arm=rx_r0|n=%d|skip=%d|pt=%d|vs_plain=%s|hex=",
		       n, sk, pt, chg[0] ? chg : "-");
		if (n > 0)
			f558_hex(cap, n > 96 ? 96 : n);
		printf("\n");
	}
	f557_devline("s1");
	f557_devline("r1");
	f557_devline("r0");

	/* How many frames does ONE send put through a bridge chain?  The bare
	 * counter cannot tell our frame from someone else's, so the witness is
	 * the rule's own log: read every message it produced, not the first. */
	{
		struct f557_env eb;
		unsigned long long c0, c1;
		unsigned char pay[192];
		int acks = -1, n, k = 0;

		memset(&eb, 0, sizeof(eb));
		eb.tag = "wy"; eb.fam = NFPROTO_BRIDGE; eb.table = "p58w";
		eb.chain = "pre"; eb.hook = 0; eb.policy = 1;
		eb.base = NFT_PAYLOAD_LL_HEADER; eb.dev = "s0";
		eb.kind = F557_PLAIN;
		if (!f557_chain(&eb)) {
			fl = f557_frame(F557_PLAIN, fr);
			snprintf(PRE57, sizeof(PRE57), "f57.wy.one");
			f557_flush(eb.fam, eb.table, eb.chain, &acks);
			f557_install(eb.fam, eb.table, eb.chain, 0, 0, 0, 0, NULL,
				     0, 0, 5, PRE57, &acks);
			nfl_drain(NFL57);
			usleep(20000);
			c0 = f555_count(eb.fam, eb.table, eb.chain);
			pkt_send_p(eb.dev, fr, fl, 0x0800);
			while (k < 8) {
				n = nfl_wait(NFL57, PRE57, pay, (int)sizeof(pay), 150);
				if (n <= 0)
					break;
				printf("F558 WHY|one_send|msg=%d|n=%d|hex=", k, n);
				f558_hex(pay, n > 24 ? 24 : n);
				printf("\n");
				k++;
			}
			c1 = f555_count(eb.fam, eb.table, eb.chain);
			printf("F558 WHY|one_send|cnt_delta=%llu|msgs=%d\n", c1 - c0, k);
		}
	}
	sh("/nft flush ruleset");
}

/* ---------- B: what an accepted store actually does ---------- */

static void f558_sec_bytes(void)
{
	static const struct {
		const char *tag;
		int off, len;
		unsigned char v[4];
	} arms[] = {
		{ "s16_2", 16, 2, { 0x08, 0x06 } },	/* ethertype in the buffer */
		{ "s14_99", 14, 2, { 0x00, 0x99 } },	/* vlan_tci = 153 */
		{ "s14_0", 14, 2, { 0x00, 0x00 } },	/* vlan_tci = 0 -> vid 0 */
		{ "s14_1064", 14, 2, { 0x10, 0x64 } },	/* vlan_tci = 100 */
		{ "s12_4z", 12, 4, { 0x81, 0x00, 0x00, 0x00 } }, /* put_tag vid 0 */
	};
	struct f557_env e;
	struct f558_view tx, rx;
	unsigned char fr[512];
	unsigned char imm[16];
	int fl, k;

	memset(&tx, 0, sizeof(tx));
	memset(&rx, 0, sizeof(rx));
	tx.tag = "tx";
	rx.tag = "rx";
	tx.fd = cap_open("r1");		/* the frame the driver is given */
	rx.fd = cap_open("r0");		/* the frame the next hop's stack sees */
	memset(&e, 0, sizeof(e));
	e.tag = "by"; e.fam = NFPROTO_BRIDGE; e.table = "p58z";
	e.chain = "pre"; e.hook = 0; e.policy = 1;
	e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "s0"; e.kind = F557_VLAN;
	fl = f557_frame(e.kind, fr);
	if (f557_chain(&e))
		return;
	printf("F558 BY|tx_fd=%d|rx_fd=%d|flen=%d\n", tx.fd, rx.fd, fl);

	/* control: the tagged frame through the bridge, no store at all */
	f558_run(&e, "ctl", -1, 0, NULL, 0, fr, fl, &tx, &rx);
	/* the PLAIN frame through the same chain: no store at all (the far side
	 * receives it TWICE -- once forwarded to r0, once flooded up to the br0
	 * device -- so "ipin" needs this baseline), and then the very store the
	 * tagged arms test, which must be DEAD here: 16 + 2 > 14.  Same table,
	 * so each arm's own flush removes the previous rule; the views are
	 * copies so the tagged control is not overwritten. */
	{
		struct f558_view txp = tx, rxp = rx;
		unsigned char fp[512];
		int flp = f557_frame(F557_PLAIN, fp);

		txp.clen = 0;
		rxp.clen = 0;
		f558_run(&e, "ctl_plain", -1, 0, NULL, 0, fp, flp, &txp, &rxp);
		f558_run(&e, "s16_2_plain", 16, 2,
			 (const unsigned char *)"\x08\x06", 2, fp, flp,
			 &txp, &rxp);
	}
	for (k = 0; k < (int)(sizeof(arms) / sizeof(arms[0])); k++) {
		memset(imm, 0, sizeof(imm));
		memcpy(imm, arms[k].v, (size_t)arms[k].len);
		f558_run(&e, arms[k].tag, arms[k].off, arms[k].len, imm,
			 arms[k].len, fr, fl, &tx, &rx);
	}
	sh("/nft flush ruleset");
}

/* ---------- C: the ip family meets a tag ---------- */

static void f558_sec_vlan(const char *only)
{
	struct f557_env e;
	unsigned char fr[512], fr0[512];
	int fl = 0, fl0 = 0, rc, add_rc = -99;

	if (!only || !strcmp(only, "p4")) {
		memset(&e, 0, sizeof(e));
		e.tag = "p4"; e.fam = NFPROTO_IPV4; e.table = "p58a";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_PLAIN;
		if (!f557_chain(&e)) {
			f557_ctl(&e, "ctl", 1);
			f557_grid(&e, G57_OFF, 12, G57_LEN, 3, 1);
		}
	}
	if (!only || !strcmp(only, "novd")) {
		fl = f558_mk_vlan_tci(fr, 100);
		memset(&e, 0, sizeof(e));
		e.tag = "novd"; e.fam = NFPROTO_IPV4; e.table = "p58b";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e)) {
			f558_run(&e, "ctl", -1, 0, NULL, 0, fr, fl, NULL, NULL);
			f558_run(&e, "g12_2", 12, 2,
				 (const unsigned char *)"\x00\x64", 2, fr, fl,
				 NULL, NULL);
		}
	}
	/* the vlan device: on T557 this is -EOPNOTSUPP, which is itself the
	 * measurement of the config line F35 named. */
	if (!only || !strcmp(only, "vd") || !strcmp(only, "novd")) {
		add_rc = f558_link_add_vlan("v1", "i1", 100);
		if (add_rc == 0)
			set_up("v1");
		printf("F558 VLANDEV|add_rc=%d|idx=%d\n", add_rc,
		       f555_ifindex("v1"));
	}
	if (!only || !strcmp(only, "vd")) {
		if (add_rc != 0) {
			printf("F558 VLANDEV|vd_skipped|reason=no_vlan_device\n");
		} else {
			fl = f558_mk_vlan_tci(fr, 100);
			memset(&e, 0, sizeof(e));
			e.tag = "vd"; e.fam = NFPROTO_IPV4; e.table = "p58c";
			e.chain = "pre"; e.hook = 0; e.policy = 1;
			e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
			e.kind = F557_VLAN;
			if (!f557_chain(&e)) {
				f558_run(&e, "ctl", -1, 0, NULL, 0, fr, fl,
					 NULL, NULL);
				f558_gframe(&e, fr, fl);
			}
		}
	}
	if (!only || !strcmp(only, "vd")) {
		rc = f558_link_del("v1");
		printf("F558 VLANDEV|del_rc=%d|idx=%d\n", rc, f555_ifindex("v1"));
		fl = f558_mk_vlan_tci(fr, 100);
		memset(&e, 0, sizeof(e));
		e.tag = "novd2"; e.fam = NFPROTO_IPV4; e.table = "p58e";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e))
			f558_run(&e, "ctl", -1, 0, NULL, 0, fr, fl, NULL, NULL);
	}
	/* vid 0: a priority tag needs no vlan device at all */
	if (!only || !strcmp(only, "v0")) {
		fl0 = f558_mk_vlan_tci(fr0, 0);
		memset(&e, 0, sizeof(e));
		e.tag = "v0"; e.fam = NFPROTO_IPV4; e.table = "p58d";
		e.chain = "pre"; e.hook = 0; e.policy = 1;
		e.base = NFT_PAYLOAD_LL_HEADER; e.dev = "i0";
		e.kind = F557_VLAN;
		if (!f557_chain(&e)) {
			f558_run(&e, "ctl", -1, 0, NULL, 0, fr0, fl0, NULL, NULL);
			f558_gframe(&e, fr0, fl0);
		}
	}
	sh("/nft flush ruleset");
}

/* ---------- D: the instrument's own pollution, measured on purpose -------- */

/* One send through a bridge chain with no match expression, run twice: with
 * IPv6 off on the devices (what every other section of this instrument runs
 * with) and with it back on.  The counter cannot tell our IPv4 datagram from
 * the kernel's own MLD/NS chatter, and the rule's log can: each message is
 * printed with its first bytes, so 0x45 is ours and 0x60 is not. */
static void f558_one_send(const char *tag)
{
	struct f557_env eb;
	unsigned long long c0, c1;
	unsigned char fr[512], pay[192];
	static const char *dv[] = { "r0", "s0", "s1", "r1", "br0", "i0", "i1" };
	char path[96];
	int acks = -1, n, k = 0, i, fl;

	memset(&eb, 0, sizeof(eb));
	eb.tag = "wy"; eb.fam = NFPROTO_BRIDGE; eb.table = "p58w";
	eb.chain = "pre"; eb.hook = 0; eb.policy = 1;
	eb.base = NFT_PAYLOAD_LL_HEADER; eb.dev = "s0";
	eb.kind = F557_PLAIN;
	if (f557_chain(&eb))
		return;
	fl = f557_frame(F557_PLAIN, fr);
	snprintf(PRE57, sizeof(PRE57), "f57.wy.%s", tag);
	f557_flush(eb.fam, eb.table, eb.chain, &acks);
	f557_install(eb.fam, eb.table, eb.chain, 0, 0, 0, 0, NULL, 0, 0, 5,
		     PRE57, &acks);
	nfl_drain(NFL57);
	usleep(30000);
	c0 = f555_count(eb.fam, eb.table, eb.chain);
	pkt_send_p(eb.dev, fr, fl, 0x0800);
	while (k < 8) {
		n = nfl_wait(NFL57, PRE57, pay, (int)sizeof(pay), 200);
		if (n <= 0)
			break;
		printf("F558 ONE|%s|msg=%d|n=%d|hex=", tag, k, n);
		f558_hex(pay, n > 24 ? 24 : n);
		printf("\n");
		k++;
	}
	c1 = f555_count(eb.fam, eb.table, eb.chain);
	printf("F558 ONE|%s|cnt_delta=%llu|msgs=%d\n", tag, c1 - c0, k);
	(void)dv;
	(void)path;
	(void)i;
}

static void f558_sec_ipv6(void)
{
	static const char *dv[] = { "r0", "s0", "s1", "r1", "br0" };
	char path[96];
	int i;

	f558_one_send("v6off");
	for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
		snprintf(path, sizeof(path),
			 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
		f555_sysctl(path, "0");
	}
	usleep(300000);
	f558_one_send("v6on1");
	usleep(300000);
	f558_one_send("v6on2");
	for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
		snprintf(path, sizeof(path),
			 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
		f555_sysctl(path, "1");
	}
	usleep(200000);
	f558_one_send("v6off2");
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int f558_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f558";
	const char *only = argc > 2 ? argv[2] : NULL;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F558 BEGIN|mode=%s|only=%s\n", mode, only ? only : "-");
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F558 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F558 KERNEL|%s\n", "7.3.4-T557/T558");
	f556_env_setup();
	/* The counter on an nft chain has no match expression: it counts any
	 * frame that crosses the chain.  The kernel's own IPv6 chatter (MLD/NS
	 * emitted out of r0 and s0, which arrive at their peers r1 and s1 --
	 * bridge ports) therefore lands in the same counter as our IPv4 frame:
	 * measured in `why`, one send produced one IPv4 log message and one
	 * IPv6 one, cnt_delta=2.  IPv6 is turned off on every device of this
	 * netns so that "one frame through the bridge" means one. */
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL57 = nfl_open(5);
	printf("F558 NFL|%d\n", NFL57);
	if (!strcmp(mode, "f558why")) {
		f558_sec_why();
	} else if (!strcmp(mode, "f558bytes")) {
		f558_sec_bytes();
	} else if (!strcmp(mode, "f558ipv6")) {
		f558_sec_ipv6();
	} else if (!strcmp(mode, "f558vlan")) {
		f558_sec_vlan(NULL);
	} else if (!strncmp(mode, "f558vlan:", 9)) {
		f558_sec_vlan(mode + 9);
	} else {
		f558_sec_why();
		f558_sec_bytes();
		f558_sec_vlan(only);
	}
	printf("F558 DONE\n");
	return 0;
}
/* differ559_add.c -- turn 559 / F37: the 802.1Q tag as BYTES.
 *
 * F36 ended with an honest instrument limit: on a veth the tag lives in skb
 * metadata, AF_PACKET taps the frame after skb_vlan_untag() on the way in and
 * after validate_xmit_vlan() on the way out, and veth advertises
 * NETIF_F_HW_VLAN_CTAG_TX so the core never puts the tag back -- so "the bytes
 * of the tag on the wire" could not be measured at all.
 *
 * The way out is not a new driver.  net/ethtool/ioctl.c:ethtool_set_features()
 * writes dev->wanted_features and calls __netdev_update_features(); it does not
 * need an ndo_set_features op.  So ONE BIT can be taken away from a veth from
 * userspace (ETHTOOL_SFEATURES, NETIF_F_HW_VLAN_CTAG_TX), and then
 * net/core/dev.c:validate_xmit_vlan() has to insert the tag into the frame
 * itself.  That single bit is the difference this turn measures.
 *
 * Two views per arm, and they are different instruments:
 *   wire -- AF_PACKET on r1, the port the bridge transmits on.  The tap runs in
 *           xmit_one(), i.e. AFTER validate_xmit_skb(): with the offload it is
 *           60 bytes and tagless, without it the tag is at 12..15.
 *   far  -- AF_PACKET on r0, the peer of r1.  That tap runs in
 *           __netif_receive_skb_core() AFTER skb_vlan_untag(), so it is
 *           untagged in BOTH cases -- but a frame whose ethertype byte was
 *           zeroed reaches it as bytes, and then it is not "the far side's
 *           verdict" any more, it is the frame.
 *
 * Sections
 *   feat   GFEATURES/SFEATURES on every device of the netns; the bit, and the
 *          two frames it decides.
 *   wire   the same eight arms in three feature states (on -> cleared ->
 *          restored), so the causal link is bit -> bytes -> bit.
 *   ih     F36's own debt: the transport-base store at the bridge, on a tagged
 *          and on a plain frame, proto 6 and proto 17, 36 cells each.
 *   chain  two chains at one hook: what `pre` writes into the frame decides
 *          whether `post`'s transport store is alive at all.
 */

#include <linux/sockios.h>	/* SIOCETHTOOL */

/* ---------- frames ---------- */

/* the tagged frame for ANY of the base kinds: the datagram is moved 4 bytes
 * down and the tag is written in front of it, so "tagged" and "plain" differ in
 * exactly those 4 bytes. */
static int f559_frame(int kind, int tagged, unsigned char *out)
{
	unsigned char tmp[512];
	int n = f556_frame(kind, tmp);

	if (!tagged) {
		memcpy(out, tmp, (size_t)n);
		return n;
	}
	memset(out, 0, 512);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x81; out[13] = 0x00;	/* 802.1Q */
	out[14] = 0x00; out[15] = 0x64;	/* prio 0, vid 100 */
	out[16] = 0x08; out[17] = 0x00;	/* inner ethertype */
	memcpy(out + 18, tmp + 14, (size_t)(n - 14));
	return n + 4;
}

/* ---------- ethtool: one bit ---------- */

#define F559_GFEATURES		0x0000003a	/* not 0x3b: that is SFEATURES here */
#define F559_SFEATURES		0x0000003b
#define F559_FWORDS		8
#define F559_TX_BIT		7	/* NETIF_F_HW_VLAN_CTAG_TX_BIT */
#define F559_RX_BIT		8	/* NETIF_F_HW_VLAN_CTAG_RX_BIT */

struct f559_fblk {
	unsigned int avail, want, act, never;
};

static int f559_gfeat(const char *dev, struct f559_fblk *blk, int max, int *nblk)
{
	struct {
		unsigned int cmd, size;
		struct f559_fblk b[F559_FWORDS];
	} c;
	struct ifreq ifr;
	int fd, rc, i;

	memset(&c, 0, sizeof(c));
	c.cmd = F559_GFEATURES;
	c.size = (unsigned int)max;	/* the kernel clamps and reports back */
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, IFNAMSIZ, "%s", dev);
	ifr.ifr_data = (char *)&c;
	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0)
		return -1;
	rc = ioctl(fd, SIOCETHTOOL, &ifr);
	close(fd);
	if (rc < 0)
		return -errno;
	*nblk = (int)c.size;
	for (i = 0; i < *nblk && i < max; i++)
		blk[i] = c.b[i];
	return 0;
}

static int f559_sfeat(const char *dev, int nblk, unsigned int valid0,
		      unsigned int req0)
{
	struct {
		unsigned int cmd, size;
		struct {
			unsigned int valid, req;
		} b[F559_FWORDS];
	} c;
	struct ifreq ifr;
	int fd, rc;

	memset(&c, 0, sizeof(c));
	c.cmd = F559_SFEATURES;
	c.size = (unsigned int)nblk;
	c.b[0].valid = valid0;
	c.b[0].req = req0;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, IFNAMSIZ, "%s", dev);
	ifr.ifr_data = (char *)&c;
	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0)
		return -1;
	rc = ioctl(fd, SIOCETHTOOL, &ifr);
	close(fd);
	return rc < 0 ? -errno : rc;	/* >= 0: an ETHTOOL_F_* mask, not errno */
}

static void f559_featline(const char *stage, const char *dev)
{
	struct f559_fblk b[F559_FWORDS];
	int n = 0, i, rc = f559_gfeat(dev, b, F559_FWORDS, &n);

	printf("F559 FEAT|stage=%s|dev=%s|rc=%d|nwords=%d", stage, dev, rc, n);
	if (rc == 0) {
		for (i = 0; i < n && i < F559_FWORDS; i++)
			printf("|avail%d=%08x|want%d=%08x|act%d=%08x", i,
			       b[i].avail, i, b[i].want, i, b[i].act);
		printf("|avail_tx=%d|act_tx=%d|act_rx=%d",
		       (int)((b[0].avail >> F559_TX_BIT) & 1),
		       (int)((b[0].act >> F559_TX_BIT) & 1),
		       (int)((b[0].act >> F559_RX_BIT) & 1));
	}
	printf("\n");
}

/* on: 1 = ask for the bit, 0 = ask it away.  Returns the raw ioctl result. */
static int f559_setoff(const char *stage, const char *dev, int on)
{
	struct f559_fblk b[F559_FWORDS];
	unsigned int bit = 1u << F559_TX_BIT;
	int n = 0, rc;

	if (f559_gfeat(dev, b, F559_FWORDS, &n) < 0 || n <= 0) {
		printf("F559 SET|stage=%s|dev=%s|no_gfeat\n", stage, dev);
		return -1;
	}
	rc = f559_sfeat(dev, n, bit, on ? bit : 0u);
	printf("F559 SET|stage=%s|dev=%s|valid=%08x|req=%08x|nwords=%d|rc=%d|"
	       "f_unsup=%d|f_wish=%d\n", stage, dev, bit, on ? bit : 0u, n, rc,
	       rc >= 0 ? (rc & 1) : -1, rc >= 0 ? (rc & 2) : -1);
	f559_featline(stage, dev);
	return rc;
}

/* ---------- one arm ---------- */

struct f559_env {
	const char *tag;
	const char *table;
	const char *chain;
	uint32_t base;
	int kind;
	int tagged;
};

struct f559_out {
	int rc, snd, acks;
	int wn, wpt, rn, rpt;
	unsigned long long cnt0, cnt, ipin;
	unsigned char w[2048], r[2048];
};

static int NFL59 = -1;
static const char *F559_STATE = "-";

static const char *f559_hexs(char *out, size_t osz, const unsigned char *b, int n)
{
	size_t at = 0;
	int i;

	out[0] = 0;
	for (i = 0; i < n && i < 96 && at + 3 < osz; i++)
		at += (size_t)snprintf(out + at, osz - at, "%02x", b[i]);
	return out;
}

static int f559_chain(const struct f559_env *e)
{
	int rc = add_table(NFPROTO_BRIDGE, e->table);
	int rc2 = f556_add_chain(NFPROTO_BRIDGE, e->table, e->chain, 0, 0, 1,
				 NULL);

	printf("F559 CHAIN|env=%s|table=%d|chain=%d\n", e->tag, rc, rc2);
	return rc || rc2;
}

/* the frame goes in from s0 (outside the bridge), the bridge floods it to r1
 * and up to br0; the two taps below are the two views. */
static void f559_send(const unsigned char *fr, int flen, int proto, int wfd,
		      int rfd, struct f559_out *o)
{
	static const unsigned char magic[8] = { 0x77, 0x77, 0x77, 0x77,
						0x77, 0x77, 0x77, 0x77 };
	int sk = 0;

	o->wpt = -1; o->rpt = -1;
	if (wfd >= 0)
		cap_drain(wfd);
	if (rfd >= 0)
		cap_drain(rfd);
	usleep(15000);
	if (wfd >= 0)
		cap_drain(wfd);
	if (rfd >= 0)
		cap_drain(rfd);
	memset(o->w, 0, sizeof(o->w));
	memset(o->r, 0, sizeof(o->r));
	o->snd = pkt_send_p("s0", fr, flen, (unsigned short)proto);
	o->wn = f558_cap_match(wfd, o->w, (int)sizeof(o->w), 700, magic, 8, &sk,
			       &o->wpt);
	sk = 0;
	o->rn = f558_cap_match(rfd, o->r, (int)sizeof(o->r), 400, magic, 8, &sk,
			       &o->rpt);
}

/* install one rule, send one frame, read both taps, print one line.
 * `base` (may be NULL) is the arm whose bytes are the diff baseline; *out, if
 * not NULL, receives this arm's capture so that a control arm can become the
 * next arm's baseline. */
static void f559_arm(const struct f559_env *e, const char *arm, int off, int len,
		     const unsigned char *imm, int do_store,
		     const struct f559_out *base, int wfd, int rfd,
		     struct f559_out *out)
{
	struct f559_out o;
	unsigned char fr[512];
	char cw[1024], cr[1024], hw[256], hr[256];
	int flen = f559_frame(e->kind, e->tagged, fr);
	int kw = 0, kr = 0;

	memset(&o, 0, sizeof(o));
	snprintf(PRE57, sizeof(PRE57), "f59.%s.%s", e->tag, arm);
	f557_flush(NFPROTO_BRIDGE, e->table, e->chain, &o.acks);
	o.rc = f557_install(NFPROTO_BRIDGE, e->table, e->chain, 0, e->base,
			    (uint32_t)off, (uint32_t)len, imm,
			    do_store ? len : 0, do_store, 5, PRE57, &o.acks);
	nfl_drain(NFL59);
	o.cnt0 = f555_count(NFPROTO_BRIDGE, e->table, e->chain);
	{
		unsigned long long ip0 = f558_ipin();

		f559_send(fr, flen, e->tagged ? 0x8100 : 0x0800, wfd, rfd, &o);
		usleep(20000);
		o.ipin = f558_ipin() - ip0;
	}
	o.cnt = f555_count(NFPROTO_BRIDGE, e->table, e->chain);
	if (base && o.wn > 0 && base->wn > 0)
		kw = f558_chg(cw, sizeof(cw), base->w, base->wn, o.w, o.wn);
	if (base && o.rn > 0 && base->rn > 0)
		kr = f558_chg(cr, sizeof(cr), base->r, base->rn, o.r, o.rn);
	printf("F559 R|state=%s|env=%s|arm=%s|tagged=%d|base=%u|off=%d|len=%d|"
	       "store=%d|rc=%d|acks=%d|snd=%d|cnt0=%llu|cnt=%llu|live=%llu|"
	       "ipin=%llu|wn=%d|wpt=%d|wchg=%d|wchgs=%s|whex=%s|"
	       "rn=%d|rpt=%d|rchg=%d|rchgs=%s|rhex=%s\n",
	       F559_STATE, e->tag, arm, e->tagged, e->base, off, len, do_store,
	       o.rc, o.acks, o.snd, o.cnt0, o.cnt, o.cnt - o.cnt0, o.ipin,
	       o.wn, o.wpt, kw, cw[0] ? cw : "-",
	       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn) : "-",
	       o.rn, o.rpt, kr, cr[0] ? cr : "-",
	       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn) : "-");
	if (out)
		memcpy(out, &o, sizeof(o));
}

/* ---------- probe: is the ioctl transport itself alive? ---------- */

static int f559_ioctl_raw(const char *dev, void *data)
{
	struct ifreq ifr;
	int fd, rc, e;

	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, IFNAMSIZ, "%s", dev);
	ifr.ifr_data = (char *)data;
	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0)
		return -1000;
	errno = 0;
	rc = ioctl(fd, SIOCETHTOOL, &ifr);
	e = errno;
	close(fd);
	return rc < 0 ? -e : rc;
}

static void f559_sec_probe(void)
{
	struct {
		unsigned int cmd, size;
		unsigned int b[8 * 4];
	} c;
	int rc;

	printf("F559 PROBE|sioc_ethtool=%08x|sizeof_ifreq=%d|sizeof_gfeat=%d|"
	       "sizeof_sfeat=%d\n", (unsigned int)SIOCETHTOOL,
	       (int)sizeof(struct ifreq), 8 + 16 * 3, 8 + 8 * 3);
	/* ETHTOOL_GSET = 0x1, GDRVINFO = 0x3, GLINK = 0xa */
	memset(&c, 0, sizeof(c));
	c.cmd = 0x00000001; c.size = 0;
	rc = f559_ioctl_raw("r1", &c);
	printf("F559 PROBE|gset=%d\n", rc);
	memset(&c, 0, sizeof(c));
	c.cmd = 0x0000000a;
	rc = f559_ioctl_raw("r1", &c);
	printf("F559 PROBE|glink=%d|link=%u\n", rc, c.size);
	memset(&c, 0, sizeof(c));
	c.cmd = F559_GFEATURES; c.size = 3;
	rc = f559_ioctl_raw("r1", &c);
	printf("F559 PROBE|gfeat3=%d|size=%u|avail0=%08x|act0=%08x\n", rc, c.size,
	       c.b[0], c.b[2]);
	memset(&c, 0, sizeof(c));
	c.cmd = F559_GFEATURES; c.size = 8;
	rc = f559_ioctl_raw("r1", &c);
	printf("F559 PROBE|gfeat8=%d|size=%u|avail0=%08x|act0=%08x\n", rc, c.size,
	       c.b[0], c.b[2]);
	memset(&c, 0, sizeof(c));
	c.cmd = F559_SFEATURES; c.size = 3;
	rc = f559_ioctl_raw("r1", &c);
	printf("F559 PROBE|sfeat_nop=%d\n", rc);
}

/* ---------- feat ---------- */

static void f559_sec_feat(void)
{
	static const char *dv[] = { "lo", "i0", "i1", "s0", "s1", "r0", "r1",
				    "br0" };
	int i;

	for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++)
		f559_featline("init", dv[i]);
	/* the causal chain, on the port the bridge transmits on */
	f559_setoff("clear", "r1", 0);
	f559_setoff("restore", "r1", 1);
}

/* ---------- wire: eight arms, three feature states ---------- */

static void f559_sec_wire(const char *state)
{
	static const struct {
		const char *tag;
		int off, len;
		unsigned char v[4];
	} arms[] = {
		{ "s16_2", 16, 2, { 0x08, 0x06 } },
		{ "s14_99", 14, 2, { 0x00, 0x99 } },
		{ "s14_0", 14, 2, { 0x00, 0x00 } },
		{ "s12_2z", 12, 2, { 0x00, 0x00 } },
		{ "s12_4z", 12, 4, { 0x81, 0x00, 0x00, 0x00 } },
	};
	struct f559_env et, ep;
	struct f559_out ct, cp, o;
	unsigned char imm[16];
	unsigned char fr[512];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int k;

	F559_STATE = state;
	memset(&et, 0, sizeof(et));
	et.tag = "wire"; et.table = "p59a"; et.chain = "pre";
	et.base = NFT_PAYLOAD_LL_HEADER; et.kind = FK33_IP4; et.tagged = 1;
	ep = et; ep.tagged = 0;
	if (f559_chain(&et))
		return;
	printf("F559 SECTION|wire|state=%s|wfd=%d|rfd=%d|flen_t=%d|flen_p=%d\n",
	       state, wfd, rfd, f559_frame(FK33_IP4, 1, fr),
	       f559_frame(FK33_IP4, 0, fr));
	memset(&ct, 0, sizeof(ct));
	f559_arm(&et, "ctl", 0, 0, NULL, 0, NULL, wfd, rfd, &ct);
	for (k = 0; k < (int)(sizeof(arms) / sizeof(arms[0])); k++) {
		memset(imm, 0, sizeof(imm));
		memcpy(imm, arms[k].v, (size_t)arms[k].len);
		f559_arm(&et, arms[k].tag, arms[k].off, arms[k].len, imm,
			 arms[k].len, &ct, wfd, rfd, &o);
	}
	/* the same store on a plain frame: 16+2 > 14, so it must be dead */
	memset(&cp, 0, sizeof(cp));
	f559_arm(&ep, "ctl_plain", 0, 0, NULL, 0, NULL, wfd, rfd, &cp);
	f559_arm(&ep, "s16_2_plain", 16, 2, (const unsigned char *)"\x08\x06",
		 2, &cp, wfd, rfd, &o);
	sh("/nft flush ruleset");
}

/* ---------- ih: transport base at the bridge, tagged and plain ---------- */

static void f559_sec_ih(void)
{
	static const int offs[12] = { 0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24 };
	static const int lens[3] = { 1, 2, 4 };
	static const struct {
		const char *tag;
		const char *table;
		int kind;
		int tagged;
	} combos[] = {
		{ "p6T", "p59b1", FK33_IP4_P6, 1 },
		{ "p6P", "p59b2", FK33_IP4_P6, 0 },
		{ "uT", "p59b3", FK33_IP4, 1 },
		{ "uP", "p59b4", FK33_IP4, 0 },
	};
	struct f559_env e;
	struct f559_out ctl, o;
	unsigned char imm[16], fr[512];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int c, i, j;

	F559_STATE = "clear";
	for (c = 0; c < (int)(sizeof(combos) / sizeof(combos[0])); c++) {
		memset(&e, 0, sizeof(e));
		e.tag = combos[c].tag;
		e.table = combos[c].table;
		e.chain = "pre";
		e.base = NFT_PAYLOAD_TRANSPORT_HEADER;
		e.kind = combos[c].kind;
		e.tagged = combos[c].tagged;
		if (f559_chain(&e))
			continue;
		printf("F559 SECTION|ih|combo=%s|wfd=%d|rfd=%d|flen=%d\n",
		       e.tag, wfd, rfd, f559_frame(e.kind, e.tagged, fr));
		memset(&ctl, 0, sizeof(ctl));
		f559_arm(&e, "ctl", 0, 0, NULL, 0, NULL, wfd, rfd, &ctl);
		for (i = 0; i < 12; i++) {
			for (j = 0; j < 3; j++) {
				char arm[32];

				f557_imm(offs[i], lens[j], imm);
				snprintf(arm, sizeof(arm), "g%d_%d", offs[i],
					 lens[j]);
				f559_arm(&e, arm, offs[i], lens[j], imm,
					 lens[j], &ctl, wfd, rfd, &o);
			}
		}
	}
	sh("/nft flush ruleset");
}

/* ---------- chain: the envelope is a property of the moment ---------- */

static void f559_two(const unsigned char *fr, int flen, const char *arm,
		     int pre_do, uint32_t pre_base, int pre_off, int pre_len,
		     const unsigned char *pre_imm, int wfd, int rfd,
		     const struct f559_out *base)
{
	unsigned char pimm[4] = { 0x1f, 0x90 };	/* the transport store */
	struct f559_out o;
	char cw[1024], cr[1024], hw[256], hr[256];
	int kw = 0, kr = 0;
	int acks = 0;	/* f557_nft_one() writes *acks unconditionally */

	memset(&o, 0, sizeof(o));
	f557_flush(NFPROTO_BRIDGE, "p59c", "pre", &acks);
	f557_flush(NFPROTO_BRIDGE, "p59c", "post", &acks);
	if (pre_do) {
		snprintf(PRE57, sizeof(PRE57), "f59.pre.%s", arm);
		f557_install(NFPROTO_BRIDGE, "p59c", "pre", 0, pre_base,
			     (uint32_t)pre_off, (uint32_t)pre_len, pre_imm,
			     pre_len, 1, 5, PRE57, &o.acks);
	}
	snprintf(PRE57, sizeof(PRE57), "f59.post.%s", arm);
	o.rc = f557_install(NFPROTO_BRIDGE, "p59c", "post", 0,
			    NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, pimm, 2, 1, 5,
			    PRE57, &o.acks);
	nfl_drain(NFL59);
	o.cnt0 = f555_count(NFPROTO_BRIDGE, "p59c", "post");
	{
		unsigned long long ip0 = f558_ipin();

		f559_send(fr, flen, 0x8100, wfd, rfd, &o);
		usleep(20000);
		o.ipin = f558_ipin() - ip0;
	}
	o.cnt = f555_count(NFPROTO_BRIDGE, "p59c", "post");
	if (base && o.wn > 0 && base->wn > 0)
		kw = f558_chg(cw, sizeof(cw), base->w, base->wn, o.w, o.wn);
	if (base && o.rn > 0 && base->rn > 0)
		kr = f558_chg(cr, sizeof(cr), base->r, base->rn, o.r, o.rn);
	printf("F559 C|state=%s|arm=%s|pre=%d|prebase=%u|preoff=%d|prelen=%d|"
	       "rc=%d|cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|"
	       "wn=%d|wchg=%d|wchgs=%s|whex=%s|rn=%d|rchg=%d|rchgs=%s|rhex=%s\n",
	       F559_STATE, arm, pre_do, pre_base, pre_off, pre_len, o.rc,
	       o.cnt0, o.cnt, o.cnt - o.cnt0, o.ipin, o.wn, kw,
	       cw[0] ? cw : "-",
	       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn) : "-", o.rn,
	       kr, cr[0] ? cr : "-",
	       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn) : "-");
}

static void f559_sec_chain(void)
{
	struct f559_out ctl;
	unsigned char fr[512];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int flen = f559_frame(FK33_IP4_P6, 1, fr);
	int rc, rc1, rc2;
	int acks = 0;

	F559_STATE = "clear";
	rc = add_table(NFPROTO_BRIDGE, "p59c");
	rc1 = f556_add_chain(NFPROTO_BRIDGE, "p59c", "pre", 0, 0, 1, NULL);
	rc2 = f556_add_chain(NFPROTO_BRIDGE, "p59c", "post", 0, 10, 1, NULL);
	printf("F559 SECTION|chain|table=%d|pre=%d|post=%d|flen=%d\n", rc, rc1,
	       rc2, flen);
	if (rc || rc1 || rc2)
		return;
	/* baseline: both chains empty, so the diffs below are the stores' own */
	memset(&ctl, 0, sizeof(ctl));
	f557_flush(NFPROTO_BRIDGE, "p59c", "pre", &acks);
	f557_flush(NFPROTO_BRIDGE, "p59c", "post", &acks);
	f559_send(fr, flen, 0x8100, wfd, rfd, &ctl);
	f559_two(fr, flen, "a_none", 0, 0, 0, 0, NULL, wfd, rfd, &ctl);
	f559_two(fr, flen, "b_et", 1, NFT_PAYLOAD_LL_HEADER, 16, 2,
		 (const unsigned char *)"\x08\x06", wfd, rfd, &ctl);
	f559_two(fr, flen, "c_tci", 1, NFT_PAYLOAD_LL_HEADER, 14, 2,
		 (const unsigned char *)"\x00\x99", wfd, rfd, &ctl);
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int f559_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f559";

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F559 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F559 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F559 KERNEL|%s\n", "7.3.4-T558");
	f556_env_setup();
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL59 = nfl_open(5);
	printf("F559 NFL|%d\n", NFL59);
	if (!strcmp(mode, "f559probe")) {
		f559_sec_probe();
	} else if (!strcmp(mode, "f559feat")) {
		f559_sec_feat();
	} else if (!strcmp(mode, "f559wire")) {
		f559_sec_wire("on");
	} else if (!strcmp(mode, "f559wiron")) {
		f559_sec_wire("on");
	} else if (!strcmp(mode, "f559wiroff")) {
		f559_setoff("clear", "r1", 0);
		f559_sec_wire("clear");
	} else if (!strcmp(mode, "f559ih")) {
		f559_setoff("clear", "r1", 0);
		f559_sec_ih();
	} else if (!strcmp(mode, "f559chain")) {
		f559_setoff("clear", "r1", 0);
		f559_sec_chain();
	} else if (!strcmp(mode, "f559smoke")) {
		f559_sec_feat();
		f559_sec_wire("on");
		f559_setoff("clear", "r1", 0);
		f559_sec_wire("clear");
	} else {
		f559_sec_feat();
		f559_sec_wire("on");
		f559_setoff("clear", "r1", 0);
		f559_sec_wire("clear");
		f559_setoff("restore", "r1", 1);
		f559_sec_wire("restored");
		f559_setoff("clear2", "r1", 0);
		f559_sec_ih();
		f559_sec_chain();
	}
	printf("F559 DONE\n");
	return 0;
}
/* differ560_add.c -- turn 560 / F38: the RECEIVING side of the tag.
 *
 * F37 ended with the tag measured as bytes on the wire: a veth whose
 * NETIF_F_HW_VLAN_CTAG_TX bit was taken away makes validate_xmit_vlan() insert
 * the tag into the frame itself, so the wire shows `8100 0064 0800 ...`.
 *
 * This turn sends that frame back IN, from an AF_PACKET socket, and asks what
 * the receiving kernel and the four guards make of it:
 *
 *   recv  family bridge, base ll, the 36-cell grid, five representations of one
 *         tagged frame: plain, wire-tagged (0x8100 vid 100), the SAME tag put
 *         into skb metadata by a `pre`-chain rule, a priority tag (vid 0), and
 *         a 0x9100 frame with the same four tag-shaped bytes.  Two of them are
 *         the same object seen from two sides; the grid must not be able to
 *         tell them apart, and neither must the wire.
 *   ndin  family netdev, INGRESS hook on s1, base nh, 40 cells: the guard
 *         returns true before it looks at skb->protocol -- but the receive path
 *         has already popped the tag, so the store's coordinates are skb
 *         coordinates, not wire coordinates.
 *   ndeg  family netdev, EGRESS hook on i0, base nh, 40 cells, three sends with
 *         sll_protocol = 0x0800 / 0x8100 / 0x9100: the only hook where a human
 *         chooses what the guard's switch reads.
 *   arp   family bridge, base nh, an 0x8100 + 0x0806 frame: F32's ARP branch
 *         (offset >= 8 && len <= 20, no test of the message length) through the
 *         new envelope.
 *   drop  policy drop at the bridge: the same rule refuses one representation
 *         and accepts the other.
 *
 * Views: w = AF_PACKET on r1 (xmit side, AFTER validate_xmit_skb: the tag the
 *        port actually put there), r = AF_PACKET on r0 (receive side, AFTER
 *        skb_vlan_untag: the frame as the far stack gets it).
 * Oracle for the guard: the rule's own counter, read before and after one send.
 */

/* ---------- frames ---------- */

/* the plain frame of `kind` with a 4-byte tag inserted in front of its
 * ethertype; tpid is the outer ethertype, tci the tag control word */
static int f560_tag(unsigned char *out, int kind, unsigned int tpid,
		    unsigned int tci)
{
	unsigned char tmp[512];
	int n = f556_frame(kind, tmp);

	memset(out, 0, 512);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = (unsigned char)((tpid >> 8) & 0xff);
	out[13] = (unsigned char)(tpid & 0xff);
	out[14] = (unsigned char)((tci >> 8) & 0xff);
	out[15] = (unsigned char)(tci & 0xff);
	memcpy(out + 16, tmp + 12, 2);		/* inner ethertype */
	memcpy(out + 18, tmp + 14, (size_t)(n - 14));	/* the datagram */
	return n + 4;
}

static const unsigned char MAGIC77[8] = { 0x77, 0x77, 0x77, 0x77,
					  0x77, 0x77, 0x77, 0x77 };

/* ---------- one send, two taps ---------- */

static void f560_send2(const char *dev, unsigned short proto,
		       const unsigned char *fr, int flen,
		       const unsigned char *magic, int mlen,
		       int wfd, int rfd, struct f559_out *o)
{
	int sk = 0;

	o->wpt = -1;
	o->rpt = -1;
	if (wfd >= 0)
		cap_drain(wfd);
	if (rfd >= 0)
		cap_drain(rfd);
	usleep(15000);
	if (wfd >= 0)
		cap_drain(wfd);
	if (rfd >= 0)
		cap_drain(rfd);
	memset(o->w, 0, sizeof(o->w));
	memset(o->r, 0, sizeof(o->r));
	o->snd = pkt_send_p(dev, fr, flen, proto);
	o->wn = f558_cap_match(wfd, o->w, (int)sizeof(o->w), 700, magic, mlen,
			       &sk, &o->wpt);
	sk = 0;
	o->rn = f558_cap_match(rfd, o->r, (int)sizeof(o->r), 400, magic, mlen,
			       &sk, &o->rpt);
}

/* ---------- one arm: one rule, one frame, two taps, one counter delta ---------- */

/* the section name, so that "p" in recv and "p" in ndin are two different
 * environments in every line of the log (the smoke run proved they collide) */
static const char *F560_SEC = "-";

static void f560_arm(const char *env, const char *arm, uint8_t fam,
		     const char *table, const char *chain, uint32_t base,
		     int off, int len, const unsigned char *imm, int do_store,
		     const unsigned char *fr, int flen, const char *sdev,
		     unsigned short sproto, const unsigned char *magic, int mlen,
		     int wfd, int rfd, const struct f559_out *base_out,
		     struct f559_out *out)
{
	struct f559_out o;
	char cw[1024], cr[1024], hw[256], hr[256];
	int kw = 0, kr = 0;

	memset(&o, 0, sizeof(o));
	snprintf(PRE57, sizeof(PRE57), "f60.%s.%s", env, arm);
	f557_flush(fam, table, chain, &o.acks);
	o.rc = f557_install(fam, table, chain, 0, base, (uint32_t)off,
			    (uint32_t)len, imm, do_store ? len : 0, do_store, 5,
			    PRE57, &o.acks);
	nfl_drain(NFL59);
	o.cnt0 = f555_count(fam, table, chain);
	{
		unsigned long long ip0 = f558_ipin();

		f560_send2(sdev, sproto, fr, flen, magic, mlen, wfd, rfd, &o);
		usleep(20000);
		o.ipin = f558_ipin() - ip0;
	}
	o.cnt = f555_count(fam, table, chain);
	if (base_out && o.wn > 0 && base_out->wn > 0)
		kw = f558_chg(cw, sizeof(cw), base_out->w, base_out->wn, o.w,
			      o.wn);
	if (base_out && o.rn > 0 && base_out->rn > 0)
		kr = f558_chg(cr, sizeof(cr), base_out->r, base_out->rn, o.r,
			      o.rn);
	printf("F560 R|env=%s.%s|arm=%s|fam=%u|base=%u|off=%d|len=%d|store=%d|"
	       "rc=%d|acks=%d|snd=%d|cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|"
	       "wn=%d|wpt=%d|wchg=%d|wchgs=%s|whex=%s|"
	       "rn=%d|rpt=%d|rchg=%d|rchgs=%s|rhex=%s\n",
	       F560_SEC, env, arm, (unsigned)fam, (unsigned)base, off, len,
	       do_store,
	       o.rc, o.acks, o.snd, o.cnt0, o.cnt, o.cnt - o.cnt0, o.ipin,
	       o.wn, o.wpt, kw, cw[0] ? cw : "-",
	       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn) : "-",
	       o.rn, o.rpt, kr, cr[0] ? cr : "-",
	       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn) : "-");
	if (out)
		memcpy(out, &o, sizeof(o));
}

/* the 12x3 grid (36 cells), every (off,len) of it */
static void f560_grid36(const char *env, uint8_t fam, const char *table,
			const char *chain, uint32_t base,
			const unsigned char *fr, int flen, int kind,
			const char *sdev, unsigned short sproto,
			const unsigned char *magic, int mlen, int wfd, int rfd,
			const struct f559_out *ctl)
{
	unsigned char imm[16];
	char arm[32];
	int i, j;

	for (i = 0; i < G33_NOFF; i++) {
		for (j = 0; j < G33_NLEN; j++) {
			f556_imm(kind, G33_OFF[i], G33_LEN[j], imm);
			snprintf(arm, sizeof(arm), "g%d_%d", G33_OFF[i],
				 G33_LEN[j]);
			f560_arm(env, arm, fam, table, chain, base, G33_OFF[i],
				 G33_LEN[j], imm, G33_LEN[j], fr, flen, sdev,
				 sproto, magic, mlen, wfd, rfd, ctl, NULL);
		}
	}
}

/* the same 36 cells plus the four wide arms = F33's 40-cell grid */
static void f560_grid40(const char *env, uint8_t fam, const char *table,
			const char *chain, uint32_t base,
			const unsigned char *fr, int flen, int kind,
			const char *sdev, unsigned short sproto,
			const unsigned char *magic, int mlen, int wfd, int rfd,
			const struct f559_out *ctl)
{
	unsigned char imm[16];
	char arm[32];
	int i;

	f560_grid36(env, fam, table, chain, base, fr, flen, kind, sdev, sproto,
		    magic, mlen, wfd, rfd, ctl);
	for (i = 0; i < G33_NEXT; i++) {
		f556_imm(kind, G33_XOFF[i], G33_XLEN[i], imm);
		snprintf(arm, sizeof(arm), "x%d_%d", G33_XOFF[i], G33_XLEN[i]);
		f560_arm(env, arm, fam, table, chain, base, G33_XOFF[i],
			 G33_XLEN[i], imm, G33_XLEN[i], fr, flen, sdev, sproto,
			 magic, mlen, wfd, rfd, ctl, NULL);
	}
}

/* ---------- recv: five representations of one tagged frame ---------- */

struct f560_rep {
	const char *tag;
	int kind;
	unsigned int tpid;	/* 0 = no tag in the frame bytes */
	unsigned int tci;
	const unsigned char *mtag;	/* four bytes for the `pre` chain, or NULL */
	unsigned short sproto;	/* sll_protocol of the send */
	int only_x;		/* 1 = only the eight informative cells */
};

/* the eight cells that a tag moves: (10,4) (12,1) (12,2) (12,4) (14,2)
 * (16,1) (16,2) (16,4) */
static const int X560_OFF[8] = { 10, 12, 12, 12, 14, 16, 16, 16 };
static const int X560_LEN[8] = { 4, 1, 2, 4, 2, 1, 2, 4 };

static int X560_IS(int off, int len)
{
	int k;

	for (k = 0; k < 8; k++)
		if (X560_OFF[k] == off && X560_LEN[k] == len)
			return 1;
	return 0;
}

static void f560_sec_recv(void)
{
	static const struct f560_rep reps[] = {
		{ "p",    FK33_IP4, 0,      0,      NULL, 0x0800, 0 },
		{ "w100", FK33_IP4, 0x8100, 0x0064, NULL, 0x8100, 0 },
		{ "m100", FK33_IP4, 0,      0,
		  (const unsigned char *)"\x81\x00\x00\x64", 0x0800, 0 },
		{ "v0",   FK33_IP4, 0x8100, 0x0000, NULL, 0x8100, 1 },
		{ "x91",  FK33_IP4, 0x9100, 0x0064, NULL, 0x9100, 1 },
	};
	struct f559_out ctl;
	unsigned char fr[512], imm[16];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int acks = 0, r, i, j, flen;

	F560_SEC = "recv";
	printf("F560 SECTION|recv|wfd=%d|rfd=%d|reps=%d\n", wfd, rfd,
	       (int)(sizeof(reps) / sizeof(reps[0])));
	if (add_table(NFPROTO_BRIDGE, "p60a") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p60a", "pre", 0, 0, 1, NULL) ||
	    f556_add_chain(NFPROTO_BRIDGE, "p60a", "g", 0, 10, 1, NULL)) {
		printf("F560 FAIL|recv|chain\n");
		return;
	}
	for (r = 0; r < (int)(sizeof(reps) / sizeof(reps[0])); r++) {
		if (reps[r].tpid)
			flen = f560_tag(fr, reps[r].kind, reps[r].tpid,
					reps[r].tci);
		else
			flen = f556_frame(reps[r].kind, fr);
		/* the `pre` chain holds the tag store, or nothing at all */
		f557_flush(NFPROTO_BRIDGE, "p60a", "pre", &acks);
		if (reps[r].mtag) {
			int prerc;

			snprintf(PRE57, sizeof(PRE57), "f60.tag.%s",
				 reps[r].tag);
			prerc = f557_install(NFPROTO_BRIDGE, "p60a", "pre", 0,
					     NFT_PAYLOAD_LL_HEADER, 12, 4,
					     reps[r].mtag, 4, 1, 5, PRE57,
					     &acks);
			printf("F560 TAGSTORE|rep=%s|rc=%d|acks=%d|off=12|len=4|"
			       "imm=%02x%02x%02x%02x\n", reps[r].tag, prerc,
			       acks, reps[r].mtag[0], reps[r].mtag[1],
			       reps[r].mtag[2], reps[r].mtag[3]);
		}
		printf("F560 REP|env=recv|rep=%s|flen=%d|tpid=%04x|tci=%04x|"
		       "meta=%d|sproto=%04x|only_x=%d\n", reps[r].tag, flen,
		       reps[r].tpid, reps[r].tci, reps[r].mtag != NULL,
		       reps[r].sproto, reps[r].only_x);
		memset(&ctl, 0, sizeof(ctl));
		f560_arm(reps[r].tag, "ctl", NFPROTO_BRIDGE, "p60a", "g", 0, 0, 0,
			 NULL, 0, fr, flen, "s0", reps[r].sproto, MAGIC77, 8,
			 wfd, rfd, NULL, &ctl);
		for (i = 0; i < G33_NOFF; i++) {
			for (j = 0; j < G33_NLEN; j++) {
				char arm[32];

				if (reps[r].only_x &&
				    !X560_IS(G33_OFF[i], G33_LEN[j]))
					continue;
				f556_imm(reps[r].kind, G33_OFF[i], G33_LEN[j],
					 imm);
				snprintf(arm, sizeof(arm), "g%d_%d",
					 G33_OFF[i], G33_LEN[j]);
				f560_arm(reps[r].tag, arm, NFPROTO_BRIDGE,
					 "p60a", "g", NFT_PAYLOAD_LL_HEADER,
					 G33_OFF[i], G33_LEN[j], imm,
					 G33_LEN[j], fr, flen, "s0",
					 reps[r].sproto, MAGIC77, 8, wfd, rfd,
					 &ctl, NULL);
			}
		}
	}
	sh("/nft flush ruleset");
}

/* ---------- ndin: the ingress hook, three ethertypes ---------- */

static void f560_sec_ndin(void)
{
	struct f559_out ctl;
	unsigned char fr[512];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int flen, i;
	static const struct {
		const char *tag;
		unsigned int tpid;
		unsigned short sproto;
	} reps[] = {
		{ "p",    0,      0x0800 },
		{ "w100", 0x8100, 0x8100 },
		{ "x91",  0x9100, 0x9100 },
	};

	F560_SEC = "ndin";
	printf("F560 SECTION|ndin|wfd=%d|rfd=%d\n", wfd, rfd);
	if (add_table(NFPROTO_NETDEV, "p60b") ||
	    f556_add_chain(NFPROTO_NETDEV, "p60b", "ing", 0, 0, 1, "s1")) {
		printf("F560 FAIL|ndin|chain\n");
		return;
	}
	for (i = 0; i < 3; i++) {
		if (reps[i].tpid)
			flen = f560_tag(fr, FK33_IP4, reps[i].tpid, 0x0064);
		else
			flen = f556_frame(FK33_IP4, fr);
		printf("F560 REP|env=ndin|rep=%s|flen=%d|sproto=%04x|dev=s1\n",
		       reps[i].tag, flen, reps[i].sproto);
		memset(&ctl, 0, sizeof(ctl));
		f560_arm(reps[i].tag, "ctl", NFPROTO_NETDEV, "p60b", "ing", 0, 0,
			 0, NULL, 0, fr, flen, "s0", reps[i].sproto, MAGIC77,
			 8, wfd, rfd, NULL, &ctl);
		f560_grid40(reps[i].tag, NFPROTO_NETDEV, "p60b", "ing",
			    NFT_PAYLOAD_NETWORK_HEADER, fr, flen, FK33_IP4, "s0",
			    reps[i].sproto, MAGIC77, 8, wfd, rfd, &ctl);
	}
	sh("/nft flush ruleset");
}

/* ---------- ndeg: the egress hook, three sll_protocol values ---------- */

static void f560_sec_ndeg(void)
{
	struct f559_out ctl;
	unsigned char fr[512];
	int wfd = cap_open("i0"), rfd = cap_open("i1");
	int flen, i;
	static const struct {
		const char *tag;
		unsigned int tpid;
		unsigned short sproto;
	} reps[] = {
		{ "s0800", 0,      0x0800 },
		{ "s8100", 0x8100, 0x8100 },
		{ "s9100", 0x9100, 0x9100 },
	};

	F560_SEC = "ndeg";
	printf("F560 SECTION|ndeg|wfd=%d|rfd=%d\n", wfd, rfd);
	if (add_table(NFPROTO_NETDEV, "p60c") ||
	    f556_add_chain(NFPROTO_NETDEV, "p60c", "egr", 1, 0, 1, "i0")) {
		printf("F560 FAIL|ndeg|chain\n");
		return;
	}
	for (i = 0; i < 3; i++) {
		if (reps[i].tpid)
			flen = f560_tag(fr, FK33_IP4, reps[i].tpid, 0x0064);
		else
			flen = f556_frame(FK33_IP4, fr);
		printf("F560 REP|env=ndeg|rep=%s|flen=%d|sproto=%04x|dev=i0\n",
		       reps[i].tag, flen, reps[i].sproto);
		memset(&ctl, 0, sizeof(ctl));
		f560_arm(reps[i].tag, "ctl", NFPROTO_NETDEV, "p60c", "egr", 0, 0,
			 0, NULL, 0, fr, flen, "i0", reps[i].sproto, MAGIC77,
			 8, wfd, rfd, NULL, &ctl);
		f560_grid40(reps[i].tag, NFPROTO_NETDEV, "p60c", "egr",
			    NFT_PAYLOAD_NETWORK_HEADER, fr, flen, FK33_IP4, "i0",
			    reps[i].sproto, MAGIC77, 8, wfd, rfd, &ctl);
	}
	sh("/nft flush ruleset");
}

/* ---------- arp: F32's branch through the new envelope ---------- */

static void f560_sec_arp(void)
{
	struct f559_out ctl;
	unsigned char fr[512];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int flen, i;
	static const struct {
		const char *tag;
		unsigned int tpid;
		unsigned short sproto;
	} reps[] = {
		{ "a",    0,      0x0806 },
		{ "aw100", 0x8100, 0x8100 },
		{ "ax91", 0x9100, 0x9100 },
	};

	F560_SEC = "arp";
	printf("F560 SECTION|arp|wfd=%d|rfd=%d\n", wfd, rfd);
	if (add_table(NFPROTO_BRIDGE, "p60d") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p60d", "g", 0, 0, 1, NULL)) {
		printf("F560 FAIL|arp|chain\n");
		return;
	}
	for (i = 0; i < 3; i++) {
		if (reps[i].tpid)
			flen = f560_tag(fr, FK33_ARP, reps[i].tpid, 0x0064);
		else
			flen = f556_frame(FK33_ARP, fr);
		printf("F560 REP|env=arp|rep=%s|flen=%d|sproto=%04x|dev=s0\n",
		       reps[i].tag, flen, reps[i].sproto);
		memset(&ctl, 0, sizeof(ctl));
		f560_arm(reps[i].tag, "ctl", NFPROTO_BRIDGE, "p60d", "g", 0, 0, 0,
			 NULL, 0, fr, flen, "s0", reps[i].sproto, MAC_SRC, 6,
			 wfd, rfd, NULL, &ctl);
		f560_grid40(reps[i].tag, NFPROTO_BRIDGE, "p60d", "g",
			    NFT_PAYLOAD_NETWORK_HEADER, fr, flen, FK33_ARP, "s0",
			    reps[i].sproto, MAC_SRC, 6, wfd, rfd, &ctl);
	}
	sh("/nft flush ruleset");
}

/* ---------- drop: one rule, two representations, two verdicts ---------- */

static void f560_sec_drop(void)
{
	static const struct {
		const char *tag;
		int off, len;
		unsigned int tpid;
		unsigned short sproto;
	} arms[] = {
		{ "ctl_p", 0, 0, 0, 0x0800 },
		{ "ctl_w", 0, 0, 0x8100, 0x8100 },
		{ "p16_2", 16, 2, 0, 0x0800 },
		{ "w16_2", 16, 2, 0x8100, 0x8100 },
		{ "p14_2", 14, 2, 0, 0x0800 },
		{ "w14_2", 14, 2, 0x8100, 0x8100 },
	};
	struct f559_out o;
	unsigned char fr[512], imm[16];
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int i, flen;

	F560_SEC = "drop";
	printf("F560 SECTION|drop|wfd=%d|rfd=%d\n", wfd, rfd);
	if (add_table(NFPROTO_BRIDGE, "p60e") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p60e", "g", 0, 0, 0, NULL)) {
		printf("F560 FAIL|drop|chain\n");
		return;
	}
	for (i = 0; i < (int)(sizeof(arms) / sizeof(arms[0])); i++) {
		if (arms[i].tpid)
			flen = f560_tag(fr, FK33_IP4, arms[i].tpid, 0x0064);
		else
			flen = f556_frame(FK33_IP4, fr);
		f556_imm(FK33_IP4, arms[i].off, arms[i].len, imm);
		f560_arm("drop", arms[i].tag, NFPROTO_BRIDGE, "p60e", "g",
			 NFT_PAYLOAD_LL_HEADER, arms[i].off, arms[i].len, imm,
			 arms[i].len, fr, flen, "s0", arms[i].sproto, MAGIC77,
			 8, wfd, rfd, NULL, &o);
	}
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int f560_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f560";

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F560 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F560 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F560 KERNEL|%s\n", "7.3.4-T558");
	f556_env_setup();
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL59 = nfl_open(5);
	printf("F560 NFL|%d\n", NFL59);
	/* the tag must survive the egress port, or the wire view is 60 bytes
	 * of nothing -- F37's one feature bit, cleared here once */
	if (!strcmp(mode, "f560recv")) {
		f559_setoff("clear", "r1", 0);
		f560_sec_recv();
	} else if (!strcmp(mode, "f560ndin")) {
		f559_setoff("clear", "r1", 0);
		f560_sec_ndin();
	} else if (!strcmp(mode, "f560ndeg")) {
		f560_sec_ndeg();
	} else if (!strcmp(mode, "f560arp")) {
		f559_setoff("clear", "r1", 0);
		f560_sec_arp();
	} else if (!strcmp(mode, "f560drop")) {
		f559_setoff("clear", "r1", 0);
		f560_sec_drop();
	} else {
		f559_setoff("clear", "r1", 0);
		f560_sec_recv();
		f560_sec_ndin();
		f560_sec_ndeg();
		f560_sec_arp();
		f560_sec_drop();
	}
	printf("F560 DONE\n");
	return 0;
}
/* differ561_add.c -- turn 561 / F39: 802.1AD and Q-in-Q.
 *
 * F38 ended with "на veth метку в байтах кадра не показать" and with a promise:
 * eth_type_vlan() knows two constants and only one of them was measured.
 *
 * This instrument measures the second one -- 0x88a8 -- and the two-tag frame.
 * Same kernel as F36..F38 (7.3.4-T558), no new build: every file that matters
 * (nft_payload.c, nft_chain_filter.c, nft_meta.c, skbuff.c, dev.c, vlan_core.c)
 * is byte-for-byte the one those findings measured.
 *
 *   meta   what the packet IS, per representation: `meta protocol` compared
 *          against eight candidate ethertypes.  The counter is the oracle, so
 *          the value is read out of a match, never out of a print.
 *   ll     bridge prerouting, base ll, the 36-cell grid, six representations.
 *   unlock the same 40-cell network grid with and without a `meta protocol`
 *          expression in front of the store: the guard switches on pkt->ethertype,
 *          and pkt->ethertype is a field another expression may rewrite.
 *   xmit   the way out.  F37's one feature bit (NETIF_F_HW_VLAN_CTAG_TX) plus
 *          the one it never touched (NETIF_F_HW_VLAN_STAG_TX, bit 46): whether
 *          a stored skb->vlan_proto survives to the wire depends on both.
 *   far    the receiving side of a two-tag frame, no bridge: one pop or two?
 *   ndin   netdev ingress on the bridge port, the 40-cell network grid on a
 *          plain and on a QinQ frame: both are 40/40, and the bytes tell where
 *          "accepted" ends and "landed in the field" begins.
 *
 * Views: w = AF_PACKET on r1 (or i0), after validate_xmit_skb; r = AF_PACKET on
 * r0 (or i1), after skb_vlan_untag.  Oracle for every store: the rule's own
 * counter, read before and after one send.
 */

/* ---------- frames ---------- */

struct f561_rep {
	const char *tag;
	int ntag;
	unsigned int tp1, tc1, tp2, tc2;
};

static const struct f561_rep R561[] = {
	{ "p",   0, 0x0000, 0x0000, 0x0000, 0x0000 },
	{ "w",   1, 0x8100, 0x0064, 0x0000, 0x0000 },
	{ "s88", 1, 0x88a8, 0x0064, 0x0000, 0x0000 },
	{ "q",   2, 0x88a8, 0x0064, 0x8100, 0x00c8 },
	{ "q81", 2, 0x8100, 0x0064, 0x8100, 0x00c8 },
	{ "x91", 1, 0x9100, 0x0064, 0x0000, 0x0000 },
};
#define N561 ((int)(sizeof(R561) / sizeof(R561[0])))

/* the plain frame with ntag tags inserted in front of its ethertype */
static int f561_mkframe(const struct f561_rep *r, unsigned char *out)
{
	unsigned char tmp[512];
	unsigned int tp[2], tc[2];
	int n = f556_frame(FK33_IP4, tmp), i;

	tp[0] = r->tp1; tc[0] = r->tc1;
	tp[1] = r->tp2; tc[1] = r->tc2;
	memset(out, 0, 512);
	memcpy(out, tmp, 12);
	for (i = 0; i < r->ntag; i++) {
		out[12 + 4 * i] = (unsigned char)(tp[i] >> 8);
		out[13 + 4 * i] = (unsigned char)tp[i];
		out[14 + 4 * i] = (unsigned char)(tc[i] >> 8);
		out[15 + 4 * i] = (unsigned char)tc[i];
	}
	memcpy(out + 12 + 4 * r->ntag, tmp + 12, (size_t)(n - 12));
	return n + 4 * r->ntag;
}

/* the ethertype the frame announces (what eth_type_trans() will copy) */
static unsigned short f561_proto(const struct f561_rep *r)
{
	return r->ntag ? (unsigned short)r->tp1 : 0x0800;
}

static const unsigned char M561_77[8] = { 0x77, 0x77, 0x77, 0x77,
					  0x77, 0x77, 0x77, 0x77 };

/* ---------- rules: up to one gate in front of one store ---------- */

#define F561_GATE_NONE		0
#define F561_GATE_META_NE	1	/* meta protocol != 0xffff  */
#define F561_GATE_META_EQ	2	/* meta protocol == want    */
#define F561_REG_META		NFT_REG32_08

static int f561_rule(uint8_t fam, const char *table, const char *chain,
		     int gate, unsigned int want, uint32_t base, uint32_t off,
		     uint32_t len, const unsigned char *imm, int immlen,
		     int do_store, int loggroup, const char *prefix, int *acks)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs, *e, *d, *cd;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			fam);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (gate != F561_GATE_NONE) {
		uint16_t v = htons((uint16_t)(gate == F561_GATE_META_EQ ? want
								       : 0xffff));

		e = nest_start(nlh, NFTA_LIST_ELEM);
		put_str(nlh, NFTA_EXPR_NAME, "meta");
		d = nest_start(nlh, NFTA_EXPR_DATA);
		put_be32(nlh, NFTA_META_KEY, NFT_META_PROTOCOL);
		put_be32(nlh, NFTA_META_DREG, F561_REG_META);
		nest_end(nlh, d);
		nest_end(nlh, e);

		e = nest_start(nlh, NFTA_LIST_ELEM);
		put_str(nlh, NFTA_EXPR_NAME, "cmp");
		d = nest_start(nlh, NFTA_EXPR_DATA);
		put_be32(nlh, NFTA_CMP_SREG, F561_REG_META);
		put_be32(nlh, NFTA_CMP_OP,
			 gate == F561_GATE_META_EQ ? NFT_CMP_EQ : NFT_CMP_NEQ);
		cd = nest_start(nlh, NFTA_CMP_DATA);
		attr_put(nlh, NFTA_DATA_VALUE, &v, 2);
		nest_end(nlh, cd);
		nest_end(nlh, d);
		nest_end(nlh, e);
	}
	if (do_store) {
		imm_value(nlh, NFT_REG32_00, imm, immlen);
		e = nest_start(nlh, NFTA_LIST_ELEM);
		put_str(nlh, NFTA_EXPR_NAME, "payload");
		d = nest_start(nlh, NFTA_EXPR_DATA);
		put_be32(nlh, NFTA_PAYLOAD_SREG, NFT_REG32_00);
		put_be32(nlh, NFTA_PAYLOAD_BASE, base);
		put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
		put_be32(nlh, NFTA_PAYLOAD_LEN, len);
		put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
		put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
		nest_end(nlh, d);
		nest_end(nlh, e);
	}
	log_expr(nlh, loggroup, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, acks);
}

/* ---------- one arm ---------- */

static const char *F561_SEC = "-";

static void f561_arm(const char *env, const char *arm, int gate,
		     unsigned int want, uint8_t fam, const char *table,
		     const char *chain, uint32_t base, int off, int len,
		     const unsigned char *imm, int do_store,
		     const unsigned char *fr, int flen, const char *sdev,
		     unsigned short sproto, const unsigned char *magic, int mlen,
		     int wfd, int rfd, const struct f559_out *base_out,
		     struct f559_out *out)
{
	struct f559_out o;
	char cw[1024], cr[1024], hw[512], hr[512];
	int kw = 0, kr = 0;

	/* F39: without this, an arm with no baseline printed the PREVIOUS arm's
	 * diff string (uninitialised stack) under wchg=0.  Found by reading the
	 * ll.q control of the smoke, fixed before any number was quoted. */
	cw[0] = 0;
	cr[0] = 0;

	memset(&o, 0, sizeof(o));
	snprintf(PRE57, sizeof(PRE57), "f61.%s.%s", env, arm);
	f557_flush(fam, table, chain, &o.acks);
	o.rc = f561_rule(fam, table, chain, gate, want, base, (uint32_t)off,
			 (uint32_t)len, imm, do_store ? len : 0, do_store, 5,
			 PRE57, &o.acks);
	nfl_drain(NFL59);
	o.cnt0 = f555_count(fam, table, chain);
	{
		unsigned long long ip0 = f558_ipin();

		f560_send2(sdev, sproto, fr, flen, magic, mlen, wfd, rfd, &o);
		usleep(20000);
		o.ipin = f558_ipin() - ip0;
	}
	o.cnt = f555_count(fam, table, chain);
	if (base_out && o.wn > 0 && base_out->wn > 0)
		kw = f558_chg(cw, sizeof(cw), base_out->w, base_out->wn, o.w,
			      o.wn);
	if (base_out && o.rn > 0 && base_out->rn > 0)
		kr = f558_chg(cr, sizeof(cr), base_out->r, base_out->rn, o.r,
			      o.rn);
	printf("F561 R|env=%s.%s|arm=%s|gate=%d|want=%04x|fam=%u|base=%u|"
	       "off=%d|len=%d|store=%d|"
	       "rc=%d|acks=%d|snd=%d|cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|"
	       "wn=%d|wpt=%d|wchg=%d|wchgs=%s|whex=%s|"
	       "rn=%d|rpt=%d|rchg=%d|rchgs=%s|rhex=%s\n",
	       F561_SEC, env, arm, gate, want, (unsigned)fam, (unsigned)base,
	       off, len, do_store,
	       o.rc, o.acks, o.snd, o.cnt0, o.cnt, o.cnt - o.cnt0, o.ipin,
	       o.wn, o.wpt, kw, cw[0] ? cw : "-",
	       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn) : "-",
	       o.rn, o.rpt, kr, cr[0] ? cr : "-",
	       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn) : "-");
	if (out)
		memcpy(out, &o, sizeof(o));
}

/* the 36-cell grid */
static void f561_grid36(const char *env, uint8_t fam, const char *table,
			const char *chain, uint32_t base, int gate,
			const unsigned char *fr, int flen, const char *sdev,
			unsigned short sproto, const unsigned char *magic,
			int mlen, int wfd, int rfd, const struct f559_out *ctl)
{
	unsigned char imm[16];
	char arm[32];
	int i, j;

	for (i = 0; i < G33_NOFF; i++) {
		for (j = 0; j < G33_NLEN; j++) {
			f556_imm(FK33_IP4, G33_OFF[i], G33_LEN[j], imm);
			snprintf(arm, sizeof(arm), "g%d_%d", G33_OFF[i],
				 G33_LEN[j]);
			f561_arm(env, arm, gate, 0, fam, table, chain, base,
				 G33_OFF[i], G33_LEN[j], imm, G33_LEN[j], fr,
				 flen, sdev, sproto, magic, mlen, wfd, rfd, ctl,
				 NULL);
		}
	}
}

/* the 36 cells plus the four wide arms = the 40-cell grid */
static void f561_grid40(const char *env, uint8_t fam, const char *table,
			const char *chain, uint32_t base, int gate,
			const unsigned char *fr, int flen, const char *sdev,
			unsigned short sproto, const unsigned char *magic,
			int mlen, int wfd, int rfd, const struct f559_out *ctl)
{
	unsigned char imm[16];
	char arm[32];
	int i;

	f561_grid36(env, fam, table, chain, base, gate, fr, flen, sdev, sproto,
		    magic, mlen, wfd, rfd, ctl);
	for (i = 0; i < G33_NEXT; i++) {
		f556_imm(FK33_IP4, G33_XOFF[i], G33_XLEN[i], imm);
		snprintf(arm, sizeof(arm), "x%d_%d", G33_XOFF[i], G33_XLEN[i]);
		f561_arm(env, arm, gate, 0, fam, table, chain, base, G33_XOFF[i],
			 G33_XLEN[i], imm, G33_XLEN[i], fr, flen, sdev, sproto,
			 magic, mlen, wfd, rfd, ctl, NULL);
	}
}

/* ---------- feature bits ---------- */

#define F561_CTAG_TX_BIT	7	/* NETIF_F_HW_VLAN_CTAG_TX_BIT */
#define F561_STAG_TX_BIT	45	/* NETIF_F_HW_VLAN_STAG_TX_BIT */
#define F561_STAG_SHIFT		(F561_STAG_TX_BIT - 32)

static void f561_feat(const char *stage, const char *dev)
{
	struct f559_fblk b[F559_FWORDS];
	int n = 0, i, rc = f559_gfeat(dev, b, F559_FWORDS, &n);

	printf("F561 FEAT|stage=%s|dev=%s|rc=%d|nwords=%d", stage, dev, rc, n);
	if (rc == 0) {
		for (i = 0; i < n && i < F559_FWORDS; i++)
			printf("|avail%d=%08x|want%d=%08x|act%d=%08x", i,
			       b[i].avail, i, b[i].want, i, b[i].act);
		printf("|ctag_tx=%d|stag_tx=%d|stag_rx=%d",
		       (int)((b[0].act >> F561_CTAG_TX_BIT) & 1),
		       n > 1 ? (int)((b[1].act >> F561_STAG_SHIFT) & 1) : -1,
		       n > 1 ? (int)((b[1].act >> (F561_STAG_SHIFT + 1)) & 1)
			     : -1);
	}
	printf("\n");
}

static int f561_sfeat2(const char *dev, int nblk, unsigned int v0,
		       unsigned int r0, unsigned int v1, unsigned int r1)
{
	struct {
		unsigned int cmd, size;
		struct {
			unsigned int valid, req;
		} b[F559_FWORDS];
	} c;
	struct ifreq ifr;
	int fd, rc;

	memset(&c, 0, sizeof(c));
	c.cmd = F559_SFEATURES;
	c.size = (unsigned int)nblk;
	c.b[0].valid = v0;
	c.b[0].req = r0;
	c.b[1].valid = v1;
	c.b[1].req = r1;
	memset(&ifr, 0, sizeof(ifr));
	snprintf(ifr.ifr_name, IFNAMSIZ, "%s", dev);
	ifr.ifr_data = (char *)&c;
	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0)
		return -1;
	rc = ioctl(fd, SIOCETHTOOL, &ifr);
	close(fd);
	return rc < 0 ? -errno : rc;
}

/* ctag/stag: 1 = ask for the bit, 0 = ask it away.  Returns the raw ioctl. */
static int f561_setbits(const char *stage, const char *dev, int ctag, int stag)
{
	struct f559_fblk b[F559_FWORDS];
	unsigned int v0 = 1u << F561_CTAG_TX_BIT, r0 = 0;
	unsigned int v1 = 0, r1 = 0;
	int n = 0, rc;

	if (f559_gfeat(dev, b, F559_FWORDS, &n) < 0 || n <= 0) {
		printf("F561 SET|stage=%s|dev=%s|no_gfeat\n", stage, dev);
		return -1;
	}
	if (ctag)
		r0 = v0;
	if (n > 1) {
		v1 = 1u << F561_STAG_SHIFT;
		if (stag)
			r1 = v1;
	}
	rc = f561_sfeat2(dev, n, v0, r0, v1, r1);
	printf("F561 SET|stage=%s|dev=%s|nwords=%d|valid0=%08x|req0=%08x|"
	       "valid1=%08x|req1=%08x|rc=%d|f_unsup=%d|f_wish=%d\n",
	       stage, dev, n, v0, r0, v1, r1, rc, rc >= 0 ? (rc & 1) : -1,
	       rc >= 0 ? (rc & 2) : -1);
	f561_feat(stage, dev);
	return rc;
}

/* ---------- meta: what the packet is ---------- */

static const unsigned int V561[8] = { 0x0800, 0x0806, 0x8100, 0x88a8,
				      0x9100, 0x4500, 0x86dd, 0x0002 };

static void f561_sec_meta(void)
{
	unsigned char fr[512];
	int r, v, acks = 0, flen;
	struct f559_out o;

	F561_SEC = "meta";
	f561_feat("meta.in", "r1");
	if (add_table(NFPROTO_BRIDGE, "p61a") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p61a", "g", 0, 0, 1, NULL)) {
		printf("F561 FAIL|meta|chain\n");
		return;
	}
	for (r = 0; r < N561; r++) {
		flen = f561_mkframe(&R561[r], fr);
		memset(&o, 0, sizeof(o));
		snprintf(PRE57, sizeof(PRE57), "f61.meta.%s.ctl", R561[r].tag);
		f557_flush(NFPROTO_BRIDGE, "p61a", "g", &acks);
		o.rc = f561_rule(NFPROTO_BRIDGE, "p61a", "g", F561_GATE_NONE, 0,
				 0, 0, 0, NULL, 0, 0, 5, PRE57, &acks);
		o.cnt0 = f555_count(NFPROTO_BRIDGE, "p61a", "g");
		o.snd = pkt_send_p("s0", fr, flen, f561_proto(&R561[r]));
		usleep(20000);
		o.cnt = f555_count(NFPROTO_BRIDGE, "p61a", "g");
		printf("F561 M|env=meta|rep=%s|want=-|ctl=1|rc=%d|acks=%d|"
		       "snd=%d|cnt0=%llu|cnt=%llu|live=%llu\n",
		       R561[r].tag, o.rc, o.acks, o.snd, o.cnt0, o.cnt,
		       o.cnt - o.cnt0);
		for (v = 0; v < 8; v++) {
			f557_flush(NFPROTO_BRIDGE, "p61a", "g", &acks);
			snprintf(PRE57, sizeof(PRE57), "f61.meta.%s.%04x",
				 R561[r].tag, V561[v]);
			o.rc = f561_rule(NFPROTO_BRIDGE, "p61a", "g",
					 F561_GATE_META_EQ, V561[v], 0, 0, 0,
					 NULL, 0, 0, 5, PRE57, &acks);
			o.cnt0 = f555_count(NFPROTO_BRIDGE, "p61a", "g");
			o.snd = pkt_send_p("s0", fr, flen,
					   f561_proto(&R561[r]));
			usleep(20000);
			o.cnt = f555_count(NFPROTO_BRIDGE, "p61a", "g");
			printf("F561 M|env=meta|rep=%s|want=%04x|ctl=0|rc=%d|"
			       "acks=%d|snd=%d|cnt0=%llu|cnt=%llu|live=%llu\n",
			       R561[r].tag, V561[v], o.rc, o.acks, o.snd,
			       o.cnt0, o.cnt, o.cnt - o.cnt0);
		}
	}
	sh("/nft flush ruleset");
}

/* ---------- ll: the 36-cell grid over six representations ---------- */

static void f561_sec_ll(void)
{
	unsigned char fr[512];
	struct f559_out ctl;
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int r, flen;

	F561_SEC = "ll";
	f561_feat("ll.in", "r1");
	printf("F561 SECTION|ll|wfd=%d|rfd=%d|reps=%d\n", wfd, rfd, N561);
	if (add_table(NFPROTO_BRIDGE, "p61b") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p61b", "g", 0, 0, 1, NULL)) {
		printf("F561 FAIL|ll|chain\n");
		return;
	}
	for (r = 0; r < N561; r++) {
		flen = f561_mkframe(&R561[r], fr);
		printf("F561 REP|env=ll|rep=%s|flen=%d|ntag=%d|tp1=%04x|"
		       "tp2=%04x|sproto=%04x\n",
		       R561[r].tag, flen, R561[r].ntag, R561[r].tp1,
		       R561[r].tp2, f561_proto(&R561[r]));
		memset(&ctl, 0, sizeof(ctl));
		f561_arm(R561[r].tag, "ctl", F561_GATE_NONE, 0, NFPROTO_BRIDGE,
			 "p61b", "g", NFT_PAYLOAD_LL_HEADER, 0, 0, NULL, 0, fr,
			 flen, "s0", f561_proto(&R561[r]), M561_77, 8, wfd,
			 rfd, NULL, &ctl);
		f561_grid36(R561[r].tag, NFPROTO_BRIDGE, "p61b", "g",
			    NFT_PAYLOAD_LL_HEADER, F561_GATE_NONE, fr, flen, "s0",
			    f561_proto(&R561[r]), M561_77, 8, wfd, rfd, &ctl);
	}
	sh("/nft flush ruleset");
}

/* ---------- unlock: the guard reads a field another expression rewrites ---- */

static void f561_sec_unlock(void)
{
	static const int reps[2] = { 1, 3 };	/* w, q */
	unsigned char fr[512];
	struct f559_out ctl;
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int k, r, flen, gate;

	F561_SEC = "unlock";
	f561_feat("unlock.in", "r1");
	printf("F561 SECTION|unlock|wfd=%d|rfd=%d\n", wfd, rfd);
	if (add_table(NFPROTO_BRIDGE, "p61c") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p61c", "g", 0, 0, 1, NULL)) {
		printf("F561 FAIL|unlock|chain\n");
		return;
	}
	for (k = 0; k < 2; k++) {
		r = reps[k];
		flen = f561_mkframe(&R561[r], fr);
		for (gate = 0; gate < 2; gate++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", R561[r].tag,
				 gate ? "meta" : "bare");
			printf("F561 REP|env=unlock|rep=%s|flen=%d|gate=%d\n",
			       env, flen, gate);
			memset(&ctl, 0, sizeof(ctl));
			f561_arm(env, "ctl", F561_GATE_NONE, 0,
				 NFPROTO_BRIDGE, "p61c", "g",
				 NFT_PAYLOAD_NETWORK_HEADER, 0, 0, NULL, 0, fr,
				 flen, "s0", f561_proto(&R561[r]), M561_77, 8,
				 wfd, rfd, NULL, &ctl);
			f561_grid40(env, NFPROTO_BRIDGE, "p61c", "g",
				    NFT_PAYLOAD_NETWORK_HEADER,
				    gate ? F561_GATE_META_NE : F561_GATE_NONE,
				    fr, flen, "s0", f561_proto(&R561[r]),
				    M561_77, 8, wfd, rfd, &ctl);
		}
	}
	sh("/nft flush ruleset");
}

/* ---------- xmit: does a stored vlan_proto survive the wire? ---------- */

static void f561_sec_xmit(void)
{
	static const struct {
		const char *tag;
		int off, len;
		unsigned int v1, v2;
	} A[] = {
		{ "ctl",   0,  0, 0x0000, 0x0000 },
		{ "p8100", 12, 2, 0x8100, 0x0000 },
		{ "p88a8", 12, 2, 0x88a8, 0x0000 },
		{ "p0000", 12, 2, 0x0000, 0x0000 },
		{ "t88a8", 12, 4, 0x88a8, 0x0064 },
	};
	static const struct {
		const char *tag;
		int ctag, stag;
	} S[] = {
		{ "A_11", 1, 1 },
		{ "B_01", 0, 1 },
		{ "C_00", 0, 0 },
	};
	unsigned char fr[512], imm[16];
	struct f559_out ctl;
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int s, a, flen;

	F561_SEC = "xmit";
	printf("F561 SECTION|xmit|wfd=%d|rfd=%d\n", wfd, rfd);
	if (add_table(NFPROTO_BRIDGE, "p61d") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p61d", "g", 0, 0, 1, NULL)) {
		printf("F561 FAIL|xmit|chain\n");
		return;
	}
	flen = f561_mkframe(&R561[1], fr);	/* the single 0x8100 tag frame */
	printf("F561 REP|env=xmit|rep=w|flen=%d|sproto=%04x\n", flen,
	       f561_proto(&R561[1]));
	for (s = 0; s < 3; s++) {
		f561_setbits(S[s].tag, "r1", S[s].ctag, S[s].stag);
		for (a = 0; a < (int)(sizeof(A) / sizeof(A[0])); a++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", S[s].tag,
				 A[a].tag);
			memset(imm, 0, sizeof(imm));
			imm[0] = (unsigned char)(A[a].v1 >> 8);
			imm[1] = (unsigned char)A[a].v1;
			imm[2] = (unsigned char)(A[a].v2 >> 8);
			imm[3] = (unsigned char)A[a].v2;
			memset(&ctl, 0, sizeof(ctl));
			if (a == 0)
				f561_arm(env, "ctl", F561_GATE_NONE, 0,
					 NFPROTO_BRIDGE, "p61d", "g",
					 NFT_PAYLOAD_LL_HEADER, 0, 0, NULL, 0,
					 fr, flen, "s0", f561_proto(&R561[1]),
					 M561_77, 8, wfd, rfd, NULL, &ctl);
			else
				f561_arm(env, A[a].tag, F561_GATE_NONE, 0,
					 NFPROTO_BRIDGE, "p61d", "g",
					 NFT_PAYLOAD_LL_HEADER, A[a].off,
					 A[a].len, imm, 1, fr, flen, "s0",
					 f561_proto(&R561[1]), M561_77, 8, wfd,
					 rfd, &ctl, NULL);
		}
	}
	f561_setbits("restore", "r1", 1, 1);
	sh("/nft flush ruleset");
}

/* ---------- far: the receiving side of a two-tag frame ---------- */

static void f561_sec_far(void)
{
	unsigned char fr[512];
	int r, flen;
	int wfd = cap_open("i0"), rfd = cap_open("i1");

	F561_SEC = "far";
	printf("F561 SECTION|far|wfd=%d|rfd=%d|dev=i0->i1\n", wfd, rfd);
	for (r = 0; r < N561; r++) {
		struct f559_out o;

		flen = f561_mkframe(&R561[r], fr);
		memset(&o, 0, sizeof(o));
		{
			unsigned long long ip0 = f558_ipin();

			f560_send2("i0", f561_proto(&R561[r]), fr, flen, M561_77,
				   8, wfd, rfd, &o);
			usleep(20000);
			o.ipin = f558_ipin() - ip0;
		}
		{
			char hw[512], hr[512];

			printf("F561 FAR|rep=%s|flen=%d|snd=%d|ipin=%llu|"
			       "wn=%d|wpt=%d|whex=%s|rn=%d|rpt=%d|rhex=%s\n",
			       R561[r].tag, flen, o.snd, o.ipin, o.wn, o.wpt,
			       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn)
					: "-",
			       o.rn, o.rpt,
			       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn)
					: "-");
		}
	}
}

/* ---------- ndin: netdev ingress, plain vs QinQ ---------- */

static void f561_sec_ndin(void)
{
	static const int reps[2] = { 0, 3 };	/* p, q */
	unsigned char fr[512];
	struct f559_out ctl;
	int wfd = cap_open("r1"), rfd = cap_open("r0");
	int k, r, flen;

	F561_SEC = "ndin";
	f561_feat("ndin.in", "s1");
	printf("F561 SECTION|ndin|wfd=%d|rfd=%d|dev=s1\n", wfd, rfd);
	if (add_table(NFPROTO_NETDEV, "p61e") ||
	    f556_add_chain(NFPROTO_NETDEV, "p61e", "ing", 0, 0, 1, "s1")) {
		printf("F561 FAIL|ndin|chain\n");
		return;
	}
	for (k = 0; k < 2; k++) {
		r = reps[k];
		flen = f561_mkframe(&R561[r], fr);
		printf("F561 REP|env=ndin|rep=%s|flen=%d|sproto=%04x\n",
		       R561[r].tag, flen, f561_proto(&R561[r]));
		memset(&ctl, 0, sizeof(ctl));
		f561_arm(R561[r].tag, "ctl", F561_GATE_NONE, 0, NFPROTO_NETDEV,
			 "p61e", "ing", NFT_PAYLOAD_NETWORK_HEADER, 0, 0, NULL,
			 0, fr, flen, "s0", f561_proto(&R561[r]), M561_77, 8,
			 wfd, rfd, NULL, &ctl);
		f561_grid40(R561[r].tag, NFPROTO_NETDEV, "p61e", "ing",
			    NFT_PAYLOAD_NETWORK_HEADER, F561_GATE_NONE, fr, flen,
			    "s0", f561_proto(&R561[r]), M561_77, 8, wfd, rfd,
			    &ctl);
	}
	sh("/nft flush ruleset");
}

/* ---------- main ---------- */

int f561_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f561";

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F561 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F561 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F561 KERNEL|%s\n", "7.3.4-T558");
	f556_env_setup();
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL59 = nfl_open(5);
	printf("F561 NFL|%d\n", NFL59);
	if (!strcmp(mode, "f561meta")) {
		f561_sec_meta();
	} else if (!strcmp(mode, "f561ll")) {
		f561_sec_ll();
	} else if (!strcmp(mode, "f561unlock")) {
		f561_sec_unlock();
	} else if (!strcmp(mode, "f561xmit")) {
		f561_sec_xmit();
	} else if (!strcmp(mode, "f561far")) {
		f561_sec_far();
	} else if (!strcmp(mode, "f561ndin")) {
		f561_sec_ndin();
	} else {
		f561_sec_far();
		f561_sec_meta();
		f561_sec_ll();
		f561_sec_unlock();
		f561_sec_xmit();
		f561_sec_ndin();
	}
	printf("F561 DONE\n");
	return 0;
}
/* differ562_add.c -- turn 562 / F40: the read side of @nh.
 *
 * F39 ended with the one guard input it saw in code and had not measured:
 *   nft_payload_eval()   (read)  offset = skb_network_offset(skb) + pkt->nhoff
 *   nft_payload_set_eval (store) offset = skb_network_offset(skb)
 * so a cell (offset,len) names one byte to a read and another to a store as
 * soon as pkt->nhoff != 0.  nhoff becomes 4 in exactly one place:
 * nft_meta_pktinfo_may_update(), reached from `meta protocol`, on an skb whose
 * skb->protocol is 0x8100 -- a Q-in-Q frame after the receive path popped
 * exactly one tag (F39's `q`).
 *
 * Same kernel as F36..F39 (7.3.4-T558, sha 459f02a5...): every file that
 * decides this (nft_payload.c, nft_meta.c, nf_tables_core.c, skbuff.c) is
 * byte-for-byte the one those findings measured.
 *
 * Sections:
 *   ctl    one counter-only rule per representation: the envelope arrives.
 *   rd     the read grid: 40 cells x {p, w, q} x {bare, meta} x 2 candidates.
 *          Candidate A = cap[14+off], the byte the STORE of that cell writes.
 *          Candidate B = cap[18+off], where a read lands if pkt->nhoff == 4.
 *          No store in these arms: neither the guard nor skb_ensure_writable
 *          is between the read and the counter.
 *   pair   one rule on one packet: read and store of the SAME cell, in both
 *          orders (rdwr: read then store; wrrd: store then read).
 *   ih     the transport base: meta's repair sets pkt->thoff from nhoff, and
 *          both the read and the store use nft_thoff() -- so they agree there.
 *   qarp   ARP in Q-in-Q: meta sets pkt->ethertype = 0x0806 but validates
 *          nothing, so nhoff stays 0 and the guard writes "ar_op" into ar_pro.
 *
 * Views: w = AF_PACKET on r1 (after xmit), r = AF_PACKET on r0.  Oracle for
 * every arm: the rule's own counter, read before and after one send.
 * Frame layout on the capture: cap starts at mac_header, skb->data is 14
 * bytes further, so a data-relative offset D is cap[14+D].
 */

/* ---------- frames ---------- */

struct f562_frame {
	const char *tag;
	int kind;			/* FK33_IP4 or FK33_ARP */
	int ntag;
	unsigned int tp1, tc1, tp2, tc2;
	unsigned char plain[256];	/* the untagged layout, as captured */
	int plainlen;
	unsigned char cap[256];		/* the captured layout (mac_header on) */
	int caplen;
	unsigned short sproto;		/* what the sender declares */
	unsigned char magic[8];		/* capture needle: the UDP payload 0x77.. */
	int mlen;			/* for IPv4, the ARP sender protocol address */
};

static int f562_wire(const struct f562_frame *f, unsigned char *out)
{
	unsigned int tp[2], tc[2];
	int i, n = f->plainlen;

	tp[0] = f->tp1; tc[0] = f->tc1;
	tp[1] = f->tp2; tc[1] = f->tc2;
	memcpy(out, f->plain, 12);
	for (i = 0; i < f->ntag; i++) {
		out[12 + 4 * i] = (unsigned char)(tp[i] >> 8);
		out[13 + 4 * i] = (unsigned char)tp[i];
		out[14 + 4 * i] = (unsigned char)(tc[i] >> 8);
		out[15 + 4 * i] = (unsigned char)tc[i];
	}
	memcpy(out + 12 + 4 * f->ntag, f->plain + 12, (size_t)(n - 12));
	return n + 4 * f->ntag;
}

/* The capture is what leaves the bridge.  Receive path, in order:
 * eth_type_trans() pulls 14; __netif_receive_skb_core() pops ONE tag
 * (skb_vlan_untag), sets skb->protocol to the next ethertype and
 * skb_reorder_vlan_header() moves the MACs forward by VLAN_HLEN.  So:
 *   no tag   -> captured = plain;
 *   one tag  -> the tag is in skb->vlan_all and veth reinserts nothing
 *               (HW_VLAN_*_TX set), captured = plain;
 *   two tags -> the outer tag is gone, the INNER one remains in the bytes,
 *               captured = MACs + inner tag + plain[12..].
 */
static void f562_build(struct f562_frame *f)
{
	int n = f->kind == FK33_ARP
		? build_arp(f->plain, 1, 0x0a010009, 0x0a090001, MAC_SRC, 6, 4, 1)
		: f556_frame(FK33_IP4, f->plain);

	f->plainlen = n;
	memcpy(f->cap, f->plain, 12);
	if (f->ntag >= 2) {
		f->cap[12] = (unsigned char)(f->tp2 >> 8);
		f->cap[13] = (unsigned char)f->tp2;
		f->cap[14] = (unsigned char)(f->tc2 >> 8);
		f->cap[15] = (unsigned char)f->tc2;
		memcpy(f->cap + 16, f->plain + 12, (size_t)(n - 12));
		f->caplen = n + 4;
	} else {
		memcpy(f->cap + 12, f->plain + 12, (size_t)(n - 12));
		f->caplen = n;
	}
	f->sproto = f->ntag ? (unsigned short)f->tp1 : f556_proto(f->kind);
	/* The capture is matched by content, not by being the next frame: the
	 * first frame on a fresh socket is ICMPv6 noise (F35).  The IPv4 frame
	 * carries 18 bytes of 0x77; the ARP frame carries none, so it is
	 * matched on its sender protocol address, which nothing else writes. */
	if (f->kind == FK33_ARP) {
		static const unsigned char arp_needle[4] = { 0x0a, 0x01, 0x00,
							     0x09 };

		memcpy(f->magic, arp_needle, 4);
		f->mlen = 4;
	} else {
		memcpy(f->magic, M561_77, 8);
		f->mlen = 8;
	}
}

/* A = the store's coordinate, B = nhoff==4, P = plain[14+off] (the value a
 * plain frame gives at this cell), T = the true transport header. */
static const unsigned char *f562_cand(const struct f562_frame *f, int which,
				      int off)
{
	switch (which) {
	case 1:
		return f->cap + 18 + off;
	case 2:
		return f->plain + 14 + off;
	case 3:
		return f->plain + 34 + off;
	}
	return f->cap + 14 + off;
}

static const char *f562_candname(int which)
{
	switch (which) {
	case 0: return "A";
	case 1: return "B";
	case 2: return "P";
	case 3: return "T";
	}
	return "?";
}

/* ---------- rule pieces ---------- */

#define F562_RD_DREG	NFT_REG32_08
#define F562_WR_SREG	NFT_REG32_00

static void f562_meta_proto(struct nlmsghdr *nlh)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "meta");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_META_KEY, NFT_META_PROTOCOL);
	put_be32(nlh, NFTA_META_DREG, F562_RD_DREG);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void f562_cmp(struct nlmsghdr *nlh, uint32_t sreg,
		     const unsigned char *val, int len)
{
	struct nlattr *e, *d, *cd;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "cmp");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_CMP_SREG, sreg);
	put_be32(nlh, NFTA_CMP_OP, NFT_CMP_EQ);
	cd = nest_start(nlh, NFTA_CMP_DATA);
	attr_put(nlh, NFTA_DATA_VALUE, val, len);
	nest_end(nlh, cd);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void f562_read(struct nlmsghdr *nlh, uint32_t base, uint32_t off,
		      uint32_t len)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "payload");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_PAYLOAD_DREG, F562_RD_DREG);
	put_be32(nlh, NFTA_PAYLOAD_BASE, base);
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
	put_be32(nlh, NFTA_PAYLOAD_LEN, len);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static void f562_store(struct nlmsghdr *nlh, uint32_t base, uint32_t off,
		       uint32_t len, const unsigned char *imm)
{
	struct nlattr *e, *d;

	imm_value(nlh, F562_WR_SREG, imm, (int)len);
	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "payload");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_PAYLOAD_SREG, F562_WR_SREG);
	put_be32(nlh, NFTA_PAYLOAD_BASE, base);
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
	put_be32(nlh, NFTA_PAYLOAD_LEN, len);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, 0);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* ---------- one arm ---------- */

static const char *F562_SEC = "-";

static void f562_arm(const char *env, const char *arm, const char *rep,
		     int gate, uint32_t base, int off, int len,
		     int do_rd, int cand, int do_wr, int wr_first,
		     const unsigned char *imm, const struct f562_frame *f,
		     const unsigned char *wire, int wlen,
		     int wfd, int rfd, const struct f559_out *ctl,
		     struct f559_out *out)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;
	struct f559_out o;
	char cw[1024], cr[1024], hw[512], hr[512], hc[512];
	const unsigned char *cv = f562_cand(f, cand, off);
	int kw = 0, kr = 0;

	cw[0] = 0;
	cr[0] = 0;
	memset(&o, 0, sizeof(o));
	snprintf(PRE57, sizeof(PRE57), "f62.%s.%s", env, arm);
	f557_flush(NFPROTO_BRIDGE, "p62", "g", &o.acks);

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_BRIDGE);
	put_str(nlh, NFTA_RULE_TABLE, "p62");
	put_str(nlh, NFTA_RULE_CHAIN, "g");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (gate)
		f562_meta_proto(nlh);
	if (do_rd && do_wr && !wr_first) {
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, cv, len);
		f562_store(nlh, base, (uint32_t)off, (uint32_t)len, imm);
	} else if (do_rd && do_wr && wr_first) {
		f562_store(nlh, base, (uint32_t)off, (uint32_t)len, imm);
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, cv, len);
	} else if (do_rd) {
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, cv, len);
	} else if (do_wr) {
		f562_store(nlh, base, (uint32_t)off, (uint32_t)len, imm);
	}
	log_expr(nlh, 5, PRE57);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	o.rc = f557_nft_one(opbuf, (int)nlh->nlmsg_len, &o.acks);

	nfl_drain(NFL59);
	o.cnt0 = f555_count(NFPROTO_BRIDGE, "p62", "g");
	{
		unsigned long long ip0 = f558_ipin();

		f560_send2("s0", f->sproto, wire, wlen, f->magic, f->mlen,
			   wfd, rfd, &o);
		usleep(20000);
		o.ipin = f558_ipin() - ip0;
	}
	o.cnt = f555_count(NFPROTO_BRIDGE, "p62", "g");
	if (ctl && o.wn > 0 && ctl->wn > 0)
		kw = f558_chg(cw, sizeof(cw), ctl->w, ctl->wn, o.w, o.wn);
	if (ctl && o.rn > 0 && ctl->rn > 0)
		kr = f558_chg(cr, sizeof(cr), ctl->r, ctl->rn, o.r, o.rn);
	printf("F562 R|env=%s.%s|rep=%s|gate=%d|base=%u|off=%d|len=%d|"
	       "rd=%d|cand=%s|cv=%s|wr=%d|first=%d|"
	       "rc=%d|acks=%d|snd=%d|cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|"
	       "wn=%d|wpt=%d|wchg=%d|wchgs=%s|whex=%s|"
	       "rn=%d|rpt=%d|rchg=%d|rchgs=%s|rhex=%s\n",
	       F562_SEC, env, rep, gate, (unsigned)base, off, len,
	       do_rd, do_rd ? f562_candname(cand) : "-",
	       do_rd ? f559_hexs(hc, sizeof(hc), cv, len) : "-",
	       do_wr, wr_first,
	       o.rc, o.acks, o.snd, o.cnt0, o.cnt, o.cnt - o.cnt0, o.ipin,
	       o.wn, o.wpt, kw, cw[0] ? cw : "-",
	       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn) : "-",
	       o.rn, o.rpt, kr, cr[0] ? cr : "-",
	       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn) : "-");
	if (out)
		memcpy(out, &o, sizeof(o));
}

/* ---------- ctl: the envelope arrives ---------- */

static void f562_sec_ctl(struct f562_frame *F, int n, int wfd, int rfd,
			 struct f559_out *ctls)
{
	unsigned char wire[256];
	int i;

	F562_SEC = "ctl";
	for (i = 0; i < n; i++) {
		int wlen = f562_wire(&F[i], wire);

		printf("F562 REP|rep=%s|plainlen=%d|caplen=%d|ntag=%d|"
		       "sproto=%04x|wlen=%d\n",
		       F[i].tag, F[i].plainlen, F[i].caplen, F[i].ntag,
		       F[i].sproto, wlen);
		memset(&ctls[i], 0, sizeof(ctls[i]));
		f562_arm(F[i].tag, "ctl", F[i].tag, 0,
			 NFT_PAYLOAD_NETWORK_HEADER, 0, 0, 0, 0, 0, 0, NULL,
			 &F[i], wire, wlen, wfd, rfd, NULL, &ctls[i]);
	}
}

/* ---------- rd: the read grid ---------- */

static void f562_sec_rd(struct f562_frame *F, int n, int wfd, int rfd,
			const struct f559_out *ctls)
{
	unsigned char wire[256];
	static const int reps[3] = { 0, 1, 2 };	/* p, w, q */
	int k, g, i, j, c;

	F562_SEC = "rd";
	for (k = 0; k < 3; k++) {
		int r = reps[k];
		int wlen = f562_wire(&F[r], wire);

		for (g = 0; g < 2; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (c = 0; c < 2; c++) {
				for (i = 0; i < G33_NOFF; i++) {
					for (j = 0; j < G33_NLEN; j++) {
						char arm[48];

						snprintf(arm, sizeof(arm),
							 "%s.g%d_%d", env,
							 G33_OFF[i], G33_LEN[j]);
						f562_arm(env, arm,
							 F[r].tag, g,
							 NFT_PAYLOAD_NETWORK_HEADER,
							 G33_OFF[i], G33_LEN[j],
							 1, c, 0, 0, NULL, &F[r],
							 wire, wlen, wfd, rfd,
							 &ctls[r], NULL);
					}
				}
				for (i = 0; i < G33_NEXT; i++) {
					char arm[48];

					snprintf(arm, sizeof(arm), "%s.x%d_%d",
						 env, G33_XOFF[i], G33_XLEN[i]);
					f562_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_NETWORK_HEADER,
						 G33_XOFF[i], G33_XLEN[i],
						 1, c, 0, 0, NULL, &F[r],
						 wire, wlen, wfd, rfd,
						 &ctls[r], NULL);
				}
			}
		}
	}
}

/* ---------- pair: one rule, one packet, two places ---------- */

static const struct {
	int off, len;
} F562_PAIR[2] = { { 8, 1 }, { 16, 4 } };

static void f562_sec_pair(struct f562_frame *F, int wfd, int rfd,
			  const struct f559_out *ctls)
{
	static const int reps[2] = { 0, 2 };	/* p, q */
	unsigned char wire[256], imm[16];
	int k, g, p, kind;

	F562_SEC = "pair";
	for (k = 0; k < 2; k++) {
		int r = reps[k];
		int wlen = f562_wire(&F[r], wire);

		for (g = 0; g < 2; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (p = 0; p < 2; p++) {
				for (kind = 0; kind < 3; kind++) {
					char arm[48];
					int i;

					for (i = 0; i < F562_PAIR[p].len; i++)
						imm[i] = (unsigned char)(0x90 + i);
					snprintf(arm, sizeof(arm),
						 "%s.%s_%d.%s", env,
						 kind == 0 ? "wr" :
						 kind == 1 ? "rdwr" : "wrrd",
						 F562_PAIR[p].off,
						 F562_PAIR[p].len == 1 ? "b" : "d");
					f562_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_NETWORK_HEADER,
						 F562_PAIR[p].off,
						 F562_PAIR[p].len,
						 kind != 0, 2, 1,
						 kind == 2, imm, &F[r], wire,
						 wlen, wfd, rfd, &ctls[r],
						 NULL);
				}
			}
		}
	}
}

/* ---------- ih: the transport base under the same repair ---------- */

static const struct {
	int off, len;
} F562_IH[5] = {
	{ 0, 2 }, { 0, 4 }, { 2, 2 }, { 2, 4 }, { 4, 2 },
};

static void f562_sec_ih(struct f562_frame *F, int wfd, int rfd,
			const struct f559_out *ctls)
{
	static const int reps[2] = { 0, 2 };	/* p, q */
	unsigned char wire[256], imm[16];
	int k, g, p, kind;

	F562_SEC = "ih";
	for (k = 0; k < 2; k++) {
		int r = reps[k];
		int wlen = f562_wire(&F[r], wire);

		for (g = 0; g < 2; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (p = 0; p < 5; p++) {
				for (kind = 0; kind < 3; kind++) {
					char arm[48];
					int i;

					for (i = 0; i < F562_IH[p].len; i++)
						imm[i] = (unsigned char)(0x90 + i);
					/* kind 0: cmp against T (the true
					 * transport header), kind 1: against
					 * data 0+off, kind 2: store only. */
					snprintf(arm, sizeof(arm),
						 "%s.%s_%d_%d", env,
						 kind == 0 ? "rdT" :
						 kind == 1 ? "rdW" : "wr",
						 F562_IH[p].off,
						 F562_IH[p].len);
					f562_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_TRANSPORT_HEADER,
						 F562_IH[p].off, F562_IH[p].len,
						 kind != 2, kind == 0 ? 3 : 0,
						 kind == 2, 0, imm, &F[r],
						 wire, wlen, wfd, rfd,
						 &ctls[r], NULL);
				}
			}
		}
	}
}

/* ---------- qarp: ARP in Q-in-Q, where the repair never happens ---------- */

static const struct {
	int off, len;
} F562_ARP[6] = {
	{ 0, 2 }, { 2, 2 }, { 4, 2 }, { 6, 2 }, { 8, 2 }, { 10, 2 },
};

static void f562_sec_qarp(struct f562_frame *F, int wfd, int rfd,
			  const struct f559_out *ctls)
{
	static const int reps[2] = { 3, 4 };	/* pa, qa */
	unsigned char wire[256], imm[16];
	int k, g, p, c;

	F562_SEC = "qarp";
	for (k = 0; k < 2; k++) {
		int r = reps[k];
		int wlen = f562_wire(&F[r], wire);

		for (g = 0; g < 2; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (p = 0; p < 6; p++) {
				for (c = 0; c < 2; c++) {
					char arm[48];

					snprintf(arm, sizeof(arm),
						 "%s.rd%s_%d", env,
						 f562_candname(c),
						 F562_ARP[p].off);
					f562_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_NETWORK_HEADER,
						 F562_ARP[p].off,
						 F562_ARP[p].len, 1, c, 0, 0,
						 NULL, &F[r], wire, wlen, wfd,
						 rfd, &ctls[r], NULL);
				}
				{
					char arm[48];
					int i;

					for (i = 0; i < F562_ARP[p].len; i++)
						imm[i] = (unsigned char)(0x90 + i);
					snprintf(arm, sizeof(arm), "%s.wr_%d",
						 env, F562_ARP[p].off);
					f562_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_NETWORK_HEADER,
						 F562_ARP[p].off,
						 F562_ARP[p].len, 0, 0, 1, 0,
						 imm, &F[r], wire, wlen, wfd,
						 rfd, &ctls[r], NULL);
				}
			}
		}
	}
}

/* ---------- val: the two cells whose verdict reads the packet ----------
 *
 * nft_nh_write_ok_ip4() does not only look at (offset,len):
 *   case 0:  requires len == 2 AND src[0] == the byte at data+0
 *   case 8:  with len == 2, requires src[1] == the byte at data+9
 * On a plain frame those bytes are the IPv4 version/ihl and the protocol
 * number.  On Q-in-Q with `meta protocol` in front they are the high byte of
 * the INNER tag's TCI and the low byte of the IP id -- so the value the guard
 * compares with is itself a byte of the envelope, and the cell becomes live
 * or dead depending on a byte that is not in the field the cell names.
 */
static void f562_sec_val(struct f562_frame *F, int wfd, int rfd,
			 const struct f559_out *ctls)
{
	static const int reps[2] = { 0, 2 };	/* p, q */
	unsigned char wire[256], imm[16];
	int k, g, p, v;

	F562_SEC = "val";
	for (k = 0; k < 2; k++) {
		int r = reps[k];
		int wlen = f562_wire(&F[r], wire);
		const unsigned char *data = F[r].cap + 14;

		for (g = 0; g < 2; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (p = 0; p < 2; p++) {
				for (v = 0; v < 2; v++) {
					char arm[48];
					int off = p ? 8 : 0;
					int i;

					for (i = 0; i < 2; i++)
						imm[i] = (unsigned char)(0x90 + i);
					if (!p)
						imm[0] = 0x45;	/* the ip4 way in */
					else
						imm[1] = 0x11;	/* keep proto */
					if (v) {
						/* the byte the guard actually
						 * reads, at data+off(+1) */
						if (!p)
							imm[0] = data[0];
						else
							imm[1] = data[9];
					}
					snprintf(arm, sizeof(arm), "%s.%s%d", env,
						 v ? "alt" : "std", off);
					f562_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_NETWORK_HEADER,
						 (uint32_t)off, 2, 0, 0, 1, 0,
						 imm, &F[r], wire, wlen, wfd,
						 rfd, &ctls[r], NULL);
				}
			}
		}
	}
}

/* ---------- main ---------- */

int f562_main(int argc, char **argv)
{
	static struct f562_frame F[5];
	static struct f559_out ctls[5];
	const char *mode = argc > 1 ? argv[1] : "f562";
	int wfd, rfd;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F562 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F562 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F562 KERNEL|%s\n", "7.3.4-T558");
	f556_env_setup();
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL59 = nfl_open(5);
	printf("F562 NFL|%d\n", NFL59);

	memset(F, 0, sizeof(F));
	F[0].tag = "p";   F[0].kind = FK33_IP4; F[0].ntag = 0;
	F[1].tag = "w";   F[1].kind = FK33_IP4; F[1].ntag = 1;
	F[1].tp1 = 0x8100; F[1].tc1 = 0x0064;
	F[2].tag = "q";   F[2].kind = FK33_IP4; F[2].ntag = 2;
	F[2].tp1 = 0x88a8; F[2].tc1 = 0x0064;
	F[2].tp2 = 0x8100; F[2].tc2 = 0x00c8;
	F[3].tag = "pa";  F[3].kind = FK33_ARP; F[3].ntag = 0;
	F[4].tag = "qa";  F[4].kind = FK33_ARP; F[4].ntag = 2;
	F[4].tp1 = 0x88a8; F[4].tc1 = 0x0064;
	F[4].tp2 = 0x8100; F[4].tc2 = 0x00c8;
	{
		int i;

		for (i = 0; i < 5; i++)
			f562_build(&F[i]);
	}

	if (add_table(NFPROTO_BRIDGE, "p62") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p62", "g", 0, 0, 1, NULL)) {
		printf("F562 FAIL|chain\n");
		return 0;
	}
	wfd = cap_open("r1");
	rfd = cap_open("r0");
	printf("F562 SECTION|open|wfd=%d|rfd=%d\n", wfd, rfd);

	f562_sec_ctl(F, 5, wfd, rfd, ctls);
	if (!strcmp(mode, "f562ctl")) {
		goto done;
	} else if (!strcmp(mode, "f562rd")) {
		f562_sec_rd(F, 3, wfd, rfd, ctls);
	} else if (!strcmp(mode, "f562pair")) {
		f562_sec_pair(F, wfd, rfd, ctls);
	} else if (!strcmp(mode, "f562ih")) {
		f562_sec_ih(F, wfd, rfd, ctls);
	} else if (!strcmp(mode, "f562qarp")) {
		f562_sec_qarp(F, wfd, rfd, ctls);
	} else if (!strcmp(mode, "f562val")) {
		f562_sec_val(F, wfd, rfd, ctls);
	} else {
		f562_sec_rd(F, 3, wfd, rfd, ctls);
		f562_sec_pair(F, wfd, rfd, ctls);
		f562_sec_ih(F, wfd, rfd, ctls);
		f562_sec_qarp(F, wfd, rfd, ctls);
		f562_sec_val(F, wfd, rfd, ctls);
	}
done:
	sh("/nft flush ruleset");
	printf("F562 DONE\n");
	return 0;
}
/* differ563_add.c -- turn 563 / F41.
 *
 * Two debts were named and left open by turn 562, and both are closed here on
 * one new image, 7.3.4-T563 = T558 + CONFIG_PPP + CONFIG_PPPOE (config delta:
 * exactly the PPP/PPPOE block and SLHC; nft_payload.c, nft_meta.c,
 * nf_tables_core.c, nft_chain_filter.c, arp.c, dev.c byte-identical to T558).
 *
 * DEBT 1 -- PPPoE is the SECOND carrier of pkt->nhoff.
 * nft_meta.c:
 *      case htons(ETH_P_PPP_SES):
 *              if (!nf_flow_pppoe_proto(skb, &ethertype)) return;
 *              nhoff = PPPOE_SES_HLEN;              <- 8, not 6 (F40 wrote 6)
 *              break;
 *      nhoff += skb_network_offset(skb);
 * so on a PPPoE session frame `meta protocol` sets pkt->nhoff = 8 and the read
 * (skb_network_offset + nhoff + off) lands on the true IPv4 header while the
 * store (skb_network_offset + off) lands EIGHT bytes earlier, inside the PPPoE
 * session header.  Sections rd / st / pair / ih measure the grid; `pppd`
 * measures the receiving side on a real PPPoX session socket (no pppd, no
 * negotiation: pppoe_connect() binds a session when sid != 0 and queues frames
 * on the socket -- so recv() is the receiver's own verdict, in bytes).
 *
 * DEBT 2 -- the ARP frame the guard makes invalid.
 * F40 said `(8,2)` on a Q-in-Q ARP frame writes ar_hln/ar_pln and "arp_rcv()
 * refuses a frame whose ar_hln is not the device's".  Section `arpd` measures
 * the death instead of reading it, with three oracles per arm: the releasing
 * chain's counter, the arp-family counter at NF_ARP_IN (arp_rcv's own NF_HOOK),
 * and the reply frame the kernel sends back (plus /proc/net/arp).  It also
 * measures the entry F40 did not see: in the netdev INGRESS envelope the guard
 * is the constant `true`, so the cell at offset 4 -- refused by the ARP list --
 * writes ar_hln there, and that frame does die in arp_rcv.
 *
 * Views: w = AF_PACKET on r1 (the bridge port), r = AF_PACKET on r0 (the far
 * side).  ARP arms send from r0 so that the reply comes back the same way.
 */

#include <linux/if_pppox.h>

/* ---------- frames ---------- */

#define F563_KIND_IP	0
#define F563_KIND_ARP	1

struct f563_frame {
	const char *tag;
	int kind;
	int ntag;
	unsigned int tp[2], tc[2];
	unsigned char wire[512];
	int wlen;
	unsigned char cap[512];		/* mac_header on, after the receive path */
	int caplen;
	unsigned char plain[512];	/* the untagged layout (mac at 0) */
	int plainlen;
	unsigned short sproto;
	unsigned char magic[8];
	int mlen;
	unsigned int spa;		/* ARP sender protocol address */
};

/* the PPPoE session frame: eth | 0x8864 | ver/code | sid | length | ppp proto | datagram */
static int f563_pppoe(const unsigned char *plain, int plainlen, unsigned char *out,
		      unsigned short sid, unsigned short pppproto)
{
	int dlen = plainlen - 14;

	memcpy(out, plain, 12);
	out[12] = 0x88;
	out[13] = 0x64;
	out[14] = 0x11;			/* version 1, type 1 */
	out[15] = 0x00;			/* code: PPPOE_SESS_DATA */
	out[16] = (unsigned char)(sid >> 8);
	out[17] = (unsigned char)sid;
	out[18] = (unsigned char)((2 + dlen) >> 8);
	out[19] = (unsigned char)(2 + dlen);
	out[20] = (unsigned char)(pppproto >> 8);
	out[21] = (unsigned char)pppproto;
	memcpy(out + 22, plain + 14, (size_t)dlen);
	return 22 + dlen;
}

static void f563_arp_build(struct f563_frame *f, int ntag, unsigned int tp1,
			   unsigned int tc1, unsigned int tp2, unsigned int tc2)
{
	unsigned int tp[2], tc[2];
	int n, i;

	f->ntag = ntag;
	f->tp[0] = tp1; f->tc[0] = tc1;
	f->tp[1] = tp2; f->tc[1] = tc2;
	n = build_arp(f->plain, 1, f->spa, 0x0a090001, MAC_SRC, 6, 4, 1);
	f->plainlen = n;
	tp[0] = tp1; tc[0] = tc1; tp[1] = tp2; tc[1] = tc2;
	memcpy(f->wire, f->plain, 12);
	for (i = 0; i < ntag; i++) {
		f->wire[12 + 4 * i] = (unsigned char)(tp[i] >> 8);
		f->wire[13 + 4 * i] = (unsigned char)tp[i];
		f->wire[14 + 4 * i] = (unsigned char)(tc[i] >> 8);
		f->wire[15 + 4 * i] = (unsigned char)tc[i];
	}
	memcpy(f->wire + 12 + 4 * ntag, f->plain + 12, (size_t)(n - 12));
	f->wlen = n + 4 * ntag;
	/* one tag is popped by the receive path; a second one stays in bytes */
	memcpy(f->cap, f->plain, 12);
	if (ntag >= 2) {
		f->cap[12] = (unsigned char)(tp2 >> 8);
		f->cap[13] = (unsigned char)tp2;
		f->cap[14] = (unsigned char)(tc2 >> 8);
		f->cap[15] = (unsigned char)tc2;
		memcpy(f->cap + 16, f->plain + 12, (size_t)(n - 12));
		f->caplen = n + 4;
	} else {
		memcpy(f->cap + 12, f->plain + 12, (size_t)(n - 12));
		f->caplen = n;
	}
	f->sproto = ntag ? (unsigned short)tp1 : 0x0806;
	f->magic[0] = (unsigned char)(f->spa >> 24);
	f->magic[1] = (unsigned char)(f->spa >> 16);
	f->magic[2] = (unsigned char)(f->spa >> 8);
	f->magic[3] = (unsigned char)f->spa;
	f->mlen = 4;
}

/* candidate coordinates.  A = the STORE's byte (data + off, data = cap + 14),
 * B = where a read lands when pkt->nhoff == 8 (cap + 22 + off), P = the plain
 * frame's byte at the same cell, T = the true transport header. */
static const unsigned char *f563_cand(const struct f563_frame *f, int which, int off)
{
	switch (which) {
	case 1: return f->cap + 22 + off;
	case 2: return f->plain + 14 + off;
	case 3: return f->plain + 34 + off;
	}
	return f->cap + 14 + off;
}

static const char *f563_candname(int which)
{
	switch (which) {
	case 0: return "A";
	case 1: return "B";
	case 2: return "P";
	case 3: return "T";
	}
	return "?";
}

/* the value a store writes.  The two cells whose verdict reads the frame
 * (ip4 case 0 at data+0, case 8+len2 at data+9) get the byte the guard will
 * compare with, so that the LENGTH is what each cell measures. */
static void f563_imm(const struct f563_frame *f, int off, int len, unsigned char *imm)
{
	int i;

	memset(imm, 0, 16);
	for (i = 0; i < len && i < 16; i++)
		imm[i] = (unsigned char)(0x90 + i);
	if (off == 0 && f->caplen > 14)
		imm[0] = f->cap[14];
	if (off == 8 && len >= 2 && f->caplen > 23)
		imm[1] = f->cap[23];
}

/* ---------- one rule in any family ---------- */

static int f563_install(uint8_t fam, const char *table, const char *chain,
			const char *pre, int gate, uint32_t base,
			int do_rd, int cand, int off, int len,
			const unsigned char *cv, int do_wr, int wr_first,
			const unsigned char *imm, int cnt, int acc)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;
	int acks = 0;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			fam);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (gate)
		f562_meta_proto(nlh);
	if (do_rd && do_wr && !wr_first) {
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, cv, len);
		f562_store(nlh, base, (uint32_t)off, (uint32_t)len, imm);
	} else if (do_rd && do_wr) {
		f562_store(nlh, base, (uint32_t)off, (uint32_t)len, imm);
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, cv, len);
	} else if (do_rd) {
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, cv, len);
	} else if (do_wr) {
		f562_store(nlh, base, (uint32_t)off, (uint32_t)len, imm);
	}
	if (cnt)
		counter_expr(nlh);
	if (acc)
		accept_expr(nlh);
	log_expr(nlh, 5, pre);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, &acks);
}

/* ---------- one arm on the bridge chain (the envelope sections) ---------- */

static const char *F563_SEC = "-";

static void f563_arm(const char *env, const char *arm, const char *rep,
		     int gate, uint32_t base, int off, int len,
		     int do_rd, int cand, int do_wr, int wr_first,
		     const unsigned char *imm, const struct f563_frame *f,
		     const char *sdev, int wfd, int rfd,
		     const struct f559_out *ctl, struct f559_out *out)
{
	struct f559_out o;
	char cw[1024], cr[1024], hw[512], hr[512], hc[512], hi[64];
	const unsigned char *cv = f563_cand(f, cand, off);
	int kw = 0, kr = 0;

	cw[0] = 0;
	cr[0] = 0;
	memset(&o, 0, sizeof(o));
	snprintf(PRE57, sizeof(PRE57), "f63.%s.%s", env, arm);
	f557_flush(NFPROTO_BRIDGE, "p63", "g", &o.acks);
	o.rc = f563_install(NFPROTO_BRIDGE, "p63", "g", PRE57, gate, base,
			    do_rd, cand, off, len, cv, do_wr, wr_first, imm,
			    1, 1);
	nfl_drain(NFL59);
	o.cnt0 = f555_count(NFPROTO_BRIDGE, "p63", "g");
	{
		unsigned long long ip0 = f558_ipin();

		f560_send2(sdev, f->sproto, f->wire, f->wlen, f->magic, f->mlen,
			   wfd, rfd, &o);
		usleep(20000);
		o.ipin = f558_ipin() - ip0;
	}
	o.cnt = f555_count(NFPROTO_BRIDGE, "p63", "g");
	if (ctl && o.wn > 0 && ctl->wn > 0)
		kw = f558_chg(cw, sizeof(cw), ctl->w, ctl->wn, o.w, o.wn);
	if (ctl && o.rn > 0 && ctl->rn > 0)
		kr = f558_chg(cr, sizeof(cr), ctl->r, ctl->rn, o.r, o.rn);
	printf("F563 R|sec=%s|env=%s.%s|rep=%s|gate=%d|base=%u|off=%d|len=%d|"
	       "rd=%d|cand=%s|cv=%s|wr=%d|first=%d|imm=%s|"
	       "rc=%d|acks=%d|snd=%d|cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|"
	       "wn=%d|wpt=%d|wchg=%d|wchgs=%s|whex=%s|"
	       "rn=%d|rpt=%d|rchg=%d|rchgs=%s|rhex=%s\n",
	       F563_SEC, env, arm, rep, gate, (unsigned)base, off, len,
	       do_rd, do_rd ? f563_candname(cand) : "-",
	       do_rd ? f559_hexs(hc, sizeof(hc), cv, len) : "-",
	       do_wr, wr_first,
	       do_wr ? f559_hexs(hi, sizeof(hi), imm, len) : "-",
	       o.rc, o.acks, o.snd, o.cnt0, o.cnt, o.cnt - o.cnt0, o.ipin,
	       o.wn, o.wpt, kw, cw[0] ? cw : "-",
	       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn) : "-",
	       o.rn, o.rpt, kr, cr[0] ? cr : "-",
	       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn) : "-");
	if (out)
		memcpy(out, &o, sizeof(o));
}

/* ---------- ctl: every envelope reaches the hook ---------- */

static void f563_sec_ctl(struct f563_frame *F, int n, int wfd, int rfd,
			 struct f559_out *ctls)
{
	int i;

	F563_SEC = "ctl";
	for (i = 0; i < n; i++) {
		unsigned char zero[16];

		memset(zero, 0, sizeof(zero));
		printf("F563 REP|rep=%s|kind=%d|plainlen=%d|caplen=%d|ntag=%d|"
		       "sproto=%04x|wlen=%d|spa=%08x\n",
		       F[i].tag, F[i].kind, F[i].plainlen, F[i].caplen,
		       F[i].ntag, F[i].sproto, F[i].wlen, F[i].spa);
		memset(&ctls[i], 0, sizeof(ctls[i]));
		f563_arm(F[i].tag, "ctl", F[i].tag, 0,
			 NFT_PAYLOAD_NETWORK_HEADER, 0, 0, 0, 0, 0, 0,
			 zero, &F[i], "s0", wfd, rfd, NULL, &ctls[i]);
	}
}

/* ---------- rd: the read grid, 40 cells, two candidates ---------- */

static void f563_sec_rd(struct f563_frame *F, int wfd, int rfd,
			const struct f559_out *ctls)
{
	unsigned char zero[16];
	int i, j, c, g, k;

	memset(zero, 0, sizeof(zero));
	F563_SEC = "rd";
	/* r = 0 (plain) and 1 (PPPoE) */
	for (k = 0; k < 2; k++) {
		int r = k;
		int gmax = (r == 0) ? 1 : 2;	/* p: meta only, ps: bare + meta */

		for (g = 0; g < gmax; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (c = 0; c < 2; c++) {
				for (i = 0; i < G33_NOFF; i++) {
					for (j = 0; j < G33_NLEN; j++) {
						char arm[64];

						snprintf(arm, sizeof(arm), "%s.g%d_%d",
							 env, G33_OFF[i], G33_LEN[j]);
						f563_arm(env, arm, F[r].tag, g,
							 NFT_PAYLOAD_NETWORK_HEADER,
							 G33_OFF[i], G33_LEN[j],
							 1, c, 0, 0, zero, &F[r],
							 "s0", wfd, rfd, &ctls[r], NULL);
					}
				}
				for (i = 0; i < G33_NEXT; i++) {
					char arm[64];

					snprintf(arm, sizeof(arm), "%s.x%d_%d", env,
						 G33_XOFF[i], G33_XLEN[i]);
					f563_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_NETWORK_HEADER,
						 G33_XOFF[i], G33_XLEN[i],
						 1, c, 0, 0, zero, &F[r], "s0",
						 wfd, rfd, &ctls[r], NULL);
				}
			}
		}
	}
}

/* ---------- st: the store grid on the PPPoE envelope ---------- */

static void f563_sec_st(struct f563_frame *F, int wfd, int rfd,
			const struct f559_out *ctls)
{
	int i, j, g;

	F563_SEC = "st";
	for (g = 0; g < 2; g++) {
		char env[32];

		snprintf(env, sizeof(env), "%s.%s", F[1].tag,
			 g ? "meta" : "bare");
		for (i = 0; i < G33_NOFF; i++) {
			for (j = 0; j < G33_NLEN; j++) {
				char arm[64];
				unsigned char imm[16];

				f563_imm(&F[1], G33_OFF[i], G33_LEN[j], imm);
				snprintf(arm, sizeof(arm), "s%d_%d",
					 G33_OFF[i], G33_LEN[j]);
				f563_arm(env, arm, F[1].tag, g,
					 NFT_PAYLOAD_NETWORK_HEADER,
					 G33_OFF[i], G33_LEN[j], 0, 0, 1, 0,
					 imm, &F[1], "s0", wfd, rfd,
					 &ctls[1], NULL);
			}
		}
		for (i = 0; i < G33_NEXT; i++) {
			char arm[64];
			unsigned char imm[16];

			f563_imm(&F[1], G33_XOFF[i], G33_XLEN[i], imm);
			snprintf(arm, sizeof(arm), "x%d_%d",
				 G33_XOFF[i], G33_XLEN[i]);
			f563_arm(env, arm, F[1].tag, g,
				 NFT_PAYLOAD_NETWORK_HEADER,
				 G33_XOFF[i], G33_XLEN[i], 0, 0, 1, 0, imm,
				 &F[1], "s0", wfd, rfd, &ctls[1], NULL);
		}
	}
}

/* ---------- pair: one rule, one packet, two places ---------- */

static const struct {
	int off, len;
} F563_PAIR[2] = { { 8, 1 }, { 16, 4 } };

static void f563_sec_pair(struct f563_frame *F, int wfd, int rfd,
			  const struct f559_out *ctls)
{
	int k, g, p, kind;

	F563_SEC = "pair";
	for (k = 0; k < 2; k++) {
		int r = k;

		for (g = 0; g < 2; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (p = 0; p < 2; p++) {
				for (kind = 0; kind < 3; kind++) {
					char arm[64];
					unsigned char imm[16];
					int i;

					memset(imm, 0, sizeof(imm));
					for (i = 0; i < F563_PAIR[p].len; i++)
						imm[i] = (unsigned char)(0x90 + i);
					snprintf(arm, sizeof(arm), "%s_%d.%s",
						 kind == 0 ? "wr" :
						 kind == 1 ? "rdwr" : "wrrd",
						 F563_PAIR[p].off,
						 F563_PAIR[p].len == 1 ? "b" : "d");
					f563_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_NETWORK_HEADER,
						 F563_PAIR[p].off,
						 F563_PAIR[p].len,
						 kind != 0, 1, 1,
						 kind == 2, imm, &F[r], "s0",
						 wfd, rfd, &ctls[r], NULL);
				}
			}
		}
	}
}

/* ---------- ih: the transport base inside a PPPoE frame ---------- */

static const struct {
	int off, len;
} F563_IH[5] = {
	{ 0, 2 }, { 0, 4 }, { 2, 2 }, { 2, 4 }, { 4, 2 },
};

static void f563_sec_ih(struct f563_frame *F, int wfd, int rfd,
			const struct f559_out *ctls)
{
	int k, g, p, kind;

	F563_SEC = "ih";
	for (k = 0; k < 2; k++) {
		int r = k;

		for (g = 0; g < 2; g++) {
			char env[32];

			snprintf(env, sizeof(env), "%s.%s", F[r].tag,
				 g ? "meta" : "bare");
			for (p = 0; p < 5; p++) {
				for (kind = 0; kind < 3; kind++) {
					char arm[64];
					unsigned char imm[16];
					int i;

					memset(imm, 0, sizeof(imm));
					for (i = 0; i < F563_IH[p].len; i++)
						imm[i] = (unsigned char)(0x90 + i);
					snprintf(arm, sizeof(arm), "%s_%d_%d",
						 kind == 0 ? "rdT" :
						 kind == 1 ? "rdW" : "wr",
						 F563_IH[p].off, F563_IH[p].len);
					f563_arm(env, arm, F[r].tag, g,
						 NFT_PAYLOAD_TRANSPORT_HEADER,
						 F563_IH[p].off, F563_IH[p].len,
						 kind != 2, kind == 0 ? 3 : 2,
						 kind == 2, 0, imm, &F[r], "s0",
						 wfd, rfd, &ctls[r], NULL);
				}
			}
		}
	}
}

/* ---------- pppd: the receiving side, on a real PPPoX session ---------- */

/* pppoe_connect() binds a session when sid != 0 -- no discovery, no pppd, no
 * PPP negotiation.  pppoe_rcv() then finds it by (sid, source MAC, ifindex),
 * and because the socket is not PPPOX_BOUND the skb is queued on it, so
 * recv() is the receiving stack's own verdict in bytes. */
static int f563_pppoe_sock(const char *dev, unsigned short sid_be,
			   const unsigned char *mac)
{
	struct sockaddr_pppox sp;
	int s, e;

	s = socket(AF_PPPOX, SOCK_DGRAM, PX_PROTO_OE);
	if (s < 0)
		return -errno;
	memset(&sp, 0, sizeof(sp));
	sp.sa_family = AF_PPPOX;
	sp.sa_protocol = PX_PROTO_OE;
	sp.sa_addr.pppoe.sid = sid_be;
	memcpy(sp.sa_addr.pppoe.remote, mac, 6);
	strncpy(sp.sa_addr.pppoe.dev, dev, IFNAMSIZ - 1);
	if (connect(s, (struct sockaddr *)&sp, sizeof(sp)) < 0) {
		e = errno;
		close(s);
		return -e;
	}
	return s;
}

static int f563_recv(int fd, unsigned char *buf, int max, int ms)
{
	struct timeval tv;
	fd_set rfds;
	int r;

	if (fd < 0)
		return -1;
	for (;;) {
		FD_ZERO(&rfds);
		FD_SET(fd, &rfds);
		tv.tv_sec = 0;
		tv.tv_usec = ms * 1000;
		r = select(fd + 1, &rfds, NULL, NULL, &tv);
		if (r <= 0)
			return -1;
		r = (int)recv(fd, buf, (size_t)max, 0);
		if (r >= 0)
			return r;
		if (errno != EAGAIN && errno != EINTR)
			return -1;
	}
}

struct f563_pa {
	const char *arm;
	int gate;
	int off, len;
	int wr;
	unsigned char imm[16];
	const char *what;	/* what the rule names */
};

static void f563_sec_pppd(struct f563_frame *F, int wfd, int rfd, int sfd)
{
	static struct f563_pa A[] = {
		{ "ctl",      1,  0, 0, 0, { 0 },                 "no store" },
		{ "id_small", 1,  4, 2, 1, { 0x00, 0x04 },        "ipv4 id -> pppoe length = 4" },
		{ "id_large", 1,  4, 2, 1, { 0x90, 0x91 },        "ipv4 id -> pppoe length = 0x9091" },
		{ "vt",       1,  0, 2, 1, { 0x11, 0x91 },        "version/ihl -> pppoe ver/type + code" },
		{ "tos",      1,  1, 1, 1, { 0x91 },              "tos -> pppoe code" },
		{ "ttl",      1,  8, 1, 1, { 0x90 },              "ttl -> ipv4 version/ihl" },
		{ "ttl2",     1,  8, 2, 1, { 0x90, 0x00 },        "ttl(2b) -> ipv4 version/ihl + tos" },
		{ "saddr",    1, 12, 4, 1, { 0x90, 0x91, 0x92, 0x93 }, "saddr -> ipv4 id + frag_off" },
		{ "daddr",    1, 16, 4, 1, { 0x90, 0x91, 0x92, 0x93 }, "daddr -> ipv4 ttl + proto + csum" },
		{ "tsaddr",   1, 20, 4, 1, { 0x90, 0x91, 0x92, 0x93 }, "the real saddr: refused" },
		{ "trdaddr",  1, 24, 4, 1, { 0x90, 0x91, 0x92, 0x93 }, "the real daddr: refused" },
		{ "id_bare",  0,  4, 2, 1, { 0x00, 0x04 },        "bare gate: no branch" },
	};
	int ppfd, i;
	char hx[256];

	F563_SEC = "pppd";
	ppfd = f563_pppoe_sock("br0", htons(99), MAC_SRC);
	printf("F563 PPSOCK|rc=%d|sid=%04x|dev=br0|remote=%02x%02x%02x%02x%02x%02x\n",
	       ppfd, 99, MAC_SRC[0], MAC_SRC[1], MAC_SRC[2], MAC_SRC[3],
	       MAC_SRC[4], MAC_SRC[5]);
	for (i = 0; i < (int)(sizeof(A) / sizeof(A[0])); i++) {
		struct f559_out o;
		unsigned char rx[512];
		int rxn, cnt;
		char env[32];
		unsigned char tmp[512];
		char hi[64], hrx[256], hw[256], hr[256];

		memset(&o, 0, sizeof(o));
		snprintf(env, sizeof(env), "%s.%s", F[1].tag,
			 A[i].gate ? "meta" : "bare");
		snprintf(PRE57, sizeof(PRE57), "f63.%s.%s", env, A[i].arm);
		f557_flush(NFPROTO_BRIDGE, "p63", "g", &o.acks);
		o.rc = f563_install(NFPROTO_BRIDGE, "p63", "g", PRE57, A[i].gate,
				    NFT_PAYLOAD_NETWORK_HEADER, 0, 0, A[i].off,
				    A[i].len, NULL, A[i].wr, 0, A[i].imm, 1, 1);
		nfl_drain(NFL59);
		while (ppfd >= 0 && recv(ppfd, tmp, sizeof(tmp), MSG_DONTWAIT) >= 0)
			;
		o.cnt0 = f555_count(NFPROTO_BRIDGE, "p63", "g");
		f560_send2("s0", F[1].sproto, F[1].wire, F[1].wlen, F[1].magic,
			   F[1].mlen, wfd, rfd, &o);
		/* the reply may be queued a moment after the frame is forwarded */
		usleep(30000);
		rxn = f563_recv(ppfd, rx, (int)sizeof(rx), 300);
		cnt = 0;
		while (ppfd >= 0 && recv(ppfd, tmp, sizeof(tmp), MSG_DONTWAIT) >= 0)
			cnt++;
		o.cnt = f555_count(NFPROTO_BRIDGE, "p63", "g");
		printf("F563 P|sec=pppd|env=%s.%s|rep=%s|off=%d|len=%d|wr=%d|"
		       "imm=%s|what=%s|rc=%d|acks=%d|snd=%d|cnt0=%llu|cnt=%llu|"
		       "live=%llu|rxn=%d|rxmore=%d|rxhex=%s|whex=%s|rhex=%s\n",
		       env, A[i].arm, F[1].tag, A[i].off, A[i].len, A[i].wr,
		       A[i].wr ? f559_hexs(hi, sizeof(hi), A[i].imm, A[i].len) : "-",
		       A[i].what, o.rc, o.acks, o.snd, o.cnt0, o.cnt,
		       o.cnt - o.cnt0, rxn, cnt,
		       rxn > 0 ? f559_hexs(hrx, sizeof(hrx), rx, rxn < 40 ? rxn : 40) : "-",
		       o.wn > 0 ? f559_hexs(hw, sizeof(hw), o.w, o.wn < 40 ? o.wn : 40) : "-",
		       o.rn > 0 ? f559_hexs(hr, sizeof(hr), o.r, o.rn < 40 ? o.rn : 40) : "-");
	}
	if (ppfd >= 0)
		close(ppfd);
}

/* ---------- arpd: the receiving side of an ARP frame ---------- */

static unsigned int F563_BRMAC;

static void f563_getmac(const char *dev, unsigned char *out)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	memset(&ifr, 0, sizeof(ifr));
	strncpy(ifr.ifr_name, dev, IFNAMSIZ - 1);
	memset(out, 0, 6);
	if (s >= 0 && ioctl(s, SIOCGIFHWADDR, &ifr) == 0)
		memcpy(out, ifr.ifr_hwaddr.sa_data, 6);
	if (s >= 0)
		close(s);
}

/* s0 is the sender in every other section; in this one it is an unwelcome
 * THIRD receiver: the frame is flooded to s1, its peer s0 has an in_device of
 * its own, and the s0 copy reaches NF_ARP_IN too (measured: the arp counter
 * read 2 per accepted frame, and /proc/net/arp showed the entry on s0).
 * IFF_NOARP is the surgical way out: s0 stays in the bridge (so the frame it
 * sees is the post-store byte image) and arp_rcv() consumes its copy before
 * the hook. */
static void f563_set_noarp(const char *dev)
{
	struct ifreq ifr;
	int s = socket(AF_INET, SOCK_DGRAM, 0);

	memset(&ifr, 0, sizeof(ifr));
	strncpy(ifr.ifr_name, dev, IFNAMSIZ - 1);
	if (s < 0)
		return;
	if (ioctl(s, SIOCGIFFLAGS, &ifr) == 0) {
		ifr.ifr_flags = (short)(ifr.ifr_flags | IFF_NOARP);
		ioctl(s, SIOCSIFFLAGS, &ifr);
	}
	close(s);
}

static void f563_arpent(unsigned int spa, char *out, size_t osz)
{
	FILE *f = fopen("/proc/net/arp", "r");
	char line[512], ip[32];
	size_t ipl;

	out[0] = 0;
	snprintf(ip, sizeof(ip), "%u.%u.%u.%u", (spa >> 24) & 255,
		 (spa >> 16) & 255, (spa >> 8) & 255, spa & 255);
	ipl = strlen(ip);
	if (!f)
		return;
	while (fgets(line, sizeof(line), f)) {
		size_t i, at = 0;
		int sp = 0;

		if (strncmp(line, ip, ipl) || (line[ipl] != ' ' && line[ipl] != '\t'))
			continue;
		/* keep the five columns after the address, spaces -> '_' */
		for (i = ipl; i < strlen(line) && at + 2 < osz; i++) {
			if (line[i] == '\n')
				break;
			if (line[i] == ' ' || line[i] == '\t') {
				if (sp)
					continue;
				sp = 1;
				out[at++] = ';';
			} else {
				sp = 0;
				out[at++] = line[i];
			}
		}
		out[at] = 0;
		break;
	}
	fclose(f);
}

struct f563_aa {
	const char *tag;	/* arm name */
	const char *env;	/* "br" or "nd" */
	int frame;		/* index into F[] */
	int gate;
	int off, len, wr;
	unsigned char imm[16];
	const char *what;
};

static void f563_sec_arpd(struct f563_frame *F, int wfd, int rfd, int sfd)
{
	static struct f563_aa A[] = {
		{ "br_pa_ctl",    "br", 2, 0,  0, 0, 0, { 0 },                 "control: no store" },
		{ "br_pa_opbad",  "br", 2, 0,  6, 2, 1, { 0x90, 0x91 },        "ar_op = 0x9091 (unknown)" },
		{ "br_pa_oprepl", "br", 2, 0,  6, 2, 1, { 0x00, 0x02 },        "ar_op = REPLY" },
		{ "br_pa_sha0",   "br", 2, 0,  8, 2, 1, { 0x90, 0x91 },        "sha[0..1]" },
		{ "br_pa_sha2",   "br", 2, 0, 10, 2, 1, { 0x90, 0x91 },        "sha[2..3]" },
		{ "br_tag0_ctl",  "br", 3, 0,  0, 0, 0, { 0 },                 "single 802.1Q tag, vid 0: control" },
		{ "br_q0_ctl",    "br", 4, 1,  0, 0, 0, { 0 },                 "Q-in-Q vid 0: control" },
		{ "br_q0_pro",    "br", 4, 1,  6, 2, 1, { 0x90, 0x91 },        "Q-in-Q: ar_pro (F40's shifted cell 6)" },
		{ "br_q0_op",     "br", 4, 1, 10, 2, 1, { 0x90, 0x91 },        "Q-in-Q: the real ar_op (offset 10)" },
		{ "br_q0_hln",    "br", 4, 1,  8, 2, 1, { 0x90, 0x91 },        "Q-in-Q: the shifted cell (writes ar_hln)" },
		{ "br_q200_ctl",  "br", 5, 1,  0, 0, 0, { 0 },                 "Q-in-Q inner vid 200: control" },
		{ "nd_pa_ctl",    "nd", 2, 0,  0, 0, 0, { 0 },                 "ingress, control" },
		{ "nd_pa_hln",    "nd", 2, 0,  4, 2, 1, { 0x90, 0x91 },        "ingress: ar_hln/ar_pln (offset 4, refused by the ARP list)" },
		{ "nd_pa_op",     "nd", 2, 0,  6, 2, 1, { 0x90, 0x91 },        "ingress: ar_op" },
		{ "nd_pa_sha0",   "nd", 2, 0,  8, 2, 1, { 0x90, 0x91 },        "ingress: sha[0..1]" },
		{ "nd_q0_hln",    "nd", 4, 1,  4, 2, 1, { 0x90, 0x91 },        "ingress on Q-in-Q: offset 4 lands in the tag" },
	};
	unsigned char brmac[6];
	int i, have_nd = 0, have_ar = 0, ackz = 0;

	F563_SEC = "arpd";
	f563_getmac("br0", brmac);
	F563_BRMAC = ((unsigned int)brmac[0] << 24) | ((unsigned int)brmac[1] << 16) |
		     ((unsigned int)brmac[2] << 8) | brmac[3];
	printf("F563 BRMAC|%02x%02x%02x%02x%02x%02x\n", brmac[0], brmac[1],
	       brmac[2], brmac[3], brmac[4], brmac[5]);
	printf("F563 ADDR|br0|rc=%d\n",
	       f555_addr_add("br0", htonl(0x0a090001), 24));
	f563_set_noarp("s0");
	printf("F563 NOARP|s0\n");
	usleep(150000);
	if (wfd >= 0) cap_drain(wfd);
	if (rfd >= 0) cap_drain(rfd);
	if (sfd >= 0) cap_drain(sfd);

	if (add_table(NFPROTO_ARP, "p63a") ||
	    f556_add_chain(NFPROTO_ARP, "p63a", "in", 0, 0, 1, NULL))
		printf("F563 FAIL|arp_chain\n");
	else
		have_ar = 1;
	if (add_table(NFPROTO_NETDEV, "p63n") ||
	    f556_add_chain(NFPROTO_NETDEV, "p63n", "ing", 0, 0, 1, "r1"))
		printf("F563 FAIL|nd_chain\n");
	else
		have_nd = 1;

	for (i = 0; i < (int)(sizeof(A) / sizeof(A[0])); i++) {
		struct f563_frame fr = F[A[i].frame];
		struct f563_frame *f = &fr;
		struct f559_out o;
		unsigned char req[1024], rep[1024], wrq[1024], rneedle[6];
		char ent[256], hx[256], hq[256], hr[256], hw[256];
		int rn = -1, repn = -1, wrn = -1, sk = 0, cnt0, cnt, ack2 = 0;
		uint8_t dfam = NFPROTO_BRIDGE;
		const char *dtab = "p63", *dch = "g";

		memset(&o, 0, sizeof(o));
		/* one sender address per arm: the neighbour table is keyed by
		 * (address, device), so a shared one would answer for the arm
		 * that created it -- measured, twice. */
		if (fr.kind == F563_KIND_ARP) {
			fr.spa = 0x0a010090u + (unsigned int)i;
			f563_arp_build(&fr, fr.ntag, fr.tp[0], fr.tc[0],
				       fr.tp[1], fr.tc[1]);
		}
		if (!strcmp(A[i].env, "nd")) {
			dfam = NFPROTO_NETDEV;
			dtab = "p63n";
			dch = "ing";
		}
		/* the two chains: the releasing rule, then the arp counter */
		snprintf(PRE57, sizeof(PRE57), "f63.%s.%s", A[i].env, A[i].tag);
		f557_flush(NFPROTO_BRIDGE, "p63", "g", &ack2);
		f557_flush(NFPROTO_NETDEV, "p63n", "ing", &ack2);
		if (have_ar) {
			f557_flush(NFPROTO_ARP, "p63a", "in", &ack2);
			f563_install(NFPROTO_ARP, "p63a", "in", PRE57, 0,
				     NFT_PAYLOAD_NETWORK_HEADER, 0, 0, 0, 0,
				     NULL, 0, 0, NULL, 1, 0);
		}
		o.rc = f563_install(dfam, dtab, dch, PRE57, A[i].gate,
				    NFT_PAYLOAD_NETWORK_HEADER, 0, 0, A[i].off,
				    A[i].len, NULL, A[i].wr, 0, A[i].imm, 1, 1);
		nfl_drain(NFL59);
		cnt0 = have_ar ? (int)f555_count(NFPROTO_ARP, "p63a", "in") : -1;
		if (rfd >= 0) cap_drain(rfd);
		if (wfd >= 0) cap_drain(wfd);
		usleep(10000);
		if (rfd >= 0) cap_drain(rfd);
		if (wfd >= 0) cap_drain(wfd);
		o.snd = pkt_send_p("r0", f->wire, f->wlen, f->sproto);
		rn = f558_cap_match(rfd, req, (int)sizeof(req), 400, f->magic,
				    f->mlen, &sk, &o.rpt);
		sk = 0;
		wrn = f558_cap_match(sfd, wrq, (int)sizeof(wrq), 300, f->magic,
				     f->mlen, &sk, &o.wpt);
		memcpy(rneedle, brmac, 6);
		sk = 0;
		repn = f558_cap_match(rfd, rep, (int)sizeof(rep), 400, rneedle, 6,
				      &sk, &o.wpt);
		cnt = have_ar ? (int)f555_count(NFPROTO_ARP, "p63a", "in") : -1;
		f563_arpent(f->spa, ent, sizeof(ent));
		printf("F563 A|sec=arpd|env=%s|arm=%s|frame=%s|gate=%d|off=%d|"
		       "len=%d|wr=%d|imm=%s|what=%s|spa=%08x|rc=%d|acks=%d|"
		       "snd=%d|reqn=%d|reqhex=%s|wrn=%d|whex=%s|repn=%d|"
		       "reppkt=%d|rephex=%s|arccnt0=%d|arccnt=%d|arc=%d|ent=%s\n",
		       A[i].env, A[i].tag, f->tag, A[i].gate, A[i].off,
		       A[i].len, A[i].wr,
		       A[i].wr ? f559_hexs(hx, sizeof(hx), A[i].imm, A[i].len) : "-",
		       A[i].what, f->spa, o.rc, o.acks, o.snd, rn,
		       rn > 0 ? f559_hexs(hq, sizeof(hq), req, rn < 46 ? rn : 46) : "-",
		       wrn,
		       wrn > 0 ? f559_hexs(hw, sizeof(hw), wrq, wrn < 46 ? wrn : 46) : "-",
		       repn, o.wpt,
		       repn > 0 ? f559_hexs(hr, sizeof(hr), rep, repn < 46 ? repn : 46) : "-",
		       cnt0, cnt, cnt < 0 ? -1 : cnt - cnt0, ent[0] ? ent : "-");
	}
	/* leave no envelope behind that could judge a later section */
	f557_flush(NFPROTO_NETDEV, "p63n", "ing", &ackz);
	f557_flush(NFPROTO_ARP, "p63a", "in", &ackz);
}

/* ---------- main ---------- */

int f563_main(int argc, char **argv)
{
	static struct f563_frame F[6];
	static struct f559_out ctls[6];
	const char *mode = argc > 1 ? argv[1] : "f563";
	int wfd, rfd, sfd;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F563 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F563 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F563 KERNEL|%s\n", "7.3.4-T563");
	f556_env_setup();
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL59 = nfl_open(5);
	printf("F563 NFL|%d\n", NFL59);

	/* 0: p   plain ethernet, IPv4/UDP, the 0x77 payload
	 * 1: ps  the same datagram inside a PPPoE session frame (sid 99)
	 * 2: pa  plain ARP request
	 * 3: tag0 ARP behind one 802.1Q tag, vid 0
	 * 4: q0  ARP behind Q-in-Q, outer 0x88a8 vid 0, inner 0x8100 vid 0
	 * 5: q200 ARP behind Q-in-Q, inner vid 200
	 */
	memset(F, 0, sizeof(F));
	F[0].tag = "p";  F[0].kind = F563_KIND_IP;
	F[0].plainlen = f556_mk_ip4(F[0].plain, 5, 17, 64);
	memcpy(F[0].cap, F[0].plain, (size_t)F[0].plainlen);
	F[0].caplen = F[0].plainlen;
	memcpy(F[0].wire, F[0].plain, (size_t)F[0].plainlen);
	F[0].wlen = F[0].plainlen;
	F[0].sproto = 0x0800;
	memcpy(F[0].magic, M561_77, 8);
	F[0].mlen = 8;

	F[1].tag = "ps"; F[1].kind = F563_KIND_IP;
	F[1].wlen = f563_pppoe(F[0].plain, F[0].plainlen, F[1].wire, 99, 0x0021);
	memcpy(F[1].cap, F[1].wire, (size_t)F[1].wlen);
	F[1].caplen = F[1].wlen;
	memcpy(F[1].plain, F[0].plain, (size_t)F[0].plainlen);
	F[1].plainlen = F[0].plainlen;
	F[1].sproto = 0x8864;
	memcpy(F[1].magic, M561_77, 8);
	F[1].mlen = 8;

	F[2].tag = "pa";   F[2].kind = F563_KIND_ARP; F[2].spa = 0x0a010090;
	f563_arp_build(&F[2], 0, 0, 0, 0, 0);
	F[3].tag = "tag0"; F[3].kind = F563_KIND_ARP; F[3].spa = 0x0a010091;
	f563_arp_build(&F[3], 1, 0x8100, 0x0000, 0, 0);
	F[4].tag = "q0";   F[4].kind = F563_KIND_ARP; F[4].spa = 0x0a010092;
	f563_arp_build(&F[4], 2, 0x88a8, 0x0000, 0x8100, 0x0000);
	F[5].tag = "q200"; F[5].kind = F563_KIND_ARP; F[5].spa = 0x0a010093;
	f563_arp_build(&F[5], 2, 0x88a8, 0x0000, 0x8100, 0x00c8);

	if (add_table(NFPROTO_BRIDGE, "p63") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p63", "g", 0, 0, 1, NULL)) {
		printf("F563 FAIL|chain\n");
		return 0;
	}
	wfd = cap_open("r1");
	rfd = cap_open("r0");
	sfd = cap_open("s0");
	printf("F563 SECTION|open|wfd=%d|rfd=%d|sfd=%d\n", wfd, rfd, sfd);

	if (!strcmp(mode, "f563ctl")) {
		f563_sec_ctl(F, 6, wfd, rfd, ctls);
		goto done;
	}
	f563_sec_ctl(F, 6, wfd, rfd, ctls);
	if (!strcmp(mode, "f563rd")) {
		f563_sec_rd(F, wfd, rfd, ctls);
	} else if (!strcmp(mode, "f563st")) {
		f563_sec_st(F, wfd, rfd, ctls);
	} else if (!strcmp(mode, "f563pair")) {
		f563_sec_pair(F, wfd, rfd, ctls);
	} else if (!strcmp(mode, "f563ih")) {
		f563_sec_ih(F, wfd, rfd, ctls);
	} else if (!strcmp(mode, "f563ppp")) {
		f563_sec_pppd(F, wfd, rfd, sfd);
	} else if (!strcmp(mode, "f563arp")) {
		f563_sec_arpd(F, wfd, rfd, sfd);
	} else {
		f563_sec_rd(F, wfd, rfd, ctls);
		f563_sec_st(F, wfd, rfd, ctls);
		f563_sec_pair(F, wfd, rfd, ctls);
		f563_sec_ih(F, wfd, rfd, ctls);
		f563_sec_pppd(F, wfd, rfd, sfd);
		f563_sec_arpd(F, wfd, rfd, sfd);
	}
done:
	sh("/nft flush ruleset");
	printf("F563 DONE\n");
	return 0;
}
/* differ564_add.c -- turn 564 / F42.
 *
 * Three sentences F41 left open, closed on the same image (7.3.4-T563,
 * sha 1efbc957...2033) -- no new kernel:
 *
 * DEBT 1 -- PPPoE in the PPPOX_BOUND state.
 * F41 measured only the socket queue: a PPPoX socket in PPPOX_CONNECTED gets
 * the frame via skb_queue_tail() and recv() returns it.  pppox.c's
 * PPPIOCGCHAN sets PPPOX_BOUND and pppoe_rcv_core() then calls
 * ppp_input(&po->chan, skb) instead -- and that is the first place in this
 * whole project where a byte written by a bridge rule reaches a *real IP
 * stack* as a packet: ppp_input -> ppp_receive_nonmp_frame -> skb_pull(2) ->
 * netif_rx on pppN -> ip_rcv.  Section `bound` attaches a real unit
 * (/dev/ppp: PPPIOCNEWUNIT + PPPIOCATTCHAN + PPPIOCCONNECT, no pppd, no
 * negotiation), brings pppN up, gives it 10.9.0.7 peer 10.1.0.1 and binds a
 * UDP socket on 10.9.0.7:5000 -- so the oracle is a userspace recv() of the
 * 18 payload bytes, plus IpInReceives/InHdrErrors/InDelivers, plus pppN's own
 * /proc/net/dev rx bytes, plus the unit file queue (control frames).
 *
 * DEBT 2 -- IPv6 inside PPPoE.
 * nf_flow_pppoe_proto() knows PPP_IPV6, so `meta protocol` on a PPPoE frame
 * carrying 0x0057 sets ethertype 0x86dd and nhoff = 8, and the ip6 white list
 * applies to the store -- which still lands at skb_network_offset() = 14, i.e.
 * EIGHT bytes before the IPv6 header.  One cell of that list (offset 7,
 * hop_limit, len 1) lands on wire byte 21: the low byte of the PPP protocol
 * field, the field that decides data-vs-control.  Section `v6p` measures it,
 * with a real UDPv6 socket on fd00::99:9:5000 and a correct UDPv6 checksum.
 *
 * DEBT 3 -- ARP behind a real VLAN device.
 * F41 could only say "vid != 0 is invisible to the ARP stack".  Section
 * `vlan` sends the same single-tagged ARP frame twice: before `v1` (a vlan on
 * br0, id 100) exists and after -- vlan_do_receive() returns true only in the
 * second case.
 *
 * Views: r0 = the far side of the bridge (AF_PACKET), fd_u = the ppp unit file
 * (control/unknown PPP frames), fd_c = the channel file, u4/u6 = the UDP
 * sockets on pppN.
 */

#include <linux/if_pppox.h>
#include <linux/ppp-ioctl.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/* ---------- counters ---------- */

static unsigned long long f564_snmp(const char *group, const char *field)
{
	FILE *f = fopen("/proc/net/snmp", "r");
	char hdr[4096], val[4096];
	unsigned long long out = 0;
	size_t gl = strlen(group);

	if (!f)
		return 0;
	while (fgets(hdr, sizeof(hdr), f)) {
		char *save = NULL, *tok;
		int idx = 0, want = -1;

		if (strncmp(hdr, group, gl) || hdr[gl] != ':')
			continue;
		if (!fgets(val, sizeof(val), f))
			break;
		tok = strtok_r(hdr + gl + 1, " \t\n", &save);
		while (tok) {
			idx++;
			if (!strcmp(tok, field)) {
				want = idx;
				break;
			}
			tok = strtok_r(NULL, " \t\n", &save);
		}
		if (want < 0)
			break;
		save = NULL;
		idx = 0;
		tok = strtok_r(val + gl + 1, " \t\n", &save);
		while (tok) {
			idx++;
			if (idx == want) {
				out = strtoull(tok, NULL, 10);
				break;
			}
			tok = strtok_r(NULL, " \t\n", &save);
		}
		break;
	}
	fclose(f);
	return out;
}

static unsigned long long f564_snmp6(const char *name)
{
	FILE *f = fopen("/proc/net/snmp6", "r");
	char line[256], nm[64];
	unsigned long long x, v = 0;

	if (!f)
		return 0;
	while (fgets(line, sizeof(line), f)) {
		if (sscanf(line, "%63s %llu", nm, &x) == 2 && !strcmp(nm, name)) {
			v = x;
			break;
		}
	}
	fclose(f);
	return v;
}

/* /proc/net/dev: the device's own rx bytes/packets (ppp adds
 * skb->len - PPP_PROTO_LEN before the protocol decision, so this counts frames
 * the IP stack never sees).  sysfs is useless here: sysfs is mounted before
 * unshare() and does not know this netns. */
static void f564_devrx(const char *dev, unsigned long long *b,
		       unsigned long long *p)
{
	FILE *f = fopen("/proc/net/dev", "r");
	char line[512];
	size_t dl = strlen(dev);

	*b = 0;
	*p = 0;
	if (!f)
		return;
	while (fgets(line, sizeof(line), f)) {
		char *c = strchr(line, ':'), *s = line;

		while (*s == ' ' || *s == '\t')
			s++;
		if (!c || strncmp(s, dev, dl) || s + dl != c)
			continue;
		if (sscanf(c + 1, "%llu %llu", b, p) != 2)
			*b = *p = 0;
		break;
	}
	fclose(f);
}

/* read everything queued on a ppp file fd (one skb per read) */
static int f564_drainf(int fd, unsigned char *buf, int max, int ms)
{
	int total = 0;

	if (fd < 0)
		return -1;
	for (;;) {
		struct timeval tv;
		fd_set rfds;
		int r;

		FD_ZERO(&rfds);
		FD_SET(fd, &rfds);
		tv.tv_sec = 0;
		tv.tv_usec = ms * 1000;
		if (select(fd + 1, &rfds, NULL, NULL, &tv) <= 0)
			break;
		r = (int)read(fd, buf + total, (size_t)(max - total));
		if (r <= 0)
			break;
		total += r;
		if (total > max - 8)
			break;
	}
	return total;
}

/* ---------- the bound unit ---------- */

struct f564_ppp {
	int sock, fd_u, fd_c, unit, u4, u6, ok;
	char dev[IFNAMSIZ];
};
static struct f564_ppp P564 = {
	.sock = -1, .fd_u = -1, .fd_c = -1, .unit = -1,
	.u4 = -1, .u6 = -1, .ok = 0, .dev = ""
};
static const char *F564_SEC = "-";

static int f564_addr_peer(const char *dev, uint32_t local_be, uint32_t peer_be,
			  int plen)
{
	struct {
		struct nlmsghdr nlh;
		struct ifaddrmsg ifa;
		char attrs[128];
	} req;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifaddrmsg));
	req.nlh.nlmsg_type = RTM_NEWADDR;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_REPLACE;
	req.nlh.nlmsg_seq = 1;
	req.ifa.ifa_family = AF_INET;
	req.ifa.ifa_prefixlen = (uint8_t)plen;
	req.ifa.ifa_index = (uint32_t)f555_ifindex(dev);
	attr_put(&req.nlh, IFA_LOCAL, &local_be, 4);
	attr_put(&req.nlh, IFA_ADDRESS, &peer_be, 4);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f564_addr6(const char *dev, const unsigned char *a, int plen)
{
	struct {
		struct nlmsghdr nlh;
		struct ifaddrmsg ifa;
		char attrs[128];
	} req;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifaddrmsg));
	req.nlh.nlmsg_type = RTM_NEWADDR;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_REPLACE;
	req.nlh.nlmsg_seq = 1;
	req.ifa.ifa_family = AF_INET6;
	req.ifa.ifa_prefixlen = (uint8_t)plen;
	req.ifa.ifa_index = (uint32_t)f555_ifindex(dev);
	attr_put(&req.nlh, IFA_LOCAL, a, 16);
	attr_put(&req.nlh, IFA_ADDRESS, a, 16);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

static int f564_udp_bind(int fam, uint32_t a4, const unsigned char *a6,
			 unsigned short port)
{
	struct timeval tv;
	int s, one = 1;

	s = socket(fam, SOCK_DGRAM, 0);
	if (s < 0)
		return -errno;
	setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
	if (fam == AF_INET) {
		struct sockaddr_in sa;

		memset(&sa, 0, sizeof(sa));
		sa.sin_family = AF_INET;
		sa.sin_addr.s_addr = htonl(a4);
		sa.sin_port = htons(port);
		if (bind(s, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
			int e = errno;

			close(s);
			return -e;
		}
	} else {
		struct sockaddr_in6 sa;

		memset(&sa, 0, sizeof(sa));
		sa.sin6_family = AF_INET6;
		memcpy(&sa.sin6_addr, a6, 16);
		sa.sin6_port = htons(port);
		if (bind(s, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
			int e = errno;

			close(s);
			return -e;
		}
	}
	tv.tv_sec = 0;
	tv.tv_usec = 250000;
	setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	return s;
}

/* the pppd sequence, without pppd: PPPIOCGCHAN marks the socket PPPOX_BOUND,
 * PPPIOCATTCHAN+PPPIOCCONNECT hang the channel on a fresh unit. */
static int f564_ppp_setup(void)
{
	int u = -1, idx = -1, up;

	if (P564.ok)
		return 0;
	P564.sock = f563_pppoe_sock("br0", htons(99), MAC_SRC);
	if (P564.sock < 0) {
		printf("F564 PPP|fail|sock|%d\n", P564.sock);
		return -1;
	}
	if (ioctl(P564.sock, PPPIOCGCHAN, &idx) < 0) {
		printf("F564 PPP|fail|gchan|%d\n", errno);
		return -1;
	}
	P564.fd_u = open("/dev/ppp", O_RDWR);
	if (P564.fd_u < 0) {
		printf("F564 PPP|fail|open_unit|%d\n", errno);
		return -1;
	}
	if (ioctl(P564.fd_u, PPPIOCNEWUNIT, &u) < 0) {
		printf("F564 PPP|fail|newunit|%d\n", errno);
		return -1;
	}
	P564.unit = u;
	P564.fd_c = open("/dev/ppp", O_RDWR);
	if (P564.fd_c < 0) {
		printf("F564 PPP|fail|open_chan|%d\n", errno);
		return -1;
	}
	if (ioctl(P564.fd_c, PPPIOCATTCHAN, &idx) < 0) {
		printf("F564 PPP|fail|attchan|%d\n", errno);
		return -1;
	}
	if (ioctl(P564.fd_c, PPPIOCCONNECT, &u) < 0) {
		printf("F564 PPP|fail|connect|%d\n", errno);
		return -1;
	}
	snprintf(P564.dev, sizeof(P564.dev), "ppp%d", u);
	up = set_up(P564.dev);
	/* ppp_receive_nonmp_frame() frees the frame when the device is down:
	 * `if ((dev->flags & IFF_UP) == 0) kfree_skb()`. */
	printf("F564 PPP|unit=%d|chan=%d|dev=%s|ifindex=%d|up=%d\n", u, idx,
	       P564.dev, f555_ifindex(P564.dev), up);
	printf("F564 PPP|addr4|rc=%d\n",
	       f564_addr_peer(P564.dev, htonl(0x0a090007), htonl(0x0a010001), 32));
	f555_sysctl("/proc/sys/net/ipv4/conf/all/rp_filter", "0");
	f555_sysctl("/proc/sys/net/ipv4/conf/default/rp_filter", "0");
	P564.u4 = f564_udp_bind(AF_INET, 0x0a090007, NULL, 5000);
	printf("F564 PPP|u4=%d\n", P564.u4);
	P564.ok = 1;
	return 0;
}

static const unsigned char F564_V6DST[16] = { 0xfd, 0, 0, 0, 0, 0, 0, 0,
					      0, 0, 0, 0, 0, 0x99, 0, 9 };

static int f564_ppp6_setup(void)
{
	char path[96];

	if (!P564.ok)
		return -1;
	if (P564.u6 >= 0)
		return 0;
	snprintf(path, sizeof(path),
		 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", P564.dev);
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/%s/dad_transmits",
		 P564.dev);
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/%s/accept_dad",
		 P564.dev);
	f555_sysctl(path, "0");
	printf("F564 PPP6|addr6|rc=%d\n", f564_addr6(P564.dev, F564_V6DST, 128));
	P564.u6 = f564_udp_bind(AF_INET6, 0, F564_V6DST, 5000);
	printf("F564 PPP6|u6=%d\n", P564.u6);
	return 0;
}

/* ---------- the IPv6-in-PPPoE datagram ---------- */

static unsigned int f564_sum(const unsigned char *p, int n, unsigned int acc)
{
	int i;

	for (i = 0; i + 1 < n; i += 2)
		acc += ((unsigned int)p[i] << 8) | p[i + 1];
	if (n & 1)
		acc += (unsigned int)p[n - 1] << 8;
	return acc;
}

static unsigned short f564_fold(unsigned int acc)
{
	while (acc >> 16)
		acc = (acc & 0xffff) + (acc >> 16);
	return (unsigned short)~acc;
}

/* the UDPv6 checksum: a zero checksum is legal only for IPv4, and ip6's
 * udp_rcv() drops a zero-checksum datagram before any socket sees it. */
static void f564_udp6_csum(unsigned char *pkt, int paylen)
{
	unsigned int acc = 0;
	unsigned short c;

	acc = f564_sum(pkt + 8, 32, 0);		/* src + dst */
	acc += (unsigned int)paylen;		/* upper-layer length */
	acc += 17;				/* next header: UDP */
	pkt[40 + 6] = 0;
	pkt[40 + 7] = 0;
	acc = f564_sum(pkt + 40, paylen, acc);
	c = f564_fold(acc);
	if (!c)
		c = 0xffff;
	pkt[40 + 6] = (unsigned char)(c >> 8);
	pkt[40 + 7] = (unsigned char)c;
}

/* ---------- A. the bound unit: what the IP stack does with the frame ---------- */

struct f564_pa {
	const char *arm;
	int gate;
	uint32_t base;
	int off, len, wr;
	unsigned char imm[16];
	const char *what;
};

static void f564_sec_bound(struct f563_frame *F, int rfd)
{
	static struct f564_pa A[] = {
		{ "ctl",      1, NFT_PAYLOAD_NETWORK_HEADER, 0, 0, 0, { 0 },
		  "control: no store" },
		{ "bare",     0, NFT_PAYLOAD_NETWORK_HEADER, 4, 2, 1, { 0x00, 0x04 },
		  "bare gate: the same cell, no meta protocol, no branch" },
		{ "vt",       1, NFT_PAYLOAD_NETWORK_HEADER, 0, 2, 1, { 0x11, 0x91 },
		  "pppoe ver/type+code (first byte must equal the old one)" },
		{ "tos",      1, NFT_PAYLOAD_NETWORK_HEADER, 1, 1, 1, { 0x91 },
		  "tos -> pppoe code" },
		{ "id4",      1, NFT_PAYLOAD_NETWORK_HEADER, 4, 2, 1, { 0x00, 0x04 },
		  "ipv4 id -> pppoe length = 4" },
		{ "idbig",    1, NFT_PAYLOAD_NETWORK_HEADER, 4, 2, 1, { 0x90, 0x91 },
		  "ipv4 id -> pppoe length = 0x9091" },
		{ "ttl",      1, NFT_PAYLOAD_NETWORK_HEADER, 8, 1, 1, { 0x90 },
		  "ttl -> ip ver/ihl" },
		{ "ttlsame",  1, NFT_PAYLOAD_NETWORK_HEADER, 8, 1, 1, { 0x45 },
		  "ttl -> ip ver/ihl, same value: the write changes nothing" },
		{ "ttl2",     1, NFT_PAYLOAD_NETWORK_HEADER, 8, 2, 1, { 0x90, 0x00 },
		  "ttl(2b) -> ver/ihl + tos" },
		{ "csum",     1, NFT_PAYLOAD_NETWORK_HEADER, 10, 2, 1, { 0x90, 0x91 },
		  "check -> ip tot_len" },
		{ "saddr",    1, NFT_PAYLOAD_NETWORK_HEADER, 12, 4, 1,
		  { 0x90, 0x91, 0x92, 0x93 }, "saddr -> ip id + frag_off" },
		{ "daddr",    1, NFT_PAYLOAD_NETWORK_HEADER, 16, 4, 1,
		  { 0x90, 0x91, 0x92, 0x93 }, "daddr -> ttl + proto + csum" },
		{ "trsaddr",  1, NFT_PAYLOAD_NETWORK_HEADER, 20, 4, 1,
		  { 0x90, 0x91, 0x92, 0x93 }, "the real saddr: refused by the list" },
		{ "trdaddr",  1, NFT_PAYLOAD_NETWORK_HEADER, 24, 4, 1,
		  { 0x90, 0x91, 0x92, 0x93 }, "the real daddr: refused by the list" },
		{ "nh6",      1, NFT_PAYLOAD_NETWORK_HEADER, 6, 2, 1,
		  { 0xff, 0xff }, "the PPP protocol field: no such cell in the ip4 list" },
		{ "ll6",      1, NFT_PAYLOAD_LL_HEADER, 6, 2, 1, { 0xff, 0xff },
		  "@ll offset 6: inside the 14-boundary, writes the source MAC" },
		{ "ll13",     1, NFT_PAYLOAD_LL_HEADER, 13, 1, 1, { 0xff },
		  "@ll offset 13: the last allowed byte, the ethertype's low byte" },
		{ "ll14",     1, NFT_PAYLOAD_LL_HEADER, 14, 2, 1, { 0x90, 0x91 },
		  "@ll offset 14: the PPPoE header, refused (boundary 14)" },
	};
	int i, n = (int)(sizeof(A) / sizeof(A[0]));

	F564_SEC = "bound";
	if (f564_ppp_setup())
		return;
	for (i = 0; i < n; i++) {
		struct f559_out o;
		unsigned char ub[1024], cb[1024], rx[1024], rf[1024];
		unsigned long long ip0[4], ip1[4], pb, pp, pb1, pp1;
		char hi[80], hux[256], hun[256], hc[128], hr[260], hw[260];
		int un, cn, rxn, rn, sk = 0;

		memset(&o, 0, sizeof(o));
		memset(&ip0, 0, sizeof(ip0));
		f564_drainf(P564.fd_u, ub, (int)sizeof(ub), 0);
		f564_drainf(P564.fd_c, cb, (int)sizeof(cb), 0);
		while (P564.u4 >= 0 && recv(P564.u4, rx, sizeof(rx), MSG_DONTWAIT) >= 0)
			;
		snprintf(PRE57, sizeof(PRE57), "f64.bb.%s", A[i].arm);
		f557_flush(NFPROTO_BRIDGE, "p64", "g", &o.acks);
		o.rc = f563_install(NFPROTO_BRIDGE, "p64", "g", PRE57, A[i].gate,
				    A[i].base, 0, 0, A[i].off, A[i].len, NULL,
				    A[i].wr, 0, A[i].imm, 1, 1);
		nfl_drain(NFL59);
		o.cnt0 = f555_count(NFPROTO_BRIDGE, "p64", "g");
		ip0[0] = f564_snmp("Ip", "InReceives");
		ip0[1] = f564_snmp("Ip", "InHdrErrors");
		ip0[2] = f564_snmp("Ip", "InAddrErrors");
		ip0[3] = f564_snmp("Ip", "InDelivers");
		f564_devrx(P564.dev, &pb, &pp);
		if (rfd >= 0)
			cap_drain(rfd);
		o.snd = pkt_send_p("s0", F[1].wire, F[1].wlen, F[1].sproto);
		usleep(60000);
		rxn = -1;
		if (P564.u4 >= 0) {
			rxn = (int)recv(P564.u4, rx, sizeof(rx), MSG_DONTWAIT);
			/* keep rx: the drain below reads into a scratch buffer */
			{
				unsigned char sc[256];

				while (recv(P564.u4, sc, sizeof(sc),
					    MSG_DONTWAIT) >= 0)
					;
			}
		}
		ip1[0] = f564_snmp("Ip", "InReceives");
		ip1[1] = f564_snmp("Ip", "InHdrErrors");
		ip1[2] = f564_snmp("Ip", "InAddrErrors");
		ip1[3] = f564_snmp("Ip", "InDelivers");
		f564_devrx(P564.dev, &pb1, &pp1);
		un = f564_drainf(P564.fd_u, ub, (int)sizeof(ub), 0);
		cn = f564_drainf(P564.fd_c, cb, (int)sizeof(cb), 0);
		o.cnt = f555_count(NFPROTO_BRIDGE, "p64", "g");
		rn = f558_cap_match(rfd, rf, (int)sizeof(rf), 250, F[1].magic,
				    F[1].mlen, &sk, &o.rpt);
		printf("F564 B|sec=bound|arm=%s|gate=%d|base=%u|off=%d|len=%d|wr=%d|"
		       "imm=%s|what=%s|rc=%d|acks=%d|snd=%d|cnt0=%llu|cnt=%llu|"
		       "live=%llu|ipin=%llu|ihdr=%llu|iaddr=%llu|ideliv=%llu|"
		       "prx=%llu|prp=%llu|udp4=%d|uhex=%s|urn=%d|urhex=%s|"
		       "crn=%d|rn=%d|rhex=%s\n",
		       A[i].arm, A[i].gate, (unsigned)A[i].base, A[i].off,
		       A[i].len, A[i].wr,
		       A[i].wr ? f559_hexs(hi, sizeof(hi), A[i].imm, A[i].len) : "-",
		       A[i].what, o.rc, o.acks, o.snd, o.cnt0, o.cnt,
		       o.cnt - o.cnt0, ip1[0] - ip0[0], ip1[1] - ip0[1],
		       ip1[2] - ip0[2], ip1[3] - ip0[3], pb1 - pb, pp1 - pp,
		       rxn, rxn > 0 ? f559_hexs(hux, sizeof(hux), rx, rxn) : "-",
		       un, un > 0 ? f559_hexs(hun, sizeof(hun), ub, un) : "-",
		       cn, rn, rn > 0 ? f559_hexs(hr, sizeof(hr), rf,
						  rn < 48 ? rn : 48) : "-");
	}

	/* The ll13 arm above wrote the ethertype's low byte (0x8864 -> 0x88ff)
	 * and the frame was STILL delivered.  Either the receive path reads the
	 * byte (and 0x88ff is somehow a session frame), or it uses the
	 * skb->protocol that eth_type_trans() cached before the hook ran.
	 * The same bytes, sent from outside with no rule at all, decide it. */
	{
		struct f559_out o;
		unsigned char fr2[128], rx[1024];
		unsigned long long ip0, ip1, pb, pp, pb1, pp1;
		int rxn, ack2 = 0;

		memset(&o, 0, sizeof(o));
		memcpy(fr2, F[1].wire, (size_t)F[1].wlen);
		fr2[12] = 0x88;
		fr2[13] = 0xff;
		f564_drainf(P564.fd_u, (unsigned char[256]){ 0 }, 256, 0);
		while (P564.u4 >= 0 && recv(P564.u4, rx, sizeof(rx), MSG_DONTWAIT) >= 0)
			;
		f557_flush(NFPROTO_BRIDGE, "p64", "g", &ack2);
		o.cnt0 = f555_count(NFPROTO_BRIDGE, "p64", "g");
		ip0 = f564_snmp("Ip", "InReceives");
		f564_devrx(P564.dev, &pb, &pp);
		o.snd = pkt_send_p("s0", fr2, F[1].wlen, 0x88ff);
		usleep(60000);
		rxn = -1;
		if (P564.u4 >= 0)
			rxn = (int)recv(P564.u4, rx, sizeof(rx), MSG_DONTWAIT);
		ip1 = f564_snmp("Ip", "InReceives");
		f564_devrx(P564.dev, &pb1, &pp1);
		o.cnt = f555_count(NFPROTO_BRIDGE, "p64", "g");
		printf("F564 B|sec=bound|arm=pre88ff|gate=-1|base=-1|off=-1|len=-1|"
		       "wr=0|imm=-|what=the ll13 bytes, sent from outside with no rule|"
		       "rc=-1|acks=0|snd=%d|cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|"
		       "ihdr=0|iaddr=0|ideliv=0|prx=%llu|prp=%llu|udp4=%d|uhex=-|"
		       "urn=0|urhex=-|crn=0|rn=-1|rhex=-\n",
		       o.snd, o.cnt0, o.cnt, o.cnt - o.cnt0, ip1 - ip0,
		       pb1 - pb, pp1 - pp, rxn);
	}
}

/* ---------- B. IPv6 inside PPPoE ---------- */

static void f564_sec_v6p(struct f563_frame *F, int rfd)
{
	static struct f564_pa A[] = {
		{ "ctl",      1, NFT_PAYLOAD_NETWORK_HEADER, 0, 0, 0, { 0 },
		  "control: no store" },
		{ "hop",      1, NFT_PAYLOAD_NETWORK_HEADER, 7, 1, 1, { 0x90 },
		  "hop_limit (len 1) -> wire 21 = the PPP protocol's low byte" },
		{ "hopsame",  1, NFT_PAYLOAD_NETWORK_HEADER, 7, 1, 1, { 0x57 },
		  "the same cell, the PPP protocol's own byte: no change" },
		{ "dscp",     1, NFT_PAYLOAD_NETWORK_HEADER, 0, 4, 1,
		  { 0x60, 0x90, 0x91, 0x92 },
		  "version/tc (len 4) -> pppoe ver/type + code + sid" },
		{ "flow2",    1, NFT_PAYLOAD_NETWORK_HEADER, 2, 2, 1, { 0x90, 0x91 },
		  "flow label low half -> pppoe sid" },
		{ "hdr_same", 1, NFT_PAYLOAD_NETWORK_HEADER, 8, 16, 1,
		  { 0x60, 0x00, 0x00, 0x00, 0x00, 0x1a, 0x11, 0x40,
		    0xfd, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
		  "saddr (16) -> wire 22: the header's first 16 bytes, unchanged" },
		{ "hdr_bad",  1, NFT_PAYLOAD_NETWORK_HEADER, 8, 16, 1,
		  { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97,
		    0x98, 0x99, 0x9a, 0x9b, 0x9c, 0x9d, 0x9e, 0x9f },
		  "saddr (16) -> wire 22: version 9" },
		{ "dst",      1, NFT_PAYLOAD_NETWORK_HEADER, 24, 16, 1,
		  { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97,
		    0x98, 0x99, 0x9a, 0x9b, 0x9c, 0x9d, 0x9e, 0x9f },
		  "daddr (16) -> wire 38: saddr[8..15] + daddr[0..7]" },
		{ "one",      1, NFT_PAYLOAD_NETWORK_HEADER, 1, 2, 1, { 0x90, 0x91 },
		  "offset 1: no such cell in the ip6 list" },
		{ "three",    1, NFT_PAYLOAD_NETWORK_HEADER, 3, 2, 1, { 0x90, 0x91 },
		  "offset 3: no such cell in the ip6 list" },
		{ "six",      1, NFT_PAYLOAD_NETWORK_HEADER, 6, 1, 1, { 0x90 },
		  "offset 6: no such cell in the ip6 list" },
	};
	unsigned char plain[256], fr[320];
	int i, n = (int)(sizeof(A) / sizeof(A[0])), plen, flen;

	F564_SEC = "v6p";
	if (f564_ppp_setup() || f564_ppp6_setup())
		return;
	plen = f556_mk_ip6(plain, 0x00, 64);
	f564_udp6_csum(plain + 14, 26);
	flen = f563_pppoe(plain, plen, fr, 99, 0x0057);
	printf("F564 V6|frame|len=%d|wire=%s\n", flen,
	       f559_hexs((char[256]){ 0 }, 256, fr, flen));
	for (i = 0; i < n; i++) {
		struct f559_out o;
		unsigned char ub[1024], cb[1024], rx[1024], rf[1024];
		unsigned long long i0[5], i1[5], pb, pp, pb1, pp1;
		char hi[80], hux[256], hun[256], hr[260];
		int un, cn, rxn, rn, sk = 0;

		memset(&o, 0, sizeof(o));
		f564_drainf(P564.fd_u, ub, (int)sizeof(ub), 0);
		f564_drainf(P564.fd_c, cb, (int)sizeof(cb), 0);
		while (P564.u6 >= 0 && recv(P564.u6, rx, sizeof(rx), MSG_DONTWAIT) >= 0)
			;
		snprintf(PRE57, sizeof(PRE57), "f64.vv.%s", A[i].arm);
		f557_flush(NFPROTO_BRIDGE, "p64", "g", &o.acks);
		o.rc = f563_install(NFPROTO_BRIDGE, "p64", "g", PRE57, A[i].gate,
				    A[i].base, 0, 0, A[i].off, A[i].len, NULL,
				    A[i].wr, 0, A[i].imm, 1, 1);
		nfl_drain(NFL59);
		o.cnt0 = f555_count(NFPROTO_BRIDGE, "p64", "g");
		i0[0] = f564_snmp6("Ip6InReceives");
		i0[1] = f564_snmp6("Ip6InHdrErrors");
		i0[2] = f564_snmp6("Ip6InAddrErrors");
		i0[3] = f564_snmp6("Ip6InDelivers");
		i0[4] = f564_snmp6("Udp6InErrors");
		f564_devrx(P564.dev, &pb, &pp);
		if (rfd >= 0)
			cap_drain(rfd);
		o.snd = pkt_send_p("s0", fr, flen, 0x8864);
		usleep(60000);
		rxn = -1;
		if (P564.u6 >= 0) {
			rxn = (int)recv(P564.u6, rx, sizeof(rx), MSG_DONTWAIT);
			{
				unsigned char sc[256];

				while (recv(P564.u6, sc, sizeof(sc),
					    MSG_DONTWAIT) >= 0)
					;
			}
		}
		i1[0] = f564_snmp6("Ip6InReceives");
		i1[1] = f564_snmp6("Ip6InHdrErrors");
		i1[2] = f564_snmp6("Ip6InAddrErrors");
		i1[3] = f564_snmp6("Ip6InDelivers");
		i1[4] = f564_snmp6("Udp6InErrors");
		f564_devrx(P564.dev, &pb1, &pp1);
		un = f564_drainf(P564.fd_u, ub, (int)sizeof(ub), 0);
		cn = f564_drainf(P564.fd_c, cb, (int)sizeof(cb), 0);
		o.cnt = f555_count(NFPROTO_BRIDGE, "p64", "g");
		rn = f558_cap_match(rfd, rf, (int)sizeof(rf), 250, F[0].magic,
				    F[0].mlen, &sk, &o.rpt);
		printf("F564 V|sec=v6p|arm=%s|gate=%d|off=%d|len=%d|wr=%d|imm=%s|"
		       "what=%s|rc=%d|acks=%d|snd=%d|cnt0=%llu|cnt=%llu|live=%llu|"
		       "i6in=%llu|i6hdr=%llu|i6addr=%llu|i6deliv=%llu|u6err=%llu|"
		       "prx=%llu|prp=%llu|udp6=%d|uhex=%s|urn=%d|urhex=%s|"
		       "crn=%d|rn=%d|rhex=%s\n",
		       A[i].arm, A[i].gate, A[i].off, A[i].len, A[i].wr,
		       A[i].wr ? f559_hexs(hi, sizeof(hi), A[i].imm, A[i].len) : "-",
		       A[i].what, o.rc, o.acks, o.snd, o.cnt0, o.cnt,
		       o.cnt - o.cnt0, i1[0] - i0[0], i1[1] - i0[1],
		       i1[2] - i0[2], i1[3] - i0[3], i1[4] - i0[4],
		       pb1 - pb, pp1 - pp, rxn,
		       rxn > 0 ? f559_hexs(hux, sizeof(hux), rx, rxn) : "-",
		       un, un > 0 ? f559_hexs(hun, sizeof(hun), ub, un) : "-",
		       cn, rn, rn > 0 ? f559_hexs(hr, sizeof(hr), rf,
						  rn < 48 ? rn : 48) : "-");
	}
}

/* ---------- C. ARP behind a real VLAN device ---------- */

static void f564_sec_vlan(struct f563_frame *F, int rfd, int sfd)
{
	struct f563_frame fr;
	static const struct {
		const char *arm;
		int off, len, wr;
		unsigned char imm[16];
		const char *what;
	} A[] = {
		{ "ctl_novlan", 0, 0, 0, { 0 }, "vid 100, no vlan device: control" },
		{ "sha_novlan", 8, 2, 1, { 0x90, 0x91 }, "vid 100, no vlan device: sha[0..1]" },
	};
	static const struct {
		const char *arm;
		int off, len, wr;
		unsigned char imm[16];
		const char *what;
	} B[] = {
		{ "ctl_vlan",  0, 0, 0, { 0 }, "vid 100, v1 on br0: control" },
		{ "sha_vlan",  8, 2, 1, { 0x90, 0x91 }, "vid 100, v1 on br0: sha[0..1]" },
		{ "op_vlan",   6, 2, 1, { 0x90, 0x91 }, "vid 100, v1: ar_op = 0x9091 (unknown)" },
		{ "hln_vlan",  4, 2, 1, { 0x90, 0x91 }, "vid 100, v1: offset 4 (ar_hln/pln) is not in the ARP list" },
	};
	unsigned char brmac[6], req[1024], rep[1024], wrq[512];
	int i, ack = 0, have_ar, rn, repn, wrn, sk, bcnt0, bcnt;
	char hx[80], hq[256], hr[256], hw[256], ent[256];

	F564_SEC = "vlan";
	/* the same frame F41 measured without a device: one 0x8100 tag, vid 100 */
	memset(&fr, 0, sizeof(fr));
	fr.kind = F563_KIND_ARP;
	f563_arp_build(&fr, 1, 0x8100, 0x0064, 0, 0);
	f563_getmac("br0", brmac);
	printf("F564 L|brmac=%02x%02x%02x%02x%02x%02x|wire=%s\n",
	       brmac[0], brmac[1], brmac[2], brmac[3], brmac[4], brmac[5],
	       f559_hexs((char[256]){ 0 }, 256, fr.wire, fr.wlen));
	f563_set_noarp("s0");
	printf("F564 L|addr_br0|rc=%d\n",
	       f555_addr_add("br0", htonl(0x0a090001), 24));
	have_ar = 0;
	f557_flush(NFPROTO_ARP, "p64a", "in", &ack);
	f557_flush(NFPROTO_BRIDGE, "p64", "g", &ack);
	if (!add_table(NFPROTO_ARP, "p64a") &&
	    !f556_add_chain(NFPROTO_ARP, "p64a", "in", 0, 0, 1, NULL))
		have_ar = 1;
	else
		printf("F564 FAIL|arp_chain|%d\n", ack);

	/* pass 1: no vlan device */
	for (i = 0; i < (int)(sizeof(A) / sizeof(A[0])); i++) {
		struct f559_out o;
		int cnt0, cnt, ack2 = 0;

		memset(&o, 0, sizeof(o));
		fr.spa = 0x0a010030u + (unsigned int)i;
		f563_arp_build(&fr, 1, 0x8100, 0x0064, 0, 0);
		snprintf(PRE57, sizeof(PRE57), "f64.ll.%s", A[i].arm);
		f557_flush(NFPROTO_BRIDGE, "p64", "g", &ack2);
		if (have_ar) {
			f557_flush(NFPROTO_ARP, "p64a", "in", &ack2);
			f563_install(NFPROTO_ARP, "p64a", "in", PRE57, 0,
				     NFT_PAYLOAD_NETWORK_HEADER, 0, 0, 0, 0, NULL,
				     0, 0, NULL, 1, 0);
		}
		o.rc = f563_install(NFPROTO_BRIDGE, "p64", "g", PRE57, 1,
				    NFT_PAYLOAD_NETWORK_HEADER, 0, 0, A[i].off,
				    A[i].len, NULL, A[i].wr, 0, A[i].imm, 1, 1);
		nfl_drain(NFL59);
		cnt0 = have_ar ? (int)f555_count(NFPROTO_ARP, "p64a", "in") : -1;
		bcnt0 = (int)f555_count(NFPROTO_BRIDGE, "p64", "g");
		if (rfd >= 0)
			cap_drain(rfd);
		if (sfd >= 0)
			cap_drain(sfd);
		usleep(15000);
		o.snd = pkt_send_p("r0", fr.wire, fr.wlen, fr.sproto);
		rn = f558_cap_match(rfd, req, (int)sizeof(req), 400, fr.magic,
				    fr.mlen, &sk, &o.rpt);
		sk = 0;
		wrn = f558_cap_match(sfd, wrq, (int)sizeof(wrq), 300, fr.magic,
				     fr.mlen, &sk, &o.wpt);
		sk = 0;
		repn = f558_cap_match(rfd, rep, (int)sizeof(rep), 300, brmac, 6,
				      &sk, &o.wpt);
		cnt = have_ar ? (int)f555_count(NFPROTO_ARP, "p64a", "in") : -1;
		bcnt = (int)f555_count(NFPROTO_BRIDGE, "p64", "g");
		f563_arpent(fr.spa, ent, sizeof(ent));
		printf("F564 L|pass=novlan|arm=%s|off=%d|len=%d|wr=%d|imm=%s|what=%s|"
		       "spa=%08x|rc=%d|snd=%d|live=%d|reqn=%d|wrn=%d|reqhex=%s|repn=%d|"
		       "rephex=%s|arccnt0=%d|arccnt=%d|arc=%d|ent=%s\n",
		       A[i].arm, A[i].off, A[i].len, A[i].wr,
		       A[i].wr ? f559_hexs(hx, sizeof(hx), A[i].imm, A[i].len) : "-",
		       A[i].what, fr.spa, o.rc, o.snd, bcnt - bcnt0, rn, wrn,
		       rn > 0 ? f559_hexs(hq, sizeof(hq), req, rn < 46 ? rn : 46) : "-",
		       repn,
		       repn > 0 ? f559_hexs(hr, sizeof(hr), rep, repn < 46 ? repn : 46) : "-",
		       cnt0, cnt, cnt < 0 ? -1 : cnt - cnt0, ent[0] ? ent : "-");
	}

	/* now the device exists: vlan 100 on top of br0 -- the device the
	 * receive path looks for in vlan_do_receive(). */
	ack = f558_link_add_vlan("v1", "br0", 100);
	printf("F564 L|vlan_add|rc=%d|ifindex=%d\n", ack, f555_ifindex("v1"));
	{
		char path[96];

		snprintf(path, sizeof(path),
			 "/proc/sys/net/ipv6/conf/v1/disable_ipv6");
		f555_sysctl(path, "1");
	}
	ack = set_up("v1");
	printf("F564 L|vlan_up|rc=%d\n", ack);
	usleep(150000);

	for (i = 0; i < (int)(sizeof(B) / sizeof(B[0])); i++) {
		struct f559_out o;
		int cnt0, cnt, ack2 = 0;

		memset(&o, 0, sizeof(o));
		fr.spa = 0x0a010040u + (unsigned int)i;
		f563_arp_build(&fr, 1, 0x8100, 0x0064, 0, 0);
		snprintf(PRE57, sizeof(PRE57), "f64.lm.%s", B[i].arm);
		f557_flush(NFPROTO_BRIDGE, "p64", "g", &ack2);
		if (have_ar) {
			f557_flush(NFPROTO_ARP, "p64a", "in", &ack2);
			f563_install(NFPROTO_ARP, "p64a", "in", PRE57, 0,
				     NFT_PAYLOAD_NETWORK_HEADER, 0, 0, 0, 0, NULL,
				     0, 0, NULL, 1, 0);
		}
		o.rc = f563_install(NFPROTO_BRIDGE, "p64", "g", PRE57, 1,
				    NFT_PAYLOAD_NETWORK_HEADER, 0, 0, B[i].off,
				    B[i].len, NULL, B[i].wr, 0, B[i].imm, 1, 1);
		nfl_drain(NFL59);
		cnt0 = have_ar ? (int)f555_count(NFPROTO_ARP, "p64a", "in") : -1;
		bcnt0 = (int)f555_count(NFPROTO_BRIDGE, "p64", "g");
		if (rfd >= 0)
			cap_drain(rfd);
		if (sfd >= 0)
			cap_drain(sfd);
		usleep(15000);
		o.snd = pkt_send_p("r0", fr.wire, fr.wlen, fr.sproto);
		rn = f558_cap_match(rfd, req, (int)sizeof(req), 400, fr.magic,
				    fr.mlen, &sk, &o.rpt);
		sk = 0;
		wrn = f558_cap_match(sfd, wrq, (int)sizeof(wrq), 300, fr.magic,
				     fr.mlen, &sk, &o.wpt);
		sk = 0;
		repn = f558_cap_match(rfd, rep, (int)sizeof(rep), 300, brmac, 6,
				      &sk, &o.wpt);
		cnt = have_ar ? (int)f555_count(NFPROTO_ARP, "p64a", "in") : -1;
		bcnt = (int)f555_count(NFPROTO_BRIDGE, "p64", "g");
		f563_arpent(fr.spa, ent, sizeof(ent));
		printf("F564 L|pass=vlan|arm=%s|off=%d|len=%d|wr=%d|imm=%s|what=%s|"
		       "spa=%08x|rc=%d|snd=%d|live=%d|reqn=%d|wrn=%d|reqhex=%s|repn=%d|"
		       "rephex=%s|arccnt0=%d|arccnt=%d|arc=%d|ent=%s\n",
		       B[i].arm, B[i].off, B[i].len, B[i].wr,
		       B[i].wr ? f559_hexs(hx, sizeof(hx), B[i].imm, B[i].len) : "-",
		       B[i].what, fr.spa, o.rc, o.snd, bcnt - bcnt0, rn, wrn,
		       rn > 0 ? f559_hexs(hq, sizeof(hq), req, rn < 46 ? rn : 46) : "-",
		       repn,
		       repn > 0 ? f559_hexs(hr, sizeof(hr), rep, repn < 46 ? repn : 46) : "-",
		       cnt0, cnt, cnt < 0 ? -1 : cnt - cnt0, ent[0] ? ent : "-");
	}
	(void)F;
}

/* ---------- main ---------- */

int f564_main(int argc, char **argv)
{
	static struct f563_frame F[6];
	const char *mode = argc > 1 ? argv[1] : "f564";
	int wfd, rfd, sfd;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F564 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F564 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F564 KERNEL|7.3.4-T563\n");
	f556_env_setup();
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL59 = nfl_open(5);
	printf("F564 NFL|%d\n", NFL59);

	memset(F, 0, sizeof(F));
	F[0].tag = "p";
	F[0].kind = F563_KIND_IP;
	F[0].plainlen = f556_mk_ip4(F[0].plain, 5, 17, 64);
	memcpy(F[0].cap, F[0].plain, (size_t)F[0].plainlen);
	F[0].caplen = F[0].plainlen;
	memcpy(F[0].wire, F[0].plain, (size_t)F[0].plainlen);
	F[0].wlen = F[0].plainlen;
	F[0].sproto = 0x0800;
	memcpy(F[0].magic, M561_77, 8);
	F[0].mlen = 8;

	F[1].tag = "ps";
	F[1].kind = F563_KIND_IP;
	F[1].wlen = f563_pppoe(F[0].plain, F[0].plainlen, F[1].wire, 99, 0x0021);
	memcpy(F[1].cap, F[1].wire, (size_t)F[1].wlen);
	F[1].caplen = F[1].wlen;
	memcpy(F[1].plain, F[0].plain, (size_t)F[0].plainlen);
	F[1].plainlen = F[0].plainlen;
	F[1].sproto = 0x8864;
	memcpy(F[1].magic, M561_77, 8);
	F[1].mlen = 8;

	/* the PPPoE frame bytes, so the verifier can rebuild every arm from the
	 * log instead of trusting the C literal */
	printf("F564 FRAME|ps|len=%d|wire=%s\n", F[1].wlen,
	       f559_hexs((char[512]){ 0 }, 512, F[1].wire, F[1].wlen));

	if (add_table(NFPROTO_BRIDGE, "p64") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p64", "g", 0, 0, 1, NULL)) {
		printf("F564 FAIL|chain\n");
		return 0;
	}
	wfd = cap_open("r1");
	rfd = cap_open("r0");
	sfd = cap_open("s0");

	if (!strcmp(mode, "f564b")) {
		f564_sec_bound(F, rfd);
	} else if (!strcmp(mode, "f564v")) {
		f564_sec_v6p(F, rfd);
	} else if (!strcmp(mode, "f564l")) {
		f564_sec_vlan(F, rfd, sfd);
	} else {
		f564_sec_bound(F, rfd);
		f564_sec_v6p(F, rfd);
		f564_sec_vlan(F, rfd, sfd);
	}
	sh("/nft flush ruleset");
	printf("F564 DONE\n");
	return 0;
}

/* ==========================================================================
 * Turn 565 -- F43: the transport base (@th), its three coordinate systems,
 * and the checksum the guard does not pay for.
 *
 * differ565.c is GENERATED: differ564.c with its main() renamed to f564_main,
 * plus this file.  Every helper under the new code is byte-for-byte the one
 * that produced F31..F42; nothing here re-implements netlink, veth, the PPPoX
 * socket or the AF_PACKET tap.
 * ========================================================================== */

static int U565_4B = -1;	/* UDP 10.9.0.7:5001  (the port the rule writes) */
static int U565_6B = -1;	/* UDP [fd00::99:9]:5001                         */

/* ---------- frames ---------- */

/* eth + IPv4 (ihl 5) + UDP + 18 bytes of `fill`.  csum != 0 puts a real
 * UDP checksum in bytes 40..41; with csum == 0 the field stays 0, which is the
 * legal IPv4 "not computed" value the earlier turns measured on. */
static int f565_udp4(unsigned char *out, unsigned short sport,
		     unsigned short dport, int csum, unsigned char fill)
{
	int tot = 20 + 26;
	unsigned char *ip = out + 14, *u = out + 34;
	unsigned int acc;
	unsigned short c;

	memset(out, 0, 256);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x08;
	out[13] = 0x00;
	ip[0] = 0x45;
	ip[2] = (unsigned char)(tot >> 8);
	ip[3] = (unsigned char)tot;
	ip[4] = 0x12;
	ip[5] = 0x34;
	ip[8] = 64;
	ip[9] = 17;
	ip[12] = 0x0a; ip[13] = 0x01; ip[14] = 0x00; ip[15] = 0x01;
	ip[16] = 0x0a; ip[17] = 0x09; ip[18] = 0x00; ip[19] = 0x07;
	c = f556_csum(ip, 20);
	ip[10] = (unsigned char)(c >> 8);
	ip[11] = (unsigned char)c;
	u[0] = (unsigned char)(sport >> 8);
	u[1] = (unsigned char)sport;
	u[2] = (unsigned char)(dport >> 8);
	u[3] = (unsigned char)dport;
	u[4] = 0x00;
	u[5] = 26;
	u[6] = 0x00;
	u[7] = 0x00;
	memset(u + 8, fill, 18);
	if (csum) {
		acc = f564_sum(ip + 12, 8, 0);	/* saddr + daddr */
		acc += 17;			/* protocol       */
		acc += 26;			/* UDP length     */
		acc = f564_sum(u, 26, acc);
		c = f564_fold(acc);
		if (!c)
			c = 0xffff;
		u[6] = (unsigned char)(c >> 8);
		u[7] = (unsigned char)c;
	}
	return 14 + tot;
}

/* eth + IPv4 (proto 6) + TCP (doff 5, SYN) + 18 bytes of 0x77 */
static int f565_tcp4(unsigned char *out, unsigned short sport,
		     unsigned short dport)
{
	int tot = 20 + 20 + 18;
	unsigned char *ip = out + 14, *t = out + 34;
	unsigned short c;

	memset(out, 0, 256);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x08;
	out[13] = 0x00;
	ip[0] = 0x45;
	ip[2] = (unsigned char)(tot >> 8);
	ip[3] = (unsigned char)tot;
	ip[4] = 0x12;
	ip[5] = 0x34;
	ip[8] = 64;
	ip[9] = 6;
	ip[12] = 0x0a; ip[13] = 0x01; ip[14] = 0x00; ip[15] = 0x01;
	ip[16] = 0x0a; ip[17] = 0x09; ip[18] = 0x00; ip[19] = 0x07;
	c = f556_csum(ip, 20);
	ip[10] = (unsigned char)(c >> 8);
	ip[11] = (unsigned char)c;
	t[0] = (unsigned char)(sport >> 8);
	t[1] = (unsigned char)sport;
	t[2] = (unsigned char)(dport >> 8);
	t[3] = (unsigned char)dport;
	t[5] = 0x01;			/* seq = 1 */
	t[12] = 0x50;			/* data offset 5, reserved 0 */
	t[13] = 0x02;			/* SYN */
	t[14] = 0x20;
	t[15] = 0x00;
	memset(t + 20, 0x77, 18);
	return 14 + tot;
}

/* put `ntag` tags (4 bytes each) between the two MACs and the ethertype */
static int f565_tagged(unsigned char *out, const unsigned char *in, int inlen,
		       const unsigned char *tags, int ntag)
{
	memcpy(out, in, 12);
	memcpy(out + 12, tags, (size_t)(4 * ntag));
	memcpy(out + 12 + 4 * ntag, in + 12, (size_t)(inlen - 12));
	return inlen + 4 * ntag;
}

/* ---------- one payload-set expression, with or without the inet csum ---------- */

static void f565_store(struct nlmsghdr *nlh, uint32_t base, uint32_t off,
		       uint32_t len, const unsigned char *imm,
		       int csum, unsigned int csum_off)
{
	struct nlattr *e, *d;

	imm_value(nlh, F562_WR_SREG, imm, (int)len);
	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "payload");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_PAYLOAD_SREG, F562_WR_SREG);
	put_be32(nlh, NFTA_PAYLOAD_BASE, base);
	put_be32(nlh, NFTA_PAYLOAD_OFFSET, off);
	put_be32(nlh, NFTA_PAYLOAD_LEN, len);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_TYPE, (uint32_t)csum);
	put_be32(nlh, NFTA_PAYLOAD_CSUM_OFFSET, csum ? csum_off : 0);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static int f565_install(uint8_t fam, const char *table, const char *chain,
			const char *pre, int gate, uint32_t base,
			int off, int len, const unsigned char *imm,
			int csum, unsigned int csum_off)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;
	int acks = 0;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			fam);
	put_str(nlh, NFTA_RULE_TABLE, table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (gate)
		f562_meta_proto(nlh);
	if (len > 0)
		f565_store(nlh, base, (uint32_t)off, (uint32_t)len, imm, csum,
			   csum_off);
	counter_expr(nlh);
	accept_expr(nlh);
	log_expr(nlh, 5, pre);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, &acks);
}

/* ---------- one arm ---------- */

struct f565_env {
	const char *tag;
	unsigned char wire[512];
	int wlen;
	unsigned short sproto;
};

struct f565_spec {
	const char *arm;
	uint32_t base;
	int off, len;
	unsigned char imm[16];
	int csum;
	unsigned int csum_off;
	const char *what;
};

static void f565_run(const char *sec, const struct f565_env *E,
		     struct f565_spec *S, int n, int gate, int rfd)
{
	int i;

	for (i = 0; i < n; i++) {
		struct f559_out o;
		unsigned char rf[1024], r4[512], r6[512], sc[512];
		unsigned long long ip0[6], ip1[6], pb, pp, pb1, pp1;
		char hi[80], hr[420], h4a[220], h4b[220];
		int rn, sk, u4a = -2, u4b = -2, u6a = -2, u6b = -2;
		int n4a = 0, n4b = 0, n6a = 0, n6b = 0;

		memset(&o, 0, sizeof(o));
		memset(ip0, 0, sizeof(ip0));
		r4[0] = 0;
		r6[0] = 0;
		if (P564.u4 >= 0)
			while (recv(P564.u4, sc, sizeof(sc), MSG_DONTWAIT) >= 0)
				;
		if (U565_4B >= 0)
			while (recv(U565_4B, sc, sizeof(sc), MSG_DONTWAIT) >= 0)
				;
		if (P564.u6 >= 0)
			while (recv(P564.u6, sc, sizeof(sc), MSG_DONTWAIT) >= 0)
				;
		if (U565_6B >= 0)
			while (recv(U565_6B, sc, sizeof(sc), MSG_DONTWAIT) >= 0)
				;
		snprintf(PRE57, sizeof(PRE57), "f65.%s.%s", E->tag, S[i].arm);
		f557_flush(NFPROTO_BRIDGE, "p65", "g", &o.acks);
		o.rc = f565_install(NFPROTO_BRIDGE, "p65", "g", PRE57,
				    S[i].len > 0 ? gate : 0, S[i].base,
				    S[i].off, S[i].len, S[i].imm, S[i].csum,
				    S[i].csum_off);
		nfl_drain(NFL59);
		o.cnt0 = f555_count(NFPROTO_BRIDGE, "p65", "g");
		ip0[0] = f564_snmp("Ip", "InReceives");
		ip0[1] = f564_snmp("Ip", "InHdrErrors");
		ip0[2] = f564_snmp("Ip", "InDelivers");
		ip0[3] = f564_snmp("Udp", "InErrors");
		ip0[4] = f564_snmp6("Ip6InReceives");
		ip0[5] = f564_snmp6("Udp6InErrors");
		f564_devrx(P564.dev, &pb, &pp);
		if (rfd >= 0)
			cap_drain(rfd);
		o.snd = pkt_send_p("s0", E->wire, E->wlen, E->sproto);
		usleep(60000);
		if (P564.u4 >= 0) {
			u4a = (int)recv(P564.u4, r4, sizeof(r4), MSG_DONTWAIT);
			if (u4a > 0)
				n4a = u4a;
		}
		if (U565_4B >= 0) {
			u4b = (int)recv(U565_4B, r4 + 300, 200, MSG_DONTWAIT);
			if (u4b > 0)
				n4b = u4b;
		}
		if (P564.u6 >= 0) {
			u6a = (int)recv(P564.u6, r6, sizeof(r6), MSG_DONTWAIT);
			if (u6a > 0)
				n6a = u6a;
		}
		if (U565_6B >= 0) {
			u6b = (int)recv(U565_6B, r6 + 300, 200, MSG_DONTWAIT);
			if (u6b > 0)
				n6b = u6b;
		}
		ip1[0] = f564_snmp("Ip", "InReceives");
		ip1[1] = f564_snmp("Ip", "InHdrErrors");
		ip1[2] = f564_snmp("Ip", "InDelivers");
		ip1[3] = f564_snmp("Udp", "InErrors");
		ip1[4] = f564_snmp6("Ip6InReceives");
		ip1[5] = f564_snmp6("Udp6InErrors");
		f564_devrx(P564.dev, &pb1, &pp1);
		o.cnt = f555_count(NFPROTO_BRIDGE, "p65", "g");
		rn = f558_cap_match(rfd, rf, (int)sizeof(rf), 250, M561_77, 8,
				    &sk, &o.rpt);
		printf("F565 R|sec=%s|env=%s|arm=%s|gate=%d|base=%u|off=%d|len=%d|"
		       "csum=%d|coff=%u|imm=%s|what=%s|rc=%d|acks=%d|snd=%d|"
		       "cnt0=%llu|cnt=%llu|live=%llu|ipin=%llu|ihdr=%llu|"
		       "ideliv=%llu|udperr=%llu|i6in=%llu|u6err=%llu|"
		       "u5000=%d|u5001=%d|u6_5000=%d|u6_5001=%d|"
		       "prx=%llu|prp=%llu|rn=%d|rpt=%d|rhex=%s|h5000=%s|h5001=%s|"
		       "h6_5000=%s|h6_5001=%s\n",
		       sec, E->tag, S[i].arm, S[i].len > 0 ? gate : 0,
		       (unsigned)S[i].base, S[i].off, S[i].len, S[i].csum,
		       S[i].csum_off,
		       S[i].len > 0 ? f559_hexs(hi, sizeof(hi), S[i].imm,
						S[i].len) : "-",
		       S[i].what, o.rc, o.acks, o.snd, o.cnt0, o.cnt,
		       o.cnt - o.cnt0, ip1[0] - ip0[0], ip1[1] - ip0[1],
		       ip1[2] - ip0[2], ip1[3] - ip0[3], ip1[4] - ip0[4],
		       ip1[5] - ip0[5], u4a, u4b, u6a, u6b, pb1 - pb, pp1 - pp,
		       rn, o.rpt,
		       rn > 0 ? f559_hexs(hr, sizeof(hr), rf, rn < 96 ? rn : 96) : "-",
		       n4a > 0 ? f559_hexs(h4a, sizeof(h4a), r4, n4a) : "-",
		       n4b > 0 ? f559_hexs(h4b, sizeof(h4b), r4 + 300, n4b) : "-",
		       n6a > 0 ? "seen" : "-", n6b > 0 ? "seen" : "-");
	}
}

/* ---------- the arm tables ---------- */

static struct f565_spec G565[] = {
	{ "ctl",  0, 0, 0, { 0 }, 0, 0, "control: counter and accept only" },
	{ "t0_2", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, { 0x90, 0x91 }, 0, 0,
	  "sport" },
	{ "t2_2", NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, { 0x90, 0x91 }, 0, 0,
	  "dport" },
	{ "t4_2", NFT_PAYLOAD_TRANSPORT_HEADER, 4, 2, { 0x90, 0x91 }, 0, 0,
	  "udp length" },
	{ "t6_2", NFT_PAYLOAD_TRANSPORT_HEADER, 6, 2, { 0x90, 0x91 }, 0, 0,
	  "udp checksum" },
	{ "t8_2", NFT_PAYLOAD_TRANSPORT_HEADER, 8, 2, { 0x90, 0x91 }, 0, 0,
	  "first payload word" },
	{ "t0_4", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 4, { 0x90, 0x91, 0x92, 0x93 },
	  0, 0, "sport+dport" },
	{ "t12_4", NFT_PAYLOAD_TRANSPORT_HEADER, 12, 4,
	  { 0x90, 0x91, 0x92, 0x93 }, 0, 0, "payload" },
	{ "t16_2", NFT_PAYLOAD_TRANSPORT_HEADER, 16, 2, { 0x90, 0x91 }, 0, 0,
	  "payload" },
};

static struct f565_spec T565[] = {
	{ "ctl",  0, 0, 0, { 0 }, 0, 0, "control: counter and accept only" },
	{ "t0_2", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, { 0x90, 0x91 }, 0, 0,
	  "tcp sport" },
	{ "t10_4", NFT_PAYLOAD_TRANSPORT_HEADER, 10, 4,
	  { 0x90, 0x91, 0x92, 0x93 }, 0, 0, "straddles ack_seq's first byte" },
	{ "t12_1", NFT_PAYLOAD_TRANSPORT_HEADER, 12, 1, { 0x90 }, 0, 0,
	  "ack_seq, len 1" },
	{ "t12_2", NFT_PAYLOAD_TRANSPORT_HEADER, 12, 2, { 0x90, 0x91 }, 0, 0,
	  "ack_seq, len 2" },
	{ "t12_4", NFT_PAYLOAD_TRANSPORT_HEADER, 12, 4,
	  { 0x90, 0x91, 0x92, 0x93 }, 0, 0, "ack_seq, len 4" },
	{ "t16_2", NFT_PAYLOAD_TRANSPORT_HEADER, 16, 2, { 0x90, 0x91 }, 0, 0,
	  "after ack_seq: flags + window" },
};

/* the same cell, three bases, one packet */
static struct f565_spec R565[] = {
	{ "ll0", NFT_PAYLOAD_LL_HEADER, 0, 2, { 0x90, 0x91 }, 0, 0,
	  "@ll 0: destination MAC" },
	{ "nh0", NFT_PAYLOAD_NETWORK_HEADER, 0, 2, { 0x11, 0x91 }, 0, 0,
	  "@nh 0: the store offset is skb_network_offset() alone (case 0 compares the value with data[0], so the first byte must be the old one)" },
	{ "th0", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, { 0x90, 0x91 }, 0, 0,
	  "@th 0: the true sport" },
};

/* the checksum section: a datagram whose UDP checksum is real */
static struct f565_spec C565[] = {
	{ "ctl",  0, 0, 0, { 0 }, 0, 0, "control: no store" },
	{ "dp_nc", NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, { 0x13, 0x89 }, 0, 0,
	  "dport -> 5001, no csum update" },
	{ "dp_cs", NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, { 0x13, 0x89 }, 1, 6,
	  "dport -> 5001, CSUM_INET at offset 6" },
	{ "sp_cs", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, { 0x99, 0x99 }, 1, 6,
	  "sport -> 0x9999, CSUM_INET" },
	{ "ck_nc", NFT_PAYLOAD_TRANSPORT_HEADER, 6, 2, { 0x90, 0x91 }, 0, 0,
	  "the checksum field itself, no update" },
	{ "ck_cs", NFT_PAYLOAD_TRANSPORT_HEADER, 6, 2, { 0x90, 0x91 }, 1, 6,
	  "the checksum field itself, CSUM_INET at the same offset" },
	{ "pay_cs", NFT_PAYLOAD_TRANSPORT_HEADER, 24, 2, { 0x90, 0x91 }, 1, 6,
	  "payload byte, CSUM_INET" },
	{ "pay_nc", NFT_PAYLOAD_TRANSPORT_HEADER, 24, 2, { 0x90, 0x91 }, 0, 0,
	  "payload byte, no update" },
};

static struct f565_spec V565[] = {
	{ "ctl",  0, 0, 0, { 0 }, 0, 0, "control: no store" },
	{ "t0_2", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, { 0x90, 0x91 }, 0, 0,
	  "udp6 sport" },
	{ "t2_2", NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, { 0x90, 0x91 }, 0, 0,
	  "udp6 dport" },
	{ "t6_2", NFT_PAYLOAD_TRANSPORT_HEADER, 6, 2, { 0x90, 0x91 }, 0, 0,
	  "udp6 checksum" },
	{ "t8_2", NFT_PAYLOAD_TRANSPORT_HEADER, 8, 2, { 0x90, 0x91 }, 0, 0,
	  "udp6 first payload word" },
	{ "dp_nc", NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, { 0x13, 0x89 }, 0, 0,
	  "udp6 dport -> 5001, no csum update (IPv6 has no 'not computed')" },
	{ "dp_cs", NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, { 0x13, 0x89 }, 1, 6,
	  "udp6 dport -> 5001, CSUM_INET at offset 6" },
};

/* ---------- the sections ---------- */

static void f565_setup(void)
{
	U565_4B = f564_udp_bind(AF_INET, 0x0a090007, NULL, 5001);
	U565_6B = f564_udp_bind(AF_INET6, 0, F564_V6DST, 5001);
	printf("F565 SOCK|u4_5001=%d|u6_5001=%d\n", U565_4B, U565_6B);
}

static void f565_print_frames(struct f565_env *E, int n)
{
	int i;
	char h[600];

	for (i = 0; i < n; i++)
		printf("F565 FRAME|%s|len=%d|proto=%04x|wire=%s\n", E[i].tag,
		       E[i].wlen, E[i].sproto,
		       f559_hexs(h, sizeof(h), E[i].wire, E[i].wlen));
}

static void f565_sec_grid(struct f565_env *E, int rfd)
{
	int g;

	for (g = 0; g <= 1; g++) {
		f565_run("thg", &E[0], G565,
			 (int)(sizeof(G565) / sizeof(G565[0])), g, rfd);
		f565_run("thg", &E[1], G565,
			 (int)(sizeof(G565) / sizeof(G565[0])), g, rfd);
		f565_run("thg", &E[2], G565,
			 (int)(sizeof(G565) / sizeof(G565[0])), g, rfd);
		f565_run("thg", &E[3], G565,
			 (int)(sizeof(G565) / sizeof(G565[0])), g, rfd);
	}
}

static void f565_sec_tcp(struct f565_env *E, int rfd)
{
	f565_run("tht", &E[4], T565, (int)(sizeof(T565) / sizeof(T565[0])), 0,
		 rfd);
	f565_run("tht", &E[5], T565, (int)(sizeof(T565) / sizeof(T565[0])), 0,
		 rfd);
	f565_run("tht", &E[5], T565, (int)(sizeof(T565) / sizeof(T565[0])), 1,
		 rfd);
}

static void f565_sec_reach(struct f565_env *E, int rfd)
{
	f565_run("thr", &E[3], R565, (int)(sizeof(R565) / sizeof(R565[0])), 1,
		 rfd);
}

static void f565_sec_csum(struct f565_env *E, int rfd)
{
	f565_run("cs", &E[6], C565, (int)(sizeof(C565) / sizeof(C565[0])), 0,
		 rfd);
	f565_run("cs", &E[7], C565, (int)(sizeof(C565) / sizeof(C565[0])), 1,
		 rfd);
}

static void f565_sec_v6(struct f565_env *E, int rfd)
{
	f565_run("v6", &E[8], V565, (int)(sizeof(V565) / sizeof(V565[0])), 0,
		 rfd);
	f565_run("v6", &E[8], V565, (int)(sizeof(V565) / sizeof(V565[0])), 1,
		 rfd);
}

int f565_main(int argc, char **argv)
{
	static struct f565_env E[9];
	const char *mode = argc > 1 ? argv[1] : "f565";
	unsigned char plain[256], plain_c[256], tcp[256], v6[256];
	int plen, plen_c, tlen, v6len, rfd;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F565 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F565 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F565 KERNEL|7.3.4-T563\n");
	f556_env_setup();
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];
		int i;

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL59 = nfl_open(5);
	printf("F565 NFL|%d\n", NFL59);

	if (add_table(NFPROTO_BRIDGE, "p65") ||
	    f556_add_chain(NFPROTO_BRIDGE, "p65", "g", 0, 0, 1, NULL)) {
		printf("F565 FAIL|chain\n");
		return 0;
	}

	plen = f565_udp4(plain, 40000, 5000, 0, 0x77);
	plen_c = f565_udp4(plain_c, 40000, 5000, 1, 0x77);
	tlen = f565_tcp4(tcp, 40000, 5000);
	v6len = f556_mk_ip6(v6, 0, 64);
	f564_udp6_csum(v6 + 14, 26);	/* the helper wants the IPv6 header */

	/* 0: bare */
	E[0].tag = "p";
	memcpy(E[0].wire, plain, (size_t)plen);
	E[0].wlen = plen;
	E[0].sproto = 0x0800;
	/* 1: one 802.1Q tag, vid 100 */
	{
		unsigned char tg[4] = { 0x81, 0x00, 0x00, 0x64 };

		E[1].tag = "w";
		E[1].wlen = f565_tagged(E[1].wire, plain, plen, tg, 1);
		E[1].sproto = 0x8100;
	}
	/* 2: Q-in-Q 0x88a8 vid 200 + 0x8100 vid 100 */
	{
		unsigned char tg[8] = { 0x88, 0xa8, 0x00, 0xc8,
					0x81, 0x00, 0x00, 0x64 };

		E[2].tag = "q";
		E[2].wlen = f565_tagged(E[2].wire, plain, plen, tg, 2);
		E[2].sproto = 0x88a8;
	}
	/* 3: PPPoE session */
	E[3].tag = "ps";
	E[3].wlen = f563_pppoe(plain, plen, E[3].wire, 99, 0x0021);
	E[3].sproto = 0x8864;
	/* 4: bare TCP */
	E[4].tag = "pt";
	memcpy(E[4].wire, tcp, (size_t)tlen);
	E[4].wlen = tlen;
	E[4].sproto = 0x0800;
	/* 5: TCP inside PPPoE */
	E[5].tag = "pst";
	E[5].wlen = f563_pppoe(tcp, tlen, E[5].wire, 99, 0x0021);
	E[5].sproto = 0x8864;
	/* 6: bare, real UDP checksum */
	E[6].tag = "pu";
	memcpy(E[6].wire, plain_c, (size_t)plen_c);
	E[6].wlen = plen_c;
	E[6].sproto = 0x0800;
	/* 7: the same datagram inside PPPoE */
	E[7].tag = "psu";
	E[7].wlen = f563_pppoe(plain_c, plen_c, E[7].wire, 99, 0x0021);
	E[7].sproto = 0x8864;
	/* 8: IPv6 inside PPPoE */
	E[8].tag = "ps6";
	E[8].wlen = f563_pppoe(v6, v6len, E[8].wire, 99, 0x0057);
	E[8].sproto = 0x8864;

	f565_print_frames(E, 9);

	rfd = cap_open("r0");
	if (f564_ppp_setup()) {
		printf("F565 FAIL|ppp\n");
		return 0;
	}
	/* the unit's addresses exist only now, so the 5001 sockets are bound
	 * after the unit is up -- a bind to 10.9.0.7 before that is EADDRNOTAVAIL */
	f565_setup();

	if (!strcmp(mode, "f565g")) {
		f565_sec_grid(E, rfd);
	} else if (!strcmp(mode, "f565t")) {
		f565_sec_tcp(E, rfd);
		f565_sec_reach(E, rfd);
	} else if (!strcmp(mode, "f565c")) {
		f565_sec_csum(E, rfd);
	} else if (!strcmp(mode, "f565v")) {
		f564_ppp6_setup();
		if (U565_6B < 0)
			U565_6B = f564_udp_bind(AF_INET6, 0, F564_V6DST, 5001);
		printf("F565 SOCK6|u6_5001=%d\n", U565_6B);
		f565_sec_v6(E, rfd);
	} else {
		f565_sec_grid(E, rfd);
		f565_sec_tcp(E, rfd);
		f565_sec_reach(E, rfd);
		f565_sec_csum(E, rfd);
		f564_ppp6_setup();
		if (U565_6B < 0)
			U565_6B = f564_udp_bind(AF_INET6, 0, F564_V6DST, 5001);
		printf("F565 SOCK6|u6_5001=%d\n", U565_6B);
		f565_sec_v6(E, rfd);
	}
	sh("/nft flush ruleset");
	printf("F565 DONE\n");
	return 0;
}

/* ==========================================================================
 * Turn 566 -- F44: the two pktinfo constructors F43 never measured
 * (`nft_set_pktinfo_ipv4()` at the layer-3 hooks of families `ip`/`inet`,
 * and `nft_set_pktinfo_ipv4_ingress()` at the inet ingress door), plus the
 * guard asymmetry the two ingress doors create: `nft_nh_write_ok()` and
 * `nft_in_ingress()` read `pkt->state->pf`, and one of the two handlers
 * rewrites that field before building the pktinfo.
 *
 * differ566.c is GENERATED: differ565.c with its main() renamed to f564_main,
 * plus this file.  Every helper under the new code is byte-for-byte the one
 * that produced F31..F43.
 * ========================================================================== */

#define NFULA_L2HDR_	21	/* nfulnl_attr_type, system header has no name */

static int U566_4B = -1;	/* UDP 10.9.0.7:5001 */
static int NFL66 = -1;

/* ---------- frames ---------- */

struct f566_frame {
	const char *tag;
	unsigned char wire[600];
	int wlen;
	unsigned short sproto;
};

/* ---------- the four doors ---------- */

struct f566_door {
	const char *tag;
	uint8_t fam;
	const char *table;
	const char *dev;	/* NULL for the layer-3 hooks */
	uint32_t hook;
	int prio0;		/* counter-only chain  */
	int prio1;		/* store/read chain    */
};

/* hook numbers: NF_INET_PRE_ROUTING = 0, NF_NETDEV_INGRESS = 1,
 * NF_INET_INGRESS = 5 (uapi/linux/netfilter.h). */
static struct f566_door D566[] = {
	{ "ipp", NFPROTO_IPV4,   "d66a", NULL, 0,  0, 10 },
	{ "inp", NFPROTO_INET,   "d66b", NULL, 0, 20, 30 },
	{ "ndg", NFPROTO_NETDEV, "d66c", "s1", 0, 40, 50 },
	{ "ieg", NFPROTO_INET,   "d66d", "s1", 5,  0, 10 },
};
#define ND66 4

/* ---------- /proc/net/netstat (IPExt), which /proc/net/snmp lacks ---------- */

static unsigned long long f566_netstat(const char *group, const char *field)
{
	FILE *f = fopen("/proc/net/netstat", "r");
	char hdr[4096], val[4096];
	unsigned long long out = 0;
	size_t gl = strlen(group);

	if (!f)
		return 0;
	while (fgets(hdr, sizeof(hdr), f)) {
		char *save = NULL, *tok;
		int idx = 0, want = -1;

		if (strncmp(hdr, group, gl) || hdr[gl] != ':')
			continue;
		if (!fgets(val, sizeof(val), f))
			break;
		tok = strtok_r(hdr + gl + 1, " \t\n", &save);
		while (tok) {
			idx++;
			if (!strcmp(tok, field)) {
				want = idx;
				break;
			}
			tok = strtok_r(NULL, " \t\n", &save);
		}
		if (want < 0)
			break;
		save = NULL;
		idx = 0;
		tok = strtok_r(val + gl + 1, " \t\n", &save);
		while (tok) {
			idx++;
			if (idx == want) {
				out = strtoull(tok, NULL, 10);
				break;
			}
			tok = strtok_r(NULL, " \t\n", &save);
		}
		break;
	}
	fclose(f);
	return out;
}

/* ---------- chains: two per door ----------
 * `pre0` (prio 0)  counter + log("p") + accept   -- did the hook run at all?
 * `ch`   (prio 10) [meta] [store|read] log("s") + counter + accept
 * The two are separate base chains, so an `accept` in the first does not keep
 * the second from running (measured in F37: two base chains, one hook).
 */

static int f566_chains(void)
{
	int i, rc = 0;

	for (i = 0; i < ND66; i++) {
		struct f566_door *D = &D566[i];

		rc |= add_table(D->fam, D->table);
		rc |= f556_add_chain(D->fam, D->table, "pre0", D->hook,
				     (uint32_t)D->prio0, 1, D->dev);
		rc |= f556_add_chain(D->fam, D->table, "ch", D->hook,
				     (uint32_t)D->prio1, 1, D->dev);
	}
	return rc;
}

static void f566_flush_all(void)
{
	int i, acks = 0;

	for (i = 0; i < ND66; i++) {
		f557_flush(D566[i].fam, D566[i].table, "pre0", &acks);
		f557_flush(D566[i].fam, D566[i].table, "ch", &acks);
	}
}

/* mode 0: none; 1: store; 2: read + cmp against `imm` */
static int f566_rule(const struct f566_door *D, const char *chain,
		     const char *prefix, int gate, uint32_t base, int off,
		     int len, const unsigned char *imm, int mode, int *acks)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			D->fam);
	put_str(nlh, NFTA_RULE_TABLE, D->table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (gate)
		f562_meta_proto(nlh);
	if (mode == 1)
		f565_store(nlh, base, (uint32_t)off, (uint32_t)len, imm, 0, 0);
	else if (mode == 2) {
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, imm, len);
	}
	log_expr(nlh, 5, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, acks);
}

/* ---------- the NFLOG reader: what the hook saw, after the store ---------- */

struct f566_log {
	int seen;
	int l2;
	int plen;
	unsigned char p[96];
};

static void f566_parse_log(unsigned char *buf, int len, struct f566_log *pre,
			   struct f566_log *post)
{
	struct nlmsghdr *h;

	for (h = (struct nlmsghdr *)buf; NLMSG_OK(h, len); h = NLMSG_NEXT(h, len)) {
		const char *p, *end, *prefix = NULL;
		const unsigned char *pl = NULL;
		int pll = 0, l2 = 0;

		if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
			continue;
		p = (const char *)h + NLMSG_HDRLEN + sizeof(struct nfgenmsg);
		end = (const char *)h + h->nlmsg_len;
		for (; p + (int)sizeof(struct nlattr) <= end; ) {
			const struct nlattr *a = (const struct nlattr *)p;
			int al = (int)a->nla_len;
			int t;

			if (al < (int)sizeof(*a) || p + al > end)
				break;
			t = a->nla_type & 0x3fff;
			if (t == NFULA_PREFIX_)
				prefix = (const char *)a + NLA_HDRLEN;
			else if (t == NFULA_PAYLOAD_) {
				pl = (const unsigned char *)a + NLA_HDRLEN;
				pll = al - NLA_HDRLEN;
			} else if (t == NFULA_L2HDR_)
				l2 = al - NLA_HDRLEN;
			p += NLA_ALIGN_(al);
		}
		if (!prefix || !pl)
			continue;
		if (prefix[0] == 'p') {
			pre->seen++;
			pre->l2 = l2;
			pre->plen = pll < (int)sizeof(pre->p) ? pll : (int)sizeof(pre->p);
			memcpy(pre->p, pl, (size_t)pre->plen);
		} else {
			post->seen++;
			post->l2 = l2;
			post->plen = pll < (int)sizeof(post->p) ? pll : (int)sizeof(post->p);
			memcpy(post->p, pl, (size_t)post->plen);
		}
	}
}

static void f566_logs(int fd, struct f566_log *pre, struct f566_log *post)
{
	unsigned char b[16384];
	int guard = 0, rl;

	memset(pre, 0, sizeof(*pre));
	memset(post, 0, sizeof(*post));
	if (fd < 0)
		return;
	while (guard++ < 64) {
		rl = (int)recv(fd, b, sizeof(b), MSG_DONTWAIT);
		if (rl <= 0)
			break;
		f566_parse_log(b, rl, pre, post);
	}
}

static int f566_drain(int fd, int *firstlen)
{
	unsigned char b[512];
	int n = 0, r;

	if (firstlen)
		*firstlen = -1;
	if (fd < 0)
		return -1;
	while (n < 6) {
		r = (int)recv(fd, b, sizeof(b), MSG_DONTWAIT);
		if (r <= 0)
			break;
		if (n == 0 && firstlen)
			*firstlen = r;
		n++;
	}
	return n;
}

/* ---------- one arm ---------- */

static void f566_arm(const char *sec, const struct f566_door *D,
		     const struct f566_frame *E, const char *arm,
		     int gate, uint32_t base, int off, int len,
		     const unsigned char *imm, int mode, int rfd,
		     const struct f559_out *ctl, struct f559_out *out)
{
	struct f559_out o;
	struct f566_log pre, post;
	unsigned char rf[1024];
	char hi[64], hpre[220], hpost[220], hr[440], cw[440];
	unsigned long long cntp0, cnts0, cntp1, cnts1;
	unsigned long long ip0[4], ip1[4];
	int rcp, rcs, acks, snd, rn = 0, sk = 0, rchg = 0;
	int u5000 = 0, u5001 = 0, f0 = -1, f1 = -1;

	f566_flush_all();
	acks = 0;
	rcp = f566_rule(D, "pre0", "p", 0, 0, 0, 0, NULL, 0, &acks);
	acks = 0;
	rcs = f566_rule(D, "ch", "s", gate, base, off, len, imm, mode, &acks);

	nfl_drain(NFL66);
	cntp0 = f555_count(D->fam, D->table, "pre0");
	cnts0 = f555_count(D->fam, D->table, "ch");
	ip0[0] = f564_snmp("Ip", "InReceives");
	ip0[1] = f564_snmp("Ip", "InHdrErrors");
	ip0[2] = f564_snmp("Ip", "InDelivers");
	ip0[3] = f566_netstat("IpExt", "InTruncatedPkts");
	f566_drain(P564.u4, NULL);
	f566_drain(U566_4B, NULL);
	if (rfd >= 0)
		cap_drain(rfd);
	memset(&o, 0, sizeof(o));
	o.rn = 0;
	o.wpt = -1;
	o.rpt = -1;
	snd = pkt_send_p("s0", E->wire, E->wlen, E->sproto);
	usleep(70000);
	u5000 = f566_drain(P564.u4, &f0);
	u5001 = f566_drain(U566_4B, &f1);
	cntp1 = f555_count(D->fam, D->table, "pre0");
	cnts1 = f555_count(D->fam, D->table, "ch");
	ip1[0] = f564_snmp("Ip", "InReceives");
	ip1[1] = f564_snmp("Ip", "InHdrErrors");
	ip1[2] = f564_snmp("Ip", "InDelivers");
	ip1[3] = f566_netstat("IpExt", "InTruncatedPkts");
	f566_logs(NFL66, &pre, &post);
	if (rfd >= 0) {
		o.rn = f558_cap_match(rfd, rf, (int)sizeof(rf), 250, M561_77, 8,
				      &sk, &o.rpt);
		rn = o.rn;
		if (rn > 0)
			memcpy(o.r, rf, (size_t)(rn < (int)sizeof(o.r) ? rn : (int)sizeof(o.r)));
	}
	if (ctl && ctl->rn > 0 && rn > 0)
		rchg = f558_chg(cw, sizeof(cw), ctl->r, ctl->rn, rf, rn);
	printf("F566 A|sec=%s|door=%s|env=%s|arm=%s|gate=%d|base=%u|off=%d|"
	       "len=%d|mode=%d|imm=%s|rcp=%d|rcs=%d|sendrc=%d|"
	       "cntp0=%llu|cntp=%llu|livep=%llu|cnts0=%llu|cnts=%llu|lives=%llu|",
	       sec, D->tag, E->tag, arm, gate, (unsigned)base, off, len, mode,
	       (mode && len > 0) ? f559_hexs(hi, sizeof(hi), imm, len) : "-",
	       rcp, rcs, snd, cntp0, cntp1, cntp1 - cntp0, cnts0, cnts1,
	       cnts1 - cnts0);
	printf("ipin=%llu|ihdr=%llu|ideliv=%llu|itrun=%llu|u5000=%d|u5001=%d|"
	       "f0=%d|f1=%d|npre=%d|npost=%d|l2=%d|",
	       ip1[0] - ip0[0], ip1[1] - ip0[1], ip1[2] - ip0[2],
	       ip1[3] - ip0[3], u5000, u5001, f0, f1, pre.seen, post.seen,
	       post.l2);
	printf("prelen=%d|pre=%s|postlen=%d|post=%s|",
	       pre.plen, pre.seen ? f559_hexs(hpre, sizeof(hpre), pre.p, pre.plen) : "-",
	       post.plen, post.seen ? f559_hexs(hpost, sizeof(hpost), post.p, post.plen) : "-");
	if (rn > 0)
		f559_hexs(hr, sizeof(hr), rf, rn < 128 ? rn : 128);
	printf("rn=%d|rpt=%d|rchg=%d|rchgs=%s|rhex=%s\n", rn, o.rpt, rchg,
	       rchg > 0 ? cw : "-", rn > 0 ? hr : "-");
	if (out)
		memcpy(out, &o, sizeof(o));
}

/* ---------- specs ---------- */

struct f566_spec {
	const char *arm;
	uint32_t base;
	int off, len;
	unsigned char imm[8];
};

/* the transport base: F43's own eight cells */
static struct f566_spec T566[] = {
	{ "ctl",  0, 0, 0, { 0 } },
	{ "t0_2", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, { 0x90, 0x91 } },
	{ "t2_2", NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, { 0x90, 0x91 } },
	{ "t4_2", NFT_PAYLOAD_TRANSPORT_HEADER, 4, 2, { 0x90, 0x91 } },
	{ "t6_2", NFT_PAYLOAD_TRANSPORT_HEADER, 6, 2, { 0x90, 0x91 } },
	{ "t8_2", NFT_PAYLOAD_TRANSPORT_HEADER, 8, 2, { 0x90, 0x91 } },
	{ "t0_4", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "t12_4", NFT_PAYLOAD_TRANSPORT_HEADER, 12, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "t16_2", NFT_PAYLOAD_TRANSPORT_HEADER, 16, 2, { 0x90, 0x91 } },
};

/* the link base, twelve cells: five inside the first twelve bytes, four on
 * the tag boundary, three past it */
static struct f566_spec L566[] = {
	{ "l0_2",  NFT_PAYLOAD_LL_HEADER, 0, 2, { 0x90, 0x91 } },
	{ "l0_4",  NFT_PAYLOAD_LL_HEADER, 0, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "l6_2",  NFT_PAYLOAD_LL_HEADER, 6, 2, { 0x90, 0x91 } },
	{ "l8_1",  NFT_PAYLOAD_LL_HEADER, 8, 1, { 0x90 } },
	{ "l10_2", NFT_PAYLOAD_LL_HEADER, 10, 2, { 0x90, 0x91 } },
	{ "l12_2", NFT_PAYLOAD_LL_HEADER, 12, 2, { 0x90, 0x91 } },
	{ "l12_4", NFT_PAYLOAD_LL_HEADER, 12, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "l13_1", NFT_PAYLOAD_LL_HEADER, 13, 1, { 0x90 } },
	{ "l14_2", NFT_PAYLOAD_LL_HEADER, 14, 2, { 0x90, 0x91 } },
	{ "l16_2", NFT_PAYLOAD_LL_HEADER, 16, 2, { 0x90, 0x91 } },
	{ "l20_4", NFT_PAYLOAD_LL_HEADER, 20, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "l24_4", NFT_PAYLOAD_LL_HEADER, 24, 4, { 0x90, 0x91, 0x92, 0x93 } },
};

/* the network base, twenty cells: the whole ip4 whitelist plus twelve cells
 * it does not name */
static struct f566_spec N566[] = {
	{ "n0_1",  NFT_PAYLOAD_NETWORK_HEADER, 0, 1, { 0x90 } },
	{ "n0_2",  NFT_PAYLOAD_NETWORK_HEADER, 0, 2, { 0x90, 0x91 } },
	{ "n0_4",  NFT_PAYLOAD_NETWORK_HEADER, 0, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "n1_1",  NFT_PAYLOAD_NETWORK_HEADER, 1, 1, { 0x90 } },
	{ "n2_2",  NFT_PAYLOAD_NETWORK_HEADER, 2, 2, { 0x90, 0x91 } },
	{ "n4_2",  NFT_PAYLOAD_NETWORK_HEADER, 4, 2, { 0x90, 0x91 } },
	{ "n4_4",  NFT_PAYLOAD_NETWORK_HEADER, 4, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "n6_2",  NFT_PAYLOAD_NETWORK_HEADER, 6, 2, { 0x90, 0x91 } },
	{ "n6_4",  NFT_PAYLOAD_NETWORK_HEADER, 6, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "n8_1",  NFT_PAYLOAD_NETWORK_HEADER, 8, 1, { 0x90 } },
	{ "n8_2",  NFT_PAYLOAD_NETWORK_HEADER, 8, 2, { 0x90, 0x91 } },
	{ "n10_2", NFT_PAYLOAD_NETWORK_HEADER, 10, 2, { 0x90, 0x91 } },
	{ "n10_4", NFT_PAYLOAD_NETWORK_HEADER, 10, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "n12_2", NFT_PAYLOAD_NETWORK_HEADER, 12, 2, { 0x90, 0x91 } },
	{ "n12_4", NFT_PAYLOAD_NETWORK_HEADER, 12, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "n16_2", NFT_PAYLOAD_NETWORK_HEADER, 16, 2, { 0x90, 0x91 } },
	{ "n16_4", NFT_PAYLOAD_NETWORK_HEADER, 16, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "n18_2", NFT_PAYLOAD_NETWORK_HEADER, 18, 2, { 0x90, 0x91 } },
	{ "n20_2", NFT_PAYLOAD_NETWORK_HEADER, 20, 2, { 0x90, 0x91 } },
	{ "n20_4", NFT_PAYLOAD_NETWORK_HEADER, 20, 4, { 0x90, 0x91, 0x92, 0x93 } },
};

/* ---------- sections ---------- */

static void f566_sec_td(struct f566_frame *E, int rfd)
{
	int d, e, i;
	int n = (int)(sizeof(T566) / sizeof(T566[0]));

	for (d = 0; d < ND66; d++) {
		for (e = 0; e < 5; e++) {
			struct f559_out ctl;

			memset(&ctl, 0, sizeof(ctl));
			f566_arm("td", &D566[d], &E[e], "ctl", 0, 0, 0, 0,
				 NULL, 0, rfd, NULL, &ctl);
			for (i = 1; i < n; i++)
				f566_arm("td", &D566[d], &E[e], T566[i].arm, 0,
					 T566[i].base, T566[i].off, T566[i].len,
					 T566[i].imm, 1, rfd, &ctl, NULL);
		}
	}
}

/* meta protocol at the two ingress doors, on the two envelopes whose
 * skb->protocol is not 0x0800 */
static void f566_sec_tm(struct f566_frame *E, int rfd)
{
	static const int doors[2] = { 2, 3 };
	static const int envs[2] = { 3, 4 };
	int di, ei, i;
	int n = (int)(sizeof(T566) / sizeof(T566[0]));

	for (di = 0; di < 2; di++) {
		for (ei = 0; ei < 2; ei++) {
			struct f559_out ctl;

			memset(&ctl, 0, sizeof(ctl));
			f566_arm("tm", &D566[doors[di]], &E[envs[ei]], "ctl", 1,
				 0, 0, 0, NULL, 0, rfd, NULL, &ctl);
			for (i = 1; i < n; i++)
				f566_arm("tm", &D566[doors[di]], &E[envs[ei]],
					 T566[i].arm, 1, T566[i].base,
					 T566[i].off, T566[i].len, T566[i].imm, 1,
					 rfd, &ctl, NULL);
		}
	}
}

static void f566_sec_gd(struct f566_frame *E, int rfd)
{
	int d, i;
	int nl = (int)(sizeof(L566) / sizeof(L566[0]));
	int nn = (int)(sizeof(N566) / sizeof(N566[0]));

	for (d = 2; d <= 3; d++) {
		int e;

		for (e = 0; e <= 1; e++) {
			struct f559_out ctl;

			memset(&ctl, 0, sizeof(ctl));
			f566_arm("gd", &D566[d], &E[e], "ctl", 0, 0, 0, 0,
				 NULL, 0, rfd, NULL, &ctl);
			for (i = 0; i < nl; i++)
				f566_arm("gd", &D566[d], &E[e], L566[i].arm, 0,
					 L566[i].base, L566[i].off, L566[i].len,
					 L566[i].imm, 1, rfd, &ctl, NULL);
		}
	}
	/* the network base, bare frame only: the whitelist is the point */
	for (d = 2; d <= 3; d++) {
		struct f559_out ctl;

		memset(&ctl, 0, sizeof(ctl));
		f566_arm("gn", &D566[d], &E[0], "ctl", 0, 0, 0, 0, NULL, 0, rfd,
			 NULL, &ctl);
		for (i = 0; i < nn; i++)
			f566_arm("gn", &D566[d], &E[0], N566[i].arm, 0,
				 N566[i].base, N566[i].off, N566[i].len,
				 N566[i].imm, 1, rfd, &ctl, NULL);
	}
}

/* read == write? three cells whose value in the frame is known */
static void f566_sec_rf(struct f566_frame *E, int rfd)
{
	static const struct {
		const char *arm;
		int off, len;
		unsigned char imm[2];
	} rd[3] = {
		{ "r0_2", 0, 2, { 0x9c, 0x40 } },	/* sport 40000 */
		{ "r2_2", 2, 2, { 0x13, 0x88 } },	/* dport 5000  */
		{ "r6_2", 6, 2, { 0x00, 0x00 } },	/* csum 0      */
	};
	int d, i;

	for (d = 0; d < ND66; d++) {
		struct f559_out ctl;

		memset(&ctl, 0, sizeof(ctl));
		for (i = 0; i < 3; i++)
			f566_arm("rf", &D566[d], &E[0], rd[i].arm, 0,
				 NFT_PAYLOAD_TRANSPORT_HEADER, rd[i].off,
				 rd[i].len, rd[i].imm, 2, rfd, NULL, NULL);
	}
}

/* the socket oracle for "the write landed on the true dport": write 5001
 * into @th,2,2 and ask the UDP socket bound to 10.9.0.7:5001 */
static void f566_sec_dp(struct f566_frame *E, int rfd)
{
	static const int envs[2] = { 0, 4 };	/* p and ps */
	unsigned char imm[2] = { 0x13, 0x89 };
	int d, e;

	for (d = 0; d < ND66; d++)
		for (e = 0; e < 2; e++)
			f566_arm("dp", &D566[d], &E[envs[e]], "dp5001", 0,
				 NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, imm, 1, rfd,
				 NULL, NULL);
}

/* malformed IPv4.  The two ingress doors live in ONE per-device hook list,
 * and the inet door's handler validates before any rule of either family can
 * run -- so the netdev door is measured twice: once with the inet ingress
 * chains present (they drop the frame first) and once with that table gone.
 */
static void f566_md_pass(const char *sec, struct f566_door *D,
			 struct f566_frame *M, int rfd)
{
	static const char *names[3] = { "badver", "ihl4", "trunc" };
	unsigned char imm[1] = { 0x90 };
	int i;

	for (i = 0; i < 3; i++) {
		struct f559_out ctl;

		memset(&ctl, 0, sizeof(ctl));
		f566_arm(sec, D, &M[i], "ctl", 0, 0, 0, 0, NULL, 0, rfd, NULL,
			 &ctl);
		f566_arm(sec, D, &M[i], names[i], 0,
			 NFT_PAYLOAD_NETWORK_HEADER, 8, 1, imm, 1, rfd, &ctl,
			 NULL);
	}
}

static void f566_sec_md(struct f566_frame *M, int rfd)
{
	int i, acks;

	/* 1. both doors present, inet ingress first by priority */
	f566_md_pass("md_both", &D566[2], M, rfd);

	/* 2. the inet ingress table deleted: the netdev door alone */
	sh("/nft delete table inet d66d");
	printf("F566 MD|deleted=inet d66d\n");
	f566_md_pass("md_ndg", &D566[2], M, rfd);

	/* 3. bring the inet ingress door back, delete the netdev one */
	add_table(NFPROTO_INET, "d66d");
	for (i = 3; i <= 3; i++) {
		f556_add_chain(D566[i].fam, D566[i].table, "pre0",
			       D566[i].hook, (uint32_t)D566[i].prio0, 1,
			       D566[i].dev);
		f556_add_chain(D566[i].fam, D566[i].table, "ch",
			       D566[i].hook, (uint32_t)D566[i].prio1, 1,
			       D566[i].dev);
	}
	sh("/nft delete table netdev d66c");
	printf("F566 MD|deleted=netdev d66c\n");
	f566_md_pass("md_ieg", &D566[3], M, rfd);
	(void)acks;
}

/* ---------- diagnostic: which of the eight chains see which frame ---------- */

static void f566_sec_diag(struct f566_frame *E, struct f566_frame *M, int rfd)
{
	int i, e, acks, brc = -1, tfd;
	unsigned long long c0[ND66], c1[ND66], b0, b1;
	struct f566_frame *all[8];
	unsigned long long ip0, ih0, it0;

	for (e = 0; e < 5; e++)
		all[e] = &E[e];
	for (e = 0; e < 3; e++)
		all[5 + e] = &M[e];

	/* a fifth counter at the bridge family, to tell "reached the bridge"
	 * from "reached the stack" */
	add_table(NFPROTO_BRIDGE, "b66z");
	brc = f556_add_chain(NFPROTO_BRIDGE, "b66z", "pre", 0, 0, 1, NULL);
	f566_rule(&D566[0], "pre0", "p", 0, 0, 0, 0, NULL, 0, &acks);
	printf("F566 DIAG|capfd=%d|bridge=%d\n", rfd, brc);
	tfd = cap_open("s1");
	printf("F566 DIAG|tap_s1=%d\n", tfd);
	for (i = 0; i < ND66; i++)
		f566_rule(&D566[i], "ch", "s", 0, 0, 0, 0, NULL, 0, &acks);
	{
		struct nlmsghdr *nlh;
		struct nlattr *exprs;

		nlh = msg_start(opbuf, (int)sizeof(opbuf),
				(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
				NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
				NFPROTO_BRIDGE);
		put_str(nlh, NFTA_RULE_TABLE, "b66z");
		put_str(nlh, NFTA_RULE_CHAIN, "pre");
		exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
		counter_expr(nlh);
		accept_expr(nlh);
		nest_end(nlh, exprs);
		f557_nft_one(opbuf, (int)nlh->nlmsg_len, &acks);
	}
	for (e = 0; e < 8; e++) {
		unsigned char buf[1024], rb[1024];
		int got = 0, sk2 = 0, pt = -1;

		for (i = 0; i < ND66; i++)
			c0[i] = f555_count(D566[i].fam, D566[i].table, "ch");
		b0 = f555_count(NFPROTO_BRIDGE, "b66z", "pre");
		ip0 = f564_snmp("Ip", "InReceives");
		ih0 = f564_snmp("Ip", "InHdrErrors");
		it0 = f566_netstat("IpExt", "InTruncatedPkts");
		if (tfd >= 0)
			cap_drain(tfd);
		pkt_send_p("s0", all[e]->wire, all[e]->wlen, all[e]->sproto);
		if (tfd >= 0) {
			got = f558_cap_match(tfd, buf, (int)sizeof(buf), 300,
					     M561_77, 8, &sk2, &pt);
			if (got <= 0)
				got = 0;
			(void)rb;
		}
		usleep(60000);
		for (i = 0; i < ND66; i++)
			c1[i] = f555_count(D566[i].fam, D566[i].table, "ch");
		b1 = f555_count(NFPROTO_BRIDGE, "b66z", "pre");
		printf("F566 DIAG|env=%s|ipp=%llu|inp=%llu|ndg=%llu|ieg=%llu|"
		       "br=%llu|s1=%d|s1pt=%d|ipin=%llu|ihdr=%llu|itrun=%llu\n",
		       all[e]->tag, c1[0] - c0[0], c1[1] - c0[1], c1[2] - c0[2],
		       c1[3] - c0[3], b1 - b0, got, pt,
		       f564_snmp("Ip", "InReceives") - ip0,
		       f564_snmp("Ip", "InHdrErrors") - ih0,
		       f566_netstat("IpExt", "InTruncatedPkts") - it0);
	}
}

/* ---------- main ---------- */

int f566_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f566";
	unsigned char plain[256], v6[256];
	struct f566_frame E[5], M[3];
	int plen, rfd = -1, i;

	set_up("lo");
	f556_fams();
	printf("F566 KERNEL|7.3.4-T563\n");
	{
		int rc = add_table(NFPROTO_INET, "d66probe");

		printf("F566 FAM|inet|%d\n", rc);
		if (rc == 0)
			sh("/nft delete table inet d66probe");
	}
	f556_env_setup();
	{
		static const char *dv[] = { "all", "default", "lo", "i0", "i1",
					    "s0", "s1", "r0", "r1", "br0" };
		char path[96];

		for (i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", dv[i]);
			f555_sysctl(path, "1");
		}
	}
	NFL66 = nfl_open(5);
	printf("F566 NFL|%d\n", NFL66);

	if (f566_chains()) {
		printf("F566 FAIL|chains\n");
		return 0;
	}

	/* ---- the frames ---- */
	plen = f565_udp4(plain, 40000, 5000, 0, 0x77);
	memset(E, 0, sizeof(E));
	memset(M, 0, sizeof(M));
	E[0].tag = "p";
	memcpy(E[0].wire, plain, (size_t)plen);
	E[0].wlen = plen;
	E[0].sproto = 0x0800;
	{
		unsigned char tg[4] = { 0x81, 0x00, 0x00, 0x64 };

		E[1].tag = "w";
		E[1].wlen = f565_tagged(E[1].wire, plain, plen, tg, 1);
		E[1].sproto = 0x8100;
	}
	{
		/* the same four bytes, vid 0: the priority tag F36 measured as
		 * deliverable, unlike vid 100 */
		unsigned char tg[4] = { 0x81, 0x00, 0x00, 0x00 };

		E[2].tag = "w0";
		E[2].wlen = f565_tagged(E[2].wire, plain, plen, tg, 1);
		E[2].sproto = 0x8100;
	}
	{
		unsigned char tg[8] = { 0x88, 0xa8, 0x00, 0xc8,
					0x81, 0x00, 0x00, 0x64 };

		E[3].tag = "q";
		E[3].wlen = f565_tagged(E[3].wire, plain, plen, tg, 2);
		E[3].sproto = 0x88a8;
	}
	E[4].tag = "ps";
	E[4].wlen = f563_pppoe(plain, plen, E[4].wire, 99, 0x0021);
	E[4].sproto = 0x8864;

	/* malformed: version 6, ihl 4, totlen 300 */
	M[0].tag = "badver";
	memcpy(M[0].wire, plain, (size_t)plen);
	M[0].wire[14] = 0x65;
	M[0].wlen = plen;
	M[0].sproto = 0x0800;
	M[1].tag = "ihl4";
	memcpy(M[1].wire, plain, (size_t)plen);
	M[1].wire[14] = 0x44;
	M[1].wlen = plen;
	M[1].sproto = 0x0800;
	M[2].tag = "trunc";
	memcpy(M[2].wire, plain, (size_t)plen);
	M[2].wire[16] = 0x01;
	M[2].wire[17] = 0x2c;
	M[2].wlen = plen;
	M[2].sproto = 0x0800;

	for (i = 0; i < 5; i++)
		printf("F566 FRAME|%s|len=%d|sproto=%04x|wire=%s\n", E[i].tag,
		       E[i].wlen, E[i].sproto,
		       f559_hexs((char *)v6, sizeof(v6), E[i].wire,
				 E[i].wlen < 96 ? E[i].wlen : 96));
	for (i = 0; i < 3; i++)
		printf("F566 MFRAME|%s|len=%d|wire=%s\n", M[i].tag, M[i].wlen,
		       f559_hexs((char *)v6, sizeof(v6), M[i].wire,
				 M[i].wlen < 96 ? M[i].wlen : 96));

	rfd = cap_open("r0");
	printf("F566 CAP|rfd=%d\n", rfd);
	if (f564_ppp_setup()) {
		printf("F566 FAIL|ppp\n");
		return 0;
	}
	U566_4B = f564_udp_bind(AF_INET, 0x0a090007, NULL, 5001);
	printf("F566 SOCK|u4_5000=%d|u4_5001=%d\n", P564.u4, U566_4B);

	if (!strcmp(mode, "diag")) {
		f566_sec_diag(E, M, rfd);
	} else if (!strcmp(mode, "td")) {
		f566_sec_td(E, rfd);
	} else if (!strcmp(mode, "tm")) {
		f566_sec_tm(E, rfd);
	} else if (!strcmp(mode, "gd")) {
		f566_sec_gd(E, rfd);
	} else if (!strcmp(mode, "rf")) {
		f566_sec_rf(E, rfd);
	} else if (!strcmp(mode, "dp")) {
		f566_sec_dp(E, rfd);
	} else if (!strcmp(mode, "md")) {
		f566_sec_md(M, rfd);
	} else {
		f566_sec_td(E, rfd);
		f566_sec_tm(E, rfd);
		f566_sec_gd(E, rfd);
		f566_sec_rf(E, rfd);
		f566_sec_dp(E, rfd);
		f566_sec_md(M, rfd);
	}
	printf("F566 DONE\n");
	return 0;
}
/* ==========================================================================
 * Turn 567 -- F45: the constructor that WALKS.
 *
 * F44 established that `@th` has one coordinate across four doors because
 * IPv4 computes it as a formula (`ihl*4`).  The IPv6 constructors do not:
 * `nft_set_pktinfo_ipv6()`, `__nft_set_pktinfo_ipv6_validate()` and
 * `nft_set_pktinfo_ipv6_ingress()` all take `thoff` from `ipv6_find_hdr()`,
 * which walks the extension-header chain and also fills `tprot` and
 * `fragoff`.  Same question as F44, one family over: where does `@th` land,
 * what does the guard say, and what happens when the walk fails.
 *
 * differ567.c is GENERATED: differ566.c with its main() renamed to f566_main,
 * plus this file.  Every helper under the new code -- netlink toolkit,
 * veth/bridge/rtnetlink, NFLOG reader, AF_PACKET capture, counter read-back --
 * is byte-for-byte the one that produced F31..F44.
 * ========================================================================== */

#define NFULA_L2HDR_	21

static int U567_6A = -1;	/* UDP6 [fd00::99:9]:5000 */
static int U567_6B = -1;	/* UDP6 [fd00::99:9]:5001 */
static int U567_4A = -1;	/* UDP4 10.9.0.7:5000     */
static int NFL67 = -1;

/* ---------- the five doors ---------- */

struct f567_door {
	const char *tag;
	uint8_t fam;
	const char *table;
	const char *dev;	/* NULL for the layer-3 hooks */
	uint32_t hook;
	int prio0;
	int prio1;
};

static struct f567_door D567[] = {
	{ "ip4p", NFPROTO_IPV4,   "d67a", NULL, 0,  0, 10 },
	{ "ip6p", NFPROTO_IPV6,   "d67b", NULL, 0, 20, 30 },
	{ "inp",  NFPROTO_INET,   "d67c", NULL, 0, 40, 50 },
	{ "ndg",  NFPROTO_NETDEV, "d67d", "s1", 0, 60, 70 },
	{ "ieg",  NFPROTO_INET,   "d67e", "s1", 5,  0, 10 },
};
#define ND67 5

/* ---------- frames ---------- */

struct f567_frame {
	const char *tag;
	unsigned char wire[900];
	int wlen;
	unsigned short sproto;
};

enum {
	K6_PLAIN = 0, K6_HBH, K6_DST, K6_HBDST, K6_FRAG0, K6_FRAGN,
	K6_NONE, K6_BADEXT, K6_DOBAD, K6_TRUNC, K6_VER5, K6_TCP, K6_NKIND
};
#define K6_P4	K6_NKIND	/* the IPv4 control frame, last slot */

static const unsigned char V6SRC[16] = { 0xfd, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0x98, 0, 1 };

/* ---------- small helpers the add file needs its own copy of ---------- */

static int f567_netstat(const char *group, const char *field)
{
	FILE *f = fopen("/proc/net/netstat", "r");
	char hdr[4096], val[4096];
	unsigned long long out = 0;
	size_t gl = strlen(group);

	if (!f)
		return 0;
	while (fgets(hdr, sizeof(hdr), f)) {
		char *save = NULL, *tok;
		int idx = 0, want = -1;

		if (strncmp(hdr, group, gl) || hdr[gl] != ':')
			continue;
		if (!fgets(val, sizeof(val), f))
			break;
		tok = strtok_r(hdr + gl + 1, " \t\n", &save);
		while (tok) {
			idx++;
			if (!strcmp(tok, field)) {
				want = idx;
				break;
			}
			tok = strtok_r(NULL, " \t\n", &save);
		}
		if (want < 0)
			break;
		save = NULL;
		idx = 0;
		tok = strtok_r(val + gl + 1, " \t\n", &save);
		while (tok) {
			idx++;
			if (idx == want) {
				out = strtoull(tok, NULL, 10);
				break;
			}
			tok = strtok_r(NULL, " \t\n", &save);
		}
		break;
	}
	fclose(f);
	return out;
}

static int f567_drain(int fd, int *firstlen)
{
	unsigned char b[512];
	int n = 0, r;

	if (firstlen)
		*firstlen = -1;
	if (fd < 0)
		return -1;
	while (n < 8) {
		r = (int)recv(fd, b, sizeof(b), MSG_DONTWAIT);
		if (r <= 0)
			break;
		if (n == 0 && firstlen)
			*firstlen = r;
		n++;
	}
	return n;
}

static unsigned long long f567_read_ll(const char *path)
{
	FILE *f = fopen(path, "r");
	unsigned long long v = 0;

	if (!f)
		return 0;
	if (fscanf(f, "%llu", &v) != 1)
		v = 0;
	fclose(f);
	return v;
}

/* ---------- the IPv6/UDP frame builders ---------- */

/* UDP checksum over an IPv6 pseudo-header.  `ip` points at the IPv6 header,
 * `udp` at the UDP header, `paylen` is the upper-layer length. */
static void f567_csum6(unsigned char *ip, unsigned char *udp, int paylen)
{
	unsigned int acc = 0;
	unsigned short c;

	acc = f564_sum(ip + 8, 32, 0);
	acc += (unsigned int)paylen;
	acc += 17;
	udp[6] = 0;
	udp[7] = 0;
	acc = f564_sum(udp, paylen, acc);
	c = f564_fold(acc);
	if (!c)
		c = 0xffff;
	udp[6] = (unsigned char)(c >> 8);
	udp[7] = (unsigned char)c;
}

/* kind == K6_TCP gets a TCP header instead of UDP */
static int f567_mk6(unsigned char *out, int kind, unsigned short dport)
{
	unsigned char *ip = out + 14, *ext = ip + 40;
	unsigned char *l4;
	int next, extlen = 0, pay, i, fragoff_word = 0;

	memset(out, 0, 900);
	memcpy(out, M33_BC, 6);
	memcpy(out + 6, MAC_SRC, 6);
	out[12] = 0x86;
	out[13] = 0xdd;

	switch (kind) {
	case K6_PLAIN:  next = 17; extlen = 0;  break;
	case K6_HBH:    next = 0;  extlen = 8;  break;
	case K6_DST:    next = 60; extlen = 8;  break;
	case K6_HBDST:  next = 0;  extlen = 16; break;
	case K6_FRAG0:  next = 44; extlen = 8;  break;
	case K6_FRAGN:  next = 44; extlen = 8; fragoff_word = 8; break;
	case K6_NONE:   next = 59; extlen = 0;  break;
	case K6_BADEXT: next = 0;  extlen = 8;  break;
	case K6_DOBAD:  next = 60; extlen = 8;  break;
	case K6_TRUNC:  next = 17; extlen = 0;  break;
	case K6_VER5:   next = 17; extlen = 0;  break;
	case K6_TCP:    next = 6;  extlen = 0;  break;
	default:        next = 17; extlen = 0;  break;
	}

	if (kind == K6_TCP)
		pay = 20 + 18;
	else if (kind == K6_NONE)
		pay = 0;
	else
		pay = 8 + 18;

	ip[0] = (kind == K6_VER5) ? 0x50 : 0x60;
	if (kind == K6_TRUNC) {
		ip[4] = 0x02;		/* claims 512 bytes of payload */
		ip[5] = 0x00;
	} else {
		ip[4] = (unsigned char)(((extlen + pay) >> 8) & 0xff);
		ip[5] = (unsigned char)((extlen + pay) & 0xff);
	}
	ip[6] = (unsigned char)next;
	ip[7] = 64;
	memcpy(ip + 8, V6SRC, 16);
	memcpy(ip + 24, F564_V6DST, 16);

	/* extension headers */
	if (kind == K6_HBH || kind == K6_BADEXT) {
		ext[0] = 17;		/* next: UDP */
		ext[1] = (kind == K6_BADEXT) ? 15 : 0;	/* 128 bytes vs 8 */
	} else if (kind == K6_HBDST) {
		ext[0] = 60;		/* next: DSTOPTS */
		ext[1] = 0;
		ext[8] = 17;		/* next: UDP */
		ext[9] = 0;
	} else if (kind == K6_DST) {
		ext[0] = 17;
		ext[1] = 0;
	} else if (kind == K6_DOBAD) {
		ext[0] = 17;
		ext[1] = 15;		/* claims 128 bytes, 8 present */
	} else if (kind == K6_FRAG0 || kind == K6_FRAGN) {
		ext[0] = 17;
		ext[1] = 0;
		ext[2] = (unsigned char)(fragoff_word >> 8);
		ext[3] = (unsigned char)fragoff_word;	/* 8 => offset 8 bytes */
		ext[4] = 0x11;
		ext[5] = 0x22;
		ext[6] = 0x33;
		ext[7] = 0x44;
	}

	if (kind == K6_NONE)
		return 14 + 40;

	l4 = ip + 40 + extlen;
	l4[0] = 0x9c;			/* sport 40000 */
	l4[1] = 0x40;
	l4[2] = (unsigned char)(dport >> 8);
	l4[3] = (unsigned char)dport;
	if (kind == K6_TCP) {
		l4[4] = 0x00;
		l4[5] = 0x01;		/* seq */
		l4[12] = 0x50;		/* doff 5 */
		l4[13] = 0x02;		/* SYN */
		l4[14] = 0x20;
		l4[15] = 0x00;
		memset(l4 + 20, 0x77, 18);
		return 14 + 40 + extlen + pay;
	}
	l4[4] = 0x00;
	l4[5] = 26;
	l4[6] = 0;
	l4[7] = 0;
	for (i = 0; i < 18; i++)
		l4[8 + i] = 0x77;
	f567_csum6(ip, l4, 26);
	return 14 + 40 + extlen + pay;
}

/* ---------- chains ---------- */

static int f567_chains(void)
{
	int i, rc = 0;

	for (i = 0; i < ND67; i++) {
		struct f567_door *D = &D567[i];

		rc |= add_table(D->fam, D->table);
		rc |= f556_add_chain(D->fam, D->table, "pre0", D->hook,
				     (uint32_t)D->prio0, 1, D->dev);
		rc |= f556_add_chain(D->fam, D->table, "ch", D->hook,
				     (uint32_t)D->prio1, 1, D->dev);
	}
	return rc;
}

static void f567_flush_all(void)
{
	int i, acks = 0;

	for (i = 0; i < ND67; i++) {
		f557_flush(D567[i].fam, D567[i].table, "pre0", &acks);
		f557_flush(D567[i].fam, D567[i].table, "ch", &acks);
	}
}

/* meta l4proto -> dreg: the only expression that can tell "flags has no
 * L4PROTO" (rule does not fire) from "tprot exists but there is no header"
 * (rule fires and compares 59). */
static void f567_meta_l4(struct nlmsghdr *nlh)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "meta");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_META_KEY, NFT_META_L4PROTO);
	put_be32(nlh, NFTA_META_DREG, F562_RD_DREG);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

/* mode 0: none; 1: store; 2: payload read + cmp; 3: meta(l4proto) + cmp;
 * 4: meta(protocol) + cmp */
static int f567_rule(const struct f567_door *D, const char *chain,
		     const char *prefix, int gate, uint32_t base, int off,
		     int len, const unsigned char *imm, int mode, int mkey,
		     int *acks)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			D->fam);
	put_str(nlh, NFTA_RULE_TABLE, D->table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (gate)
		f562_meta_proto(nlh);
	(void)mkey;
	if (mode == 1)
		f565_store(nlh, base, (uint32_t)off, (uint32_t)len, imm, 0, 0);
	else if (mode == 2) {
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, imm, len);
	} else if (mode == 3) {
		f567_meta_l4(nlh);
		f562_cmp(nlh, F562_RD_DREG, imm, len);
	} else if (mode == 4) {
		f562_meta_proto(nlh);
		f562_cmp(nlh, F562_RD_DREG, imm, len);
	}
	log_expr(nlh, 5, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, acks);
}

/* ---------- NFLOG reader (same parser as F44) ---------- */

struct f567_log {
	int seen;
	int l2;
	int plen;
	unsigned char p[128];
};

static void f567_parse_log(unsigned char *buf, int len, struct f567_log *pre,
			   struct f567_log *post)
{
	struct nlmsghdr *h;

	for (h = (struct nlmsghdr *)buf; NLMSG_OK(h, len); h = NLMSG_NEXT(h, len)) {
		const char *p, *end, *prefix = NULL;
		const unsigned char *pl = NULL;
		int pll = 0, l2 = 0;

		if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
			continue;
		p = (const char *)h + NLMSG_HDRLEN + sizeof(struct nfgenmsg);
		end = (const char *)h + h->nlmsg_len;
		for (; p + (int)sizeof(struct nlattr) <= end; ) {
			const struct nlattr *a = (const struct nlattr *)p;
			int al = (int)a->nla_len;
			int t;

			if (al < (int)sizeof(*a) || p + al > end)
				break;
			t = a->nla_type & 0x3fff;
			if (t == NFULA_PREFIX_)
				prefix = (const char *)a + NLA_HDRLEN;
			else if (t == NFULA_PAYLOAD_) {
				pl = (const unsigned char *)a + NLA_HDRLEN;
				pll = al - NLA_HDRLEN;
			} else if (t == NFULA_L2HDR_)
				l2 = al - NLA_HDRLEN;
			p += NLA_ALIGN_(al);
		}
		if (!prefix || !pl)
			continue;
		if (prefix[0] == 'p') {
			pre->seen++;
			pre->l2 = l2;
			pre->plen = pll < (int)sizeof(pre->p) ? pll : (int)sizeof(pre->p);
			memcpy(pre->p, pl, (size_t)pre->plen);
		} else {
			post->seen++;
			post->l2 = l2;
			post->plen = pll < (int)sizeof(post->p) ? pll : (int)sizeof(post->p);
			memcpy(post->p, pl, (size_t)post->plen);
		}
	}
}

static void f567_logs(int fd, struct f567_log *pre, struct f567_log *post)
{
	unsigned char b[16384];
	int guard = 0, rl;

	memset(pre, 0, sizeof(*pre));
	memset(post, 0, sizeof(*post));
	if (fd < 0)
		return;
	while (guard++ < 64) {
		rl = (int)recv(fd, b, sizeof(b), MSG_DONTWAIT);
		if (rl <= 0)
			break;
		f567_parse_log(b, rl, pre, post);
	}
}

/* ---------- one arm ---------- */

static void f567_arm(const char *sec, const struct f567_door *D,
		     const struct f567_frame *E, const char *arm,
		     int gate, uint32_t base, int off, int len,
		     const unsigned char *imm, int mode, int rfd,
		     struct f559_out *ctl, struct f559_out *out)
{
	struct f559_out o;
	struct f567_log pre, post;
	unsigned char rf[1024];
	char hi[160], hpre[300], hpost[300], hr[440], cw[440];
	unsigned long long cntp0, cnts0, cntp1, cnts1;
	unsigned long long ip0[3], ip1[3], i60[6], i61[6];
	int rcp, rcs, acks, snd, rn = 0, sk = 0, rchg = 0;
	int f0 = -1, f1 = -1, f2 = -1, u6a = 0, u6b = 0, u4 = 0;

	f567_flush_all();
	acks = 0;
	rcp = f567_rule(D, "pre0", "p", 0, 0, 0, 0, NULL, 0, 0, &acks);
	acks = 0;
	rcs = f567_rule(D, "ch", "s", gate, base, off, len, imm, mode, 0, &acks);

	nfl_drain(NFL67);
	cntp0 = f555_count(D->fam, D->table, "pre0");
	cnts0 = f555_count(D->fam, D->table, "ch");
	ip0[0] = f564_snmp("Ip", "InReceives");
	ip0[1] = f564_snmp("Ip", "InDelivers");
	ip0[2] = f567_netstat("IpExt", "InTruncatedPkts");
	i60[0] = f564_snmp6("Ip6InReceives");
	i60[1] = f564_snmp6("Ip6InHdrErrors");
	i60[2] = f564_snmp6("Ip6InTruncatedPkts");
	i60[3] = f564_snmp6("Ip6InDelivers");
	i60[4] = f564_snmp6("Ip6InReasmReqds");
	i60[5] = f564_snmp6("Ip6InUnknownProtos");
	f567_drain(U567_6A, &f0);
	f567_drain(U567_6B, &f1);
	f567_drain(U567_4A, &f2);
	if (rfd >= 0)
		cap_drain(rfd);
	memset(&o, 0, sizeof(o));
	o.wpt = -1;
	o.rpt = -1;
	snd = pkt_send_p("s0", E->wire, E->wlen, E->sproto);
	usleep(70000);
	u6a = f567_drain(U567_6A, NULL);
	u6b = f567_drain(U567_6B, NULL);
	u4 = f567_drain(U567_4A, NULL);
	cntp1 = f555_count(D->fam, D->table, "pre0");
	cnts1 = f555_count(D->fam, D->table, "ch");
	ip1[0] = f564_snmp("Ip", "InReceives");
	ip1[1] = f564_snmp("Ip", "InDelivers");
	ip1[2] = f567_netstat("IpExt", "InTruncatedPkts");
	i61[0] = f564_snmp6("Ip6InReceives");
	i61[1] = f564_snmp6("Ip6InHdrErrors");
	i61[2] = f564_snmp6("Ip6InTruncatedPkts");
	i61[3] = f564_snmp6("Ip6InDelivers");
	i61[4] = f564_snmp6("Ip6InReasmReqds");
	i61[5] = f564_snmp6("Ip6InUnknownProtos");
	f567_logs(NFL67, &pre, &post);
	if (rfd >= 0) {
		o.rn = f558_cap_match(rfd, rf, (int)sizeof(rf), 250, M561_77, 8,
				      &sk, &o.rpt);
		rn = o.rn;
		if (rn > 0)
			memcpy(o.r, rf, (size_t)(rn < (int)sizeof(o.r) ? rn : (int)sizeof(o.r)));
	}
	if (ctl && ctl->rn > 0 && rn > 0)
		rchg = f558_chg(cw, sizeof(cw), ctl->r, ctl->rn, rf, rn);
	printf("F567 A|sec=%s|door=%s|env=%s|arm=%s|gate=%d|base=%u|off=%d|"
	       "len=%d|mode=%d|imm=%s|rcp=%d|rcs=%d|sendrc=%d|",
	       sec, D->tag, E->tag, arm, gate, (unsigned)base, off, len, mode,
	       (len > 0 && imm) ? f559_hexs(hi, sizeof(hi), imm, len) : "-",
	       rcp, rcs, snd);
	printf("cntp0=%llu|cntp=%llu|livep=%llu|cnts0=%llu|cnts=%llu|lives=%llu|",
	       cntp0, cntp1, cntp1 - cntp0, cnts0, cnts1, cnts1 - cnts0);
	printf("ipin=%llu|ideliv=%llu|itrun=%llu|i6in=%llu|i6hdr=%llu|"
	       "i6trun=%llu|i6deliv=%llu|i6reasm=%llu|i6unk=%llu|",
	       ip1[0] - ip0[0], ip1[1] - ip0[1], ip1[2] - ip0[2],
	       i61[0] - i60[0], i61[1] - i60[1], i61[2] - i60[2],
	       i61[3] - i60[3], i61[4] - i60[4], i61[5] - i60[5]);
	printf("u6a=%d|u6b=%d|u4=%d|f6a=%d|f6b=%d|f4=%d|npre=%d|npost=%d|l2=%d|",
	       u6a, u6b, u4, f0, f1, f2, pre.seen, post.seen, post.l2);
	printf("prelen=%d|pre=%s|postlen=%d|post=%s|",
	       pre.plen, pre.seen ? f559_hexs(hpre, sizeof(hpre), pre.p, pre.plen) : "-",
	       post.plen, post.seen ? f559_hexs(hpost, sizeof(hpost), post.p, post.plen) : "-");
	if (rn > 0)
		f559_hexs(hr, sizeof(hr), rf, rn < 128 ? rn : 128);
	printf("rn=%d|rpt=%d|rchg=%d|rchgs=%s|rhex=%s\n", rn, o.rpt, rchg,
	       rchg > 0 ? cw : "-", rn > 0 ? hr : "-");
	if (out)
		memcpy(out, &o, sizeof(o));
}

/* ---------- cells ---------- */

struct f567_spec {
	const char *arm;
	uint32_t base;
	int off, len;
	unsigned char imm[32];
};

/* the transport base: F43's eight cells, unchanged */
static struct f567_spec T567[] = {
	{ "ctl",  0, 0, 0, { 0 } },
	{ "t0_2", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, { 0x90, 0x91 } },
	{ "t2_2", NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, { 0x90, 0x91 } },
	{ "t4_2", NFT_PAYLOAD_TRANSPORT_HEADER, 4, 2, { 0x90, 0x91 } },
	{ "t6_2", NFT_PAYLOAD_TRANSPORT_HEADER, 6, 2, { 0x90, 0x91 } },
	{ "t8_2", NFT_PAYLOAD_TRANSPORT_HEADER, 8, 2, { 0x90, 0x91 } },
	{ "t0_4", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "t12_4", NFT_PAYLOAD_TRANSPORT_HEADER, 12, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "t16_2", NFT_PAYLOAD_TRANSPORT_HEADER, 16, 2, { 0x90, 0x91 } },
};

/* the network base for IPv6: every branch of nft_nh_write_ok_ip6() plus
 * cells it does not name, and two cells whose verdict reads the VALUE */
static struct f567_spec N567[] = {
	{ "n0_1",  NFT_PAYLOAD_NETWORK_HEADER, 0, 1, { 0x60 } },
	{ "n0_1x", NFT_PAYLOAD_NETWORK_HEADER, 0, 1, { 0x90 } },
	{ "n0_2v", NFT_PAYLOAD_NETWORK_HEADER, 0, 2, { 0x61, 0x00 } },
	{ "n0_2x", NFT_PAYLOAD_NETWORK_HEADER, 0, 2, { 0x90, 0x91 } },
	{ "n1_1",  NFT_PAYLOAD_NETWORK_HEADER, 1, 1, { 0x90 } },
	{ "n2_2",  NFT_PAYLOAD_NETWORK_HEADER, 2, 2, { 0x90, 0x91 } },
	{ "n2_4",  NFT_PAYLOAD_NETWORK_HEADER, 2, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "n4_2",  NFT_PAYLOAD_NETWORK_HEADER, 4, 2, { 0x90, 0x91 } },
	{ "n6_2",  NFT_PAYLOAD_NETWORK_HEADER, 6, 2, { 0x90, 0x91 } },
	{ "n7_1",  NFT_PAYLOAD_NETWORK_HEADER, 7, 1, { 0x90 } },
	{ "n7_2",  NFT_PAYLOAD_NETWORK_HEADER, 7, 2, { 0x90, 0x91 } },
	{ "n8_1",  NFT_PAYLOAD_NETWORK_HEADER, 8, 1, { 0x90 } },
	{ "n8_2",  NFT_PAYLOAD_NETWORK_HEADER, 8, 2, { 0x90, 0x91 } },
	{ "n8_16", NFT_PAYLOAD_NETWORK_HEADER, 8, 16,
	  { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97,
	    0x98, 0x99, 0x9a, 0x9b, 0x9c, 0x9d, 0x9e, 0x9f } },
	{ "n24_4", NFT_PAYLOAD_NETWORK_HEADER, 24, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "n24_16", NFT_PAYLOAD_NETWORK_HEADER, 24, 16,
	  { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97,
	    0x98, 0x99, 0x9a, 0x9b, 0x9c, 0x9d, 0x9e, 0x9f } },
	{ "n28_4", NFT_PAYLOAD_NETWORK_HEADER, 28, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "n40_2", NFT_PAYLOAD_NETWORK_HEADER, 40, 2, { 0x90, 0x91 } },
	{ "n44_2", NFT_PAYLOAD_NETWORK_HEADER, 44, 2, { 0x90, 0x91 } },
};

/* ---------- sections ---------- */

/* A. the walk: four envelopes, four doors, eight cells */
static void f567_sec_td(struct f567_frame *E, int rfd)
{
	static const int doors[4] = { 1, 2, 3, 4 };
	static const int envs[4] = { K6_PLAIN, K6_HBH, K6_DST, K6_HBDST };
	int di, ei, i;
	int n = (int)(sizeof(T567) / sizeof(T567[0]));

	for (di = 0; di < 4; di++) {
		for (ei = 0; ei < 4; ei++) {
			struct f559_out ctl;

			memset(&ctl, 0, sizeof(ctl));
			f567_arm("td", &D567[doors[di]], &E[envs[ei]], "ctl", 0,
				 0, 0, 0, NULL, 0, rfd, NULL, &ctl);
			for (i = 1; i < n; i++)
				f567_arm("td", &D567[doors[di]], &E[envs[ei]],
					 T567[i].arm, 0, T567[i].base,
					 T567[i].off, T567[i].len, T567[i].imm, 1,
					 rfd, &ctl, NULL);
		}
	}
}

/* B. fragments and the none-header */
static void f567_sec_tf(struct f567_frame *E, int rfd)
{
	static const int doors[4] = { 1, 2, 3, 4 };
	static const int envs[3] = { K6_FRAG0, K6_FRAGN, K6_NONE };
	int di, ei, i;
	int n = (int)(sizeof(T567) / sizeof(T567[0]));

	for (di = 0; di < 4; di++) {
		for (ei = 0; ei < 3; ei++) {
			struct f559_out ctl;

			memset(&ctl, 0, sizeof(ctl));
			f567_arm("tf", &D567[doors[di]], &E[envs[ei]], "ctl", 0,
				 0, 0, 0, NULL, 0, rfd, NULL, &ctl);
			for (i = 1; i < n; i++)
				f567_arm("tf", &D567[doors[di]], &E[envs[ei]],
					 T567[i].arm, 0, T567[i].base,
					 T567[i].off, T567[i].len, T567[i].imm, 1,
					 rfd, &ctl, NULL);
		}
	}
}

/* C. the network base: ip6 whitelist vs the ingress constant */
static void f567_sec_nh(struct f567_frame *E, int rfd)
{
	static const int doors[4] = { 1, 2, 3, 4 };
	int di, i;
	int n = (int)(sizeof(N567) / sizeof(N567[0]));

	for (di = 0; di < 4; di++) {
		struct f559_out ctl;

		memset(&ctl, 0, sizeof(ctl));
		f567_arm("nh", &D567[doors[di]], &E[K6_PLAIN], "ctl", 0, 0, 0, 0,
			 NULL, 0, rfd, NULL, &ctl);
		for (i = 0; i < n; i++)
			f567_arm("nh", &D567[doors[di]], &E[K6_PLAIN],
				 N567[i].arm, 0, N567[i].base, N567[i].off,
				 N567[i].len, N567[i].imm, 1, rfd, &ctl, NULL);
	}
}

/* D. one chain, one rule, two families */
struct f567_xf {
	const char *arm;
	int off, len;
	unsigned char imm[4];
};

static struct f567_xf X567[] = {
	{ "x2_2",  2, 2, { 0x90, 0x91 } },
	{ "x4_2",  4, 2, { 0x90, 0x91 } },
	{ "x7_1",  7, 1, { 0x90 } },
	{ "x0_2x", 0, 2, { 0x90, 0x91 } },
	{ "x0_2v", 0, 2, { 0x60, 0x00 } },
	{ "x0_2d", 0, 2, { 0x45, 0x00 } },
};

static void f567_sec_xf(struct f567_frame *E, int rfd)
{
	static const int envs[2] = { K6_PLAIN, K6_P4 };
	int ei, i;
	int n = (int)(sizeof(X567) / sizeof(X567[0]));

	for (ei = 0; ei < 2; ei++) {
		struct f559_out ctl;

		memset(&ctl, 0, sizeof(ctl));
		f567_arm("xf", &D567[2], &E[envs[ei]], "ctl", 0, 0, 0, 0, NULL,
			 0, rfd, NULL, &ctl);
		for (i = 0; i < n; i++)
			f567_arm("xf", &D567[2], &E[envs[ei]], X567[i].arm, 0,
				 NFT_PAYLOAD_NETWORK_HEADER, X567[i].off,
				 X567[i].len, X567[i].imm, 1, rfd, &ctl, NULL);
		/* the transport base in both families: same rule, two
		 * coordinates */
		f567_arm("xf", &D567[2], &E[envs[ei]], "xt0_2", 0,
			 NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, T567[1].imm, 1,
			 rfd, &ctl, NULL);
		f567_arm("xf", &D567[2], &E[envs[ei]], "xt2_2", 0,
			 NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, T567[2].imm, 1,
			 rfd, &ctl, NULL);
		f567_arm("xf", &D567[2], &E[envs[ei]], "xt12_4", 0,
			 NFT_PAYLOAD_TRANSPORT_HEADER, 12, 4, T567[7].imm, 1,
			 rfd, &ctl, NULL);
	}
}

/* E. read side: does the read land where the write does */
static void f567_sec_rd(struct f567_frame *E, int rfd)
{
	static const struct {
		const char *arm;
		int off, len;
		unsigned char imm[2];
	} rd[3] = {
		{ "r0_2", 0, 2, { 0x9c, 0x40 } },
		{ "r2_2", 2, 2, { 0x13, 0x88 } },
		{ "r4_2", 4, 2, { 0x00, 0x1a } },
	};
	static const int doors[2] = { 2, 4 };
	static const int envs[2] = { K6_PLAIN, K6_HBH };
	int di, ei, i;

	for (di = 0; di < 2; di++)
		for (ei = 0; ei < 2; ei++)
			for (i = 0; i < 3; i++)
				f567_arm("rd", &D567[doors[di]], &E[envs[ei]],
					 rd[i].arm, 0,
					 NFT_PAYLOAD_TRANSPORT_HEADER, rd[i].off,
					 rd[i].len, rd[i].imm, 2, rfd, NULL, NULL);
}

/* F. meta: does tprot exist when there is no transport header */
struct f567_meta {
	const char *arm;
	int len, mode;
	unsigned char imm[2];
};

static const struct f567_meta M567[4] = {
	{ "l4_17", 1, 3, { 0x11 } },		/* tprot == UDP  */
	{ "l4_59", 1, 3, { 0x3b } },		/* tprot == NONE */
	{ "pr_86", 2, 4, { 0x86, 0xdd } },	/* meta protocol */
	{ "pr_08", 2, 4, { 0x08, 0x00 } },
};

static void f567_mp_pass(const char *sec, struct f567_frame *E, int rfd)
{
	static const int envs[4] = { K6_PLAIN, K6_NONE, K6_BADEXT, K6_DOBAD };
	int ei, i;

	for (ei = 0; ei < 4; ei++)
		for (i = 0; i < 4; i++)
			f567_arm(sec, &D567[2], &E[envs[ei]], M567[i].arm, 0, 0,
				 0, M567[i].len, M567[i].imm, M567[i].mode, rfd,
				 NULL, NULL);
}

/* G. malformed: one frame, three doors, three outcomes */
static const int MD_FRAMES[4] = { K6_TRUNC, K6_BADEXT, K6_DOBAD, K6_NONE };
static const char *MD_NAMES[4] = { "mtrunc", "mexth", "mdobad", "none" };

static void f567_md_pass(const char *sec, struct f567_door *D,
			 struct f567_frame *E, int rfd)
{
	unsigned char imm[1] = { 0x90 };
	int i;

	for (i = 0; i < 4; i++) {
		int k = MD_FRAMES[i];
		struct f559_out ctl;

		memset(&ctl, 0, sizeof(ctl));
		f567_arm(sec, D, &E[k], "ctl", 0, 0, 0, 0, NULL, 0, rfd, NULL,
			 &ctl);
		f567_arm(sec, D, &E[k], MD_NAMES[i], 0,
			 NFT_PAYLOAD_NETWORK_HEADER, 8, 1, imm, 1, rfd, &ctl,
			 NULL);
		f567_arm(sec, D, &E[k], "th0_2", 0,
			 NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, T567[1].imm, 1,
			 rfd, &ctl, NULL);
		f567_arm(sec, D, &E[k], "th2_2", 0,
			 NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, T567[2].imm, 1,
			 rfd, &ctl, NULL);
	}
}

static void f567_sec_md(struct f567_frame *E, int rfd)
{
	int i;

	/* 1. both ingress doors present, inet first by priority */
	f567_md_pass("md_both_ndg", &D567[3], E, rfd);
	f567_md_pass("md_both_ieg", &D567[4], E, rfd);

	/* 2. the inet ingress table deleted: the netdev door alone -- and now
	 * the same frames reach the two layer-3 doors, which live behind
	 * ip6_rcv_core() and were never touched while ieg dropped them. */
	sh("/nft delete table inet d67e");
	printf("F567 MD|deleted=inet d67e\n");
	f567_md_pass("md_ndg_only", &D567[3], E, rfd);
	f567_md_pass("md_inp_l3", &D567[2], E, rfd);
	f567_md_pass("md_ip6p_l3", &D567[1], E, rfd);
	f567_mp_pass("mp_l3", E, rfd);

	/* 3. the netdev table deleted instead: the inet door alone */
	add_table(NFPROTO_INET, "d67e");
	for (i = 4; i <= 4; i++) {
		f556_add_chain(D567[i].fam, D567[i].table, "pre0",
			       D567[i].hook, (uint32_t)D567[i].prio0, 1,
			       D567[i].dev);
		f556_add_chain(D567[i].fam, D567[i].table, "ch",
			       D567[i].hook, (uint32_t)D567[i].prio1, 1,
			       D567[i].dev);
	}
	sh("/nft delete table netdev d67d");
	printf("F567 MD|deleted=netdev d67d\n");
	f567_md_pass("md_ieg_only", &D567[4], E, rfd);
	/* both again, for the record */
	add_table(NFPROTO_NETDEV, "d67d");
	for (i = 3; i <= 3; i++) {
		f556_add_chain(D567[i].fam, D567[i].table, "pre0",
			       D567[i].hook, (uint32_t)D567[i].prio0, 1,
			       D567[i].dev);
		f556_add_chain(D567[i].fam, D567[i].table, "ch",
			       D567[i].hook, (uint32_t)D567[i].prio1, 1,
			       D567[i].dev);
	}
	printf("F567 MD|restored=netdev d67d\n");
	f567_md_pass("md_again_ieg", &D567[4], E, rfd);
	f567_md_pass("md_again_ndg", &D567[3], E, rfd);
}

/* H. cross-family: IPv4 frames in the same boot, before and after a dropped
 * IPv6 frame */
static void f567_sec_xc(struct f567_frame *E, int rfd)
{
	static const int seq[6] = { K6_P4, K6_PLAIN, K6_TRUNC, K6_P4,
				    K6_BADEXT, K6_P4 };
	int i, acks = 0;

	(void)rfd;
	for (i = 0; i < ND67; i++)
		f567_rule(&D567[i], "ch", "s", 0, 0, 0, 0, NULL, 0, 0, &acks);
	for (i = 0; i < 6; i++) {
		unsigned long long c0[ND67], c1[ND67];
		int d, u4, u6, f0 = -1;

		for (d = 0; d < ND67; d++)
			c0[d] = f555_count(D567[d].fam, D567[d].table, "ch");
		f567_drain(U567_4A, &f0);
		f567_drain(U567_6A, NULL);
		pkt_send_p("s0", E[seq[i]].wire, E[seq[i]].wlen, E[seq[i]].sproto);
		usleep(70000);
		u4 = f567_drain(U567_4A, NULL);
		u6 = f567_drain(U567_6A, NULL);
		for (d = 0; d < ND67; d++)
			c1[d] = f555_count(D567[d].fam, D567[d].table, "ch");
		printf("F567 XC|i=%d|env=%s|ipp=%llu|ip6p=%llu|inp=%llu|ndg=%llu|"
		       "ieg=%llu|u4=%d|u6=%d|f4=%d\n", i, E[seq[i]].tag,
		       c1[0] - c0[0], c1[1] - c0[1], c1[2] - c0[2],
		       c1[3] - c0[3], c1[4] - c0[4], u4, u6, f0);
	}
}

/* I. diagnostic: which door sees which frame */
static void f567_sec_diag(struct f567_frame *E, int rfd)
{
	static const int order[K6_NKIND + 1] = {
		K6_PLAIN, K6_HBH, K6_DST, K6_HBDST, K6_FRAG0, K6_FRAGN,
		K6_NONE, K6_BADEXT, K6_DOBAD, K6_TRUNC, K6_VER5, K6_TCP, K6_P4
	};
	int i, e, acks = 0;
	unsigned long long c0[ND67], c1[ND67];

	printf("F567 DIAG|capfd=%d\n", rfd);
	for (i = 0; i < ND67; i++)
		f567_rule(&D567[i], "ch", "s", 0, 0, 0, 0, NULL, 0, 0, &acks);
	for (e = 0; e <= K6_NKIND; e++) {
		unsigned long long i0[6], i1[6], q0, q1;
		int d, u6a, u6b, f0 = -1;

		for (d = 0; d < ND67; d++)
			c0[d] = f555_count(D567[d].fam, D567[d].table, "ch");
		i0[0] = f564_snmp6("Ip6InReceives");
		i0[1] = f564_snmp6("Ip6InHdrErrors");
		i0[2] = f564_snmp6("Ip6InTruncatedPkts");
		i0[3] = f564_snmp6("Ip6InDelivers");
		i0[4] = f564_snmp6("Ip6InReasmReqds");
		i0[5] = f564_snmp6("Ip6InUnknownProtos");
		q0 = f564_snmp("Ip", "InReceives");
		f567_drain(U567_6A, &f0);
		f567_drain(U567_6B, NULL);
		pkt_send_p("s0", E[order[e]].wire, E[order[e]].wlen,
			   E[order[e]].sproto);
		usleep(70000);
		u6a = f567_drain(U567_6A, NULL);
		u6b = f567_drain(U567_6B, NULL);
		for (d = 0; d < ND67; d++)
			c1[d] = f555_count(D567[d].fam, D567[d].table, "ch");
		i1[0] = f564_snmp6("Ip6InReceives");
		i1[1] = f564_snmp6("Ip6InHdrErrors");
		i1[2] = f564_snmp6("Ip6InTruncatedPkts");
		i1[3] = f564_snmp6("Ip6InDelivers");
		i1[4] = f564_snmp6("Ip6InReasmReqds");
		i1[5] = f564_snmp6("Ip6InUnknownProtos");
		q1 = f564_snmp("Ip", "InReceives");
		printf("F567 DIAG|env=%s|ipp=%llu|ip6p=%llu|inp=%llu|ndg=%llu|"
		       "ieg=%llu|i6in=%llu|i6hdr=%llu|i6trun=%llu|i6deliv=%llu|"
		       "i6reasm=%llu|i6unk=%llu|ipin=%llu|u6a=%d|u6b=%d|f6a=%d\n",
		       E[order[e]].tag, c1[0] - c0[0], c1[1] - c0[1],
		       c1[2] - c0[2], c1[3] - c0[3], c1[4] - c0[4],
		       i1[0] - i0[0], i1[1] - i0[1], i1[2] - i0[2],
		       i1[3] - i0[3], i1[4] - i0[4], i1[5] - i0[5],
		       q1 - q0, u6a, u6b, f0);
	}
}

/* J. delivery probe: is one of these frames a real datagram to a real socket? */
static void f567_sec_dbg(struct f567_frame *E, int rfd)
{
	static const int envs[5] = { K6_PLAIN, K6_HBH, K6_DST, K6_HBDST,
				     K6_FRAG0 };
	char line[256];
	FILE *f;
	int i;

	(void)rfd;
	printf("F567 DBG|if_inet6_begin\n");
	f = fopen("/proc/net/if_inet6", "r");
	if (f) {
		while (fgets(line, sizeof(line), f))
			printf("F567 DBG6|%s", line);
		fclose(f);
	}
	printf("F567 DBG|if_inet6_end\n");
	for (i = 0; i < 5; i++) {
		unsigned long long a0[6], a1[6];
		int u6a;

		a0[0] = f564_snmp6("Ip6InReceives");
		a0[1] = f564_snmp6("Ip6InAddrErrors");
		a0[2] = f564_snmp6("Ip6InNoRoutes");
		a0[3] = f564_snmp6("Ip6InDiscards");
		a0[4] = f564_snmp6("Ip6InDelivers");
		a0[5] = f564_snmp6("Ip6InMcastPkts");
		f567_drain(U567_6A, NULL);
		pkt_send_p("s0", E[envs[i]].wire, E[envs[i]].wlen,
			   E[envs[i]].sproto);
		usleep(90000);
		u6a = f567_drain(U567_6A, NULL);
		a1[0] = f564_snmp6("Ip6InReceives");
		a1[1] = f564_snmp6("Ip6InAddrErrors");
		a1[2] = f564_snmp6("Ip6InNoRoutes");
		a1[3] = f564_snmp6("Ip6InDiscards");
		a1[4] = f564_snmp6("Ip6InDelivers");
		a1[5] = f564_snmp6("Ip6InMcastPkts");
		printf("F567 DBG|env=%s|i6in=%llu|i6addr=%llu|i6noroute=%llu|"
		       "i6disc=%llu|i6deliv=%llu|i6mcast=%llu|u6a=%d\n",
		       E[envs[i]].tag, a1[0] - a0[0], a1[1] - a0[1],
		       a1[2] - a0[2], a1[3] - a0[3], a1[4] - a0[4],
		       a1[5] - a0[5], u6a);
	}
}

/* ---------- main ---------- */

int f567_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f567";
	struct f567_frame E[K6_NKIND + 1];
	char hx[400];
	int rfd = -1, i;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F567 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F567 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F567 KERNEL|7.3.4-T563\n");
	/* every new device comes up with IPv6 off; only br0 gets it back.
	 * IPv6 delivers a unicast packet only on the device that owns the
	 * address (strict), and the bridge hands the frame up on br0 -- so the
	 * address has to live there, not on i1 like the IPv4 one. */
	f555_sysctl("/proc/sys/net/ipv6/conf/default/disable_ipv6", "1");
	f556_env_setup();
	{
		static const char *on[] = { "br0" };
		char path[96];
		int k;

		for (k = 0; k < 1; k++) {
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/dad_transmits", on[k]);
			f555_sysctl(path, "0");
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/accept_dad", on[k]);
			f555_sysctl(path, "0");
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/accept_ra", on[k]);
			f555_sysctl(path, "0");
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6", on[k]);
			f555_sysctl(path, "0");
		}
		printf("F567 V6ON|br0=%llu|s1=%llu|s0=%llu\n",
		       f567_read_ll("/proc/sys/net/ipv6/conf/br0/disable_ipv6"),
		       f567_read_ll("/proc/sys/net/ipv6/conf/s1/disable_ipv6"),
		       f567_read_ll("/proc/sys/net/ipv6/conf/s0/disable_ipv6"));
		printf("F567 V6ADDR|rc=%d\n", f564_addr6("br0", F564_V6DST, 128));
		printf("F567 ADDR4|rc=%d\n",
		       f555_addr_add("i1", htonl(0x0a090007), 24));
		usleep(400000);
	}
	NFL67 = nfl_open(5);
	printf("F567 NFL|%d\n", NFL67);

	if (f567_chains()) {
		printf("F567 FAIL|chains\n");
		return 0;
	}

	memset(E, 0, sizeof(E));
	for (i = 0; i < K6_NKIND; i++) {
		E[i].tag = (i == K6_PLAIN) ? "v6" : (i == K6_HBH) ? "hb" :
			   (i == K6_DST) ? "do" : (i == K6_HBDST) ? "hbdo" :
			   (i == K6_FRAG0) ? "fr0" : (i == K6_FRAGN) ? "frn" :
			   (i == K6_NONE) ? "none" : (i == K6_BADEXT) ? "mexth" :
			   (i == K6_DOBAD) ? "mdobad" :
			   (i == K6_TRUNC) ? "mtrunc" : (i == K6_VER5) ? "mver" :
			   "t6";
		E[i].wlen = f567_mk6(E[i].wire, i, 5000);
		E[i].sproto = 0x86dd;
	}
	E[K6_P4].tag = "p4";
	E[K6_P4].wlen = f565_udp4(E[K6_P4].wire, 40000, 5000, 0, 0x77);
	E[K6_P4].sproto = 0x0800;

	for (i = 0; i <= K6_NKIND; i++)
		printf("F567 FRAME|%s|len=%d|wire=%s\n", E[i].tag, E[i].wlen,
		       f559_hexs(hx, sizeof(hx), E[i].wire,
				 E[i].wlen < 128 ? E[i].wlen : 128));

	rfd = cap_open("r0");
	printf("F567 CAP|rfd=%d\n", rfd);
	U567_6A = f564_udp_bind(AF_INET6, 0, F564_V6DST, 5000);
	U567_6B = f564_udp_bind(AF_INET6, 0, F564_V6DST, 5001);
	U567_4A = f564_udp_bind(AF_INET, 0x0a090007, NULL, 5000);
	printf("F567 SOCK|u6a=%d|u6b=%d|u4=%d\n", U567_6A, U567_6B, U567_4A);

	if (!strcmp(mode, "diag"))
		f567_sec_diag(E, rfd);
	else if (!strcmp(mode, "dbg"))
		f567_sec_dbg(E, rfd);
	else if (!strcmp(mode, "td"))
		f567_sec_td(E, rfd);
	else if (!strcmp(mode, "tf"))
		f567_sec_tf(E, rfd);
	else if (!strcmp(mode, "nh"))
		f567_sec_nh(E, rfd);
	else if (!strcmp(mode, "xf"))
		f567_sec_xf(E, rfd);
	else if (!strcmp(mode, "rd"))
		f567_sec_rd(E, rfd);
	else if (!strcmp(mode, "mp"))
		f567_mp_pass("mp", E, rfd);
	else if (!strcmp(mode, "md"))
		f567_sec_md(E, rfd);
	else if (!strcmp(mode, "xc"))
		f567_sec_xc(E, rfd);
	else {
		f567_sec_dbg(E, rfd);
		f567_sec_diag(E, rfd);
		f567_sec_td(E, rfd);
		f567_sec_tf(E, rfd);
		f567_sec_nh(E, rfd);
		f567_sec_xf(E, rfd);
		f567_sec_rd(E, rfd);
		f567_mp_pass("mp", E, rfd);
		f567_sec_xc(E, rfd);
		f567_sec_md(E, rfd);
	}
	printf("F567 DONE\n");
	return 0;
}
/* ==========================================================================
 * Turn 568 -- F46: the EGRESS doors.
 *
 * F44/F45 asked where `@th` lands and found one coordinate behind five doors.
 * Every door so far was an INGRESS door, and every frame arrived from the
 * wire.  This turn asks the mirror question on the way out:
 *
 *   where is the MAC header, and who pays for a write into the IP header?
 *
 * Source, read before any measurement:
 *   __ip_local_out():   ip_send_check(iph) BEFORE nf_hook(LOCAL_OUT)
 *   ip_forward():       ip_decrease_ttl()  BEFORE nf_hook(FORWARD)
 *   ip_rcv():           ip_rcv_core() (header csum) BEFORE nf_hook(PRE_ROUTING)
 *   __dev_queue_xmit(): skb_reset_mac_header() is its FIRST statement
 *   eth_header():       skb_push(ETH_HLEN) + writes all 14 bytes, no mac_reset
 *   eth_type_trans():   skb_reset_mac_header() on receive
 *   nft_payload_set_eval(): @ll offset = mac_header - data, guard len+off <= net_off
 *                           @nh offset = skb_network_offset (no nhoff)
 *   nft_payload_csum_inet(): incremental -- read the csum at csum_offset,
 *                            add the delta, store, THEN store the immediate
 *
 * Three traffic classes, one receiver in its own netns (pipe protocol):
 *   loc -- socket 10.10.0.1:40000 -> 10.10.0.2:5000, out x0
 *   fwd -- frame injected on o0, dst 10.10.0.2, received on o1, forwarded via x0
 *   in  -- frame injected on y0, dst 10.11.0.2 (local on y1), delivered here
 *
 * differ568.c is GENERATED: differ567.c with its main() renamed, plus this
 * file.  The netlink toolkit, veth/rtnetlink helpers, NFLOG reader, AF_PACKET
 * capture and counter read-back are the ones that produced F31..F45.
 * ========================================================================== */

#define NFULA_L2HDR_	21
#define F568_CSUM_INET	1

/* ---------- doors ---------- */

struct f568_door {
	const char *tag;
	uint8_t fam;
	const char *table;
	const char *dev;
	uint32_t hook;
	int prio0, prio1;
};

#define NF_INET_PRE_	0
#define NF_INET_IN_	1
#define NF_INET_FWD_	2
#define NF_INET_OUT_	3
#define NF_INET_POST_	4
#define NF_NETDEV_EGR_	1

static struct f568_door D568[] = {
	{ "out",  NFPROTO_INET,   "e68a", NULL, NF_INET_OUT_,   10,  20 },
	{ "post", NFPROTO_INET,   "e68b", NULL, NF_INET_POST_,  30,  40 },
	{ "fwd",  NFPROTO_INET,   "e68c", NULL, NF_INET_FWD_,   50,  60 },
	{ "pre",  NFPROTO_INET,   "e68d", NULL, NF_INET_PRE_,   70,  80 },
	{ "lin",  NFPROTO_INET,   "e68e", NULL, NF_INET_IN_,    90, 100 },
	{ "egr",  NFPROTO_NETDEV, "e68f", "x0", NF_NETDEV_EGR_, 110, 120 },
};
#define ND68 6

enum { C_LOC = 0, C_FWD, C_IN, C_NK };
static const char *CLSN[C_NK] = { "loc", "fwd", "in" };

struct f568_pair { int door, cls; };
static struct f568_pair P568[] = {
	{ 0, C_LOC }, { 1, C_LOC }, { 5, C_LOC },
	{ 1, C_FWD }, { 2, C_FWD }, { 5, C_FWD }, { 3, C_FWD },
	{ 3, C_IN },  { 4, C_IN },
};
#define NP68 ((int)(sizeof(P568) / sizeof(P568[0])))

/* ---------- addresses ---------- */

#define A_X0	0x0a0a0001u	/* 10.10.0.1  x0  (sender side)      */
#define A_X1	0x0a0a0002u	/* 10.10.0.2  x1  (receiver netns)   */
#define A_Y1	0x0b0b0002u	/* 10.11.0.2  y1  (local delivery)   */
#define A_FS	0x0a080002u	/* 10.8.0.2   src of the fwd frame   */
#define A_IS	0x0a080302u	/* 10.8.3.2   src of the in frame    */

static const unsigned char F568_PAY[18] = {
	0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77,
	0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77
};

static int LOC_SOCK = -1;	/* 10.10.0.1:40000 -> 10.10.0.2:5000 */
static int IN_SOCK = -1;	/* bound 10.11.0.2:5000               */
static int P_W = -1, P_R = -1;	/* parent -> child, child -> parent   */
static pid_t CHILD = -1;

/* the reference frame of every (door, class): from the control arm */
static unsigned char REF568[ND68][C_NK][256];
static int REFLEN568[ND68][C_NK];

/* ---------- the receiver in its own netns ---------- */

struct f568_rep {
	int tapn, taplen;
	char taphex[600];
	int udpn, ulen0, usport0;
	char pay[40];
	unsigned long long ipin, ihdr, iaddr, ideliv;
	unsigned long long udpin, udperr, udpnoport, ipout, icmpin;
};

static int f568_needle(const unsigned char *b, int n)
{
	int i;

	for (i = 0; i + 8 <= n; i++)
		if (!memcmp(b + i, F568_PAY, 8))
			return 1;
	return 0;
}

static void f568_child_snap(int tapfd, int ufd, int wfd)
{
	unsigned char b[2048], last[512];
	int r, tapn = 0, lastlen = -1;
	int udpn = 0, ulen0 = -1, usport0 = -1;
	char pay[40] = "-", hx[600] = "-";

	while ((r = (int)recv(tapfd, b, sizeof(b), MSG_DONTWAIT)) > 0) {
		if (!f568_needle(b, r))
			continue;
		tapn++;
		/* keep the FIRST matching frame: a later one may be an ICMP
		 * error that quotes our payload (F46 smoke, port arms) */
		if (lastlen >= 0)
			continue;
		lastlen = r < (int)sizeof(last) ? r : (int)sizeof(last);
		memcpy(last, b, (size_t)lastlen);
	}
	for (;;) {
		struct sockaddr_in from;
		socklen_t fl = sizeof(from);

		memset(&from, 0, sizeof(from));
		r = (int)recvfrom(ufd, b, sizeof(b), MSG_DONTWAIT,
				  (struct sockaddr *)&from, &fl);
		if (r < 0)
			break;
		if (udpn == 0) {
			int k, n = r < 8 ? r : 8;
			char *o = pay;

			ulen0 = r;
			usport0 = (int)ntohs(from.sin_port);
			for (k = 0; k < n; k++)
				o += sprintf(o, "%02x", b[k]);
		}
		udpn++;
		if (udpn > 32)
			break;
	}
	if (lastlen > 0) {
		int k, n = lastlen < 200 ? lastlen : 200;
		char *o = hx;

		for (k = 0; k < n; k++)
			o += sprintf(o, "%02x", last[k]);
	}
	dprintf(wfd, "R|%d|%d|%s|%d|%d|%d|%s|%llu|%llu|%llu|%llu|%llu|%llu|%llu|%llu|%llu\n",
		tapn, lastlen, hx, udpn, ulen0, usport0, pay,
		f564_snmp("Ip", "InReceives"), f564_snmp("Ip", "InHdrErrors"),
		f564_snmp("Ip", "InAddrErrors"), f564_snmp("Ip", "InDelivers"),
		f564_snmp("Udp", "InDatagrams"), f564_snmp("Udp", "InErrors"),
		f564_snmp("Udp", "NoPorts"), f564_snmp("Ip", "OutRequests"),
		f564_snmp("Icmp", "InMsgs"));
}

/* The child: unshare, wait for the device to be moved in, configure, serve. */
static void f568_child_loop(int rfd, int wfd)
{
	char cmd[64];
	int tapfd, ufd;

	setvbuf(stdout, NULL, _IONBF, 0);
	if (unshare(CLONE_NEWNET) < 0) {
		dprintf(wfd, "E|unshare|%d\n", errno);
		_exit(1);
	}
	dprintf(wfd, "U\n");
	for (;;) {
		int n = (int)read(rfd, cmd, sizeof(cmd) - 1);

		if (n <= 0)
			_exit(2);
		cmd[n] = 0;
		if (cmd[0] == 'C')
			break;
	}
	set_up("lo");
	set_up("x1");
	dprintf(wfd, "A|%d\n", f555_addr_add("x1", htonl(A_X1), 24));
	{
		char p[96];

		snprintf(p, sizeof(p), "/proc/sys/net/ipv4/conf/x1/rp_filter");
		f555_sysctl(p, "0");
		snprintf(p, sizeof(p), "/proc/sys/net/ipv4/conf/all/rp_filter");
		f555_sysctl(p, "0");
		snprintf(p, sizeof(p), "/proc/sys/net/ipv4/conf/default/rp_filter");
		f555_sysctl(p, "0");
	}
	{
		struct sockaddr_in sa;
		int one = 1;

		ufd = socket(AF_INET, SOCK_DGRAM, 0);
		setsockopt(ufd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
		memset(&sa, 0, sizeof(sa));
		sa.sin_family = AF_INET;
		sa.sin_addr.s_addr = htonl(INADDR_ANY);
		sa.sin_port = htons(5000);
		if (bind(ufd, (struct sockaddr *)&sa, sizeof(sa)) < 0)
			dprintf(wfd, "E|bind|%d\n", errno);
	}
	tapfd = cap_open("x1");
	dprintf(wfd, "READY|%d|%d\n", tapfd, f555_ifindex("x1"));
	for (;;) {
		int n = (int)read(rfd, cmd, sizeof(cmd) - 1);

		if (n <= 0)
			_exit(3);
		cmd[n] = 0;
		if (cmd[0] == 'Q')
			_exit(0);
		if (cmd[0] == 'S')
			f568_child_snap(tapfd, ufd, wfd);
	}
}

/* ---------- parent side of the pipe ---------- */

static int f568_ask(const char *what)
{
	char c = what[0];
	ssize_t w;

	w = write(P_W, &c, 1);
	(void)w;
	return 0;
}

static int f568_read_line(char *out, int osz, int ms)
{
	struct timeval tv = { .tv_sec = ms / 1000, .tv_usec = (ms % 1000) * 1000 };
	fd_set rfds;
	int n = 0;

	out[0] = 0;
	for (;;) {
		char ch;
		int r;

		FD_ZERO(&rfds);
		FD_SET(P_R, &rfds);
		if (select(P_R + 1, &rfds, NULL, NULL, &tv) <= 0)
			return -1;
		r = (int)read(P_R, &ch, 1);
		if (r <= 0)
			return -1;
		if (ch == '\n')
			return n;
		if (n < osz - 1)
			out[n++] = ch;
		out[n] = 0;
	}
}

static int f568_split(char *line, char **f, int max)
{
	int n = 0;
	char *p = line;

	while (n < max) {
		char *b = strchr(p, '|');

		f[n++] = p;
		if (!b)
			break;
		*b = 0;
		p = b + 1;
	}
	return n;
}

/* returns 0 on success; fills R with the child's answer */
static int f568_snapshot(struct f568_rep *R)
{
	char line[2048], *f[24];
	int n;

	memset(R, 0, sizeof(*R));
	R->taplen = -1;
	R->ulen0 = -1;
	R->usport0 = -1;
	snprintf(R->taphex, sizeof(R->taphex), "-");
	snprintf(R->pay, sizeof(R->pay), "-");
	f568_ask("S");
	if (f568_read_line(line, (int)sizeof(line), 8000) < 0)
		return -1;
	n = f568_split(line, f, 24);
	if (n < 17 || f[0][0] != 'R')
		return -2;
	R->tapn = atoi(f[1]);
	R->taplen = atoi(f[2]);
	snprintf(R->taphex, sizeof(R->taphex), "%s", f[3]);
	R->udpn = atoi(f[4]);
	R->ulen0 = atoi(f[5]);
	R->usport0 = atoi(f[6]);
	snprintf(R->pay, sizeof(R->pay), "%s", f[7]);
	R->ipin = strtoull(f[8], NULL, 10);
	R->ihdr = strtoull(f[9], NULL, 10);
	R->iaddr = strtoull(f[10], NULL, 10);
	R->ideliv = strtoull(f[11], NULL, 10);
	R->udpin = strtoull(f[12], NULL, 10);
	R->udperr = strtoull(f[13], NULL, 10);
	R->udpnoport = strtoull(f[14], NULL, 10);
	R->ipout = strtoull(f[15], NULL, 10);
	R->icmpin = strtoull(f[16], NULL, 10);
	return 0;
}

/* ---------- moving a device into the child's netns ---------- */

static int f568_move_link(const char *dev, int pid)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[64];
	} req;
	struct nlattr *a;
	int fd, rc, idx = f555_ifindex(dev);

	if (idx < 0)
		return -1;
	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	req.ifi.ifi_index = idx;
	a = (struct nlattr *)((char *)&req + NLMSG_ALIGN(req.nlh.nlmsg_len));
	a->nla_type = IFLA_NET_NS_PID;
	a->nla_len = NLA_HDRLEN + 4;
	memcpy((char *)a + NLA_HDRLEN, &pid, 4);
	req.nlh.nlmsg_len = NLMSG_ALIGN(req.nlh.nlmsg_len) + NLA_ALIGN(a->nla_len);
	fd = rtnl_open();
	if (fd < 0)
		return -2;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

/* A permanent neighbour for the receiver: without it the entry goes STALE
 * after base_reachable_time (15..45 s) and the next packet is queued behind an
 * ARP probe -- the smoke run lost a whole block of egress arms that way, and
 * the loss looked exactly like a refused store. */
static int f568_neigh_add(const char *dev, uint32_t dst_be,
			  const unsigned char *mac)
{
	struct {
		struct nlmsghdr nlh;
		struct ndmsg ndm;
		char attrs[64];
	} req;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ndmsg));
	req.nlh.nlmsg_type = RTM_NEWNEIGH;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_REPLACE;
	req.nlh.nlmsg_seq = 1;
	req.ndm.ndm_family = AF_INET;
	req.ndm.ndm_ifindex = f555_ifindex(dev);
	req.ndm.ndm_state = NUD_PERMANENT;
	attr_put(&req.nlh, NDA_DST, &dst_be, 4);
	attr_put(&req.nlh, NDA_LLADDR, mac, 6);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

/* ---------- frames ---------- */

static int f568_mkframe(unsigned char *out, const unsigned char *dmac,
			uint32_t sip, uint32_t dip, unsigned short sport,
			unsigned short dport)
{
	struct {
		unsigned char dmac[6], smac[6];
		unsigned short proto;
	} __attribute__((packed)) eth;
	struct {
		unsigned char vihl, tos;
		unsigned short tot;
		unsigned short id;
		unsigned short frag;
		unsigned char ttl, proto;
		unsigned short csum;
		uint32_t src, dst;
	} __attribute__((packed)) ip;
	struct {
		unsigned short sport, dport, len, csum;
	} __attribute__((packed)) udp;
	int o = 0, iplen = 20 + 8 + (int)sizeof(F568_PAY);
	unsigned char pseudo[12];

	memcpy(eth.dmac, dmac, 6);
	{
		static const unsigned char sm[6] = { 0x02, 0x00, 0x00, 0x00, 0x00, 0x68 };

		memcpy(eth.smac, sm, 6);
	}
	eth.proto = htons(0x0800);

	memset(&ip, 0, sizeof(ip));
	ip.vihl = 0x45;
	ip.tos = 0;
	ip.tot = htons((unsigned short)iplen);
	ip.id = htons(0x1234);
	ip.frag = 0;
	ip.ttl = 64;
	ip.proto = 17;
	ip.src = htonl(sip);
	ip.dst = htonl(dip);
	ip.csum = 0;
	ip.csum = htons(f556_csum(&ip, sizeof(ip)));

	udp.sport = htons(sport);
	udp.dport = htons(dport);
	udp.len = htons((unsigned short)(8 + sizeof(F568_PAY)));
	udp.csum = 0;
	memcpy(pseudo, &ip.src, 4);
	memcpy(pseudo + 4, &ip.dst, 4);
	pseudo[8] = 0;
	pseudo[9] = 17;
	memcpy(pseudo + 10, &udp.len, 2);	/* already network order in memory */
	{
		unsigned char buf[12 + 8 + sizeof(F568_PAY)];
		unsigned short cs;

		memcpy(buf, pseudo, 12);
		memcpy(buf + 12, &udp, 8);
		memcpy(buf + 20, F568_PAY, sizeof(F568_PAY));
		cs = f556_csum(buf, (int)sizeof(buf));
		if (cs == 0)
			cs = 0xffff;
		udp.csum = htons(cs);
	}

	memcpy(out + o, &eth, sizeof(eth));
	o += (int)sizeof(eth);
	memcpy(out + o, &ip, sizeof(ip));
	o += (int)sizeof(ip);
	memcpy(out + o, &udp, sizeof(udp));
	o += (int)sizeof(udp);
	memcpy(out + o, F568_PAY, sizeof(F568_PAY));
	o += (int)sizeof(F568_PAY);
	return o;
}

static unsigned char X1_MAC[6];	/* read before x1 leaves this netns */
static int FWD_FRAME_LEN = -1, IN_FRAME_LEN = -1;
static unsigned char FWD_FRAME[128], IN_FRAME[128];

/* ---------- chains and rules ---------- */

static int f568_chains(void)
{
	int i, rc = 0;

	for (i = 0; i < ND68; i++) {
		struct f568_door *D = &D568[i];

		rc |= add_table(D->fam, D->table);
		rc |= f556_add_chain(D->fam, D->table, "pre0", D->hook,
				     (uint32_t)D->prio0, 1, D->dev);
		rc |= f556_add_chain(D->fam, D->table, "ch", D->hook,
				     (uint32_t)D->prio1, 1, D->dev);
	}
	return rc;
}

static void f568_flush_all(void)
{
	int i, acks = 0;

	for (i = 0; i < ND68; i++) {
		f557_flush(D568[i].fam, D568[i].table, "pre0", &acks);
		f557_flush(D568[i].fam, D568[i].table, "ch", &acks);
	}
}

/* mode 0: nothing; 1: store; 2: store, then read the same cell and compare
 * with the immediate ("did the write land?"); 3: read + compare. */
static int f568_rule(const struct f568_door *D, const char *chain,
		     const char *prefix, uint32_t base, int off, int len,
		     const unsigned char *imm, int mode, int csum, int cso,
		     int *acks)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			D->fam);
	put_str(nlh, NFTA_RULE_TABLE, D->table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (mode == 1 || mode == 2)
		f565_store(nlh, base, (uint32_t)off, (uint32_t)len, imm, csum, (unsigned int)cso);
	if (mode == 2 || mode == 3) {
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, imm, len);
	}
	log_expr(nlh, 5, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, acks);
}

/* ---------- NFLOG ---------- */

struct f568_log {
	int seen;
	int l2;
	int plen;
	unsigned char p[128];
};

static void f568_parse_log(unsigned char *buf, int len, struct f568_log *pre,
			   struct f568_log *post)
{
	struct nlmsghdr *h;

	for (h = (struct nlmsghdr *)buf; NLMSG_OK(h, len); h = NLMSG_NEXT(h, len)) {
		const char *p, *end, *prefix = NULL;
		const unsigned char *pl = NULL;
		int pll = 0, l2 = 0;

		if (h->nlmsg_type == NLMSG_DONE || h->nlmsg_type == NLMSG_ERROR)
			continue;
		p = (const char *)h + NLMSG_HDRLEN + sizeof(struct nfgenmsg);
		end = (const char *)h + h->nlmsg_len;
		for (; p + (int)sizeof(struct nlattr) <= end; ) {
			const struct nlattr *a = (const struct nlattr *)p;
			int al = (int)a->nla_len;
			int t;

			if (al < (int)sizeof(*a) || p + al > end)
				break;
			t = a->nla_type & 0x3fff;
			if (t == NFULA_PREFIX_)
				prefix = (const char *)a + NLA_HDRLEN;
			else if (t == NFULA_PAYLOAD_) {
				pl = (const unsigned char *)a + NLA_HDRLEN;
				pll = al - NLA_HDRLEN;
			} else if (t == NFULA_L2HDR_)
				l2 = al - NLA_HDRLEN;
			p += NLA_ALIGN_(al);
		}
		if (!prefix || !pl)
			continue;
		if (prefix[0] == 'p') {
			pre->seen++;
			pre->l2 = l2;
			pre->plen = pll < (int)sizeof(pre->p) ? pll : (int)sizeof(pre->p);
			memcpy(pre->p, pl, (size_t)pre->plen);
		} else {
			post->seen++;
			post->l2 = l2;
			post->plen = pll < (int)sizeof(post->p) ? pll : (int)sizeof(post->p);
			memcpy(post->p, pl, (size_t)post->plen);
		}
	}
}

static void f568_logs(int fd, struct f568_log *pre, struct f568_log *post)
{
	unsigned char b[16384];
	int guard = 0, rl;

	memset(pre, 0, sizeof(*pre));
	memset(post, 0, sizeof(*post));
	if (fd < 0)
		return;
	while (guard++ < 64) {
		rl = (int)recv(fd, b, sizeof(b), MSG_DONTWAIT);
		if (rl <= 0)
			break;
		f568_parse_log(b, rl, pre, post);
	}
}

/* how many rules are in the chain right now?  f555_count() sums counters and
 * cannot see a rule that has not counted anything yet -- a rule left behind by
 * a failed flush, whose counter is 0, doubled the door counter in one arm and
 * the sum looked clean. */
static int f568_rule_count(uint8_t family, const char *table, const char *chain)
{
	char buf[1024], rbuf[65536];
	struct nlmsghdr *nlh;
	struct nfgenmsg *nfg;
	int fd, sent, n = 0;

	fd = nl_open();
	if (fd < 0)
		return -1;
	{
		struct timeval tv = { .tv_sec = 0, .tv_usec = 120000 };

		setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	}
	memset(buf, 0, sizeof(buf));
	nlh = (struct nlmsghdr *)buf;
	nlh->nlmsg_len = NLMSG_HDRLEN + sizeof(*nfg);
	nlh->nlmsg_type = (NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_GETRULE;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = 1;
	nfg = (struct nfgenmsg *)NLMSG_DATA(nlh);
	nfg->nfgen_family = family;
	nfg->version = NFNETLINK_V0;
	nfg->res_id = htons(0);
	attr_put(nlh, NFTA_RULE_TABLE, table, (int)strlen(table) + 1);
	attr_put(nlh, NFTA_RULE_CHAIN, chain, (int)strlen(chain) + 1);
	sent = (int)nlh->nlmsg_len;
	if (send(fd, buf, (size_t)sent, 0) != sent) {
		close(fd);
		return -2;
	}
	for (;;) {
		int rl = (int)recv(fd, rbuf, sizeof(rbuf), 0);
		struct nlmsghdr *h;

		if (rl <= 0)
			break;
		for (h = (struct nlmsghdr *)rbuf; NLMSG_OK(h, rl); h = NLMSG_NEXT(h, rl)) {
			if (h->nlmsg_type == NLMSG_DONE) {
				close(fd);
				return n;
			}
			if (h->nlmsg_type == NLMSG_ERROR) {
				close(fd);
				return -3;
			}
			if (h->nlmsg_type == (uint16_t)((NFNL_SUBSYS_NFTABLES << 8) |
							NFT_MSG_NEWRULE))
				n++;
		}
	}
	close(fd);
	return n;
}

/* ---------- one arm ---------- */

static int f568_parent_udp_drain(int *firstlen, int *sport, char *pay, int paysz)
{
	unsigned char b[512];
	int n = 0, r;

	if (firstlen)
		*firstlen = -1;
	if (sport)
		*sport = -1;
	if (pay && paysz > 0)
		pay[0] = 0;
	if (IN_SOCK < 0)
		return -1;
	for (;;) {
		struct sockaddr_in from;
		socklen_t fl = sizeof(from);
		int k, m;

		memset(&from, 0, sizeof(from));
		r = (int)recvfrom(IN_SOCK, b, sizeof(b), MSG_DONTWAIT,
				  (struct sockaddr *)&from, &fl);
		if (r < 0)
			break;
		if (n == 0 && firstlen) {
			char *o = pay;

			*firstlen = r;
			if (sport)
				*sport = (int)ntohs(from.sin_port);
			if (pay && paysz > 0) {
				m = r < 8 ? r : 8;
				for (k = 0; k < m; k++)
					o += sprintf(o, "%02x", b[k]);
			}
		}
		n++;
	}
	return n;
}

static void f568_arm(const char *sec, const struct f568_pair *P,
		     const char *arm, uint32_t base, int off, int len,
		     const unsigned char *imm, int mode, int csum, int cso,
		     int rfd)
{
	const struct f568_door *D = &D568[P->door];
	struct f568_rep r0, r1;
	struct f568_log pre, post;
	unsigned char rf[1024], cf[1024];
	char hi[160], hpre[300], hpost[300], hr[600], cw[600];
	unsigned long long cntp0, cnts0, cntp1, cnts1;
	unsigned long long pin0, phdr0, pdel0, puerr0;
	unsigned long long pin1, phdr1, pdel1, puerr1;
	unsigned long long pnr0, pout0, picmp0, picmpo0;
	unsigned long long pnr1, pout1, picmp1, picmpo1;
	int rcp, rcs, acks, snd, rn = 0, rchg = 0;
	int pr = 0, prlen = -1, prsport = -1;
	char prpay[40] = "-";
	int plen = 0;
	const char *cn = CLSN[P->cls];

	{
		int try, np, ns;

		for (try = 0; try < 4; try++) {
			f568_flush_all();
			np = f568_rule_count(D->fam, D->table, "pre0");
			ns = f568_rule_count(D->fam, D->table, "ch");
			if (np == 0 && ns == 0)
				break;
			printf("F568 RETRY2|sec=%s|door=%s|cls=%s|arm=%s|try=%d|np=%d|ns=%d\n",
			       sec, D->tag, cn, arm, try, np, ns);
		}
	}
	acks = 0;
	rcp = f568_rule(D, "pre0", "p", 0, 0, 0, NULL, 0, 0, 0, &acks);
	acks = 0;
	rcs = f568_rule(D, "ch", "s", base, off, len, imm, mode, csum, cso, &acks);

	nfl_drain(NFL67);
	if (rfd >= 0)
		cap_drain(rfd);
	f568_parent_udp_drain(NULL, NULL, NULL, 0);
	f568_snapshot(&r0);
	cntp0 = f555_count(D->fam, D->table, "pre0");
	cnts0 = f555_count(D->fam, D->table, "ch");
	if (cntp0 || cnts0) {
		/* a rule that survived the flush would double the door counter for
		 * every packet (measured once: cntp=3 for a single datagram) */
		printf("F568 RETRY|sec=%s|door=%s|cls=%s|arm=%s|c0p=%llu|c0s=%llu\n",
		       sec, D->tag, cn, arm, cntp0, cnts0);
		f568_flush_all();
		acks = 0;
		rcp = f568_rule(D, "pre0", "p", 0, 0, 0, NULL, 0, 0, 0, &acks);
		acks = 0;
		rcs = f568_rule(D, "ch", "s", base, off, len, imm, mode, csum, cso, &acks);
		cntp0 = f555_count(D->fam, D->table, "pre0");
		cnts0 = f555_count(D->fam, D->table, "ch");
	}
	pin0 = f564_snmp("Ip", "InReceives");
	phdr0 = f564_snmp("Ip", "InHdrErrors");
	pdel0 = f564_snmp("Ip", "InDelivers");
	puerr0 = f564_snmp("Udp", "InErrors");
	pnr0 = f567_netstat("IpExt", "InNoRoutes");
	pout0 = f564_snmp("Ip", "OutRequests");
	picmp0 = f564_snmp("Icmp", "InMsgs");
	picmpo0 = f564_snmp("Icmp", "OutMsgs");
	memset(&r1, 0, sizeof(r1));

	if (P->cls == C_LOC) {
		struct sockaddr_in sin;

		memset(&sin, 0, sizeof(sin));
		sin.sin_family = AF_INET;
		sin.sin_addr.s_addr = htonl(A_X1);
		sin.sin_port = htons(5000);
		snd = (int)sendto(LOC_SOCK, F568_PAY, sizeof(F568_PAY), 0,
				  (struct sockaddr *)&sin, sizeof(sin));
	} else if (P->cls == C_FWD) {
		snd = pkt_send_p("o0", FWD_FRAME, FWD_FRAME_LEN, 0x0800);
	} else {
		snd = pkt_send_p("y0", IN_FRAME, IN_FRAME_LEN, 0x0800);
	}
	usleep(150000);
	pr = f568_parent_udp_drain(&prlen, &prsport, prpay, (int)sizeof(prpay));
	cntp1 = f555_count(D->fam, D->table, "pre0");
	cnts1 = f555_count(D->fam, D->table, "ch");
	pin1 = f564_snmp("Ip", "InReceives");
	phdr1 = f564_snmp("Ip", "InHdrErrors");
	pdel1 = f564_snmp("Ip", "InDelivers");
	puerr1 = f564_snmp("Udp", "InErrors");
	pnr1 = f567_netstat("IpExt", "InNoRoutes");
	pout1 = f564_snmp("Ip", "OutRequests");
	picmp1 = f564_snmp("Icmp", "InMsgs");
	picmpo1 = f564_snmp("Icmp", "OutMsgs");
	f568_logs(NFL67, &pre, &post);
	if (f568_snapshot(&r1) < 0)
		memset(&r1, 0, sizeof(r1));
	if (rfd >= 0) {
		int skip = 0, pt = -1;

		rn = f558_cap_match(rfd, rf, (int)sizeof(rf), 60, F568_PAY, 8,
				    &skip, &pt);
	}
	if (P->cls == C_IN) {
		/* no second wire: the reference is the frame we injected */
		rn = IN_FRAME_LEN;
		memcpy(rf, IN_FRAME, (size_t)IN_FRAME_LEN);
	}
	if (r1.taplen > 0 && strcmp(r1.taphex, "-")) {
		int k, nb = (int)strlen(r1.taphex) / 2;

		if (nb > (int)sizeof(rf))
			nb = (int)sizeof(rf);
		for (k = 0; k < nb; k++) {
			unsigned v;
			char hh[3] = { r1.taphex[2 * k], r1.taphex[2 * k + 1], 0 };

			if (sscanf(hh, "%x", &v) != 1)
				break;
			rf[k] = (unsigned char)v;
		}
		rn = k;
	}
	if (REFLEN568[P->door][P->cls] > 0 && rn > 0) {
		int cl = REFLEN568[P->door][P->cls];

		memcpy(cf, REF568[P->door][P->cls], (size_t)cl);
		rchg = f558_chg(cw, sizeof(cw), cf, cl, rf, rn);
	}
	if (mode == 0 && rn > 0) {
		memcpy(REF568[P->door][P->cls], rf, (size_t)rn);
		REFLEN568[P->door][P->cls] = rn;
	}
	plen = post.plen > 64 ? 64 : post.plen;

	printf("F568 A|sec=%s|door=%s|cls=%s|arm=%s|mode=%d|base=%u|off=%d|len=%d|"
	       "csum=%d|cso=%d|imm=%s|",
	       sec, D->tag, cn, arm, mode, (unsigned)base, off, len, csum, cso,
	       (len > 0 && imm) ? f559_hexs(hi, sizeof(hi), imm, len) : "-");
	printf("rcp=%d|rcs=%d|sendrc=%d|c0p=%llu|c0s=%llu|cntp=%llu|lives=%llu|",
	       rcp, rcs, snd, cntp0, cnts0, cntp1 - cntp0, cnts1 - cnts0);
	printf("tapn=%d|taplen=%d|tap=%s|", r1.tapn, r1.taplen, r1.taphex);
	printf("udpn=%d|ulen=%d|usport=%d|pay=%s|", r1.udpn, r1.ulen0,
	       r1.usport0, r1.pay);
	printf("ripin=%llu|rihdr=%llu|riaddr=%llu|rideliv=%llu|rudpin=%llu|"
	       "rudperr=%llu|rudpnp=%llu|ripout=%llu|ricmp=%llu|",
	       r1.ipin - r0.ipin, r1.ihdr - r0.ihdr, r1.iaddr - r0.iaddr,
	       r1.ideliv - r0.ideliv, r1.udpin - r0.udpin,
	       r1.udperr - r0.udperr, r1.udpnoport - r0.udpnoport,
	       r1.ipout - r0.ipout, r1.icmpin - r0.icmpin);
	printf("pin=%llu|phdr=%llu|pdeliv=%llu|puerr=%llu|precv=%d|prlen=%d|"
	       "prsport=%d|prpay=%s|",
	       pin1 - pin0, phdr1 - phdr0, pdel1 - pdel0, puerr1 - puerr0,
	       pr, prlen, prsport, prpay);
	printf("pnr=%llu|pout=%llu|picmp=%llu|picmpo=%llu|",
	       pnr1 - pnr0, pout1 - pout0, picmp1 - picmp0, picmpo1 - picmpo0);
	printf("npre=%d|prel2=%d|pre=%s|npost=%d|postl2=%d|postlen=%d|post=%s|",
	       pre.seen, pre.l2,
	       pre.seen ? f559_hexs(hpre, sizeof(hpre), pre.p, pre.plen) : "-",
	       post.seen, post.l2, plen,
	       post.seen ? f559_hexs(hpost, sizeof(hpost), post.p, plen) : "-");
	if (rn > 0)
		f559_hexs(hr, sizeof(hr), rf, rn < 200 ? rn : 200);
	printf("rn=%d|rchg=%d|rchgs=%s|rhex=%s\n", rn, rchg,
	       rchg > 0 ? cw : "-", rn > 0 ? hr : "-");
}

/* ---------- cells ---------- */

struct f568_spec {
	const char *arm;
	uint32_t base;
	int off, len;
	unsigned char imm[32];
};

/* the link-layer base: twelve cells, four of them past the guard's boundary */
static struct f568_spec L568[] = {
	{ "cz",  0, 0, 0, { 0 } },
	{ "l0_2",  NFT_PAYLOAD_LL_HEADER, 0, 2, { 0x90, 0x91 } },
	{ "l0_6",  NFT_PAYLOAD_LL_HEADER, 0, 6, { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95 } },
	{ "l2_4",  NFT_PAYLOAD_LL_HEADER, 2, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "l4_2",  NFT_PAYLOAD_LL_HEADER, 4, 2, { 0x90, 0x91 } },
	{ "l6_2",  NFT_PAYLOAD_LL_HEADER, 6, 2, { 0x90, 0x91 } },
	{ "l8_6",  NFT_PAYLOAD_LL_HEADER, 8, 6, { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95 } },
	{ "l10_2", NFT_PAYLOAD_LL_HEADER, 10, 2, { 0x90, 0x91 } },
	{ "l11_1", NFT_PAYLOAD_LL_HEADER, 11, 1, { 0x90 } },
	{ "l12_2", NFT_PAYLOAD_LL_HEADER, 12, 2, { 0x90, 0x91 } },
	{ "l13_1", NFT_PAYLOAD_LL_HEADER, 13, 1, { 0x90 } },
	{ "l12_4", NFT_PAYLOAD_LL_HEADER, 12, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "l14_2", NFT_PAYLOAD_LL_HEADER, 14, 2, { 0x90, 0x91 } },
};
#define NL68 ((int)(sizeof(L568) / sizeof(L568[0])))

/* the network base: every branch of nft_nh_write_ok_ip4() and cells it
 * does not name; two cells whose verdict reads the VALUE (offset 0) */
static struct f568_spec N568[] = {
	{ "nz",   0, 0, 0, { 0 } },
	{ "n0_2s", NFT_PAYLOAD_NETWORK_HEADER, 0, 2, { 0x45, 0x00 } },
	{ "n0_2t", NFT_PAYLOAD_NETWORK_HEADER, 0, 2, { 0x45, 0x10 } },
	{ "n0_2x", NFT_PAYLOAD_NETWORK_HEADER, 0, 2, { 0x90, 0x91 } },
	{ "n0_1",  NFT_PAYLOAD_NETWORK_HEADER, 0, 1, { 0x45 } },
	{ "n1_1",  NFT_PAYLOAD_NETWORK_HEADER, 1, 1, { 0x90 } },
	{ "n2_2",  NFT_PAYLOAD_NETWORK_HEADER, 2, 2, { 0x90, 0x91 } },
	{ "n4_2",  NFT_PAYLOAD_NETWORK_HEADER, 4, 2, { 0x90, 0x91 } },
	{ "n6_2",  NFT_PAYLOAD_NETWORK_HEADER, 6, 2, { 0x90, 0x91 } },
	{ "n8_1",  NFT_PAYLOAD_NETWORK_HEADER, 8, 1, { 0x90 } },
	{ "n8_1s", NFT_PAYLOAD_NETWORK_HEADER, 8, 1, { 0x40 } },
	{ "n8_2p", NFT_PAYLOAD_NETWORK_HEADER, 8, 2, { 0x90, 0x11 } },
	{ "n8_2x", NFT_PAYLOAD_NETWORK_HEADER, 8, 2, { 0x90, 0x91 } },
	{ "n9_1",  NFT_PAYLOAD_NETWORK_HEADER, 9, 1, { 0x90 } },
	{ "n10_2", NFT_PAYLOAD_NETWORK_HEADER, 10, 2, { 0x90, 0x91 } },
	{ "n10_10", NFT_PAYLOAD_NETWORK_HEADER, 10, 10,
	  { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99 } },
	{ "n12_4", NFT_PAYLOAD_NETWORK_HEADER, 12, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "n12_8", NFT_PAYLOAD_NETWORK_HEADER, 12, 8,
	  { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97 } },
	{ "n14_2", NFT_PAYLOAD_NETWORK_HEADER, 14, 2, { 0x90, 0x91 } },
	{ "n16_4", NFT_PAYLOAD_NETWORK_HEADER, 16, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "n16_8", NFT_PAYLOAD_NETWORK_HEADER, 16, 8,
	  { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97 } },
	{ "n20_2", NFT_PAYLOAD_NETWORK_HEADER, 20, 2, { 0x90, 0x91 } },
};
#define NN68 ((int)(sizeof(N568) / sizeof(N568[0])))

/* the transport base: F43's eight cells */
static struct f568_spec T568[] = {
	{ "tz",  0, 0, 0, { 0 } },
	{ "t0_2",  NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, { 0x90, 0x91 } },
	{ "t2_2",  NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, { 0x90, 0x91 } },
	{ "t4_2",  NFT_PAYLOAD_TRANSPORT_HEADER, 4, 2, { 0x90, 0x91 } },
	{ "t6_2",  NFT_PAYLOAD_TRANSPORT_HEADER, 6, 2, { 0x90, 0x91 } },
	{ "t8_2",  NFT_PAYLOAD_TRANSPORT_HEADER, 8, 2, { 0x90, 0x91 } },
	{ "t0_4",  NFT_PAYLOAD_TRANSPORT_HEADER, 0, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "t12_4", NFT_PAYLOAD_TRANSPORT_HEADER, 12, 4, { 0x90, 0x91, 0x92, 0x93 } },
	{ "t16_2", NFT_PAYLOAD_TRANSPORT_HEADER, 16, 2, { 0x90, 0x91 } },
};
#define NT68 ((int)(sizeof(T568) / sizeof(T568[0])))

/* the repair arms: one cell, one immediate, and the csum attribute */
struct f568_csum {
	const char *arm;
	uint32_t base;
	int off, len;
	unsigned char imm[8];
	int csum, cso;
};

static struct f568_csum C568[] = {
	{ "r_ttl0",  NFT_PAYLOAD_NETWORK_HEADER, 8, 1, { 0x90 }, 0, 0 },
	{ "r_ttl12", NFT_PAYLOAD_NETWORK_HEADER, 8, 1, { 0x90 }, F568_CSUM_INET, 12 },
	{ "r_ttl10", NFT_PAYLOAD_NETWORK_HEADER, 8, 1, { 0x90 }, F568_CSUM_INET, 10 },
	{ "r_ttl6",  NFT_PAYLOAD_NETWORK_HEADER, 8, 1, { 0x90 }, F568_CSUM_INET, 6 },
	{ "r_tos0",  NFT_PAYLOAD_NETWORK_HEADER, 1, 1, { 0x90 }, 0, 0 },
	{ "r_tos12", NFT_PAYLOAD_NETWORK_HEADER, 1, 1, { 0x90 }, F568_CSUM_INET, 12 },
	{ "r_tos10", NFT_PAYLOAD_NETWORK_HEADER, 1, 1, { 0x90 }, F568_CSUM_INET, 10 },
	{ "r_src0",  NFT_PAYLOAD_NETWORK_HEADER, 12, 4, { 0x90, 0x91, 0x92, 0x93 }, 0, 0 },
	{ "r_src12", NFT_PAYLOAD_NETWORK_HEADER, 12, 4, { 0x90, 0x91, 0x92, 0x93 }, F568_CSUM_INET, 12 },
	{ "r_src10", NFT_PAYLOAD_NETWORK_HEADER, 12, 4, { 0x90, 0x91, 0x92, 0x93 }, F568_CSUM_INET, 10 },
	{ "r_src6",  NFT_PAYLOAD_NETWORK_HEADER, 12, 4, { 0x90, 0x91, 0x92, 0x93 }, F568_CSUM_INET, 6 },
	{ "r_chk10", NFT_PAYLOAD_NETWORK_HEADER, 10, 2, { 0x90, 0x91 }, F568_CSUM_INET, 10 },
	{ "r_chk12", NFT_PAYLOAD_NETWORK_HEADER, 10, 2, { 0x90, 0x91 }, F568_CSUM_INET, 12 },
	{ "r_port6", NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, { 0x90, 0x91 }, F568_CSUM_INET, 6 },
	{ "r_port0", NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, { 0x90, 0x91 }, 0, 0 },
	{ "r_sport6", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, { 0x90, 0x91 }, F568_CSUM_INET, 6 },
	{ "r_sport0", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, { 0x90, 0x91 }, 0, 0 },
	{ "r_pay6",  NFT_PAYLOAD_TRANSPORT_HEADER, 8, 2, { 0x90, 0x91 }, F568_CSUM_INET, 6 },
	{ "r_pay0",  NFT_PAYLOAD_TRANSPORT_HEADER, 8, 2, { 0x90, 0x91 }, 0, 0 },
};
#define NC68 ((int)(sizeof(C568) / sizeof(C568[0])))

/* read-only cells at the egress door: does the read land on the same byte the
 * store writes when nhoff == 0? */
struct f568_rd {
	const char *arm;
	uint32_t base;
	int off, len;
	unsigned char imm[8];
};

static struct f568_rd R568[] = {
	{ "q_ttl", NFT_PAYLOAD_NETWORK_HEADER, 8, 1, { 0x40 } },
	{ "q_ver", NFT_PAYLOAD_NETWORK_HEADER, 0, 2, { 0x45, 0x00 } },
	{ "q_ttl_x", NFT_PAYLOAD_NETWORK_HEADER, 8, 1, { 0x99 } },
	{ "q_src", NFT_PAYLOAD_NETWORK_HEADER, 12, 4, { 0x0a, 0x0a, 0x00, 0x01 } },
	{ "q_dst", NFT_PAYLOAD_NETWORK_HEADER, 16, 4, { 0x0a, 0x0a, 0x00, 0x02 } },
	{ "q_sport", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, { 0x9c, 0x40 } },
};
#define NR68 ((int)(sizeof(R568) / sizeof(R568[0])))

/* ---------- sections ---------- */

/* A. the reference frame of every (door, class) */
static void f568_sec_ctl(int rfd)
{
	int i;

	for (i = 0; i < NP68; i++) {
		f568_arm("ctl", &P568[i], "ctl", 0, 0, 0, NULL, 0, 0, 0, rfd);
		f568_arm("ctl", &P568[i], "ctl2", 0, 0, 0, NULL, 0, 0, 0, rfd);
	}
}

/* B. the link-layer base on every door */
static void f568_sec_ll(int rfd)
{
	int i, k;

	for (i = 0; i < NP68; i++)
		for (k = 1; k < NL68; k++)
			f568_arm("ll", &P568[i], L568[k].arm, L568[k].base,
				 L568[k].off, L568[k].len, L568[k].imm, 1, 0, 0,
				 rfd);
}

/* C. the network base on six (door, class) pairs */
static void f568_sec_nh(int rfd)
{
	static const int pairs[] = { 0, 1, 2, 3, 4, 8, 7 };	/* out/loc post/loc egr/loc post/fwd fwd/fwd lin/in pre/in */
	int i, k;

	for (i = 0; i < (int)(sizeof(pairs) / sizeof(pairs[0])); i++)
		for (k = 1; k < NN68; k++)
			f568_arm("nh", &P568[pairs[i]], N568[k].arm, N568[k].base,
				 N568[k].off, N568[k].len, N568[k].imm, 1, 0, 0,
				 rfd);
}

/* D. the transport base: one egress door and one ingress door */
static void f568_sec_th(int rfd)
{
	int k;

	static const int pairs[] = { 0, 2, 3, 8, 7 };	/* out/loc egr/loc post/fwd lin/in pre/in */
	int i;

	for (i = 0; i < (int)(sizeof(pairs) / sizeof(pairs[0])); i++)
		for (k = 1; k < NT68; k++)
			f568_arm("th", &P568[pairs[i]], T568[k].arm, T568[k].base,
				 T568[k].off, T568[k].len, T568[k].imm, 1, 0, 0,
				 rfd);
}

/* E. the repair: one store, one csum attribute, four doors */
static void f568_sec_cs(int rfd)
{
	static const int pairs[] = { 0, 1, 3, 5, 8 };	/* out/loc post/loc post/fwd egr/fwd lin/in */
	int i, k;

	for (i = 0; i < (int)(sizeof(pairs) / sizeof(pairs[0])); i++)
		for (k = 0; k < NC68; k++)
			f568_arm("cs", &P568[pairs[i]], C568[k].arm, C568[k].base,
				 C568[k].off, C568[k].len, C568[k].imm, 1,
				 C568[k].csum, C568[k].cso, rfd);
}

/* F. read-only cells at the egress doors: read and write share a base */
static void f568_sec_rd(int rfd)
{
	int i, k;

	for (i = 0; i < 2; i++)		/* out/loc, pre/in */
		for (k = 0; k < NR68; k++)
			f568_arm("rd", &P568[i ? 8 : 0], R568[k].arm,
				 R568[k].base, R568[k].off, R568[k].len,
				 R568[k].imm, 3, 0, 0, rfd);
}

/* G. did the write land where nobody can see it?  store, read back, compare */
static void f568_sec_ld(int rfd)
{
	static const int pairs[] = { 8, 7 };	/* pre/in, pre/fwd */
	struct f568_spec cells[] = {
		{ "d_ttl",  NFT_PAYLOAD_NETWORK_HEADER, 8, 1, { 0x90 } },
		{ "d_src",  NFT_PAYLOAD_NETWORK_HEADER, 12, 4, { 0x90, 0x91, 0x92, 0x93 } },
		{ "d_port", NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, { 0x90, 0x91 } },
		{ "d_ll",   NFT_PAYLOAD_LL_HEADER, 0, 2, { 0x90, 0x91 } },
	};
	int i, k;

	for (i = 0; i < 2; i++)
		for (k = 0; k < (int)(sizeof(cells) / sizeof(cells[0])); k++)
			f568_arm("ld", &P568[pairs[i]], cells[k].arm, cells[k].base,
				 cells[k].off, cells[k].len, cells[k].imm, 2, 0, 0,
				 rfd);
}

/* ---------- setup ---------- */

static void f568_setup_env(void)
{
	if (link_add_veth("x0", "x1"))
		printf("F568 FAIL|veth x\n");
	if (link_add_veth("o0", "o1"))
		printf("F568 FAIL|veth o\n");
	if (link_add_veth("y0", "y1"))
		printf("F568 FAIL|veth y\n");
	if (mac_get("x1", X1_MAC))
		printf("F568 FAIL|mac x1\n");
	set_up("x0"); set_up("x1");
	set_up("o0"); set_up("o1");
	set_up("y0"); set_up("y1");
	printf("F568 SETUP|x0=%d|x1=%d|o0=%d|o1=%d|y0=%d|y1=%d\n",
	       f555_ifindex("x0"), f555_ifindex("x1"), f555_ifindex("o0"),
	       f555_ifindex("o1"), f555_ifindex("y0"), f555_ifindex("y1"));
	printf("F568 ADDR|rc=%d\n", f555_addr_add("x0", htonl(A_X0), 24));
	printf("F568 ADDR2|rc=%d\n", f555_addr_add("y1", htonl(A_Y1), 24));
	{
		char p[96];
		static const char *devs[] = { "x0", "o0", "o1", "y0", "y1" };
		int i;

		for (i = 0; i < 5; i++) {
			snprintf(p, sizeof(p), "/proc/sys/net/ipv4/conf/%s/rp_filter", devs[i]);
			f555_sysctl(p, "0");
		}
		f555_sysctl("/proc/sys/net/ipv4/conf/all/rp_filter", "0");
		f555_sysctl("/proc/sys/net/ipv4/conf/default/rp_filter", "0");
		f555_sysctl("/proc/sys/net/ipv4/ip_forward", "1");
		f555_sysctl("/proc/sys/net/ipv6/conf/default/disable_ipv6", "1");
	}
}

static int f568_start_child(void)
{
	int to_ch[2], to_p[2];
	pid_t pid;

	if (pipe(to_ch) || pipe(to_p))
		return -1;
	pid = fork();
	if (pid < 0)
		return -2;
	if (pid == 0) {
		close(to_ch[1]);
		close(to_p[0]);
		f568_child_loop(to_ch[0], to_p[1]);
		_exit(0);
	}
	close(to_ch[0]);
	close(to_p[1]);
	P_W = to_ch[1];
	P_R = to_p[0];
	CHILD = pid;
	return 0;
}

int f568_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "f568";
	char line[512], hx[400];
	int rfd = -1, i, rc;

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F568 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F568 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F568 KERNEL|7.3.4-T563\n");

	f568_setup_env();

	/* the receiver lives in its own netns; x1 is moved into it */
	rc = f568_start_child();
	printf("F568 FORK|rc=%d|pid=%d\n", rc, (int)CHILD);
	if (rc == 0) {
		if (f568_read_line(line, sizeof(line), 20000) < 0 || line[0] != 'U')
			printf("F568 FAIL|child unshare|%s\n", line);
		else
			printf("F568 CHILD|%s\n", line);
		printf("F568 MOVE|rc=%d\n", f568_move_link("x1", (int)CHILD));
		f568_ask("C");
		for (;;) {
			if (f568_read_line(line, sizeof(line), 20000) < 0) {
				printf("F568 FAIL|child cfg\n");
				break;
			}
			printf("F568 CHILDR|%s\n", line);
			if (!strncmp(line, "READY", 5) || line[0] == 'E')
				break;
		}
	}
	NFL67 = nfl_open(5);
	printf("F568 NFL|%d\n", NFL67);

	if (f568_chains()) {
		printf("F568 FAIL|chains\n");
		return 0;
	}

	/* the two frames we inject */
	{
		unsigned char mo[6], my[6];

		if (mac_get("o1", mo) || mac_get("y1", my)) {
			printf("F568 FAIL|mac\n");
			return 0;
		}
		FWD_FRAME_LEN = f568_mkframe(FWD_FRAME, mo, A_FS, A_X1, 40000, 5000);
		IN_FRAME_LEN = f568_mkframe(IN_FRAME, my, A_IS, A_Y1, 40000, 5000);
		printf("F568 FRAME|fwd|len=%d|wire=%s\n", FWD_FRAME_LEN,
		       f559_hexs(hx, sizeof(hx), FWD_FRAME, FWD_FRAME_LEN));
		printf("F568 FRAME|in|len=%d|wire=%s\n", IN_FRAME_LEN,
		       f559_hexs(hx, sizeof(hx), IN_FRAME, IN_FRAME_LEN));
	}
	LOC_SOCK = f564_udp_bind(AF_INET, A_X0, NULL, 40000);
	IN_SOCK = f564_udp_bind(AF_INET, A_Y1, NULL, 5000);
	printf("F568 SOCK|loc=%d|in=%d\n", LOC_SOCK, IN_SOCK);
	rfd = cap_open("y1");
	printf("F568 CAP|rfd=%d\n", rfd);

	/* pin the neighbour so that no arm is spent waiting for an ARP probe */
	{
		unsigned char mx1[6];

		memcpy(mx1, X1_MAC, 6);
		printf("F568 NEIGH|rc=%d|mac=%02x%02x%02x%02x%02x%02x\n",
		       f568_neigh_add("x0", htonl(A_X1), mx1),
		       mx1[0], mx1[1], mx1[2], mx1[3], mx1[4], mx1[5]);
	}

	/* warm-up: resolve the neighbour for 10.10.0.2 through the receiver */
	{
		struct f568_rep r;
		struct sockaddr_in sin;
		int k, got = 0;

		f568_flush_all();
		for (k = 0; k < 6; k++) {
			memset(&sin, 0, sizeof(sin));
			sin.sin_family = AF_INET;
			sin.sin_addr.s_addr = htonl(A_X1);
			sin.sin_port = htons(5000);
			sendto(LOC_SOCK, F568_PAY, sizeof(F568_PAY), 0,
			       (struct sockaddr *)&sin, sizeof(sin));
			usleep(120000);
			if (f568_snapshot(&r) == 0 && r.udpn > 0) {
				got = 1;
				break;
			}
		}
		printf("F568 WARM|got=%d|tapn=%d|udpn=%d\n", got, r.tapn, r.udpn);
	}

	if (!strcmp(mode, "ctl"))
		f568_sec_ctl(rfd);
	else if (!strcmp(mode, "ll"))
		f568_sec_ll(rfd);
	else if (!strcmp(mode, "nh"))
		f568_sec_nh(rfd);
	else if (!strcmp(mode, "th"))
		f568_sec_th(rfd);
	else if (!strcmp(mode, "cs"))
		f568_sec_cs(rfd);
	else if (!strcmp(mode, "rd"))
		f568_sec_rd(rfd);
	else if (!strcmp(mode, "ld"))
		f568_sec_ld(rfd);
	else {
		f568_sec_ctl(rfd);
		f568_sec_ll(rfd);
		f568_sec_nh(rfd);
		f568_sec_th(rfd);
		f568_sec_cs(rfd);
		f568_sec_rd(rfd);
		f568_sec_ld(rfd);
	}
	(void)i;
	f568_ask("Q");
	printf("F568 DONE\n");
	return 0;
}
/* differ569_add.c -- turn 569.
 *
 *  PART 1 (mode `iso`): the F46 anomaly `post/loc n0_1 cntp=2`, reproduced on
 *  purpose.  One `inet` base chain at postrouting with counter+log+accept; an
 *  IPv4 datagram is sent while the parent's own stack emits IPv6 packets, and
 *  the counter is read under four conditions:
 *      ctl4    IPv6 off            -> 1 packet
 *      v6on    IPv6 just enabled   -> k packets, none of them ours
 *      v6plus  the same + one IPv4 -> k+1
 *      guard   the same, with a `meta nfproto ipv4` chain in front -> 1
 *      v6off   IPv6 off again      -> 0
 *  If those five numbers hold, `cntp=2` was never a double count: an `inet`
 *  chain counts both families, and the second packet was IPv6.
 *
 *  PART 2 (mode `v6`): F47 -- IPv6 at the egress doors.  The same six doors
 *  and two traffic classes as F46, with an IPv6/UDP frame instead of an IPv4
 *  one.  IPv6 has no header checksum, so the question is what replaces it as
 *  the toll: the hop limit at FORWARD, the pseudo-header at the transport
 *  layer, the route lookup, or nothing at all.
 *
 *  Every helper below the new code (netlink toolkit, rtnetlink, NFLOG, capture,
 *  counters, chain install) is the one that produced F31..F46.
 */

/* ---------- addresses ---------- */

static const unsigned char A6_X0[16] = { 0xfd, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 1 };
static const unsigned char A6_X1[16] = { 0xfd, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 2 };
static const unsigned char A6_FS[16] = { 0xfd, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0x08, 0, 2 };
static const unsigned char A6_BAD[16] = { 0xfd, 0, 0, 0, 0, 0, 0, 0,
					  0, 0, 0, 0, 0, 0, 0, 0x99 };
static const unsigned char A6_ZERO[16] = { 0 };

#define F569_PAY	18
#define F569_UDP6LEN	(8 + F569_PAY)

/* ---------- an IPv6/UDP frame ---------- */

static int f569_mk6(unsigned char *out, const unsigned char *dmac,
		    const unsigned char *s16, const unsigned char *d16,
		    unsigned short sport, unsigned short dport)
{
	static const unsigned char sm[6] = { 0x02, 0x00, 0x00, 0x00, 0x00, 0x69 };

	memset(out, 0, 128);
	memcpy(out, dmac, 6);
	memcpy(out + 6, sm, 6);
	out[12] = 0x86;
	out[13] = 0xdd;
	out[14] = 0x60;					/* version 6, tc 0 */
	out[18] = (unsigned char)(F569_UDP6LEN >> 8);
	out[19] = (unsigned char)(F569_UDP6LEN & 0xff);
	out[20] = 17;					/* nexthdr: UDP */
	out[21] = 64;					/* hop limit */
	memcpy(out + 22, s16, 16);
	memcpy(out + 38, d16, 16);
	out[54] = (unsigned char)(sport >> 8);
	out[55] = (unsigned char)(sport & 0xff);
	out[56] = (unsigned char)(dport >> 8);
	out[57] = (unsigned char)(dport & 0xff);
	out[58] = (unsigned char)(F569_UDP6LEN >> 8);
	out[59] = (unsigned char)(F569_UDP6LEN & 0xff);
	memcpy(out + 62, F568_PAY, F569_PAY);
	f564_udp6_csum(out + 14, F569_UDP6LEN);
	return 14 + 40 + F569_UDP6LEN;			/* 80 */
}

/* an NDP entry, so that no arm waits for a solicitation */
static int f569_neigh6_add(const char *dev, const unsigned char *dst,
			   const unsigned char *mac)
{
	struct {
		struct nlmsghdr nlh;
		struct ndmsg ndm;
		char attrs[64];
	} req;
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ndmsg));
	req.nlh.nlmsg_type = RTM_NEWNEIGH;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_REPLACE;
	req.nlh.nlmsg_seq = 1;
	req.ndm.ndm_family = AF_INET6;
	req.ndm.ndm_ifindex = f555_ifindex(dev);
	req.ndm.ndm_state = NUD_PERMANENT;
	attr_put(&req.nlh, NDA_DST, dst, 16);
	attr_put(&req.nlh, NDA_LLADDR, mac, 6);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

/* ---------- every NFLOG payload of an arm, not just the last ---------- */

#define F569_NMSG 8
struct f569_pl {
	int n;
	int plen[F569_NMSG];
	unsigned char p[F569_NMSG][56];
};

static void f569_drain(int fd, struct f569_pl *v)
{
	unsigned char b[16384];
	int guard = 0, rl;

	memset(v, 0, sizeof(*v));
	if (fd < 0)
		return;
	while (guard++ < 64) {
		struct nlmsghdr *h;
		int len;

		rl = (int)recv(fd, b, sizeof(b), MSG_DONTWAIT);
		if (rl <= 0)
			break;
		len = rl;
		for (h = (struct nlmsghdr *)b; NLMSG_OK(h, len);
		     h = NLMSG_NEXT(h, len)) {
			const char *p, *end, *prefix = NULL;
			const unsigned char *pl = NULL;
			int pll = 0;

			if (h->nlmsg_type == NLMSG_DONE ||
			    h->nlmsg_type == NLMSG_ERROR)
				continue;
			p = (const char *)h + NLMSG_HDRLEN + sizeof(struct nfgenmsg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int al = (int)a->nla_len;
				int t;

				if (al < (int)sizeof(*a) || p + al > end)
					break;
				t = a->nla_type & 0x3fff;
				if (t == NFULA_PREFIX_)
					prefix = (const char *)a + NLA_HDRLEN;
				else if (t == NFULA_PAYLOAD_) {
					pl = (const unsigned char *)a + NLA_HDRLEN;
					pll = al - NLA_HDRLEN;
				}
				p += NLA_ALIGN_(al);
			}
			if (!prefix || !pl || prefix[0] != 'p')
				continue;
			if (v->n < F569_NMSG) {
				int k = pll < (int)sizeof(v->p[0]) ? pll
								   : (int)sizeof(v->p[0]);

				memcpy(v->p[v->n], pl, (size_t)k);
				v->plen[v->n] = k;
			}
			v->n++;
		}
	}
}

/* ---------- the receiving side in the child netns ---------- */

struct f569_rep6 {
	int tapn, taplen;
	char taphex[600];
	int u6n, u6len0, u6sport0;
	char u6pay[40];
	unsigned long long i6in, i6hdr, i6addr, i6unk, i6trunc, i6noroute,
			   i6deliv, u6in, u6err, u6noport, i6out, i6outnoroute,
			   icmp6in;
	int taptot, u6tot, alltot;
	unsigned long long i6octets, i6mcast;
};

/* a frame on the wire that is IPv6/UDP and carries our payload: an ICMPv6
 * error quoting the packet has nexthdr 58 and must not be counted */
static int f569_tap6(const unsigned char *b, int n)
{
	if (n < 14 + 40 + 8)
		return 0;
	if (b[12] != 0x86 || b[13] != 0xdd)
		return 0;
	if (b[20] != 17)
		return 0;
	return f568_needle(b, n);
}

static int F569_TAPTOT, F569_U6TOT, F569_ALLTOT;

static void f569_child_snap(int tapfd, int ufd, int ufd6, int wfd)
{
	unsigned char b[2048], first[512];
	int r, tapn = 0, firstlen = -1;
	int u6n = 0, u6len0 = -1, u6sport0 = -1;
	char pay[40] = "-", hx[600] = "-";

	/* Under TCG the frames sit in the backlog until this process yields;
	 * draining twice with a yield in between is what makes the tap and the
	 * socket see the packet of the arm they are asked about. */
	usleep(40000);
	while ((r = (int)recv(tapfd, b, sizeof(b), MSG_DONTWAIT)) > 0) {
		F569_ALLTOT++;
		if (!f569_tap6(b, r))
			continue;
		tapn++;
		F569_TAPTOT++;
		if (firstlen >= 0)
			continue;
		firstlen = r < (int)sizeof(first) ? r : (int)sizeof(first);
		memcpy(first, b, (size_t)firstlen);
	}
	for (;;) {
		struct sockaddr_in6 from;
		socklen_t fl = sizeof(from);

		memset(&from, 0, sizeof(from));
		r = (int)recvfrom(ufd6, b, sizeof(b), MSG_DONTWAIT,
				  (struct sockaddr *)&from, &fl);
		if (r < 0)
			break;
		if (u6n == 0) {
			int k, n = r < 8 ? r : 8;
			char *o = pay;

			u6len0 = r;
			u6sport0 = (int)ntohs(from.sin6_port);
			for (k = 0; k < n; k++)
				o += sprintf(o, "%02x", b[k]);
		}
		u6n++;
		F569_U6TOT++;
		if (u6n > 32)
			break;
	}
	if (firstlen > 0) {
		int k, n = firstlen < 200 ? firstlen : 200;
		char *o = hx;

		for (k = 0; k < n; k++)
			o += sprintf(o, "%02x", first[k]);
	}
	(void)ufd;
	dprintf(wfd, "R6|%d|%d|%s|%d|%d|%d|%s|%llu|%llu|%llu|%llu|%llu|%llu|%llu|"
		"%llu|%llu|%llu|%llu|%llu|%llu|%d|%d|%llu|%llu|%d\n",
		tapn, firstlen, hx, u6n, u6len0, u6sport0, pay,
		f564_snmp6("Ip6InReceives"), f564_snmp6("Ip6InHdrErrors"),
		f564_snmp6("Ip6InAddrErrors"), f564_snmp6("Ip6InUnknownProtos"),
		f564_snmp6("Ip6InTruncatedPkts"), f564_snmp6("Ip6InNoRoutes"),
		f564_snmp6("Ip6InDelivers"), f564_snmp6("Udp6InDatagrams"),
		f564_snmp6("Udp6InErrors"), f564_snmp6("Udp6NoPorts"),
		f564_snmp6("Ip6OutRequests"), f564_snmp6("Ip6OutNoRoutes"),
		f564_snmp6("Icmp6InMsgs"), F569_TAPTOT, F569_U6TOT,
		f564_snmp6("Ip6InOctets"), f564_snmp6("Ip6InMcastPkts"),
		F569_ALLTOT);
	(void)0;
}

static void f569_child_loop(int rfd, int wfd);

static int f569_start_child(void)
{
	int to_ch[2], to_p[2];
	pid_t pid;

	if (pipe(to_ch) || pipe(to_p))
		return -1;
	pid = fork();
	if (pid < 0)
		return -2;
	if (pid == 0) {
		close(to_ch[1]);
		close(to_p[0]);
		f569_child_loop(to_ch[0], to_p[1]);
		_exit(0);
	}
	close(to_ch[0]);
	close(to_p[1]);
	P_W = to_ch[1];
	P_R = to_p[0];
	CHILD = pid;
	return 0;
}

/* The child: unshare, wait for x1, configure IPv4 and IPv6, serve. */
static void f569_child_loop(int rfd, int wfd)
{
	char cmd[64];
	int tapfd, ufd, ufd6, one = 1;

	setvbuf(stdout, NULL, _IONBF, 0);
	if (unshare(CLONE_NEWNET) < 0) {
		dprintf(wfd, "E|unshare|%d\n", errno);
		_exit(1);
	}
	dprintf(wfd, "U\n");
	for (;;) {
		int n = (int)read(rfd, cmd, sizeof(cmd) - 1);

		if (n <= 0)
			_exit(2);
		cmd[n] = 0;
		if (cmd[0] == 'C')
			break;
	}
	set_up("lo");
	set_up("x1");
	f555_sysctl("/proc/sys/net/ipv6/conf/default/disable_ipv6", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/all/disable_ipv6", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/all/accept_dad", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/all/dad_transmits", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/all/accept_ra", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/all/rtr_solicitations", "0");
	dprintf(wfd, "A|%d|%d\n", f555_addr_add("x1", htonl(A_X1), 24),
		f564_addr6("x1", A6_X1, 64));
	{
		struct sockaddr_in sa;

		ufd = socket(AF_INET, SOCK_DGRAM, 0);
		setsockopt(ufd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
		memset(&sa, 0, sizeof(sa));
		sa.sin_family = AF_INET;
		sa.sin_port = htons(5000);
	}
	{
		struct sockaddr_in6 sa6;

		ufd6 = socket(AF_INET6, SOCK_DGRAM, 0);
		setsockopt(ufd6, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
		setsockopt(ufd6, IPPROTO_IPV6, IPV6_V6ONLY, &one, sizeof(one));
		memset(&sa6, 0, sizeof(sa6));
		sa6.sin6_family = AF_INET6;
		memcpy(&sa6.sin6_addr, A6_X1, 16);
		sa6.sin6_port = htons(5000);
		{
			/* the address may still be tentative (DAD runs the moment
			 * it is added, whatever accept_dad says): retry */
			int k, rc = -1;

			for (k = 0; k < 20; k++) {
				rc = bind(ufd6, (struct sockaddr *)&sa6, sizeof(sa6));
				if (rc == 0)
					break;
				usleep(200000);
			}
			dprintf(wfd, "B6|rc=%d|tries=%d|errno=%d\n", rc, k,
				rc ? errno : 0);
			if (rc)
				dprintf(wfd, "E|bind6|%d\n", errno);
		}
	}
	tapfd = cap_open("x1");
	{
		char ifa[128] = "-", car[32] = "-";
		FILE *f = fopen("/proc/net/if_inet6", "r");

		if (f) {
			char l[256];

			while (fgets(l, sizeof(l), f))
				if (strstr(l, "x1")) {
					snprintf(ifa, sizeof(ifa), "%s", l);
					break;
				}
			fclose(f);
		}
		f = fopen("/sys/class/net/x1/carrier", "r");
		if (f) {
			if (fgets(car, sizeof(car), f)) {
				char *n = strchr(car, '\n');

				if (n)
					*n = 0;
			}
			fclose(f);
		}
		dprintf(wfd, "READY|%d|%d|dis6=%llu|carrier=%s|ifa=%s\n", tapfd,
			f555_ifindex("x1"),
			f567_read_ll("/proc/sys/net/ipv6/conf/x1/disable_ipv6"),
			car, ifa);
	}
	for (;;) {
		int n = (int)read(rfd, cmd, sizeof(cmd) - 1);

		if (n <= 0)
			_exit(3);
		cmd[n] = 0;
		if (cmd[0] == 'Q')
			_exit(0);
		if (cmd[0] == 'S')
			f569_child_snap(tapfd, ufd, ufd6, wfd);
	}
}

static int f569_snapshot6(struct f569_rep6 *R)
{
	char line[3072], *f[32];
	int n;

	memset(R, 0, sizeof(*R));
	R->taplen = -1;
	R->u6len0 = -1;
	R->u6sport0 = -1;
	snprintf(R->taphex, sizeof(R->taphex), "-");
	snprintf(R->u6pay, sizeof(R->u6pay), "-");
	f568_ask("S");
	if (f568_read_line(line, (int)sizeof(line), 8000) < 0)
		return -1;
	n = f568_split(line, f, 32);
	if (n < 26 || f[0][0] != 'R' || f[0][1] != '6')
		return -2;
	R->tapn = atoi(f[1]);
	R->taplen = atoi(f[2]);
	snprintf(R->taphex, sizeof(R->taphex), "%s", f[3]);
	R->u6n = atoi(f[4]);
	R->u6len0 = atoi(f[5]);
	R->u6sport0 = atoi(f[6]);
	snprintf(R->u6pay, sizeof(R->u6pay), "%s", f[7]);
	R->i6in = strtoull(f[8], NULL, 10);
	R->i6hdr = strtoull(f[9], NULL, 10);
	R->i6addr = strtoull(f[10], NULL, 10);
	R->i6unk = strtoull(f[11], NULL, 10);
	R->i6trunc = strtoull(f[12], NULL, 10);
	R->i6noroute = strtoull(f[13], NULL, 10);
	R->i6deliv = strtoull(f[14], NULL, 10);
	R->u6in = strtoull(f[15], NULL, 10);
	R->u6err = strtoull(f[16], NULL, 10);
	R->u6noport = strtoull(f[17], NULL, 10);
	R->i6out = strtoull(f[18], NULL, 10);
	R->i6outnoroute = strtoull(f[19], NULL, 10);
	R->icmp6in = strtoull(f[20], NULL, 10);
	R->taptot = atoi(f[21]);
	R->u6tot = atoi(f[22]);
	R->i6octets = strtoull(f[23], NULL, 10);
	R->i6mcast = strtoull(f[24], NULL, 10);
	R->alltot = atoi(f[25]);
	return 0;
}

/* ---------- PART 2: the six doors, IPv6 ---------- */

static unsigned char FWD6[128], IN6[128];
static int FWD6_LEN = -1, IN6_LEN = -1;
static int LOC6_SOCK = -1;

static void f569_emit(int cls)
{
	if (cls == C_LOC) {
		struct sockaddr_in6 sa;

		memset(&sa, 0, sizeof(sa));
		sa.sin6_family = AF_INET6;
		memcpy(&sa.sin6_addr, A6_X1, 16);
		sa.sin6_port = htons(5000);
		sendto(LOC6_SOCK, F568_PAY, F569_PAY, 0, (struct sockaddr *)&sa,
		       sizeof(sa));
	} else {
		pkt_send_p("o1", FWD6, FWD6_LEN, 0x86dd);
	}
}

static void f569_arm(const char *sec, const struct f568_pair *P, const char *arm,
		     int off, int len, const unsigned char *imm, int mode,
		     int rfd)
{
	struct f568_door *D = &D568[P->door];
	const char *cn = CLSN[P->cls];
	unsigned long long c0p, c0s, c1p, c1s;
	struct f569_rep6 r, r0;
	struct f569_pl pl;
	int rcp = -1, rcs = -1, acks = 0, snd = 0, rc0 = -9, rc1 = -9, npolls = 0;
	unsigned long long p0in, p0hdr, p0out, p0disc, q0rx, q0tx, p0addr, p0idisc;
	char hx[600], hx2[600];
	int i;

	memset(&r, 0, sizeof(r));
	memset(&r0, 0, sizeof(r0));
	p0addr = f564_snmp6("Ip6InAddrErrors");
	p0idisc = f564_snmp6("Ip6InDiscards");
	q0rx = f567_read_ll("/sys/class/net/o0/statistics/rx_packets");
	q0tx = f567_read_ll("/sys/class/net/x0/statistics/tx_packets");
	p0in = f564_snmp6("Ip6InReceives");
	p0hdr = f564_snmp6("Ip6InHdrErrors");
	p0out = f564_snmp6("Ip6OutRequests");
	p0disc = f564_snmp6("Ip6OutDiscards");
	f568_flush_all();
	f569_drain(rfd, &pl);
	rcp = f568_rule(D, "pre0", "p", 0, 0, 0, NULL, 0, 0, 0, &acks);
	rcs = f568_rule(D, "ch", "s", 1, off, len, imm, mode, 0, 0, &acks);
	c0p = f555_count(D->fam, D->table, "pre0");
	c0s = f555_count(D->fam, D->table, "ch");
	/* clear whatever the previous arm left in the child's buffers, so that
	 * no delivery can be attributed to the wrong arm */
	rc0 = f569_snapshot6(&r0);
	f569_emit(P->cls);
	snd = P->cls == C_LOC ? F569_PAY : FWD6_LEN;
	{
		int k, polls = 0;
		unsigned long long o0rx0 = f567_read_ll("/sys/class/net/o0/statistics/rx_packets");

		rc1 = -1;
		for (k = 0; k < 20; k++) {
			unsigned long long o0rx;

			usleep(250000);
			rc1 = f569_snapshot6(&r);
			polls++;
			if (rc1)
				break;
			o0rx = f567_read_ll("/sys/class/net/o0/statistics/rx_packets");
			/* the arm ends when its own packet has been seen, wherever
			 * it is seen: the wire, the receive counters, the socket */
			if (r.u6tot > r0.u6tot || r.alltot > r0.alltot ||
			    r.i6in > r0.i6in || r.i6hdr > r0.i6hdr ||
			    r.i6addr > r0.i6addr || r.i6trunc > r0.i6trunc ||
			    r.i6unk > r0.i6unk || r.i6noroute > r0.i6noroute ||
			    o0rx > o0rx0)
				break;
		}
		npolls = polls;
	}
	f569_drain(rfd, &pl);
	c1p = f555_count(D->fam, D->table, "pre0");
	c1s = f555_count(D->fam, D->table, "ch");

	printf("F569 A|sec=%s|door=%s|cls=%s|arm=%s|mode=%d|off=%d|len=%d|imm=%s|"
	       "rcp=%d|rcs=%d|sendrc=%d|cntp=%llu|lives=%llu|nmsg=%d|"
	       "rc0=%d|rc1=%d|u6n0=%d|i6in0=%llu|in_d=%llu|u6in_d=%llu|polls=%d|"
	       "tapd=%d|u6d=%d|all_d=%d|deliv_d=%llu|oct_d=%llu|mcast_d=%llu|",
	       sec, D->tag, cn, arm, mode, off, len,
	       f559_hexs(hx, sizeof(hx), imm, len), rcp, rcs, snd,
	       c1p - c0p, c1s - c0s, pl.n, rc0, rc1, r0.u6n, r0.i6in,
	       r.i6in - r0.i6in, r.u6in - r0.u6in, npolls, r.taptot - r0.taptot,
	       r.u6tot - r0.u6tot, r.alltot - r0.alltot,
	       r.i6deliv - r0.i6deliv, r.i6octets - r0.i6octets,
	       r.i6mcast - r0.i6mcast);
	for (i = 0; i < pl.n && i < F569_NMSG; i++)
		printf("m%d=%s|", i,
		       f559_hexs(hx2, sizeof(hx2), pl.p[i], pl.plen[i]));
	printf("paddr_d=%llu|pidisc_d=%llu|", f564_snmp6("Ip6InAddrErrors") - p0addr,
	       f564_snmp6("Ip6InDiscards") - p0idisc);
	printf("o0rx_d=%llu|x0tx_d=%llu|pin_d=%llu|phdr_d=%llu|pout_d=%llu|pdisc_d=%llu|",
	       f567_read_ll("/sys/class/net/o0/statistics/rx_packets") - q0rx,
	       f567_read_ll("/sys/class/net/x0/statistics/tx_packets") - q0tx,
	       f564_snmp6("Ip6InReceives") - p0in,
	       f564_snmp6("Ip6InHdrErrors") - p0hdr,
	       f564_snmp6("Ip6OutRequests") - p0out,
	       f564_snmp6("Ip6OutDiscards") - p0disc);
	printf("tapn=%d|taplen=%d|tap=%s|u6n=%d|u6len=%d|u6sport=%d|u6pay=%s|",
	       r.tapn, r.taplen, r.taphex, r.u6n, r.u6len0, r.u6sport0, r.u6pay);
	printf("i6in=%llu|i6hdr=%llu|i6addr=%llu|i6unk=%llu|i6trunc=%llu|"
	       "i6noroute=%llu|i6deliv=%llu|u6in=%llu|u6err=%llu|u6noport=%llu|"
	       "i6out=%llu|i6outnoroute=%llu|icmp6in=%llu\n",
	       r.i6in, r.i6hdr, r.i6addr, r.i6unk, r.i6trunc, r.i6noroute,
	       r.i6deliv, r.u6in, r.u6err, r.u6noport, r.i6out,
	       r.i6outnoroute, r.icmp6in);
}

struct f569_cell { const char *tag; int off, len; unsigned char imm[16]; };

static void f569_sec_v6(int rfd)
{
	static const struct f568_pair P[] = {
		{ 0, C_LOC }, { 1, C_LOC }, { 5, C_LOC },
		{ 1, C_FWD }, { 2, C_FWD }, { 5, C_FWD }, { 3, C_FWD },
	};
	static const struct f569_cell K[] = {
		{ "hop90",  7, 1, { 0x90 } },
		{ "hop00",  7, 1, { 0x00 } },
		{ "hop01",  7, 1, { 0x01 } },
		{ "hop64",  7, 1, { 0x40 } },		/* the value the frame carries */
		{ "flow2",  2, 2, { 0x90, 0x91 } },
		{ "tc4",    0, 4, { 0x60, 0x91, 0x92, 0x93 } },
		{ "ver9",   0, 4, { 0x90, 0x91, 0x92, 0x93 } },
		{ "saddr",  8, 16, { 0 } },		/* filled below */
		{ "saddr_same", 8, 16, { 0 } },
		{ "daddr",  24, 16, { 0 } },
		{ "plen2",  4, 2, { 0x90, 0x91 } },	/* refused: no case for 4 */
		{ "nh1",    6, 1, { 0x90 } },		/* refused: no case for 6 */
	};
	const int NK = (int)(sizeof(K) / sizeof(K[0]));
	const int NPAIR = (int)(sizeof(P) / sizeof(P[0]));
	int i, j;
	unsigned char imm[16];

	for (i = 0; i < NK; i++) {
		for (j = 0; j < NPAIR; j++) {
			int cls = P[j].cls;
			char arm[64];

			memcpy(imm, K[i].imm, 16);
			if (!strcmp(K[i].tag, "saddr")) {
				memcpy(imm, A6_BAD, 16);
			} else if (!strcmp(K[i].tag, "saddr_same")) {
				memcpy(imm, cls == C_LOC ? A6_X0 : A6_FS, 16);
			} else if (!strcmp(K[i].tag, "daddr")) {
				memcpy(imm, A6_BAD, 16);
			}
			snprintf(arm, sizeof(arm), "%s", K[i].tag);
			f569_arm("v6", &P[j], arm, K[i].off, K[i].len, imm, 1, rfd);
		}
	}
	/* the read side of the same coordinate: mode 3 reads the cell and
	 * compares it with the immediate, and the counter after the compare
	 * says how many packets matched */
	for (j = 0; j < NPAIR; j++) {
		int cls = P[j].cls;

		memset(imm, 0, 16);
		imm[0] = 0x40;			/* the hop limit the frame carries */
		f569_arm("v6", &P[j], "rd_hop64", 7, 1, imm, 3, rfd);
		imm[0] = 0x00;			/* nothing carries zero */
		f569_arm("v6", &P[j], "rd_hop00", 7, 1, imm, 3, rfd);
		memcpy(imm, cls == C_LOC ? A6_X0 : A6_FS, 16);
		f569_arm("v6", &P[j], "rd_src", 8, 16, imm, 3, rfd);
		memcpy(imm, cls == C_LOC ? A6_X1 : A6_X1, 16);
		f569_arm("v6", &P[j], "rd_dst", 24, 16, imm, 3, rfd);
	}
}

/* ---------- PART 1: the isolation ---------- */

static void f569_meta_nfproto(struct nlmsghdr *nlh)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "meta");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_META_KEY, NFT_META_NFPROTO);
	put_be32(nlh, NFTA_META_DREG, F562_RD_DREG);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static int f569_gu_rule(void)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;
	unsigned char v4 = 2;		/* NFPROTO_IPV4 */
	int acks = 0;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_INET);
	put_str(nlh, NFTA_RULE_TABLE, "e69a");
	put_str(nlh, NFTA_RULE_CHAIN, "gu");
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	f569_meta_nfproto(nlh);
	f562_cmp(nlh, F562_RD_DREG, &v4, 1);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, &acks);
}

/* send one IPv4 datagram into the receiver netns (mode iso: x1 is local) */
static void f569_send4(int sock, uint32_t dst)
{
	struct sockaddr_in sin;

	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = htonl(dst);
	sin.sin_port = htons(5000);
	sendto(sock, F568_PAY, sizeof(F568_PAY), 0, (struct sockaddr *)&sin,
	       sizeof(sin));
}

/* one counted arm: drain, read the counters, do something, read again */
static void f569_iso_arm(const char *arm, int nfl, int have_gu, int send4,
			 int sock, int action)
{
	unsigned long long c0, c1, g0, g1;
	struct f569_pl pl;
	char hx[600];
	int i;

	f569_drain(nfl, &pl);
	c0 = f555_count(NFPROTO_INET, "e69a", "pre0");
	g0 = have_gu ? f555_count(NFPROTO_INET, "e69a", "gu") : 0;
	if (action == 1) {			/* IPv6 on */
		f555_sysctl("/proc/sys/net/ipv6/conf/x0/disable_ipv6", "0");
	} else if (action == 2) {		/* off, then on again */
		f555_sysctl("/proc/sys/net/ipv6/conf/x0/disable_ipv6", "1");
		usleep(400000);
		f555_sysctl("/proc/sys/net/ipv6/conf/x0/disable_ipv6", "0");
	} else if (action == 3) {		/* off */
		f555_sysctl("/proc/sys/net/ipv6/conf/x0/disable_ipv6", "1");
	}
	if (send4)
		f569_send4(sock, A_X1);
	usleep(600000);
	f569_drain(nfl, &pl);
	c1 = f555_count(NFPROTO_INET, "e69a", "pre0");
	g1 = have_gu ? f555_count(NFPROTO_INET, "e69a", "gu") : 0;
	printf("F569 ISO|arm=%s|gu=%d|send4=%d|act=%d|cnt=%llu|gcnt=%llu|nmsg=%d|",
	       arm, have_gu, send4, action, c1 - c0, g1 - g0, pl.n);
	for (i = 0; i < pl.n && i < F569_NMSG; i++)
		printf("m%d=%s|", i,
		       f559_hexs(hx, sizeof(hx), pl.p[i], pl.plen[i]));
	printf("\n");
}

static void f569_sec_iso(void)
{
	static struct f568_door ISO = { "iso", NFPROTO_INET, "e69a", NULL,
					NF_INET_POST_, 0, 10 };
	int rfd, acks = 0, i, rc, s;

	f555_sysctl("/proc/sys/net/ipv6/conf/default/disable_ipv6", "1");
	if (link_add_veth("x0", "x1"))
		printf("F569 FAIL|veth x\n");
	set_up("x0");
	set_up("x1");
	f555_addr_add("x0", htonl(A_X0), 24);
	f555_addr_add("x1", htonl(A_X1), 24);
	f555_sysctl("/proc/sys/net/ipv4/conf/all/rp_filter", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/x0/disable_ipv6", "1");
	f555_sysctl("/proc/sys/net/ipv6/conf/x1/disable_ipv6", "1");

	if (add_table(NFPROTO_INET, "e69a") ||
	    f556_add_chain(NFPROTO_INET, "e69a", "pre0", NF_INET_POST_, 0, 1,
			   NULL) ||
	    f556_add_chain(NFPROTO_INET, "e69a", "gu", NF_INET_POST_, 0, 1,
			   NULL)) {
		printf("F569 FAIL|chains\n");
		return;
	}
	rc = f568_rule(&ISO, "pre0", "p", 0, 0, 0, NULL, 0, 0, 0, &acks);
	printf("F569 ISO_RULE|rc=%d|acks=%d\n", rc, acks);
	rfd = nfl_open(5);
	printf("F569 NFL|%d\n", rfd);
	s = f564_udp_bind(AF_INET, A_X0, NULL, 40000);
	printf("F569 SOCK|%d\n", s);

	/* 1. IPv6 off: the datagram, and the ICMP error it provokes, are the
	 *    only two packets the chain can see */
	f569_iso_arm("ctl4", rfd, 0, 1, s, 0);

	/* 2. IPv6 enabled on x0 and not a byte sent: whatever the chain
	 *    counts here was emitted by the IPv6 stack, not by the rule */
	f569_iso_arm("v6on", rfd, 0, 0, s, 1);
	usleep(500000);
	f569_iso_arm("v6on2", rfd, 0, 0, s, 0);

	/* 3. the same enable *and* one IPv4 datagram in one arm: the two
	 *    families counted by one `inet` counter */
	f555_sysctl("/proc/sys/net/ipv6/conf/x0/disable_ipv6", "1");
	usleep(400000);
	f569_iso_arm("v6plus", rfd, 0, 1, s, 1);

	/* 4. the same with `meta nfproto ipv4` in front of a second counter */
	rc = f569_gu_rule();
	printf("F569 ISO_GU|rc=%d\n", rc);
	f569_iso_arm("guard", rfd, 1, 1, s, 2);

	/* 5. IPv6 off again: the IPv6 half disappears, the IPv4 half does not */
	f569_iso_arm("v6off", rfd, 1, 1, s, 3);

	/* 6. controls: nothing at all, four times */
	f569_iso_arm("quiet", rfd, 1, 0, s, 0);
	for (i = 0; i < 3; i++) {
		usleep(400000);
		f569_iso_arm("quiet2", rfd, 1, 0, s, 0);
	}
	f569_iso_arm("state", rfd, 1, 0, s, 0);
	printf("F569 ISO_END|dad=%llu|dis=%llu\n",
	       f567_read_ll("/proc/sys/net/ipv6/conf/x0/accept_dad"),
	       f567_read_ll("/proc/sys/net/ipv6/conf/x0/disable_ipv6"));
	close(s);
}

/* ---------- the IPv6 environment of mode `v6` ---------- */

static void f569_setup_v6(void)
{
	f555_sysctl("/proc/sys/net/ipv6/conf/default/disable_ipv6", "1");
	if (link_add_veth("x0", "x1"))
		printf("F569 FAIL|veth x\n");
	if (link_add_veth("o0", "o1"))
		printf("F569 FAIL|veth o\n");
	if (mac_get("x1", X1_MAC))
		printf("F569 FAIL|mac x1\n");
	set_up("x0"); set_up("x1"); set_up("o0"); set_up("o1");
	f555_sysctl("/proc/sys/net/ipv6/conf/x0/disable_ipv6", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/o0/disable_ipv6", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/o1/disable_ipv6", "0");
	usleep(600000);
	f555_sysctl("/proc/sys/net/ipv6/conf/x0/accept_dad", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/x0/dad_transmits", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/x0/accept_ra", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/x0/rtr_solicitations", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/all/forwarding", "1");
	printf("F569 ADDR6|rc=%d\n", f564_addr6("x0", A6_X0, 64));
	printf("F569 SYS6|x0=%llu|o0=%llu|o1=%llu|o0rx=%llu|x0tx=%llu\n",
	       f567_read_ll("/proc/sys/net/ipv6/conf/x0/disable_ipv6"),
	       f567_read_ll("/proc/sys/net/ipv6/conf/o0/disable_ipv6"),
	       f567_read_ll("/proc/sys/net/ipv6/conf/o1/disable_ipv6"),
	       f567_read_ll("/sys/class/net/o0/statistics/rx_packets"),
	       f567_read_ll("/sys/class/net/x0/statistics/tx_packets"));
	usleep(300000);
}

int f569_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "v6";
	char line[1024], hx[600];

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F569 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F569 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F569 KERNEL|7.3.4-T563\n");

	if (!strcmp(mode, "iso")) {
		f569_sec_iso();
		printf("F569 DONE\n");
		return 0;
	}

	f569_setup_v6();
	{
		int rc = f569_start_child();

		printf("F569 FORK|rc=%d|pid=%d\n", rc, (int)CHILD);
	}
	{
		int n;

		if (f568_read_line(line, (int)sizeof(line), 20000) < 0 || line[0] != 'U')
			printf("F569 FAIL|child unshare|%s\n", line);
		else
			printf("F569 CHILD|%s\n", line);
		printf("F569 MOVE|rc=%d\n", f568_move_link("x1", (int)CHILD));
		f568_ask("C");
		for (;;) {
			if (f568_read_line(line, (int)sizeof(line), 20000) < 0) {
				printf("F569 FAIL|child cfg\n");
				break;
			}
			printf("F569 CHILDR|%s\n", line);
			n = (int)strlen(line);
			if (!strncmp(line, "READY", 5) || (n && line[0] == 'E'))
				break;
		}
	}
	{
		unsigned char mo[6];
		int rfd;

		if (mac_get("o0", mo))
			printf("F569 FAIL|mac o0\n");
		FWD6_LEN = f569_mk6(FWD6, mo, A6_FS, A6_X1, 40000, 5000);
		printf("F569 FRAME|fwd|len=%d|wire=%s\n", FWD6_LEN,
		       f559_hexs(hx, sizeof(hx), FWD6, FWD6_LEN));
		LOC6_SOCK = f564_udp_bind(AF_INET6, 0, A6_X0, 40000);
		printf("F569 SOCK|loc6=%d\n", LOC6_SOCK);
		printf("F569 NEIGH6|rc=%d\n", f569_neigh6_add("x0", A6_X1, X1_MAC));
		rfd = nfl_open(5);
		printf("F569 NFL|%d\n", rfd);
		if (f568_chains()) {
			printf("F569 FAIL|chains\n");
			return 0;
		}
		{
			struct f569_rep6 r;
			int k, got = 0;

			memset(&r, 0, sizeof(r));
			f568_flush_all();
			for (k = 0; k < 6; k++) {
				struct sockaddr_in6 sa;

				memset(&sa, 0, sizeof(sa));
				sa.sin6_family = AF_INET6;
				memcpy(&sa.sin6_addr, A6_X1, 16);
				sa.sin6_port = htons(5000);
				sendto(LOC6_SOCK, F568_PAY, F569_PAY, 0,
				       (struct sockaddr *)&sa, sizeof(sa));
				usleep(150000);
				if (f569_snapshot6(&r) == 0 && r.u6n > 0) {
					got = 1;
					break;
				}
			}
			printf("F569 WARM|got=%d|tapn=%d|u6n=%d|i6deliv=%llu\n",
			       got, r.tapn, r.u6n, r.i6deliv);
			printf("F569 P6OUT|req=%llu|noroute=%llu|discard=%llu|tx=%llu\n",
			       f564_snmp6("Ip6OutRequests"),
			       f564_snmp6("Ip6OutNoRoutes"),
			       f564_snmp6("Ip6OutDiscards"),
			       f564_snmp6("Ip6OutTransmits"));
		}
		f569_sec_v6(rfd);
	}
	f568_ask("Q");
	printf("F569 DONE\n");
	return 0;
}
/* differ570_add.c -- turn 570 (F48).
 *
 *  DEBT 1 (mode `ppp6e`): IPv6 inside PPPoE at an EGRESS door.  The frame is
 *  built by the kernel itself -- a PF_PPPOX/PX_PROTO_OE session socket bound to
 *  x0 with sid 99 -- so the egress door of x0 sees a real PPPoE frame whose
 *  skb_network_offset is 14 and whose IPv6 header sits at frame offset 22.
 *  A plain IPv6 datagram out the same device is the control on the same door;
 *  the ingress door of x0 with the same bytes is the second control.
 *
 *  DEBT 2 (mode `th6`): @th in the v6 mode.  Six door/class pairs and five frame
 *  shapes (bare, hop-by-hop, hop-by-hop + dest-opts, AH, routing header), all on
 *  the F46/F47 harness (f569_setup_v6, the child netns, the door table D568).
 *
 *  Every helper below the new code is the one that produced F31..F47.
 */

#include <linux/if_pppox.h>

#define F570_PAY	18
#define F570_META	0x51
#define F570_SID	99

/* ---------- the IPv6 datagram, with optional extension headers ---------- */

/* shape: 0 bare, 1 hop-by-hop, 2 hop-by-hop+dest, 3 AH, 4 routing header */
static int f570_extlen(int shape)
{
	switch (shape) {
	case 1: return 8;
	case 2: return 16;
	case 3: return 24;
	case 4: return 8;
	}
	return 0;
}

static void f570_udp6_csum(unsigned char *ip6, int extlen, int udplen)
{
	unsigned char *udp = ip6 + 40 + extlen;
	unsigned int acc;
	unsigned short c;

	acc = f564_sum(ip6 + 8, 32, 0);		/* saddr + daddr */
	acc += (unsigned int)udplen;
	acc += 17;				/* next header: UDP */
	udp[6] = 0;
	udp[7] = 0;
	acc = f564_sum(udp, udplen, acc);
	c = f564_fold(acc);
	if (!c)
		c = 0xffff;
	udp[6] = (unsigned char)(c >> 8);
	udp[7] = (unsigned char)c;
}

/* the IPv6 datagram alone: 40 + ext + 8 + F570_PAY bytes */
static int f570_ip6(unsigned char *ip, const unsigned char *s16,
		    const unsigned char *d16, int shape, int sport, int dport)
{
	int ext = f570_extlen(shape);
	int udplen = 8 + F570_PAY;
	int tot = ext + udplen;
	unsigned char *p, *udp;
	int i;

	memset(ip, 0, (size_t)(40 + tot));
	ip[0] = 0x60;
	ip[4] = (unsigned char)(tot >> 8);
	ip[5] = (unsigned char)(tot & 0xff);
	ip[7] = 64;
	memcpy(ip + 8, s16, 16);
	memcpy(ip + 24, d16, 16);

	switch (shape) {
	case 0:
		ip[6] = 17;
		break;
	case 1:
		ip[6] = 0;
		p = ip + 40;
		p[0] = 17;
		p[1] = 0;
		break;
	case 2:
		ip[6] = 0;
		p = ip + 40;
		p[0] = 60;
		p[1] = 0;
		p = ip + 48;
		p[0] = 17;
		p[1] = 0;
		break;
	case 3:
		ip[6] = 51;
		p = ip + 40;
		p[0] = 17;
		p[1] = 4;			/* (4 + 2) * 4 = 24 bytes */
		p[4] = 0x11;
		p[5] = 0x22;
		p[6] = 0x33;
		p[7] = 0x44;
		p[11] = 1;
		for (i = 0; i < 12; i++)
			p[12 + i] = 0x5a;
		break;
	case 4:
		ip[6] = 43;
		p = ip + 40;
		p[0] = 17;
		p[1] = 0;
		p[2] = 0;
		p[3] = 0;			/* segments left */
		break;
	}

	udp = ip + 40 + ext;
	udp[0] = (unsigned char)(sport >> 8);
	udp[1] = (unsigned char)(sport & 0xff);
	udp[2] = (unsigned char)(dport >> 8);
	udp[3] = (unsigned char)(dport & 0xff);
	udp[4] = (unsigned char)(udplen >> 8);
	udp[5] = (unsigned char)(udplen & 0xff);
	memcpy(udp + 8, F568_PAY, F570_PAY);
	f570_udp6_csum(ip, ext, udplen);
	return 40 + tot;
}

/* ethernet + PPPoE session + PPP protocol + IPv6 */
static int f570_frame_ppp(unsigned char *out, const unsigned char *dmac,
			  const unsigned char *smac, unsigned short sid,
			  const unsigned char *s16, const unsigned char *d16,
			  int shape)
{
	int n;

	memset(out, 0, 14 + 8 + 40 + 64);
	memcpy(out, dmac, 6);
	memcpy(out + 6, smac, 6);
	out[12] = 0x88;
	out[13] = 0x64;
	out[14] = 0x11;
	out[15] = 0x00;
	out[16] = (unsigned char)(sid >> 8);
	out[17] = (unsigned char)(sid & 0xff);
	out[20] = 0x00;
	out[21] = 0x57;			/* PPP_IPV6 */
	n = f570_ip6(out + 22, s16, d16, shape, 40000, 5000);
	out[18] = (unsigned char)((2 + n) >> 8);
	out[19] = (unsigned char)((2 + n) & 0xff);
	return 22 + n;
}

/* ethernet + IPv6 (the plain control frame) */
static int f570_frame_plain(unsigned char *out, const unsigned char *dmac,
			    const unsigned char *smac, const unsigned char *s16,
			    const unsigned char *d16, int shape)
{
	memset(out, 0, 14 + 40 + 64);
	memcpy(out, dmac, 6);
	memcpy(out + 6, smac, 6);
	out[12] = 0x86;
	out[13] = 0xdd;
	return 14 + f570_ip6(out + 14, s16, d16, shape, 40000, 5000);
}

/* the payload handed to send() on the PPPoX session socket */
static int f570_ppp_payload(unsigned char *out, const unsigned char *s16,
			    const unsigned char *d16, int shape)
{
	int n;

	out[0] = 0x00;
	out[1] = 0x57;
	n = f570_ip6(out + 2, s16, d16, shape, 40000, 5000);
	return 2 + n;
}

/* ---------- addresses of mode `ppp6e` ---------- */

static const unsigned char A6_P_SRC[16] = { 0xfd, 0x01, 0x02, 0x03, 0x04, 0x05,
					    0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b,
					    0x0c, 0x0d, 0x0e, 0x0f };
static const unsigned char A6_P_DST[16] = { 0xfd, 0x11, 0x12, 0x13, 0x14, 0x15,
					    0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b,
					    0x1c, 0x1d, 0x1e, 0x1f };
/* crafted: byte 36 (saddr[6]) reads 0x60, daddr[0..1] give a payload length */
static const unsigned char A6_P_FS[16] = { 0xfd, 0x00, 0x00, 0x00, 0x00, 0x00,
					   0x60, 0x00, 0x00, 0x08, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00 };
static const unsigned char A6_P_FD[16] = { 0x00, 0x08, 0x11, 0x12, 0x13, 0x14,
					   0x15, 0x16, 0x17, 0x18, 0x19, 0x1a,
					   0x1b, 0x1c, 0x1d, 0x1e };

struct f570_door {
	const char *tag;
	const char *table;
	const char *dev;
	uint32_t hook;
	int prio0, prio1;
};

static struct f570_door DB[] = {
	{ "egr", "e70a", "x0", 1, 10, 20 },
	{ "ing", "e70b", "x0", 0, 10, 20 },
};
#define NDB	(int)(sizeof(DB) / sizeof(DB[0]))

struct f570_cfg {
	const char *arm;
	int send_kind;			/* 0 plain egress, 1 pppoe egress, 2 injected */
	int shape;			/* 0 normal, 1 crafted */
	int meta_proto;
	unsigned char pv[2];
	int meta_l4;
	int l4;
	int nh_rd;
	int nh_off, nh_len;
	unsigned char nhi[4];
	int wr, rd;
	uint32_t base;
	int off, len;
	unsigned char imm[16];
	int csum, cso;
};

/* ---------- rule builder for mode `ppp6e` ---------- */

static void f570_put_meta(struct nlmsghdr *nlh, int key)
{
	struct nlattr *e, *d;

	e = nest_start(nlh, NFTA_LIST_ELEM);
	put_str(nlh, NFTA_EXPR_NAME, "meta");
	d = nest_start(nlh, NFTA_EXPR_DATA);
	put_be32(nlh, NFTA_META_KEY, key);
	put_be32(nlh, NFTA_META_DREG, F562_RD_DREG);
	nest_end(nlh, d);
	nest_end(nlh, e);
}

static int f570_rule_b(const struct f570_door *D, const char *chain,
		       const char *prefix, const struct f570_cfg *C, int *acks)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			NFPROTO_NETDEV);
	put_str(nlh, NFTA_RULE_TABLE, D->table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (C->meta_proto) {
		f570_put_meta(nlh, NFT_META_PROTOCOL);
		f562_cmp(nlh, F562_RD_DREG, C->pv, 2);
	}
	if (C->meta_l4) {
		unsigned char v = (unsigned char)C->l4;

		f570_put_meta(nlh, NFT_META_L4PROTO);
		f562_cmp(nlh, F562_RD_DREG, &v, 1);
	}
	if (C->nh_rd) {
		f562_read(nlh, NFT_PAYLOAD_NETWORK_HEADER, (uint32_t)C->nh_off,
			  (uint32_t)C->nh_len);
		f562_cmp(nlh, F562_RD_DREG, C->nhi, C->nh_len);
	}
	if (C->wr)
		f565_store(nlh, C->base, (uint32_t)C->off, (uint32_t)C->len,
			   C->imm, C->csum, (unsigned int)C->cso);
	if (C->rd) {
		f562_read(nlh, C->base, (uint32_t)C->off, (uint32_t)C->len);
		f562_cmp(nlh, F562_RD_DREG, C->imm, C->len);
	}
	log_expr(nlh, 5, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, acks);
}

/* ---------- capture ---------- */

static int f570_needle(const unsigned char *b, int n)
{
	return f568_needle(b, n);
}

static int f570_tap(int fd, unsigned char *out, int max, int *count)
{
	unsigned char b[2048];
	int r, n = -1, seen = 0;

	if (count)
		*count = 0;
	if (fd < 0)
		return -1;
	while ((r = (int)recv(fd, b, sizeof(b), MSG_DONTWAIT)) > 0) {
		if (!f570_needle(b, r))
			continue;
		seen++;
		if (n < 0) {
			n = r < max ? r : max;
			memcpy(out, b, (size_t)n);
		}
	}
	if (count)
		*count = seen;
	return n;
}

/* ---------- mode `ppp6e`: the environment ---------- */

static unsigned char F570_PLAIN_PAY[F569_PAY] = { 0x77, 0x77, 0x77, 0x77,
	0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77,
	0x77, 0x77, 0x77 };
static unsigned char F570_PAYLOAD[256];
static int F570_PAYLOAD_LEN = -1;
static unsigned char F570_INJ[256];
static int F570_INJ_LEN = -1;
static int F570_PPPFD = -1;
static int F570_LOC6 = -1;
static unsigned char F570_X0MAC[6];

static int f570_env_b(void)
{
	f555_sysctl("/proc/sys/net/ipv6/conf/default/disable_ipv6", "1");
	if (link_add_veth("x0", "x1"))
		return -1;
	set_up("x0");
	set_up("x1");
	if (mac_get("x1", X1_MAC))
		return -2;
	if (mac_get("x0", F570_X0MAC))
		return -3;
	f555_sysctl("/proc/sys/net/ipv6/conf/x0/disable_ipv6", "0");
	usleep(300000);
	f555_sysctl("/proc/sys/net/ipv6/conf/x0/accept_dad", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/x0/dad_transmits", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/x0/accept_ra", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/x0/rtr_solicitations", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/all/forwarding", "1");
	f564_addr6("x0", A6_X0, 64);
	f569_neigh6_add("x0", A6_X1, X1_MAC);
	F570_LOC6 = f564_udp_bind(AF_INET6, 0, A6_X0, 40000);
	F570_PPPFD = f563_pppoe_sock("x0", htons(F570_SID), X1_MAC);
	printf("F570 ENV|loc6=%d|pppoe=%d|errno=%d\n", F570_LOC6, F570_PPPFD,
	       errno);
	return 0;
}

static int f570_send(const struct f570_cfg *C)
{
	if (C->send_kind == 0) {
		struct sockaddr_in6 sa;

		memset(&sa, 0, sizeof(sa));
		sa.sin6_family = AF_INET6;
		memcpy(&sa.sin6_addr, A6_X1, 16);
		sa.sin6_port = htons(5000);
		return (int)sendto(F570_LOC6, F570_PLAIN_PAY, F569_PAY, 0,
				   (struct sockaddr *)&sa, sizeof(sa));
	}
	if (C->send_kind == 1) {
		F570_PAYLOAD_LEN = f570_ppp_payload(F570_PAYLOAD,
						    C->shape ? A6_P_FS : A6_P_SRC,
						    C->shape ? A6_P_FD : A6_P_DST,
						    0);
		return (int)send(F570_PPPFD, F570_PAYLOAD, F570_PAYLOAD_LEN, 0);
	}
	F570_INJ_LEN = f570_frame_ppp(F570_INJ, F570_X0MAC, X1_MAC, F570_SID,
				      C->shape ? A6_P_FS : A6_P_SRC,
				      C->shape ? A6_P_FD : A6_P_DST, 0);
	return pkt_send_p("x1", F570_INJ, F570_INJ_LEN, 0x8864);
}

static void f570_arm_b(const struct f570_door *D, const struct f570_cfg *C,
		       int rfd, int tapfd)
{
	struct f570_cfg P;
	struct f568_log pre, post;
	unsigned long long c0p, c0s, c1p, c1s;
	unsigned char tap[1024];
	char hp[1200], hs[1200], ht[1800], hi[40];
	int taplen, tapn = 0, rcp = -1, rcs = -1, acks = 0, snd = -99, try;

	memset(&P, 0, sizeof(P));
	memset(&pre, 0, sizeof(pre));
	memset(&post, 0, sizeof(post));
	memset(tap, 0, sizeof(tap));
	for (try = 0; try < 4; try++) {
		int np, ns;

		acks = 0;
		f557_flush(NFPROTO_NETDEV, D->table, "pre0", &acks);
		acks = 0;
		f557_flush(NFPROTO_NETDEV, D->table, "ch", &acks);
		np = f568_rule_count(NFPROTO_NETDEV, D->table, "pre0");
		ns = f568_rule_count(NFPROTO_NETDEV, D->table, "ch");
		if (!np && !ns)
			break;
		printf("F570 RETRY|arm=%s|try=%d|np=%d|ns=%d\n", C->arm, try,
		       np, ns);
	}
	acks = 0;
	rcp = f570_rule_b(D, "pre0", "p", &P, &acks);
	acks = 0;
	rcs = f570_rule_b(D, "ch", "s", C, &acks);
	c0p = f555_count(NFPROTO_NETDEV, D->table, "pre0");
	c0s = f555_count(NFPROTO_NETDEV, D->table, "ch");
	nfl_drain(rfd);
	cap_drain(tapfd);
	snd = f570_send(C);
	usleep(250000);
	c1p = f555_count(NFPROTO_NETDEV, D->table, "pre0");
	c1s = f555_count(NFPROTO_NETDEV, D->table, "ch");
	f568_logs(rfd, &pre, &post);
	taplen = f570_tap(tapfd, tap, (int)sizeof(tap), &tapn);
	hp[0] = 0;
	hs[0] = 0;
	ht[0] = 0;
	if (pre.seen)
		f559_hexs(hp, sizeof(hp), pre.p, pre.plen);
	if (post.seen)
		f559_hexs(hs, sizeof(hs), post.p, post.plen);
	if (taplen > 0)
		f559_hexs(ht, sizeof(ht), tap, taplen);
	printf("F570 A|sec=ppp6e|door=%s|arm=%s|sk=%d|shape=%d|mp=%d|ml=%d|nh=%d|"
	       "wr=%d|rd=%d|base=%u|off=%d|len=%d|imm=%s|rcp=%d|rcs=%d|sendrc=%d|"
	       "cntp=%llu|cnts=%llu|pn=%d|plen=%d|p=%s|sn=%d|slen=%d|s=%s|"
	       "tn=%d|tlen=%d|tap=%s\n",
	       D->tag, C->arm, C->send_kind, C->shape, C->meta_proto, C->meta_l4,
	       C->nh_rd, C->wr, C->rd, C->base, C->off, C->len,
	       C->wr || C->rd ? f559_hexs(hi, sizeof(hi), C->imm,
					  C->len > 0 ? C->len : 1) : "-",
	       rcp, rcs, snd, c1p - c0p, c1s - c0s, pre.seen, pre.plen, hp,
	       post.seen, post.plen, hs, tapn, taplen, ht);
}

static void f570_sec_ppp6e(void)
{
	static const struct f570_cfg A[] = {
		{ "ctl_plain", 0, 0, 0, { 0 }, 0, 0, 0, 0, 0, { 0 }, 0, 0, 0, 0, 0,
		  { 0 }, 0, 0 },
		{ "ctl_ppp", 1, 0, 0, { 0 }, 0, 0, 0, 0, 0, { 0 }, 0, 0, 0, 0, 0,
		  { 0 }, 0, 0 },
		{ "proto_plain", 0, 0, 1, { 0x86, 0xdd }, 0, 0, 0, 0, 0, { 0 }, 0,
		  0, 0, 0, 0, { 0 }, 0, 0 },
		{ "proto_ppp", 1, 0, 1, { 0x86, 0xdd }, 0, 0, 0, 0, 0, { 0 }, 0, 0,
		  0, 0, 0, { 0 }, 0, 0 },
		{ "l4_plain", 0, 0, 0, { 0 }, 1, 17, 0, 0, 0, { 0 }, 0, 0, 0, 0,
		  0, { 0 }, 0, 0 },
		{ "l4_ppp", 1, 0, 0, { 0 }, 1, 17, 0, 0, 0, { 0 }, 0, 0, 0, 0, 0,
		  { 0 }, 0, 0 },
	};
	static const unsigned char NH_PLAIN[4] = { 0x60, 0x00, 0x00, 0x00 };
	static const unsigned char NH_PPP[4] = { 0x11, 0x00, 0x00, 0x63 };
	static const unsigned char NH_OFF36[4] = { 0x06, 0x07, 0x08, 0x09 };
	static const unsigned char NH_FAKE[4] = { 0x60, 0x00, 0x00, 0x08 };
	static const unsigned char IMM_HOP[1] = { 0x90 };
	static const unsigned char IMM_SP[2] = { 0x90, 0x91 };
	static const unsigned char IMM_SP_OR[2] = { 0x9c, 0x40 };
	struct f570_cfg C;
	int i, rfd, tapfd;

	if (f570_env_b()) {
		printf("F570 FAIL|env ppp6e\n");
		return;
	}
	for (i = 0; i < NDB; i++)
		if (add_table(NFPROTO_NETDEV, DB[i].table) ||
		    f556_add_chain(NFPROTO_NETDEV, DB[i].table, "pre0", DB[i].hook,
				   (uint32_t)DB[i].prio0, 1, DB[i].dev) ||
		    f556_add_chain(NFPROTO_NETDEV, DB[i].table, "ch", DB[i].hook,
				   (uint32_t)DB[i].prio1, 1, DB[i].dev)) {
			printf("F570 FAIL|chains %s\n", DB[i].tag);
			return;
		}
	rfd = nfl_open(5);
	tapfd = cap_open("x0");
	printf("F570 NFL|%d|tap=%d\n", rfd, tapfd);
	{
		unsigned char fr[256];
		char hx[1200];
		int n = f570_frame_ppp(fr, F570_X0MAC, X1_MAC, F570_SID, A6_P_SRC,
				       A6_P_DST, 0);

		printf("F570 FRAME|ppp|len=%d|hex=%s\n", n,
		       f559_hexs(hx, sizeof(hx), fr, n));
		n = f570_frame_ppp(fr, F570_X0MAC, X1_MAC, F570_SID, A6_P_FS,
				   A6_P_FD, 0);
		printf("F570 FRAME|fake|len=%d|hex=%s\n", n,
		       f559_hexs(hx, sizeof(hx), fr, n));
	}

	for (i = 0; i < (int)(sizeof(A) / sizeof(A[0])); i++)
		f570_arm_b(&DB[0], &A[i], rfd, tapfd);

	/* @nh read without any meta: the base is skb_network_offset alone */
	memset(&C, 0, sizeof(C));
	C.arm = "nh0_ppp";
	C.send_kind = 1;
	C.nh_rd = 1;
	C.nh_off = 0;
	C.nh_len = 4;
	memcpy(C.nhi, NH_PPP, 4);
	f570_arm_b(&DB[0], &C, rfd, tapfd);

	/* @nh read through `meta protocol`: the coordinate the write never sees */
	memset(&C, 0, sizeof(C));
	C.arm = "nh_m_ppp";
	C.send_kind = 1;
	C.meta_proto = 1;
	C.pv[0] = 0x86;
	C.pv[1] = 0xdd;
	C.nh_rd = 1;
	C.nh_off = 0;
	C.nh_len = 4;
	memcpy(C.nhi, NH_OFF36, 4);
	f570_arm_b(&DB[0], &C, rfd, tapfd);

	/* the writes: @nh and @th, on the plain datagram and on the PPPoE frame */
	memset(&C, 0, sizeof(C));
	C.arm = "nhw_plain";
	C.send_kind = 0;
	C.wr = 1;
	C.base = NFT_PAYLOAD_NETWORK_HEADER;
	C.off = 7;
	C.len = 1;
	memcpy(C.imm, IMM_HOP, 1);
	f570_arm_b(&DB[0], &C, rfd, tapfd);

	C.arm = "nhw_ppp";
	C.send_kind = 1;
	f570_arm_b(&DB[0], &C, rfd, tapfd);

	memset(&C, 0, sizeof(C));
	C.arm = "thw_plain";
	C.send_kind = 0;
	C.wr = 1;
	C.base = NFT_PAYLOAD_TRANSPORT_HEADER;
	C.off = 0;
	C.len = 2;
	memcpy(C.imm, IMM_SP, 2);
	f570_arm_b(&DB[0], &C, rfd, tapfd);

	C.arm = "thw_ppp";
	C.send_kind = 1;
	f570_arm_b(&DB[0], &C, rfd, tapfd);

	/* the read side of @th: the coordinate the walk builds from nhoff */
	memset(&C, 0, sizeof(C));
	C.arm = "thr_plain";
	C.send_kind = 0;
	C.rd = 1;
	C.base = NFT_PAYLOAD_TRANSPORT_HEADER;
	C.off = 0;
	C.len = 2;
	memcpy(C.imm, IMM_SP_OR, 2);
	f570_arm_b(&DB[0], &C, rfd, tapfd);

	/* the same write on the *normal* frame: refused because validation
	 * never gets past the version byte at 36 */
	memset(&C, 0, sizeof(C));
	C.arm = "thw_ppp_m";
	C.send_kind = 1;
	C.meta_proto = 1;
	C.pv[0] = 0x86;
	C.pv[1] = 0xdd;
	C.wr = 1;
	C.base = NFT_PAYLOAD_TRANSPORT_HEADER;
	C.off = 0;
	C.len = 2;
	memcpy(C.imm, IMM_SP, 2);
	f570_arm_b(&DB[0], &C, rfd, tapfd);

	/* the crafted frame: the version check at 36 passes, the walk still
	 * starts at 22, and the two bases disagree inside one expression */
	memset(&C, 0, sizeof(C));
	C.arm = "fak_l4";
	C.send_kind = 1;
	C.shape = 1;
	C.meta_proto = 1;
	C.pv[0] = 0x86;
	C.pv[1] = 0xdd;
	C.meta_l4 = 1;
	C.l4 = 17;
	f570_arm_b(&DB[0], &C, rfd, tapfd);

	C.arm = "fak_nh";
	C.meta_l4 = 0;
	C.nh_rd = 1;
	C.nh_off = 0;
	C.nh_len = 4;
	memcpy(C.nhi, NH_FAKE, 4);
	f570_arm_b(&DB[0], &C, rfd, tapfd);

	C.arm = "fak_thw";
	C.nh_rd = 0;
	C.wr = 1;
	C.base = NFT_PAYLOAD_TRANSPORT_HEADER;
	C.off = 0;
	C.len = 2;
	memcpy(C.imm, IMM_SP, 2);
	f570_arm_b(&DB[0], &C, rfd, tapfd);

	/* the same cells at the ingress door: same bytes, the other hook */
	memset(&C, 0, sizeof(C));
	C.arm = "in_ctl";
	C.send_kind = 2;
	f570_arm_b(&DB[1], &C, rfd, tapfd);

	C.arm = "in_nhw";
	C.wr = 1;
	C.base = NFT_PAYLOAD_NETWORK_HEADER;
	C.off = 7;
	C.len = 1;
	memcpy(C.imm, IMM_HOP, 1);
	f570_arm_b(&DB[1], &C, rfd, tapfd);

	memset(&C, 0, sizeof(C));
	C.arm = "in_rdnh";
	C.send_kind = 2;
	C.meta_proto = 1;
	C.pv[0] = 0x86;
	C.pv[1] = 0xdd;
	C.nh_rd = 1;
	C.nh_off = 0;
	C.nh_len = 4;
	memcpy(C.nhi, NH_PLAIN, 4);
	f570_arm_b(&DB[1], &C, rfd, tapfd);

	C.arm = "in_thw";
	C.meta_proto = 0;
	C.nh_rd = 0;
	C.wr = 1;
	C.base = NFT_PAYLOAD_TRANSPORT_HEADER;
	C.off = 0;
	C.len = 2;
	memcpy(C.imm, IMM_SP, 2);
	f570_arm_b(&DB[1], &C, rfd, tapfd);

	C.arm = "in_thw_m";
	C.meta_proto = 1;
	C.pv[0] = 0x86;
	C.pv[1] = 0xdd;
	C.wr = 1;
	f570_arm_b(&DB[1], &C, rfd, tapfd);

	C.arm = "in_rdth_m";
	C.wr = 0;
	C.rd = 1;
	memcpy(C.imm, IMM_SP_OR, 2);
	f570_arm_b(&DB[1], &C, rfd, tapfd);

	C.arm = "in_rdth";
	C.meta_proto = 0;
	C.wr = 0;
	C.rd = 1;
	memcpy(C.imm, IMM_SP_OR, 2);
	f570_arm_b(&DB[1], &C, rfd, tapfd);

	/* repeat of the first arm: determinism */
	{
		char hx[1200];

		printf("F570 PAYLOAD|len=%d|hex=%s\n", F570_PAYLOAD_LEN,
		       f559_hexs(hx, sizeof(hx), F570_PAYLOAD,
				 F570_PAYLOAD_LEN > 0 ? F570_PAYLOAD_LEN : 0));
		printf("F570 INJ|len=%d|hex=%s\n", F570_INJ_LEN,
		       f559_hexs(hx, sizeof(hx), F570_INJ,
				 F570_INJ_LEN > 0 ? F570_INJ_LEN : 0));
	}
	f570_arm_b(&DB[0], &A[1], rfd, tapfd);
	close(tapfd);
}

/* ---------- part 2: mode `th6` — @th at the v6 doors ---------- */

static int F570_SHAPE = 0;
static unsigned char F570_FWD[200];
static int F570_FWD_LEN = -1;
static unsigned char F570_O0MAC[6];
static const char *F570_SN[5] = { "bare", "hbh", "hbd", "ah", "rh" };

static void f570_emit6(int cls)
{
	if (cls == C_LOC) {
		struct sockaddr_in6 sa;

		memset(&sa, 0, sizeof(sa));
		sa.sin6_family = AF_INET6;
		memcpy(&sa.sin6_addr, A6_X1, 16);
		sa.sin6_port = htons(5000);
		sendto(LOC6_SOCK, F568_PAY, F569_PAY, 0,
		       (struct sockaddr *)&sa, sizeof(sa));
	} else {
		F570_FWD_LEN = f570_frame_plain(F570_FWD, F570_O0MAC,
						(const unsigned char *)"\x02\x00\x00\x00\x00\x71",
						A6_FS, A6_X1, F570_SHAPE);
		pkt_send_p("o1", F570_FWD, F570_FWD_LEN, 0x86dd);
	}
}

static int f570_rule6(const struct f568_door *D, const char *chain,
		      const char *prefix, uint32_t base, int off, int len,
		      const unsigned char *imm, int mode, int csum, int cso,
		      int l4cmp, int *acks)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;
	unsigned char v;

	if (l4cmp < 0)
		return f568_rule(D, chain, prefix, base, off, len, imm, mode, csum,
				 cso, acks);
	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			D->fam);
	put_str(nlh, NFTA_RULE_TABLE, D->table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	f570_put_meta(nlh, NFT_META_L4PROTO);
	v = (unsigned char)l4cmp;
	f562_cmp(nlh, F562_RD_DREG, &v, 1);
	if (mode == 1 || mode == 2)
		f565_store(nlh, base, (uint32_t)off, (uint32_t)len, imm, csum,
			   (unsigned int)cso);
	if (mode == 2 || mode == 3) {
		f562_read(nlh, base, (uint32_t)off, (uint32_t)len);
		f562_cmp(nlh, F562_RD_DREG, imm, len);
	}
	log_expr(nlh, 5, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, acks);
}

static void f570_arm6(const char *sec, const struct f568_pair *P,
		      const char *arm, uint32_t base, int off, int len,
		      const unsigned char *imm, int mode, int csum, int cso,
		      int l4cmp, int rfd)
{
	struct f568_door *D = &D568[P->door];
	const char *cn = CLSN[P->cls];
	unsigned long long c0p, c0s, c1p, c1s;
	struct f569_rep6 r, r0;
	struct f569_pl pl;
	int rcp = -1, rcs = -1, acks = 0, snd = 0, rc0 = -9, rc1 = -9, npolls = 0;
	unsigned long long p0in, p0hdr, p0out, p0disc, q0rx, q0tx, p0addr, p0idisc;
	char hx[600], hx2[600], hi[40];
	int i;

	memset(&r, 0, sizeof(r));
	memset(&r0, 0, sizeof(r0));
	p0addr = f564_snmp6("Ip6InAddrErrors");
	p0idisc = f564_snmp6("Ip6InDiscards");
	q0rx = f567_read_ll("/sys/class/net/o0/statistics/rx_packets");
	q0tx = f567_read_ll("/sys/class/net/x0/statistics/tx_packets");
	p0in = f564_snmp6("Ip6InReceives");
	p0hdr = f564_snmp6("Ip6InHdrErrors");
	p0out = f564_snmp6("Ip6OutRequests");
	p0disc = f564_snmp6("Ip6OutDiscards");
	if (P->cls == C_FWD) {
		F570_FWD_LEN = f570_frame_plain(F570_FWD, F570_O0MAC,
						(const unsigned char *)"\x02\x00\x00\x00\x00\x71",
						A6_FS, A6_X1, F570_SHAPE);
		printf("F570 FRAME6|shape=%s|len=%d|hex=%s\n", F570_SN[F570_SHAPE],
		       F570_FWD_LEN, f559_hexs(hx, sizeof(hx), F570_FWD,
					       F570_FWD_LEN));
	}
	f568_flush_all();
	f569_drain(rfd, &pl);
	acks = 0;
	rcp = f568_rule(D, "pre0", "p", 0, 0, 0, NULL, 0, 0, 0, &acks);
	acks = 0;
	rcs = f570_rule6(D, "ch", "s", base, off, len, imm, mode, csum, cso,
			 l4cmp, &acks);
	c0p = f555_count(D->fam, D->table, "pre0");
	c0s = f555_count(D->fam, D->table, "ch");
	rc0 = f569_snapshot6(&r0);
	f570_emit6(P->cls);
	snd = P->cls == C_LOC ? F569_PAY : F570_FWD_LEN;
	{
		int k, polls = 0;
		unsigned long long o0rx0 = f567_read_ll("/sys/class/net/o0/statistics/rx_packets");

		rc1 = -1;
		for (k = 0; k < 20; k++) {
			unsigned long long o0rx;

			usleep(250000);
			rc1 = f569_snapshot6(&r);
			polls++;
			if (rc1)
				break;
			o0rx = f567_read_ll("/sys/class/net/o0/statistics/rx_packets");
			if (r.u6tot > r0.u6tot || r.alltot > r0.alltot ||
			    r.i6in > r0.i6in || r.i6hdr > r0.i6hdr ||
			    r.i6addr > r0.i6addr || r.i6trunc > r0.i6trunc ||
			    r.i6unk > r0.i6unk || r.i6noroute > r0.i6noroute ||
			    o0rx > o0rx0)
				break;
		}
		npolls = polls;
	}
	f569_drain(rfd, &pl);
	c1p = f555_count(D->fam, D->table, "pre0");
	c1s = f555_count(D->fam, D->table, "ch");

	printf("F570 T|sec=%s|door=%s|cls=%s|shape=%s|arm=%s|l4cmp=%d|base=%u|mode=%d|"
	       "off=%d|len=%d|imm=%s|rcp=%d|rcs=%d|sendrc=%d|cntp=%llu|lives=%llu|"
	       "nmsg=%d|rc0=%d|rc1=%d|polls=%d|tapd=%d|u6d=%d|all_d=%d|"
	       "deliv_d=%llu|u6in_d=%llu|u6err_d=%llu|",
	       sec, D->tag, cn, F570_SN[F570_SHAPE], arm, l4cmp, base, mode, off, len,
	       f559_hexs(hi, sizeof(hi), imm, len > 0 ? len : 1), rcp, rcs, snd,
	       c1p - c0p, c1s - c0s, pl.n, rc0, rc1, npolls, r.taptot - r0.taptot,
	       r.u6tot - r0.u6tot, r.alltot - r0.alltot, r.i6deliv - r0.i6deliv,
	       r.u6in - r0.u6in, r.u6err - r0.u6err);
	for (i = 0; i < pl.n && i < F569_NMSG; i++)
		printf("m%d=%s|", i,
		       f559_hexs(hx2, sizeof(hx2), pl.p[i], pl.plen[i]));
	printf("paddr_d=%llu|pidisc_d=%llu|", f564_snmp6("Ip6InAddrErrors") - p0addr,
	       f564_snmp6("Ip6InDiscards") - p0idisc);
	printf("o0rx_d=%llu|x0tx_d=%llu|pin_d=%llu|phdr_d=%llu|pout_d=%llu|pdisc_d=%llu|",
	       f567_read_ll("/sys/class/net/o0/statistics/rx_packets") - q0rx,
	       f567_read_ll("/sys/class/net/x0/statistics/tx_packets") - q0tx,
	       f564_snmp6("Ip6InReceives") - p0in,
	       f564_snmp6("Ip6InHdrErrors") - p0hdr,
	       f564_snmp6("Ip6OutRequests") - p0out,
	       f564_snmp6("Ip6OutDiscards") - p0disc);
	printf("tapn=%d|taplen=%d|tap=%s|u6n=%d|u6len=%d|u6sport=%d|u6pay=%s|",
	       r.tapn, r.taplen, r.taphex, r.u6n, r.u6len0, r.u6sport0, r.u6pay);
	printf("i6in=%llu|i6hdr=%llu|i6addr=%llu|i6unk=%llu|i6trunc=%llu|"
	       "i6noroute=%llu|i6deliv=%llu|u6in=%llu|u6err=%llu|u6noport=%llu|"
	       "i6out=%llu|i6outnoroute=%llu|icmp6in=%llu\n",
	       r.i6in, r.i6hdr, r.i6addr, r.i6unk, r.i6trunc, r.i6noroute,
	       r.i6deliv, r.u6in, r.u6err, r.u6noport, r.i6out,
	       r.i6outnoroute, r.icmp6in);
}

static void f570_sec_th6(int rfd)
{
	static const struct f568_pair P[] = {
		{ 0, C_LOC }, { 1, C_LOC }, { 5, C_LOC },
		{ 3, C_FWD }, { 2, C_FWD }, { 5, C_FWD },
	};
	const int NP = (int)(sizeof(P) / sizeof(P[0]));
	unsigned char imm[2] = { 0x90, 0x91 };
	int i, j;

	for (i = 0; i < 3; i++) {
		F570_SHAPE = i;
		for (j = 0; j < NP; j++)
			f570_arm6("th6", &P[j], "thw", NFT_PAYLOAD_TRANSPORT_HEADER,
				  0, 2, imm, 1, 0, 0, -1, rfd);
	}
	/* AH and routing header: the walk's two named exceptions */
	for (i = 3; i < 5; i++) {
		F570_SHAPE = i;
		for (j = 3; j < 5; j++)
			f570_arm6("th6", &P[j], "thw", NFT_PAYLOAD_TRANSPORT_HEADER,
				  0, 2, imm, 1, 0, 0, -1, rfd);
	}
	/* the read side on the bare shape */
	F570_SHAPE = 0;
	for (j = 0; j < NP; j++) {
		unsigned char im2[2] = { 0x9c, 0x40 };

		f570_arm6("th6", &P[j], "thr", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2,
			  im2, 3, 0, 0, -1, rfd);
	}
	/* `meta l4proto` where the walk has an exception */
	for (i = 1; i < 5; i++) {
		F570_SHAPE = i;
		f570_arm6("th6", &P[3], "l4_17", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2,
			  imm, 1, 0, 0, 17, rfd);
		f570_arm6("th6", &P[3], "l4_51", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2,
			  imm, 1, 0, 0, 51, rfd);
	}
	/* the toll: the forwarded class with a recomputed transport checksum */
	F570_SHAPE = 0;
	{
		unsigned char im3[2] = { 0x90, 0x91 };

		f570_arm6("th6", &P[3], "cs", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2,
			  im3, 1, 1, 6, -1, rfd);
		f570_arm6("th6", &P[4], "cs", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2,
			  im3, 1, 1, 6, -1, rfd);
		f570_arm6("th6", &P[5], "cs", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2,
			  im3, 1, 1, 6, -1, rfd);
		/* the walk and the toll together: the receiver reports the source
		 * port the rule wrote, which names the base the walk produced */
		for (i = 1; i < 5; i++) {
			F570_SHAPE = i;
			f570_arm6("th6", &P[3], "cs", NFT_PAYLOAD_TRANSPORT_HEADER,
				  0, 2, im3, 1, 1, 6, -1, rfd);
		}
	}
}

/* ---------- main ---------- */

int f570_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "ppp6e";
	char line[1024];

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F570 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F570 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F570 KERNEL|7.3.4-T563\n");

	if (!strcmp(mode, "ppp6e")) {
		f570_sec_ppp6e();
		printf("F570 DONE\n");
		return 0;
	}
	if (strcmp(mode, "th6")) {
		printf("F570 FAIL|mode|%s\n", mode);
		return 0;
	}

	/* mode th6: the F47 environment, verbatim */
	f569_setup_v6();
	printf("F570 FORK|rc=%d\n", f569_start_child());
	if (f568_read_line(line, (int)sizeof(line), 20000) < 0 || line[0] != 'U')
		printf("F570 FAIL|child unshare|%s\n", line);
	printf("F570 MOVE|rc=%d\n", f568_move_link("x1", (int)CHILD));
	f568_ask("C");
	for (;;) {
		int n;

		if (f568_read_line(line, (int)sizeof(line), 20000) < 0) {
			printf("F570 FAIL|child cfg\n");
			break;
		}
		printf("F570 CHILDR|%s\n", line);
		n = (int)strlen(line);
		if (!strncmp(line, "READY", 5) || (n && line[0] == 'E'))
			break;
	}
	{
		int rfdt;
		char hx[600];

		if (mac_get("o0", F570_O0MAC))
			printf("F570 FAIL|mac o0\n");
		F570_FWD_LEN = f570_frame_plain(F570_FWD, F570_O0MAC,
						(const unsigned char *)"\x02\x00\x00\x00\x00\x71",
						A6_FS, A6_X1, 0);
		printf("F570 FRAME6|shape=bare|len=%d|hex=%s\n", F570_FWD_LEN,
		       f559_hexs(hx, sizeof(hx), F570_FWD, F570_FWD_LEN));
		LOC6_SOCK = f564_udp_bind(AF_INET6, 0, A6_X0, 40000);
		printf("F570 SOCK|loc6=%d\n", LOC6_SOCK);
		printf("F570 NEIGH6|rc=%d\n", f569_neigh6_add("x0", A6_X1, X1_MAC));
		rfdt = nfl_open(5);
		printf("F570 NFL|%d\n", rfdt);
		if (f568_chains()) {
			printf("F570 FAIL|chains\n");
			return 0;
		}
		{
			struct f569_rep6 r;
			int k, got = 0;

			memset(&r, 0, sizeof(r));
			f568_flush_all();
			for (k = 0; k < 6; k++) {
				struct sockaddr_in6 sa;

				memset(&sa, 0, sizeof(sa));
				sa.sin6_family = AF_INET6;
				memcpy(&sa.sin6_addr, A6_X1, 16);
				sa.sin6_port = htons(5000);
				sendto(LOC6_SOCK, F568_PAY, F569_PAY, 0,
				       (struct sockaddr *)&sa, sizeof(sa));
				usleep(150000);
				if (f569_snapshot6(&r) == 0 && r.u6n > 0) {
					got = 1;
					break;
				}
			}
			printf("F570 WARM|got=%d|tapn=%d|u6n=%d|i6deliv=%llu\n", got,
			       r.tapn, r.u6n, r.i6deliv);
		}
		f570_sec_th6(rfdt);
	}
	f568_ask("Q");
	printf("F570 DONE\n");
	return 0;
}
/* differ571_add.c -- turn 571 (F49).
 *
 *  THE DEBT (named at the end of 570): "the same PPPoE frame at a layer-3
 *  door, pf = NFPROTO_IPV6, nhoff = 22, the guard nft_nh_write_ok_ip6()
 *  instead of the netdev branch".
 *
 *  Mode `pp6l3`: one frame, made by f570_frame_ppp() (the F48 builder) and
 *  injected on x0:  ethernet (14) | PPPoE session hdr (6, sid 99) | PPP proto
 *  00 57 (2) | IPv6 + UDP 40000->5000 + 18x77.  The PPPoX session socket is
 *  bound on x1 with remote = x0's MAC, the unit is attached exactly as pppd
 *  does it, and ppp0 carries an IPv6 address -- so the 8 bytes the netdev door
 *  still sees are removed by the kernel, not by the instrument, and the same
 *  frame is presented to *four* doors:
 *
 *    in3   inet  family, prerouting (layer 3, on ppp0)  <- the door in question
 *    ip63  ipv6  family, prerouting (layer 3, on ppp0)  <- control for the family
 *    nd1   netdev family, ingress on x1                 <- the door of F44/F48
 *    ip43  ipv4  family, prerouting                     <- a door this frame is not for
 *
 *  Mode `tap6f` closes the other named debt: the three extension shapes that
 *  came out of F48 with tapn = 0.  Same veth, the old filter (byte 20 must be
 *  17) and a shape-aware filter on the same frames, counted on the same tap.
 *
 *  Every helper below the new code is the one that produced F31..F48.
 */

#define F571_SID	99
#define F571_SPORT	40000
#define F571_DPORT	5000

/* the IPv6 datagram the frame carries: fd02::11 -> fd02::91 */
static const unsigned char A6_L_SRC[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00, 0x00,
					    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					    0x00, 0x00, 0x00, 0x11 };
static const unsigned char A6_L_DST[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00, 0x00,
					    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					    0x00, 0x00, 0x00, 0x91 };
static const unsigned char A6_L_ALT[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00, 0x00,
					    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					    0x00, 0x00, 0x00, 0x92 };

/* ---------- the four doors ---------- */

struct f571_door {
	const char *tag;
	uint8_t fam;
	const char *table;
	const char *dev;
	uint32_t hook;
	int prio0, prio1;
};

static struct f571_door D571[] = {
	{ "in3",  NFPROTO_INET,   "e71a", NULL, 0, 10, 20 },
	{ "ip63", NFPROTO_IPV6,   "e71b", NULL, 0, 30, 40 },
	{ "nd1",  NFPROTO_NETDEV, "e71c", "x1", 0, 50, 60 },
	{ "ip43", NFPROTO_IPV4,   "e71d", NULL, 0, 70, 80 },
};
#define ND71	4
enum { D_IN3 = 0, D_IP63, D_ND1, D_IP43 };

static unsigned char F571_X0M[6], F571_X1M[6];
static char F571_PPP[16];
static int F571_SOCK = -1, F571_FDU = -1, F571_FDC = -1;
static int F571_U6 = -1, F571_TAP = -1, F571_NFL = -1;
static unsigned char F571_FR[256];
static int F571_FRLEN = -1;

/* ---------- environment ---------- */

static int f571_ppp_unit(void)
{
	int u = -1, idx = -1, up;
	char path[96];

	F571_SOCK = f563_pppoe_sock("x1", htons(F571_SID), F571_X0M);
	if (F571_SOCK < 0) {
		printf("F571 PPP|fail|sock|%d\n", F571_SOCK);
		return -1;
	}
	if (ioctl(F571_SOCK, PPPIOCGCHAN, &idx) < 0) {
		printf("F571 PPP|fail|gchan|%d\n", errno);
		return -1;
	}
	F571_FDU = open("/dev/ppp", O_RDWR);
	if (F571_FDU < 0) {
		printf("F571 PPP|fail|unit|%d\n", errno);
		return -1;
	}
	if (ioctl(F571_FDU, PPPIOCNEWUNIT, &u) < 0) {
		printf("F571 PPP|fail|newunit|%d\n", errno);
		return -1;
	}
	F571_FDC = open("/dev/ppp", O_RDWR);
	if (F571_FDC < 0) {
		printf("F571 PPP|fail|chan|%d\n", errno);
		return -1;
	}
	if (ioctl(F571_FDC, PPPIOCATTCHAN, &idx) < 0) {
		printf("F571 PPP|fail|attchan|%d\n", errno);
		return -1;
	}
	if (ioctl(F571_FDC, PPPIOCCONNECT, &u) < 0) {
		printf("F571 PPP|fail|connect|%d\n", errno);
		return -1;
	}
	snprintf(F571_PPP, sizeof(F571_PPP), "ppp%d", u);
	up = set_up(F571_PPP);
	/* ppp_receive_nonmp_frame() frees the frame when the device is down */
	printf("F571 PPP|unit=%d|chan=%d|dev=%s|ifindex=%d|up=%d\n", u, idx,
	       F571_PPP, f555_ifindex(F571_PPP), up);
	return 0;
}

static int f571_env(void)
{
	char path[96];

	f555_sysctl("/proc/sys/net/ipv6/conf/default/disable_ipv6", "1");
	if (link_add_veth("x0", "x1")) {
		printf("F571 FAIL|veth\n");
		return -1;
	}
	set_up("x0");
	set_up("x1");
	if (mac_get("x0", F571_X0M) || mac_get("x1", F571_X1M)) {
		printf("F571 FAIL|mac\n");
		return -1;
	}
	if (f571_ppp_unit())
		return -2;

	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/%s/disable_ipv6",
		 F571_PPP);
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/%s/accept_dad",
		 F571_PPP);
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/%s/dad_transmits",
		 F571_PPP);
	f555_sysctl(path, "0");
	printf("F571 ADDR6|rc=%d\n", f564_addr6(F571_PPP, A6_L_DST, 128));
	F571_U6 = f564_udp_bind(AF_INET6, 0, A6_L_DST, F571_DPORT);

	F571_FRLEN = f570_frame_ppp(F571_FR, F571_X1M, F571_X0M, F571_SID,
				    A6_L_SRC, A6_L_DST, 0);
	{
		char hx[64], hy[64];

		printf("F571 ENV|u6=%d|flen=%d|ppp=%d|x0=%s|x1=%s\n", F571_U6,
		       F571_FRLEN, f555_ifindex(F571_PPP),
		       f559_hexs(hx, sizeof(hx), F571_X0M, 6),
		       f559_hexs(hy, sizeof(hy), F571_X1M, 6));
	}
	return 0;
}

static int f571_chains(void)
{
	int i, rc = 0;

	for (i = 0; i < ND71; i++) {
		struct f571_door *D = &D571[i];

		rc |= add_table(D->fam, D->table);
		rc |= f556_add_chain(D->fam, D->table, "pre0", D->hook,
				     (uint32_t)D->prio0, 1, D->dev);
		rc |= f556_add_chain(D->fam, D->table, "ch", D->hook,
				     (uint32_t)D->prio1, 1, D->dev);
	}
	return rc;
}

static void f571_flush_all(void)
{
	int i, acks = 0;

	for (i = 0; i < ND71; i++) {
		f557_flush(D571[i].fam, D571[i].table, "pre0", &acks);
		f557_flush(D571[i].fam, D571[i].table, "ch", &acks);
	}
}

/* ---------- the snapshot ---------- */

struct f571_rep {
	int u6n, u6len, u6sport;
	char u6pay[64];
	unsigned long long i6in, i6hdr, i6addr, i6unk, i6trunc, i6noroute,
			   i6deliv, u6in, u6err, u6noport, i6out, i6disc,
			   i6mcast, icmp6in;
	unsigned long long prx, pby;
	int tapn;
};

static void f571_u6_drain(struct f571_rep *R)
{
	unsigned char b[1024];
	struct sockaddr_in6 sa;
	socklen_t sl;
	int r, k;

	if (F571_U6 < 0)
		return;
	for (;;) {
		memset(&sa, 0, sizeof(sa));
		sl = sizeof(sa);
		r = (int)recvfrom(F571_U6, b, sizeof(b), MSG_DONTWAIT,
				  (struct sockaddr *)&sa, &sl);
		if (r < 0)
			break;
		if (!f568_needle(b, r))
			continue;
		R->u6n++;
		R->u6len = r;
		R->u6sport = ntohs(sa.sin6_port);
		k = r < (int)sizeof(R->u6pay) - 1 ? r
						 : (int)sizeof(R->u6pay) - 1;
		memcpy(R->u6pay, b, (size_t)k);
		R->u6pay[k] = 0;
	}
}

static void f571_snap(struct f571_rep *R)
{
	char p[96];

	f571_u6_drain(R);
	R->i6in = f564_snmp6("Ip6InReceives");
	R->i6hdr = f564_snmp6("Ip6InHdrErrors");
	R->i6addr = f564_snmp6("Ip6InAddrErrors");
	R->i6unk = f564_snmp6("Ip6InUnknownProtos");
	R->i6trunc = f564_snmp6("Ip6InTruncatedPkts");
	R->i6noroute = f564_snmp6("Ip6InNoRoutes");
	R->i6deliv = f564_snmp6("Ip6InDelivers");
	R->i6disc = f564_snmp6("Ip6InDiscards");
	R->i6mcast = f564_snmp6("Ip6InMcastPkts");
	R->u6in = f564_snmp6("Udp6InDatagrams");
	R->u6err = f564_snmp6("Udp6InErrors");
	R->u6noport = f564_snmp6("Udp6NoPorts");
	R->i6out = f564_snmp6("Ip6OutRequests");
	R->icmp6in = f564_snmp6("Icmp6InMsgs");
	f564_devrx(F571_PPP, &R->pby, &R->prx);	/* bytes, packets */
}

/* ---------- NFLOG: payload, L2 header, device ---------- */

#define F571_NPL	6
#define F571_PLLEN	96
struct f571_msg {
	int plen;
	unsigned char p[F571_PLLEN];
	int l2len;
	unsigned char l2[32];
	int hwlen2;
	unsigned char hw[32];
	int hwlen, hwtype, hwhdr, indev, outdev;
	char prefix[8];
};
struct f571_pl {
	int n;
	struct f571_msg m[F571_NPL];
};

#define NFULA_IFINDEX_INDEV_	4
#define NFULA_IFINDEX_OUTDEV_	5
#define NFULA_HWTYPE_		15	/* value: ARPHRD_*      */
#define NFULA_HWHEADER_		16	/* bytes of the L2 hdr  */
#define NFULA_HWLEN_		17	/* declared hard_header_len */
#define NFULA_L2HDR_571 	21

static void f571_nfl_drain(struct f571_pl *v)
{
	unsigned char b[16384];
	int guard = 0, rl;

	if (v)
		memset(v, 0, sizeof(*v));
	if (F571_NFL < 0)
		return;
	while (guard++ < 64) {
		struct nlmsghdr *h;
		int len;

		rl = (int)recv(F571_NFL, b, sizeof(b), MSG_DONTWAIT);
		if (rl <= 0)
			break;
		len = rl;
		for (h = (struct nlmsghdr *)b; NLMSG_OK(h, len);
		     h = NLMSG_NEXT(h, len)) {
			const char *p, *end, *prefix = NULL;
			const unsigned char *pl = NULL, *l2 = NULL;
			int pll = 0, l2l = 0, hwl = -1, hwt = -1, hwh = -1;
			int ind = -1, outd = -1, hwhl = 0;
			unsigned char hwb[32];

			if (h->nlmsg_type == NLMSG_DONE ||
			    h->nlmsg_type == NLMSG_ERROR)
				continue;
			p = (const char *)h + NLMSG_HDRLEN +
			    sizeof(struct nfgenmsg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int al = (int)a->nla_len;
				int t;

				if (al < (int)sizeof(*a) || p + al > end)
					break;
				t = a->nla_type & 0x3fff;
				if (t == NFULA_PREFIX_) {
					prefix = (const char *)a + NLA_HDRLEN;
				} else if (t == NFULA_PAYLOAD_) {
					pl = (const unsigned char *)a +
					     NLA_HDRLEN;
					pll = al - NLA_HDRLEN;
				} else if (t == NFULA_L2HDR_571) {
					l2 = (const unsigned char *)a +
					     NLA_HDRLEN;
					l2l = al - NLA_HDRLEN;
				} else if (t == NFULA_HWLEN_) {
					__be16 v;

					memcpy(&v, (const char *)a + NLA_HDRLEN,
					       2);
					hwl = ntohs(v);
				} else if (t == NFULA_HWHEADER_) {
					const unsigned char *hp =
						(const unsigned char *)a +
						NLA_HDRLEN;
					int kk = al - NLA_HDRLEN;

					hwh = kk;
					if (kk > (int)sizeof(hwb))
						kk = (int)sizeof(hwb);
					memcpy(hwb, hp, (size_t)kk);
					hwhl = kk;
				} else if (t == NFULA_HWTYPE_) {
					__be16 v;

					memcpy(&v, (const char *)a + NLA_HDRLEN,
					       2);
					hwt = ntohs(v);
				} else if (t == NFULA_IFINDEX_INDEV_) {
					__be32 v;

					memcpy(&v, (const char *)a + NLA_HDRLEN,
					       4);
					ind = (int)ntohl(v);
				} else if (t == NFULA_IFINDEX_OUTDEV_) {
					__be32 v;

					memcpy(&v, (const char *)a + NLA_HDRLEN,
					       4);
					outd = (int)ntohl(v);
				}
				p += NLA_ALIGN_(al);
			}
			if (!v || !prefix || prefix[0] == 0)
				continue;
			if (v->n < F571_NPL) {
				struct f571_msg *M = &v->m[v->n];
				int k;

				snprintf(M->prefix, sizeof(M->prefix), "%s",
					 prefix);
				if (pl) {
					k = pll < F571_PLLEN ? pll : F571_PLLEN;
					memcpy(M->p, pl, (size_t)k);
					M->plen = k;
				}
				if (l2) {
					k = l2l < (int)sizeof(M->l2) ? l2l
							    : (int)sizeof(M->l2);
					memcpy(M->l2, l2, (size_t)k);
					M->l2len = k;
				}
				M->hwlen = hwl;
				M->hwhdr = hwh;
				M->hwlen2 = hwhl;
				memcpy(M->hw, hwb, (size_t)hwhl);
				M->hwtype = hwt;
				M->indev = ind;
				M->outdev = outd;
			}
			v->n++;
		}
	}
}

/* ---------- the rule ---------- */

struct f571_cfg {
	const char *arm;
	int mode;			/* 0 none, 1 store, 2 store+read, 3 read */
	int meta;			/* -1 or NFT_META_* */
	unsigned char mv[2];
	int mlen;
	uint32_t base;
	int off, len;
	unsigned char imm[16];
	int csum, cso;
};

static void f571_zero(struct f571_cfg *C, const char *arm)
{
	memset(C, 0, sizeof(*C));
	C->arm = arm;
	C->meta = -1;
}

static int f571_rule(const struct f571_door *D, const char *chain,
		     const char *prefix, const struct f571_cfg *C, int *acks)
{
	struct nlmsghdr *nlh;
	struct nlattr *exprs;

	nlh = msg_start(opbuf, (int)sizeof(opbuf),
			(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
			NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND,
			D->fam);
	put_str(nlh, NFTA_RULE_TABLE, D->table);
	put_str(nlh, NFTA_RULE_CHAIN, chain);
	exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
	if (C->meta >= 0) {
		f570_put_meta(nlh, C->meta);
		f562_cmp(nlh, F562_RD_DREG, C->mv, C->mlen);
	}
	if (C->mode == 1 || C->mode == 2)
		f565_store(nlh, C->base, (uint32_t)C->off, (uint32_t)C->len,
			   C->imm, C->csum, (unsigned int)C->cso);
	if (C->mode == 2 || C->mode == 3) {
		f562_read(nlh, C->base, (uint32_t)C->off, (uint32_t)C->len);
		f562_cmp(nlh, F562_RD_DREG, C->imm, C->len);
	}
	log_expr(nlh, 5, prefix);
	counter_expr(nlh);
	accept_expr(nlh);
	nest_end(nlh, exprs);
	return f557_nft_one(opbuf, (int)nlh->nlmsg_len, acks);
}

/* ---------- one arm ---------- */

static int f571_send(void)
{
	return pkt_send_p("x0", F571_FR, F571_FRLEN, 0x8864);
}

static void f571_arm(int door, const char *sec, const struct f571_cfg *C,
		     int send, int maxp)
{
	struct f571_door *D = &D571[door];
	struct f571_cfg N;
	struct f571_rep r0, r;
	struct f571_pl pl;
	unsigned long long c0p, c0s, c1p, c1s;
	int rcp = -1, rcs = -1, acks = 0, snd = 0, polls = 0, k;
	const struct f571_msg *mp = NULL, *ms = NULL;
	char hx[300], hy[300], hz[300], hw[80], hm[40], hq[80], hr2[80];

	memset(&r0, 0, sizeof(r0));
	memset(&r, 0, sizeof(r));
	f571_zero(&N, "pre");
	f571_flush_all();
	f571_nfl_drain(NULL);
	f571_snap(&r0);
	rcp = f571_rule(D, "pre0", "p", &N, &acks);
	rcs = f571_rule(D, "ch", "s", C, &acks);
	c0p = f555_count(D->fam, D->table, "pre0");
	c0s = f555_count(D->fam, D->table, "ch");
	/* the socket was drained by f571_snap(&r0) -- clear what arrived
	 * between the drain and the rule install */
	f571_u6_drain(&r0);
	if (send)
		snd = f571_send();
	if (send) {
		for (k = 0; k < maxp; k++) {
			usleep(120000);
			f571_snap(&r);
			polls++;
			if (r.u6n > r0.u6n || r.i6in > r0.i6in ||
			    r.i6hdr > r0.i6hdr || r.i6addr > r0.i6addr ||
			    r.i6trunc > r0.i6trunc || r.i6unk > r0.i6unk ||
			    r.i6noroute > r0.i6noroute || r.u6err > r0.u6err ||
			    r.prx > r0.prx || r.i6deliv > r0.i6deliv)
				break;
		}
	} else {
		usleep(400000);
		f571_snap(&r);
		polls = 1;
	}
	f571_snap(&r);
	c1p = f555_count(D->fam, D->table, "pre0");
	c1s = f555_count(D->fam, D->table, "ch");
	memset(&pl, 0, sizeof(pl));
	f571_nfl_drain(&pl);
	for (k = 0; k < pl.n; k++) {
		if (pl.m[k].prefix[0] == 'p' && !mp)
			mp = &pl.m[k];
		if (pl.m[k].prefix[0] == 's' && !ms)
			ms = &pl.m[k];
	}
	printf("F571 A|sec=%s|door=%s|arm=%s|mode=%d|meta=%d|base=%u|off=%d|"
	       "len=%d|imm=%s|mv=%s|mlen=%d|csum=%d|cso=%d|rcp=%d|rcs=%d|"
	       "sendrc=%d|snt=%d|"
	       "cntp=%llu|lives=%llu|"
	       "polls=%d|u6d=%d|u6len=%d|u6sport=%d|u6pay=%s|",
	       sec, D->tag, C->arm, C->mode, C->meta, C->base, C->off, C->len,
	       f559_hexs(hx, sizeof(hx), C->imm, C->len),
	       C->meta >= 0 ? f559_hexs(hm, sizeof(hm), C->mv, C->mlen) : "-",
	       C->meta >= 0 ? C->mlen : 0, C->csum, C->cso, rcp, rcs, snd, send,
	       c1p - c0p, c1s - c0s, polls, r.u6n - r0.u6n, r.u6len,
	       r.u6sport, r.u6pay[0] ? r.u6pay : "-");
	printf("i6in_d=%llu|i6hdr_d=%llu|i6addr_d=%llu|i6unk_d=%llu|"
	       "i6trunc_d=%llu|i6noroute_d=%llu|deliv_d=%llu|u6in_d=%llu|"
	       "u6err_d=%llu|u6noport_d=%llu|i6out_d=%llu|i6disc_d=%llu|"
	       "icmp6_d=%llu|prx_d=%llu|pby_d=%llu|",
	       r.i6in - r0.i6in, r.i6hdr - r0.i6hdr, r.i6addr - r0.i6addr,
	       r.i6unk - r0.i6unk, r.i6trunc - r0.i6trunc,
	       r.i6noroute - r0.i6noroute, r.i6deliv - r0.i6deliv,
	       r.u6in - r0.u6in, r.u6err - r0.u6err,
	       r.u6noport - r0.u6noport, r.i6out - r0.i6out,
	       r.i6disc - r0.i6disc, r.icmp6in - r0.icmp6in,
	       r.prx - r0.prx, r.pby - r0.pby);
	printf("prelen=%d|pre=%s|prel2=%d|preind=%d|prehw=%d|preht=%d|prehh=%d|"
	       "prehwhex=%s|",
	       mp ? mp->plen : -1,
	       mp ? f559_hexs(hy, sizeof(hy), mp->p, mp->plen) : "-",
	       mp ? mp->l2len : -1, mp ? mp->indev : -1, mp ? mp->hwlen : -1,
	       mp ? mp->hwtype : -1, mp ? mp->hwhdr : -1,
	       mp && mp->hwlen2 > 0 ? f559_hexs(hq, sizeof(hq), mp->hw,
						mp->hwlen2) : "-");
	printf("postlen=%d|post=%s|postl2=%d|postind=%d|posthw=%d|postht=%d|"
	       "posthh=%d|postl2hex=%s|posthwhex=%s\n",
	       ms ? ms->plen : -1,
	       ms ? f559_hexs(hz, sizeof(hz), ms->p, ms->plen) : "-",
	       ms ? ms->l2len : -1, ms ? ms->indev : -1, ms ? ms->hwlen : -1,
	       ms ? ms->hwtype : -1, ms ? ms->hwhdr : -1,
	       ms && ms->l2len > 0
		       ? f559_hexs(hw, sizeof(hw), ms->l2, ms->l2len) : "-",
	       ms && ms->hwlen2 > 0
		       ? f559_hexs(hr2, sizeof(hr2), ms->hw, ms->hwlen2) : "-");
}

/* ---------- read cells: the immediate is what the frame carries ---------- */

static void f571_rd(struct f571_cfg *C, const char *arm, uint32_t base, int off,
		    int len, const unsigned char *src)
{
	f571_zero(C, arm);
	C->mode = 3;
	C->base = base;
	C->off = off;
	C->len = len;
	memcpy(C->imm, src + off, (size_t)len);
}

static void f571_wr(struct f571_cfg *C, const char *arm, uint32_t base, int off,
		    int len, const unsigned char *imm, int csum, int cso)
{
	f571_zero(C, arm);
	C->mode = 1;
	C->base = base;
	C->off = off;
	C->len = len;
	memcpy(C->imm, imm, (size_t)len);
	C->csum = csum;
	C->cso = cso;
}

/* ---------- section `ctl` ---------- */

static void f571_sec_ctl(void)
{
	struct f571_cfg C;

	f571_zero(&C, "ctl_in3");
	f571_arm(D_IN3, "ctl", &C, 1, 14);
	f571_zero(&C, "ctl_ip63");
	f571_arm(D_IP63, "ctl", &C, 1, 14);
	f571_zero(&C, "ctl_nd1");
	f571_arm(D_ND1, "ctl", &C, 1, 14);
	f571_zero(&C, "ctl_ip43");
	f571_arm(D_IP43, "ctl", &C, 1, 6);
	f571_zero(&C, "quiet_in3");
	f571_arm(D_IN3, "ctl", &C, 0, 1);
	f571_zero(&C, "quiet_ip63");
	f571_arm(D_IP63, "ctl", &C, 0, 1);
}

/* ---------- section `rd`: where each base lands ---------- */

static void f571_sec_rd(void)
{
	struct f571_cfg C;
	const unsigned char *ip = F571_FR + 22;	/* IPv6 header = data on ppp0 */
	const unsigned char *fr = F571_FR;	/* frame start = data on x1   */
	const unsigned char *nd = F571_FR + 14;	/* PPPoE header = data on x1  */

	/* layer 3, door in3 */
	f571_rd(&C, "nh0", NFT_PAYLOAD_NETWORK_HEADER, 0, 4, ip);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	f571_rd(&C, "nh4", NFT_PAYLOAD_NETWORK_HEADER, 4, 2, ip);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	f571_rd(&C, "nh6", NFT_PAYLOAD_NETWORK_HEADER, 6, 1, ip);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	f571_rd(&C, "nh7", NFT_PAYLOAD_NETWORK_HEADER, 7, 1, ip);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	/* ... and the twin: the byte the netdev door sees at the same cell */
	f571_rd(&C, "nh7_ppp", NFT_PAYLOAD_NETWORK_HEADER, 7, 1, nd);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	f571_rd(&C, "nh8", NFT_PAYLOAD_NETWORK_HEADER, 8, 16, ip);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	f571_rd(&C, "nh24", NFT_PAYLOAD_NETWORK_HEADER, 24, 16, ip);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	/* @ll on ppp0: mac_header == data */
	f571_rd(&C, "ll0", NFT_PAYLOAD_LL_HEADER, 0, 1, ip);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	f571_rd(&C, "ll4", NFT_PAYLOAD_LL_HEADER, 4, 2, ip);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	f571_rd(&C, "ll8", NFT_PAYLOAD_LL_HEADER, 8, 16, ip);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	/* @th on ppp0: data + thoff */
	f571_rd(&C, "th0", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, F571_FR + 62);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	f571_rd(&C, "th2", NFT_PAYLOAD_TRANSPORT_HEADER, 2, 2, F571_FR + 62);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	f571_rd(&C, "th6", NFT_PAYLOAD_TRANSPORT_HEADER, 6, 2, F571_FR + 62);
	f571_arm(D_IN3, "rd", &C, 1, 10);
	/* meta */
	f571_zero(&C, "meta_proto");
	C.meta = NFT_META_PROTOCOL;
	C.mv[0] = 0x86;
	C.mv[1] = 0xdd;
	C.mlen = 2;
	f571_arm(D_IN3, "rd", &C, 1, 10);
	f571_zero(&C, "meta_l4");
	C.meta = NFT_META_L4PROTO;
	C.mv[0] = 17;
	C.mlen = 1;
	f571_arm(D_IN3, "rd", &C, 1, 10);
	f571_zero(&C, "meta_pf");
	C.meta = NFT_META_NFPROTO;
	C.mv[0] = 10;			/* NFPROTO_IPV6 */
	C.mlen = 1;
	f571_arm(D_IN3, "rd", &C, 1, 10);

	/* layer 3, door ip63 -- the same cells in the other family */
	f571_rd(&C, "nh7", NFT_PAYLOAD_NETWORK_HEADER, 7, 1, ip);
	f571_arm(D_IP63, "rd", &C, 1, 10);
	f571_rd(&C, "ll0", NFT_PAYLOAD_LL_HEADER, 0, 1, ip);
	f571_arm(D_IP63, "rd", &C, 1, 10);
	f571_rd(&C, "th0", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, F571_FR + 62);
	f571_arm(D_IP63, "rd", &C, 1, 10);
	f571_zero(&C, "meta_pf");
	C.meta = NFT_META_NFPROTO;
	C.mv[0] = 10;
	C.mlen = 1;
	f571_arm(D_IP63, "rd", &C, 1, 10);

	/* the netdev ingress door on x1: data = the PPPoE header */
	f571_rd(&C, "nh0", NFT_PAYLOAD_NETWORK_HEADER, 0, 4, nd);
	f571_arm(D_ND1, "rd", &C, 1, 10);
	f571_rd(&C, "nh4_len", NFT_PAYLOAD_NETWORK_HEADER, 4, 2, nd);
	f571_arm(D_ND1, "rd", &C, 1, 10);
	f571_rd(&C, "nh7_ppp", NFT_PAYLOAD_NETWORK_HEADER, 7, 1, nd);
	f571_arm(D_ND1, "rd", &C, 1, 10);
	f571_rd(&C, "nh7_hop", NFT_PAYLOAD_NETWORK_HEADER, 7, 1, ip);
	f571_arm(D_ND1, "rd", &C, 1, 10);
	f571_rd(&C, "ll0", NFT_PAYLOAD_LL_HEADER, 0, 6, fr);
	f571_arm(D_ND1, "rd", &C, 1, 10);
	f571_rd(&C, "ll13", NFT_PAYLOAD_LL_HEADER, 13, 1, fr);
	f571_arm(D_ND1, "rd", &C, 1, 10);
	f571_rd(&C, "th0_nm", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2,
		F571_FR + 62);
	f571_arm(D_ND1, "rd", &C, 1, 10);
	f571_zero(&C, "meta_proto");
	C.meta = NFT_META_PROTOCOL;
	C.mv[0] = 0x88;
	C.mv[1] = 0x64;
	C.mlen = 2;
	f571_arm(D_ND1, "rd", &C, 1, 10);
	f571_zero(&C, "meta_pf");
	C.meta = NFT_META_NFPROTO;
	C.mv[0] = 5;			/* NFPROTO_NETDEV */
	C.mlen = 1;
	f571_arm(D_ND1, "rd", &C, 1, 10);
	/* `meta protocol` at this door asks nf_flow_pppoe_proto(): the answer is
	 * the *inner* ethertype, and asking it also rebuilds pktinfo with
	 * nhoff = PPPOE_SES_HLEN (8) + skb_network_offset. */
	f571_zero(&C, "meta_proto86");
	C.meta = NFT_META_PROTOCOL;
	C.mv[0] = 0x86;
	C.mv[1] = 0xdd;
	C.mlen = 2;
	f571_arm(D_ND1, "rd", &C, 1, 10);
	f571_rd(&C, "th0_m", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2,
		F571_FR + 62);
	C.meta = NFT_META_PROTOCOL;
	C.mv[0] = 0x86;
	C.mv[1] = 0xdd;
	C.mlen = 2;
	f571_arm(D_ND1, "rd", &C, 1, 10);
}

/* ---------- section `wr`: what the guards let through ---------- */

static void f571_sec_wr(void)
{
	struct f571_cfg C;
	static const unsigned char hop90[1] = { 0x90 };
	static const unsigned char hop00[1] = { 0x00 };
	static const unsigned char big[2] = { 0x90, 0x91 };
	static const unsigned char v6f[4] = { 0x60, 0x00, 0x00, 0x08 };
	static const unsigned char v9f[4] = { 0x90, 0x00, 0x00, 0x08 };
	static const unsigned char nh3b[1] = { 0x3b };
	const unsigned char *nd = F571_FR + 14;	/* PPPoE header = data on x1 */
	static const unsigned char ff[2] = { 0xff, 0xff };

	/* --- the guard of nft_nh_write_ok_ip6(), one cell at a time --- */
	f571_wr(&C, "nh7_90", NFT_PAYLOAD_NETWORK_HEADER, 7, 1, hop90, 0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 14);
	f571_wr(&C, "nh7_00", NFT_PAYLOAD_NETWORK_HEADER, 7, 1, hop00, 0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 14);
	f571_wr(&C, "nh4_2", NFT_PAYLOAD_NETWORK_HEADER, 4, 2, big, 0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 10);
	f571_wr(&C, "nh6_1", NFT_PAYLOAD_NETWORK_HEADER, 6, 1, nh3b, 0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 10);
	f571_wr(&C, "nh0_ok", NFT_PAYLOAD_NETWORK_HEADER, 0, 4, v6f, 0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 14);
	f571_wr(&C, "nh0_bad", NFT_PAYLOAD_NETWORK_HEADER, 0, 4, v9f, 0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 10);
	f571_wr(&C, "nh2_2", NFT_PAYLOAD_NETWORK_HEADER, 2, 2, big, 0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 14);
	f571_wr(&C, "nh40_16", NFT_PAYLOAD_NETWORK_HEADER, 40, 16, A6_L_ALT,
		0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 10);
	/* saddr: same value (checksum stays valid) and another value */
	f571_wr(&C, "nh8_same", NFT_PAYLOAD_NETWORK_HEADER, 8, 16, A6_L_SRC,
		0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 14);
	f571_wr(&C, "nh8_alt", NFT_PAYLOAD_NETWORK_HEADER, 8, 16, A6_L_ALT,
		0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 14);
	f571_wr(&C, "nh8_cs", NFT_PAYLOAD_NETWORK_HEADER, 8, 16, A6_L_SRC, 1,
		10);
	f571_arm(D_IN3, "wr", &C, 1, 10);
	/* daddr */
	f571_wr(&C, "nh24_same", NFT_PAYLOAD_NETWORK_HEADER, 24, 16, A6_L_DST,
		0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 14);
	f571_wr(&C, "nh24_alt", NFT_PAYLOAD_NETWORK_HEADER, 24, 16, A6_L_ALT,
		0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 14);
	/* @ll on ppp0: every write is outside the link header */
	f571_wr(&C, "ll0_1", NFT_PAYLOAD_LL_HEADER, 0, 1, hop90, 0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 10);
	f571_wr(&C, "ll0_2", NFT_PAYLOAD_LL_HEADER, 0, 2, big, 0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 10);
	f571_wr(&C, "ll7_1", NFT_PAYLOAD_LL_HEADER, 7, 1, hop90, 0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 10);
	/* @th on ppp0: the real transport header */
	f571_wr(&C, "th0_2", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, big, 0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 14);
	f571_wr(&C, "th0_2_cs", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, big, 1, 6);
	f571_arm(D_IN3, "wr", &C, 1, 14);
	f571_wr(&C, "th6_2", NFT_PAYLOAD_TRANSPORT_HEADER, 6, 2, big, 0, 0);
	f571_arm(D_IN3, "wr", &C, 1, 14);

	/* --- the same two cells at the ip6 family door --- */
	f571_wr(&C, "nh7_90", NFT_PAYLOAD_NETWORK_HEADER, 7, 1, hop90, 0, 0);
	f571_arm(D_IP63, "wr", &C, 1, 14);
	f571_wr(&C, "nh4_2", NFT_PAYLOAD_NETWORK_HEADER, 4, 2, big, 0, 0);
	f571_arm(D_IP63, "wr", &C, 1, 10);
	f571_wr(&C, "ll0_1", NFT_PAYLOAD_LL_HEADER, 0, 1, hop90, 0, 0);
	f571_arm(D_IP63, "wr", &C, 1, 10);
	f571_wr(&C, "th0_2", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, big, 0, 0);
	f571_arm(D_IP63, "wr", &C, 1, 14);

	/* --- the same frame at the netdev ingress door: guard = constant --- */
	f571_wr(&C, "nh7_90", NFT_PAYLOAD_NETWORK_HEADER, 7, 1, hop90, 0, 0);
	f571_arm(D_ND1, "wr", &C, 1, 14);
	/* the same cell, the value the frame already carries: the write happens
	 * and the packet is delivered -- the death is the value, not the act */
	f571_wr(&C, "nh7_same", NFT_PAYLOAD_NETWORK_HEADER, 7, 1, nd + 7, 0, 0);
	f571_arm(D_ND1, "wr", &C, 1, 14);
	f571_wr(&C, "nh4_2_len", NFT_PAYLOAD_NETWORK_HEADER, 4, 2, big, 0, 0);
	f571_arm(D_ND1, "wr", &C, 1, 14);
	f571_wr(&C, "nh4_2_same", NFT_PAYLOAD_NETWORK_HEADER, 4, 2, nd + 4, 0,
		0);
	f571_arm(D_ND1, "wr", &C, 1, 14);
	f571_arm(D_ND1, "wr", &C, 1, 14);
	f571_wr(&C, "nh2_2_sid", NFT_PAYLOAD_NETWORK_HEADER, 2, 2, big, 0, 0);
	f571_arm(D_ND1, "wr", &C, 1, 14);
	f571_wr(&C, "nh6_1_proto", NFT_PAYLOAD_NETWORK_HEADER, 6, 1, nh3b, 0,
		0);
	f571_arm(D_ND1, "wr", &C, 1, 14);
	f571_wr(&C, "ll6_2", NFT_PAYLOAD_LL_HEADER, 6, 2, ff, 0, 0);
	f571_arm(D_ND1, "wr", &C, 1, 14);
	/* @th at ingress needs meta protocol; without it the base is refused */
	f571_wr(&C, "th0_2_nm", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, big, 0, 0);
	f571_arm(D_ND1, "wr", &C, 1, 10);
	f571_wr(&C, "th0_2_m", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, big, 0, 0);
	C.meta = NFT_META_PROTOCOL;
	C.mv[0] = 0x86;
	C.mv[1] = 0xdd;
	C.mlen = 2;
	f571_arm(D_ND1, "wr", &C, 1, 14);
	f571_wr(&C, "th0_2_m_cs", NFT_PAYLOAD_TRANSPORT_HEADER, 0, 2, big, 1, 6);
	C.meta = NFT_META_PROTOCOL;
	C.mv[0] = 0x86;
	C.mv[1] = 0xdd;
	C.mlen = 2;
	f571_arm(D_ND1, "wr", &C, 1, 14);
}

/* ---------- section `tapf`: the filter that ate three shapes ---------- */

struct f571_tap {
	int total, old, new;
	unsigned char first[256];
	int firstlen;
};

/* the filter of F48 (f569_tap6): byte 20 of the frame must be 17 */
static int f571_tap_old(const unsigned char *b, int n)
{
	if (n < 14 + 40 + 8)
		return 0;
	if (b[12] != 0x86 || b[13] != 0xdd)
		return 0;
	if (b[20] != 17)
		return 0;
	return f568_needle(b, n);
}

/* the same question asked by walking the next-header chain: the frame is
 * ethernet (14) + IPv6 (40) + extension headers + UDP.  `hdr` is the frame
 * offset of the extension header that `nh` announces. */
static int f571_tap_new(const unsigned char *b, int n)
{
	int hdr = 14 + 40, nh, guard = 0;

	if (n < 14 + 40 + 8)
		return 0;
	if (b[12] != 0x86 || b[13] != 0xdd)
		return 0;
	nh = b[14 + 6];
	while (guard++ < 8) {
		if (nh == 17)
			return f568_needle(b, n);
		if (hdr + 2 > n)
			return 0;
		if (nh == 0 || nh == 60 || nh == 43) {
			nh = b[hdr];
			hdr += (b[hdr + 1] + 1) * 8;
			continue;
		}
		if (nh == 51) {
			nh = b[hdr];
			hdr += (b[hdr + 1] + 2) * 4;
			continue;
		}
		return 0;
	}
	return 0;
}

static int f571_tap_open(const char *dev)
{
	struct sockaddr_ll sll;
	int s, idx = f555_ifindex(dev);

	if (idx < 0)
		return -1;
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s < 0)
		return -2;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_ALL);
	sll.sll_ifindex = idx;
	if (bind(s, (struct sockaddr *)&sll, sizeof(sll)) < 0) {
		close(s);
		return -3;
	}
	return s;
}

static void f571_tap_drain(struct f571_tap *T)
{
	unsigned char b[2048];
	int r;

	memset(T, 0, sizeof(*T));
	T->firstlen = -1;
	if (F571_TAP < 0)
		return;
	while ((r = (int)recv(F571_TAP, b, sizeof(b), MSG_DONTWAIT)) > 0) {
		T->total++;
		if (f571_tap_old(b, r))
			T->old++;
		if (f571_tap_new(b, r)) {
			T->new++;
			if (T->firstlen < 0) {
				T->firstlen = r < (int)sizeof(T->first) ? r
									: (int)sizeof(T->first);
				memcpy(T->first, b, (size_t)T->firstlen);
			}
		}
	}
}

static void f571_sec_tapf(void)
{
	static const char *NM[2] = { "bare", "hbh" };
	unsigned char fr[256];
	int shape, n;

	F571_TAP = f571_tap_open("x1");
	printf("F571 TAP|fd=%d\n", F571_TAP);
	for (shape = 0; shape < 2; shape++) {
		struct f571_tap T;
		char hx[600];

		f571_flush_all();
		f571_tap_drain(&T);
		n = f570_frame_plain(fr, F571_X1M, F571_X0M, A6_L_SRC, A6_L_DST,
				     shape);
		pkt_send_p("x0", fr, n, 0x86dd);
		usleep(300000);
		f571_tap_drain(&T);
		printf("F571 T|shape=%s|len=%d|total=%d|old=%d|new=%d|"
		       "firstlen=%d|first=%s|frame=%s\n",
		       NM[shape], n, T.total, T.old, T.new, T.firstlen,
		       T.firstlen > 0 ? f559_hexs(hx, sizeof(hx), T.first,
						  T.firstlen) : "-",
		       f559_hexs(hx, sizeof(hx), fr, n));
	}
}

/* ---------- mode entry ---------- */

int f571_main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "pp6l3";

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("F571 BEGIN|mode=%s\n", mode);
	if (unshare(CLONE_NEWNET) < 0) {
		printf("F571 FAIL|unshare|%d\n", errno);
		return 0;
	}
	set_up("lo");
	f556_fams();
	printf("F571 KERNEL|7.3.4-T563\n");
	if (f571_env())
		return 0;
	printf("F571 DOORS|rc=%d\n", f571_chains());
	F571_NFL = nfl_open(5);
	printf("F571 NFL|%d\n", F571_NFL);
	{
		char hx[400];

		printf("F571 FRAME|len=%d|%s\n", F571_FRLEN,
		       f559_hexs(hx, sizeof(hx), F571_FR, F571_FRLEN));
	}
	if (!strcmp(mode, "ctl"))
		f571_sec_ctl();
	else if (!strcmp(mode, "rd"))
		f571_sec_rd();
	else if (!strcmp(mode, "wr"))
		f571_sec_wr();
	else if (!strcmp(mode, "tapf"))
		f571_sec_tapf();
	else {
		f571_sec_ctl();
		f571_sec_rd();
		f571_sec_wr();
		f571_sec_tapf();
	}
	printf("F571 END|mode=%s\n", mode);
	return 0;
}

int f571_entry(int argc, char **argv)
{
	return f571_main(argc, argv);
}
/* differ572_add.c -- turn 572 (F50).
 *
 *  THE DEBT (named at the end of 571): "the one door left where the same frame
 *  reaches the @nh guard with mac_len != 0 and pf = NFPROTO_IPV6 at once --
 *  ppp0 inside a bridge."
 *
 *  Mode `ll3br`: two veth pairs, one bridge br0 with ports x1 and y1, IPv6
 *  enabled on br0 only.  One frame is injected on x0 (80 bytes):
 *
 *    ethernet broadcast (14) | IPv6 fd02::11 -> fd02::92 (40) | UDP (8) | 18x77
 *
 *  and the same skb is presented to four doors in one boot:
 *
 *    in6   ip6    prerouting   (all devs)  <- the layer-3 door of the bridge
 *    i6in  ip6    input        (all devs)  <- witness: the same skb, one door on
 *    brp   bridge prerouting   on br0      <- the door of F37/F38, before the
 *                                             bridge makes its copies
 *    nd1   netdev ingress      on x1       <- the door of F44, no guard at all
 *
 *  Oracles: the rule's own counter (guard verdict), a read-back at the NEXT
 *  door of the same skb, two AF_PACKET taps (br0 = the local copy before the
 *  hook, y0 = the port's copy after the hook), the socket, the net-wide SNMP6
 *  counters and the per-device rx_otherhost_dropped from IFLA_STATS64.
 *
 *  Mode `ll3br` also closes the 571 debt by measurement: br_add_if() is asked
 *  to enslave ppp0 (ARPHRD_PPP, type 512) and lo, and the rc is printed.
 *
 *  Every helper below the new code is the one that produced F31..F49.
 */

#define F572_SID	99
#define F572_SPORT	40000
#define F572_DPORT	5000
#define F572_TAPN	2
#define F572_NDOOR	4
#define ND72		4

/* the IPv6 datagram the frame carries: fd02::11 -> fd02::92 (br0) */
static const unsigned char A72_SRC[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x11 };
static const unsigned char A72_DST[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x92 };
static const unsigned char A72_BC[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
static const unsigned char A72_NEEDLE[6] = { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95 };
static const unsigned char A72_N2[2] = { 0x90, 0x91 };
static const unsigned char A72_N4[4] = { 0x90, 0x91, 0x92, 0x93 };

/* ---------- the four doors ---------- */

static struct f571_door D572[] = {
	{ "in6",  NFPROTO_IPV6,   "e72a", NULL,  0, 10, 20 },	/* prerouting */
	{ "i6in", NFPROTO_IPV6,   "e72b", NULL,  1, 30, 40 },	/* input      */
	/* NOTE: this kernel's nft_chain_parse_hook() accepts NFTA_HOOK_DEV only
	 * for the netdev family hooks; a bridge-family chain cannot be pinned
	 * to a device (-EOPNOTSUPP, measured in the first smoke). */
	{ "brp",  NFPROTO_BRIDGE, "e72c", NULL,  0, 50, 60 },	/* NF_BR_PRE  */
	{ "nd1",  NFPROTO_NETDEV, "e72d", "x1",  0, 70, 80 },	/* ingress    */
};
enum { E_IN6 = 0, E_I6IN, E_BRP, E_ND1 };

static unsigned char F572_X0M[6], F572_BRM[6];
static char F572_PPP[16];
static int F572_U6 = -1, F572_NFL = -1;
static unsigned char F572_FR[256];
static int F572_FRLEN = -1;

/* taps: 0 = br0 (the local copy, before the hook), 1 = y0 (the port's copy) */
struct f572_tap {
	int fd;
	int n;
	int len;	/* bytes copied into b[] */
	int flen;	/* the frame's real length */
	unsigned char b[64];
};
static struct f572_tap F572_TAP[F572_TAPN];
static const char *F572_TAPDEV[F572_TAPN] = { "br0", "y0" };

/* ---------- /sys readers ---------- */

static int f572_sysint(const char *path)
{
	FILE *f = fopen(path, "r");
	int v = -2;

	if (!f)
		return -1;
	if (fscanf(f, "%d", &v) != 1)
		v = -3;
	fclose(f);
	return v;
}

static int f572_exists(const char *path)
{
	FILE *f = fopen(path, "r");

	if (!f)
		return 0;
	fclose(f);
	return 1;
}

/* ---------- IFLA_STATS64: rx_otherhost_dropped lives only here ---------- */

struct f572_lst {
	unsigned long long rxp, txp, rxb, txb, rxd, txd, other;
	int ok;
};

static unsigned long long f572_u64(const unsigned char *p)
{
	unsigned long long v = 0;
	int i;

	for (i = 7; i >= 0; i--)
		v = (v << 8) | (unsigned long long)p[i];
	return v;
}

#define F572_IFLA_STATS64 23	/* uapi/linux/if_link.h enum position */
#define F572_OFF_OTHERHOST 192	/* 24th u64 of struct rtnl_link_stats64 */

static void f572_stats(const char *dev, struct f572_lst *s)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
	} req;
	unsigned char rbuf[8192];
	struct nlmsghdr *nlh;
	struct sockaddr_nl sa;
	int fd, idx = f555_ifindex(dev), r;

	memset(s, 0, sizeof(*s));
	if (idx < 0)
		return;
	fd = socket(AF_NETLINK, SOCK_RAW | SOCK_CLOEXEC, NETLINK_ROUTE);
	if (fd < 0)
		return;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_GETLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST;
	req.nlh.nlmsg_seq = 7;
	req.ifi.ifi_family = AF_UNSPEC;
	req.ifi.ifi_index = idx;
	if (sendto(fd, &req, req.nlh.nlmsg_len, 0, (struct sockaddr *)&sa,
		   sizeof(sa)) < 0) {
		close(fd);
		return;
	}
	r = (int)recv(fd, rbuf, sizeof(rbuf), 0);
	close(fd);
	if (r < (int)(NLMSG_HDRLEN + sizeof(struct ifinfomsg)))
		return;
	nlh = (struct nlmsghdr *)rbuf;
	if (nlh->nlmsg_type == NLMSG_ERROR)
		return;
	{
		const char *p = (const char *)nlh + NLMSG_HDRLEN +
				sizeof(struct ifinfomsg);
		const char *end = (const char *)nlh + nlh->nlmsg_len;

		for (; p + (int)sizeof(struct nlattr) <= end; ) {
			const struct nlattr *a = (const struct nlattr *)p;
			int al = (int)a->nla_len, t;

			if (al < (int)sizeof(*a) || p + al > end)
				break;
			t = a->nla_type & 0x3fff;
			if (t == F572_IFLA_STATS64 &&
			    al - NLA_HDRLEN >= F572_OFF_OTHERHOST + 8) {
				const unsigned char *d =
					(const unsigned char *)a + NLA_HDRLEN;

				s->rxp = f572_u64(d + 0);
				s->txp = f572_u64(d + 8);
				s->rxb = f572_u64(d + 16);
				s->txb = f572_u64(d + 24);
				s->rxd = f572_u64(d + 48);
				s->txd = f572_u64(d + 56);
				s->other = f572_u64(d + F572_OFF_OTHERHOST);
				s->ok = 1;
			}
			p += NLA_ALIGN_(al);
		}
	}
}

/* ---------- environment ---------- */

/* the PPPoE unit of F49, bound on x0 (not a bridge port) */
static int f572_ppp_make(void)
{
	int u = -1, idx = -1, up, sock, fdu, fdc;

	sock = f563_pppoe_sock("x0", htons(F572_SID), F572_X0M);
	if (sock < 0) {
		printf("F572 PPP|fail|sock|%d\n", sock);
		return -1;
	}
	if (ioctl(sock, PPPIOCGCHAN, &idx) < 0) {
		printf("F572 PPP|fail|gchan|%d\n", errno);
		return -1;
	}
	fdu = open("/dev/ppp", O_RDWR);
	if (fdu < 0) {
		printf("F572 PPP|fail|unit|%d\n", errno);
		return -1;
	}
	if (ioctl(fdu, PPPIOCNEWUNIT, &u) < 0) {
		printf("F572 PPP|fail|newunit|%d\n", errno);
		return -1;
	}
	fdc = open("/dev/ppp", O_RDWR);
	if (fdc < 0) {
		printf("F572 PPP|fail|chan|%d\n", errno);
		return -1;
	}
	if (ioctl(fdc, PPPIOCATTCHAN, &idx) < 0) {
		printf("F572 PPP|fail|attchan|%d\n", errno);
		return -1;
	}
	if (ioctl(fdc, PPPIOCCONNECT, &u) < 0) {
		printf("F572 PPP|fail|connect|%d\n", errno);
		return -1;
	}
	snprintf(F572_PPP, sizeof(F572_PPP), "ppp%d", u);
	up = set_up(F572_PPP);
	printf("F572 PPP|unit=%d|chan=%d|dev=%s|ifindex=%d|up=%d|type=%d\n", u,
	       idx, F572_PPP, f555_ifindex(F572_PPP), up,
	       f572_sysint("/sys/class/net/ppp0/type"));
	return 0;
}

static int f572_env(void)
{
	char path[96];

	f572_stats("lo", &(struct f572_lst){ 0 });
	f555_sysctl("/proc/sys/net/ipv6/conf/default/disable_ipv6", "1");
	f555_sysctl("/proc/sys/net/ipv6/conf/default/accept_dad", "0");
	if (link_add_veth("x0", "x1") || link_add_veth("y0", "y1")) {
		printf("F572 FAIL|veth\n");
		return -1;
	}
	if (f556_link_add_kind("br0", "bridge")) {
		printf("F572 FAIL|bridge\n");
		return -1;
	}
	set_up("x0");
	set_up("x1");
	set_up("y0");
	set_up("y1");
	set_up("br0");
	if (mac_get("x0", F572_X0M)) {
		printf("F572 FAIL|mac\n");
		return -1;
	}
	/* ports are enslaved after everything is up, so br_stp_enable_port()
	 * runs and the ports are FORWARDING with no STP */
	printf("F572 REF|arm=ok_x1|port=x1|master=br0|rc=%d\n",
	       f556_link_enslave("x1", "br0"));
	printf("F572 REF|arm=ok_y1|port=y1|master=br0|rc=%d\n",
	       f556_link_enslave("y1", "br0"));
	/* br0's MAC is recalculated when a port is added (br_stp_recalculate_
	 * bridge_id), so it must be read AFTER the enslave, not before. */
	if (mac_get("br0", F572_BRM)) {
		printf("F572 FAIL|mac_br\n");
		return -1;
	}

	f555_sysctl("/proc/sys/net/ipv6/conf/br0/disable_ipv6", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/accept_dad", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/dad_transmits", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/accept_ra", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/autoconf", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/forwarding", "0");
	f555_sysctl("/sys/class/net/br0/bridge/multicast_snooping", "0");
	f555_sysctl("/sys/class/net/br0/bridge/multicast_querier", "0");
	printf("F572 ADDR6|rc=%d\n", f564_addr6("br0", A72_DST, 128));
	F572_U6 = f564_udp_bind(AF_INET6, 0, A72_DST, F572_DPORT);
	F572_NFL = nfl_open(5);
	F571_NFL = F572_NFL;	/* f571_nfl_drain() reads F571_NFL */
	F572_FRLEN = f570_frame_plain(F572_FR, A72_BC, F572_X0M, A72_SRC,
				      A72_DST, 0);
	if (f572_ppp_make())
		return -2;
	{
		char hx[64], hy[64], hf[256];

		printf("F572 ENV|u6=%d|nfl=%d|flen=%d|br0=%d|x1=%d|y0=%d|"
		       "br0mac=%s|x0mac=%s|frame=%s\n",
		       F572_U6, F572_NFL, F572_FRLEN, f555_ifindex("br0"),
		       f555_ifindex("x1"), f555_ifindex("y0"),
		       f559_hexs(hx, sizeof(hx), F572_BRM, 6),
		       f559_hexs(hy, sizeof(hy), F572_X0M, 6),
		       f559_hexs(hf, sizeof(hf), F572_FR, F572_FRLEN));
	}
	printf("F572 SYS|stp=%d|x1state=%d|y1state=%d|mcsnoop=%d|"
	       "br0v6=%d|br0dad=%d|x1v6=%d|y0v6=%d|br0mclen=%d\n",
	       f572_sysint("/sys/class/net/br0/bridge/stp_state"),
	       f572_sysint("/sys/class/net/x1/brport/state"),
	       f572_sysint("/sys/class/net/y1/brport/state"),
	       f572_sysint("/sys/class/net/br0/bridge/multicast_snooping"),
	       f572_sysint("/proc/sys/net/ipv6/conf/br0/disable_ipv6"),
	       f572_sysint("/proc/sys/net/ipv6/conf/br0/accept_dad"),
	       f572_sysint("/proc/sys/net/ipv6/conf/x1/disable_ipv6"),
	       f572_sysint("/proc/sys/net/ipv6/conf/y0/disable_ipv6"),
	       f572_sysint("/sys/class/net/br0/mtu"));
	{
		int i;

		for (i = 0; i < F572_TAPN; i++) {
			F572_TAP[i].fd = f571_tap_open(F572_TAPDEV[i]);
			F572_TAP[i].n = 0;
			F572_TAP[i].len = -1;
		}
		printf("F572 TAP|br0=%d|y0=%d\n", F572_TAP[0].fd,
		       F572_TAP[1].fd);
	}
	return 0;
}

static int f572_chains(void)
{
	int i, rc = 0;

	for (i = 0; i < ND72; i++) {
		struct f571_door *D = &D572[i];
		int a, b, c;

		a = add_table(D->fam, D->table);
		b = f556_add_chain(D->fam, D->table, "pre0", D->hook,
				   (uint32_t)D->prio0, 1, D->dev);
		c = f556_add_chain(D->fam, D->table, "ch", D->hook,
				   (uint32_t)D->prio1, 1, D->dev);
		printf("F572 CH|door=%s|fam=%d|dev=%s|table=%d|pre0=%d|ch=%d\n",
		       D->tag, (int)D->fam, D->dev ? D->dev : "-", a, b, c);
		rc |= a | b | c;
	}
	/* the witness chain: a separate base chain at the input hook */
	{
		int w = f556_add_chain(NFPROTO_IPV6, D572[E_I6IN].table, "chk",
				       D572[E_I6IN].hook,
				       (uint32_t)(D572[E_I6IN].prio1 + 10), 1,
				       NULL);

		printf("F572 CH|door=chk|fam=10|dev=-|table=-1|pre0=-1|ch=%d\n",
		       w);
		rc |= w;
	}
	return rc;
}

static void f572_flush_all(void)
{
	int i, acks = 0;

	for (i = 0; i < ND72; i++) {
		f557_flush(D572[i].fam, D572[i].table, "pre0", &acks);
		f557_flush(D572[i].fam, D572[i].table, "ch", &acks);
	}
	f557_flush(NFPROTO_IPV6, D572[E_I6IN].table, "chk", &acks);
}

/* ---------- the snapshot ---------- */

struct f572_rep {
	int u6n, u6len, u6sport;
	unsigned long long i6in, i6hdr, i6addr, i6unk, i6trunc, i6noroute,
			   i6deliv, u6in, u6err, u6noport, i6disc, i6mcast;
	unsigned long long brrxp, brrxb;
	unsigned long long y0rxp, y0rxd, y0other;
	int y0ok;
};

static void f572_u6_drain(struct f572_rep *R)
{
	unsigned char b[1024];
	struct sockaddr_in6 sa;
	socklen_t sl;
	int r, k;

	if (F572_U6 < 0)
		return;
	for (;;) {
		memset(&sa, 0, sizeof(sa));
		sl = sizeof(sa);
		r = (int)recvfrom(F572_U6, b, sizeof(b), MSG_DONTWAIT,
				  (struct sockaddr *)&sa, &sl);
		if (r < 0)
			break;
		if (!f568_needle(b, r))
			continue;
		R->u6n++;
		R->u6len = r;
		R->u6sport = ntohs(sa.sin6_port);
		k = r;
		(void)k;
	}
}

static void f572_snap(struct f572_rep *R)
{
	struct f572_lst s;

	f572_u6_drain(R);
	R->i6in = f564_snmp6("Ip6InReceives");
	R->i6hdr = f564_snmp6("Ip6InHdrErrors");
	R->i6addr = f564_snmp6("Ip6InAddrErrors");
	R->i6unk = f564_snmp6("Ip6InUnknownProtos");
	R->i6trunc = f564_snmp6("Ip6InTruncatedPkts");
	R->i6noroute = f564_snmp6("Ip6InNoRoutes");
	R->i6deliv = f564_snmp6("Ip6InDelivers");
	R->i6disc = f564_snmp6("Ip6InDiscards");
	R->i6mcast = f564_snmp6("Ip6InMcastPkts");
	R->u6in = f564_snmp6("Udp6InDatagrams");
	R->u6err = f564_snmp6("Udp6InErrors");
	R->u6noport = f564_snmp6("Udp6NoPorts");
	f572_stats("br0", &s);
	R->brrxp = s.rxp;
	R->brrxb = s.rxb;
	f572_stats("y0", &s);
	R->y0rxp = s.rxp;
	R->y0rxd = s.rxd;
	R->y0other = s.other;
	R->y0ok = s.ok;
}

static void f572_tap_drain(int i)
{
	unsigned char b[2048];
	int r;

	F572_TAP[i].n = 0;
	F572_TAP[i].len = -1;
	F572_TAP[i].flen = -1;
	if (F572_TAP[i].fd < 0)
		return;
	while ((r = (int)recv(F572_TAP[i].fd, b, sizeof(b), MSG_DONTWAIT)) >
	       0) {
		if (!f568_needle(b, r))
			continue;
		F572_TAP[i].n++;
		if (F572_TAP[i].len < 0) {
			F572_TAP[i].flen = r;
			int k = r < (int)sizeof(F572_TAP[i].b)
					? r : (int)sizeof(F572_TAP[i].b);

			memcpy(F572_TAP[i].b, b, (size_t)k);
			F572_TAP[i].len = k;
		}
	}
}

/* ---------- one arm ---------- */

/* W == NULL: no witness chain.  door2 == -1: witness not used. */
static void f572_arm(int door, const char *sec, const char *arm,
		     const struct f571_cfg *Cp, const struct f571_cfg *C,
		     const struct f571_cfg *W, int send, int maxp)
{
	struct f571_door *D = &D572[door];
	struct f571_cfg N, Z;
	struct f572_rep r0, r;
	struct f571_pl pl;
	unsigned long long c0p, c0s, c0w, c1p, c1s, c1w;
	int rcp = -1, rcs = -1, rcw = -1, acks = 0, snd = 0, polls = 0, k;
	const struct f571_msg *mp = NULL;
	char hx[300], hm[40], hy[400], hq[200], hr[200], ht[200], hb[80];

	memset(&r0, 0, sizeof(r0));
	memset(&r, 0, sizeof(r));
	f571_zero(&N, "pre");
	f571_zero(&Z, "w");
	f572_flush_all();
	f571_nfl_drain(NULL);
	for (k = 0; k < F572_TAPN; k++)
		f572_tap_drain(k);
	for (k = 0; k < F572_TAPN; k++) {
		F572_TAP[k].n = 0;
		F572_TAP[k].len = -1;
		F572_TAP[k].flen = -1;
	}
	f572_snap(&r0);
	rcp = f571_rule(D, "pre0", "p", Cp ? Cp : &N, &acks);
	if (C)
		rcs = f571_rule(D, "ch", "s", C, &acks);
	if (W)
		rcw = f571_rule(&D572[E_I6IN], "chk", "w", W, &acks);
	c0p = f555_count(D->fam, D->table, "pre0");
	c0s = f555_count(D->fam, D->table, "ch");
	c0w = f555_count(NFPROTO_IPV6, D572[E_I6IN].table, "chk");
	f572_u6_drain(&r0);
	if (send)
		snd = pkt_send_p("x0", F572_FR, F572_FRLEN, 0x86dd);
	if (send) {
		for (k = 0; k < maxp; k++) {
			usleep(120000);
			f572_snap(&r);
			polls++;
			if (r.u6n > r0.u6n || r.i6in > r0.i6in ||
			    r.i6disc > r0.i6disc || r.i6hdr > r0.i6hdr ||
			    r.i6deliv > r0.i6deliv ||
			    r.y0other > r0.y0other ||
			    r.y0rxp > r0.y0rxp)
				break;
		}
	} else {
		usleep(300000);
		f572_snap(&r);
		polls = 1;
	}
	f572_snap(&r);
	usleep(150000);
	f572_snap(&r);
	c1p = f555_count(D->fam, D->table, "pre0");
	c1s = f555_count(D->fam, D->table, "ch");
	c1w = f555_count(NFPROTO_IPV6, D572[E_I6IN].table, "chk");
	memset(&pl, 0, sizeof(pl));
	f571_nfl_drain(&pl);
	for (k = 0; k < pl.n; k++) {
		if (pl.m[k].prefix[0] == 's' && !mp)
			mp = &pl.m[k];
	}
	for (k = 0; k < F572_TAPN; k++)
		f572_tap_drain(k);

	printf("F572 A|sec=%s|arm=%s|door=%s|mode=%d|base=%u|off=%d|len=%d|"
	       "imm=%s|rcp=%d|rcs=%d|rcw=%d|sendrc=%d|snt=%d|"
	       "cntp=%llu|cnts=%llu|cntw=%lld|polls=%d|"
	       "u6n=%d|u6len=%d|u6sport=%d\n",
	       sec, arm, D->tag, C ? C->mode : -1, C ? C->base : 0,
	       C ? C->off : -1, C ? C->len : -1,
	       C ? f559_hexs(hx, sizeof(hx), C->imm, C->len) : "-", rcp, rcs,
	       rcw, snd, send, c1p - c0p, c1s - c0s,
	       W ? (long long)(c1w - c0w) : -1LL, polls, r.u6n - r0.u6n,
	       r.u6len, r.u6sport);
	printf("F572 B|i6in_d=%llu|i6hdr_d=%llu|i6addr_d=%llu|i6unk_d=%llu|"
	       "i6trunc_d=%llu|i6noroute_d=%llu|deliv_d=%llu|u6in_d=%llu|"
	       "u6err_d=%llu|i6disc_d=%llu|i6mcast_d=%llu|"
	       "brrxp_d=%llu|brrxb_d=%llu|y0rxp_d=%llu|y0rxd_d=%llu|"
	       "y0other_d=%llu|y0ok=%d\n",
	       r.i6in - r0.i6in, r.i6hdr - r0.i6hdr, r.i6addr - r0.i6addr,
	       r.i6unk - r0.i6unk, r.i6trunc - r0.i6trunc,
	       r.i6noroute - r0.i6noroute, r.i6deliv - r0.i6deliv,
	       r.u6in - r0.u6in, r.u6err - r0.u6err, r.i6disc - r0.i6disc,
	       r.i6mcast - r0.i6mcast, r.brrxp - r0.brrxp,
	       r.brrxb - r0.brrxb, r.y0rxp - r0.y0rxp, r.y0rxd - r0.y0rxd,
	       r.y0other - r0.y0other, r.y0ok);
	{
		char mb[600];
		int i2, o2 = 0;

		mb[0] = 0;
		for (i2 = 0; i2 < pl.n && i2 < F571_NPL; i2++) {
			char hh[80];
			int w = snprintf(mb + o2, sizeof(mb) - (size_t)o2,
					 "|m%d=%s:%s:%d", i2,
					 pl.m[i2].prefix,
					 f559_hexs(hh, sizeof(hh), pl.m[i2].hw,
						   pl.m[i2].hwlen2),
					 pl.m[i2].plen);

			if (w < 0 || w >= (int)sizeof(mb) - o2)
				break;
			o2 += w;
		}
		printf("F572 M|n=%d%s\n", pl.n, mb);
	}
	printf("F572 N|prelen=%d|pre=%s|prel2=%d|prehw=%d|preht=%d|prehh=%d|"
	       "preind=%d|prehwhex=%s|postlen=%d|postind=%d|posthw=%d\n",
	       mp ? mp->plen : -1,
	       mp ? f559_hexs(hy, sizeof(hy), mp->p, mp->plen) : "-",
	       mp ? mp->l2len : -1, mp ? mp->hwlen : -1, mp ? mp->hwtype : -1,
	       mp ? mp->hwhdr : -1, mp ? mp->indev : -1,
	       mp && mp->hwlen2 > 0
		       ? f559_hexs(hq, sizeof(hq), mp->hw, mp->hwlen2) : "-",
	       mp ? mp->plen : -1, mp ? mp->indev : -1, mp ? mp->hwlen : -1);
	{
		char d0[24], t0[16], d1[24], t1[16];

		d0[0] = t0[0] = d1[0] = t1[0] = 0;
		if (F572_TAP[0].len > 0)
			f559_hexs(d0, sizeof(d0), F572_TAP[0].b, 6);
		if (F572_TAP[0].len > 13)
			f559_hexs(t0, sizeof(t0), F572_TAP[0].b + 12, 2);
		if (F572_TAP[1].len > 0)
			f559_hexs(d1, sizeof(d1), F572_TAP[1].b, 6);
		if (F572_TAP[1].len > 13)
			f559_hexs(t1, sizeof(t1), F572_TAP[1].b + 12, 2);
		printf("F572 T|brn=%d|brlen=%d|brhex=%s|farn=%d|farlen=%d|"
		       "farhex=%s|brdst=%s|brtype=%s|fardst=%s|bartype=%s\n",
		       F572_TAP[0].n, F572_TAP[0].flen,
		       F572_TAP[0].len > 0
			       ? f559_hexs(hr, sizeof(hr), F572_TAP[0].b, 20)
			       : "-",
		       F572_TAP[1].n, F572_TAP[1].flen,
		       F572_TAP[1].len > 0
			       ? f559_hexs(ht, sizeof(ht), F572_TAP[1].b, 20)
			       : "-",
		       d0[0] ? d0 : "-", t0[0] ? t0 : "-",
		       d1[0] ? d1 : "-", t1[0] ? t1 : "-");
	}
}

/* ---------- config builders ---------- */

static void f572_rd(struct f571_cfg *C, const char *arm, uint32_t base,
		    int off, int len, const unsigned char *src)
{
	f571_rd(C, arm, base, off, len, src);
}

static void f572_wr(struct f571_cfg *C, const char *arm, uint32_t base,
		    int off, int len, const unsigned char *imm)
{
	f571_wr(C, arm, base, off, len, imm, 0, 0);
}

/* a read cell whose immediate is `imm` itself (f571_rd() takes src+off,
 * which is right for "what the frame carries" and wrong for "what a store
 * should have put there") */
static void f572_rdv(struct f571_cfg *C, const char *arm, uint32_t base,
		     int off, int len, const unsigned char *imm)
{
	f571_zero(C, arm);
	C->mode = 3;
	C->base = base;
	C->off = off;
	C->len = len;
	memcpy(C->imm, imm, (size_t)len);
}

/* ---------- section `ref`: the door of 571 does not exist ---------- */

static void f572_ref(const char *arm, const char *port, const char *master)
{
	char p[128];
	int rc = f556_link_enslave(port, master), type, masterf;

	snprintf(p, sizeof(p), "/sys/class/net/%s/master", port);
	masterf = f572_exists(p);
	snprintf(p, sizeof(p), "/sys/class/net/%s/type", port);
	type = f572_sysint(p);
	printf("F572 R|arm=%s|port=%s|master=%s|rc=%d|type=%d|masterf=%d|"
	       "iff=%d\n", arm, port, master, rc, type, masterf,
	       f555_ifindex(port));
}

static void f572_sec_ref(void)
{
	f572_ref("ref_ppp", F572_PPP, "br0");
	f572_ref("ref_lo", "lo", "br0");
	f572_ref("ok_y1", "y1", "br0");
	f572_ref("ok_x1", "x1", "br0");
}

/* ---------- section `rd`: the read domain of @ll at a layer-3 door ------ */

static const int F572_OFFS[12] = { 0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24 };
static const int F572_LENS[3] = { 1, 2, 4 };

static void f572_sec_rd(void)
{
	struct f571_cfg C;
	const unsigned char *fr = F572_FR;
	const unsigned char *ip = F572_FR + 14;
	int i, j;
	char nm[24];

	for (i = 0; i < 12; i++) {
		for (j = 0; j < 3; j++) {
			snprintf(nm, sizeof(nm), "r%d_%d", F572_OFFS[i],
				 F572_LENS[j]);
			f572_rd(&C, nm, NFT_PAYLOAD_LL_HEADER, F572_OFFS[i],
				F572_LENS[j], fr);
			f572_arm(E_IN6, "rd", nm, NULL, &C, NULL, 1, 10);
		}
	}
	/* the same base at the netdev ingress door of F44 */
	snprintf(nm, sizeof(nm), "r0_6_nd");
	f572_rd(&C, nm, NFT_PAYLOAD_LL_HEADER, 0, 6, fr);
	f572_arm(E_ND1, "rd", nm, NULL, &C, NULL, 1, 10);
	snprintf(nm, sizeof(nm), "r14_2_nd");
	f572_rd(&C, nm, NFT_PAYLOAD_LL_HEADER, 14, 2, fr);
	f572_arm(E_ND1, "rd", nm, NULL, &C, NULL, 1, 10);
	snprintf(nm, sizeof(nm), "r13_1_nd");
	f572_rd(&C, nm, NFT_PAYLOAD_LL_HEADER, 13, 1, fr);
	f572_arm(E_ND1, "rd", nm, NULL, &C, NULL, 1, 10);
	/* @nh at the layer-3 door of the bridge: base at 14, not 0 */
	snprintf(nm, sizeof(nm), "nh0");
	f572_rd(&C, nm, NFT_PAYLOAD_NETWORK_HEADER, 0, 4, ip);
	f572_arm(E_IN6, "rd", nm, NULL, &C, NULL, 1, 10);
	snprintf(nm, sizeof(nm), "nh7");
	f572_rd(&C, nm, NFT_PAYLOAD_NETWORK_HEADER, 7, 1, ip);
	f572_arm(E_IN6, "rd", nm, NULL, &C, NULL, 1, 10);
	/* state->pf, measured */
	snprintf(nm, sizeof(nm), "pf6");
	f571_zero(&C, nm);
	C.meta = NFT_META_NFPROTO;
	C.mv[0] = 10;
	C.mlen = 1;
	f572_arm(E_IN6, "rd", nm, NULL, &C, NULL, 1, 10);
	snprintf(nm, sizeof(nm), "pfbr");
	f571_zero(&C, nm);
	C.meta = NFT_META_NFPROTO;
	C.mv[0] = 7;
	C.mlen = 1;
	f572_arm(E_BRP, "rd", nm, NULL, &C, NULL, 1, 10);
	{
		struct f571_cfg M2;

		f571_zero(&M2, "ctlb");
		f572_arm(E_BRP, "rd", "ctlb", NULL, &M2, NULL, 1, 10);
	}
}

/* ---------- section `wr`: the write domain of @ll at the same door ------ */

static void f572_sec_wr(void)
{
	struct f571_cfg C;
	int i, j;
	char nm[24];

	for (i = 0; i < 12; i++) {
		for (j = 0; j < 3; j++) {
			snprintf(nm, sizeof(nm), "w%d_%d", F572_OFFS[i],
				 F572_LENS[j]);
			if (F572_LENS[j] == 1)
				f572_wr(&C, nm, NFT_PAYLOAD_LL_HEADER,
					F572_OFFS[i], 1, A72_N4);
			else if (F572_LENS[j] == 2)
				f572_wr(&C, nm, NFT_PAYLOAD_LL_HEADER,
					F572_OFFS[i], 2, A72_N2);
			else
				f572_wr(&C, nm, NFT_PAYLOAD_LL_HEADER,
					F572_OFFS[i], 4, A72_N4);
			f572_arm(E_IN6, "wr", nm, NULL, &C, NULL, 1, 12);
		}
	}
	snprintf(nm, sizeof(nm), "w12_4_nd");
	f572_wr(&C, nm, NFT_PAYLOAD_LL_HEADER, 12, 4, A72_N4);
	f572_arm(E_ND1, "wr", nm, NULL, &C, NULL, 1, 12);
	snprintf(nm, sizeof(nm), "w14_1_nd");
	f572_wr(&C, nm, NFT_PAYLOAD_LL_HEADER, 14, 1, A72_N4);
	f572_arm(E_ND1, "wr", nm, NULL, &C, NULL, 1, 12);
	snprintf(nm, sizeof(nm), "w20_4_nd");
	f572_wr(&C, nm, NFT_PAYLOAD_LL_HEADER, 20, 4, A72_N4);
	f572_arm(E_ND1, "wr", nm, NULL, &C, NULL, 1, 12);
}

/* ---------- section `inv`: what the same accept means at two doors ------ */

static void f572_sec_inv(void)
{
	struct f571_cfg C, W;
	static const unsigned char et86dd[2] = { 0x86, 0xdd };
	static const unsigned char et0806[2] = { 0x08, 0x06 };

	/* control: no store anywhere, the witness reads the broadcast MAC */
	f571_zero(&C, "ctl");
	f572_rdv(&W, "w_bc", NFT_PAYLOAD_LL_HEADER, 0, 6, A72_BC);
	f572_arm(E_IN6, "inv", "ctl", NULL, &C, &W, 1, 12);

	/* the dst MAC written at the layer-3 door of the bridge */
	f572_wr(&C, "pre_dst", NFT_PAYLOAD_LL_HEADER, 0, 6, A72_NEEDLE);
	f572_rdv(&W, "w_dst", NFT_PAYLOAD_LL_HEADER, 0, 6, A72_NEEDLE);
	f572_arm(E_IN6, "inv", "pre_dst", NULL, &C, &W, 1, 12);

	/* the same write at the netdev ingress door: before the bridge */
	f572_wr(&C, "nd_dst", NFT_PAYLOAD_LL_HEADER, 0, 6, A72_NEEDLE);
	f572_rdv(&W, "w_dst", NFT_PAYLOAD_LL_HEADER, 0, 6, A72_NEEDLE);
	f572_arm(E_ND1, "inv", "nd_dst", NULL, &C, &W, 1, 12);

	/* the same write at the bridge prerouting door: after ingress, before
	 * the forwarding decision */
	f572_wr(&C, "br_dst", NFT_PAYLOAD_LL_HEADER, 0, 6, A72_NEEDLE);
	f572_rdv(&W, "w_dst", NFT_PAYLOAD_LL_HEADER, 0, 6, A72_NEEDLE);
	f572_arm(E_BRP, "inv", "br_dst", NULL, &C, &W, 1, 12);

	/* and the same door with the bridge's OWN address as the value */
	f572_wr(&C, "br_dst_br", NFT_PAYLOAD_LL_HEADER, 0, 6, F572_BRM);
	f572_rdv(&W, "w_br", NFT_PAYLOAD_LL_HEADER, 0, 6, F572_BRM);
	f572_arm(E_BRP, "inv", "br_dst_br", NULL, &C, &W, 1, 12);

	/* the bridge door again, but with the value the frame already carries */
	f572_wr(&C, "br_dst_bc", NFT_PAYLOAD_LL_HEADER, 0, 6, A72_BC);
	f572_rdv(&W, "w_bc", NFT_PAYLOAD_LL_HEADER, 0, 6, A72_BC);
	f572_arm(E_BRP, "inv", "br_dst_bc", NULL, &C, &W, 1, 12);

	/* the src MAC written at the layer-3 door */
	f572_wr(&C, "pre_src", NFT_PAYLOAD_LL_HEADER, 6, 6, A72_NEEDLE);
	f572_rdv(&W, "w_src", NFT_PAYLOAD_LL_HEADER, 6, 6, A72_NEEDLE);
	f572_arm(E_IN6, "inv", "pre_src", NULL, &C, &W, 1, 12);

	/* the ethertype written at the layer-3 door */
	f572_wr(&C, "pre_et", NFT_PAYLOAD_LL_HEADER, 12, 2, et0806);
	f572_rdv(&W, "w_et", NFT_PAYLOAD_LL_HEADER, 12, 2, et0806);
	f572_arm(E_IN6, "inv", "pre_et", NULL, &C, &W, 1, 12);

	/* the same write at the bridge prerouting door */
	f572_wr(&C, "br_et", NFT_PAYLOAD_LL_HEADER, 12, 2, et0806);
	f572_rdv(&W, "w_et", NFT_PAYLOAD_LL_HEADER, 12, 2, et0806);
	f572_arm(E_BRP, "inv", "br_et", NULL, &C, &W, 1, 12);

	/* the same value the frame already carries: a same-value control */
	f572_wr(&C, "pre_et6", NFT_PAYLOAD_LL_HEADER, 12, 2, et86dd);
	f572_rdv(&W, "w_et6", NFT_PAYLOAD_LL_HEADER, 12, 2, et86dd);
	f572_arm(E_IN6, "inv", "pre_et6", NULL, &C, &W, 1, 12);

	/* the write at the layer-3 door that the guard refuses: 14+1 */
	f572_wr(&C, "pre_w15", NFT_PAYLOAD_LL_HEADER, 14, 1, A72_N4);
	f572_rdv(&W, "w_dst4", NFT_PAYLOAD_LL_HEADER, 0, 6, A72_BC);
	f572_arm(E_IN6, "inv", "pre_w15", NULL, &C, &W, 1, 12);
}

/* ---------- section `comp`: does the guard read the frame or the cache? -- */

static void f572_sec_comp(void)
{
	struct f571_cfg C;
	struct nlmsghdr *nlh;
	struct nlattr *exprs;
	static const unsigned char et0800[2] = { 0x08, 0x00 };
	int acks = 0;

	/* one rule, two expressions, at the bridge door:
	 *   @ll,12,2 = 0800     (accepted: 12+2 = 14 <= 14)
	 *   @nh,10,2 = 9091     (ip4 allows offset 10; ip6 has no case 10) */
	f572_flush_all();
	f571_nfl_drain(NULL);
	{
		struct f571_cfg N;
		struct f572_rep r0, r;
		unsigned long long c0p, c0s, c1p, c1s;
		int k;

		memset(&r0, 0, sizeof(r0));
		memset(&r, 0, sizeof(r));
		f571_zero(&N, "pre");
		f572_snap(&r0);
		f571_rule(&D572[E_BRP], "pre0", "p", &N, &acks);
		nlh = msg_start(opbuf, (int)sizeof(opbuf),
				(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
				NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE |
					NLM_F_APPEND, NFPROTO_BRIDGE);
		put_str(nlh, NFTA_RULE_TABLE, D572[E_BRP].table);
		put_str(nlh, NFTA_RULE_CHAIN, "ch");
		exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
		f565_store(nlh, NFT_PAYLOAD_LL_HEADER, 12, 2, et0800, 0, 0);
		f565_store(nlh, NFT_PAYLOAD_NETWORK_HEADER, 10, 2, A72_N2, 0, 0);
		log_expr(nlh, 5, "s");
		counter_expr(nlh);
		accept_expr(nlh);
		nest_end(nlh, exprs);
		printf("F572 C|arm=comp_l2l3|rc=%d\n",
		       f557_nft_one(opbuf, (int)nlh->nlmsg_len, &acks));
		c0p = f555_count(NFPROTO_BRIDGE, D572[E_BRP].table, "pre0");
		c0s = f555_count(NFPROTO_BRIDGE, D572[E_BRP].table, "ch");
		f572_u6_drain(&r0);
		pkt_send_p("x0", F572_FR, F572_FRLEN, 0x86dd);
		for (k = 0; k < 12; k++) {
			usleep(120000);
			f572_snap(&r);
			if (r.u6n > r0.u6n || r.i6in > r0.i6in ||
			    r.y0rxp > r0.y0rxp)
				break;
		}
		f572_snap(&r);
		c1p = f555_count(NFPROTO_BRIDGE, D572[E_BRP].table, "pre0");
		c1s = f555_count(NFPROTO_BRIDGE, D572[E_BRP].table, "ch");
		{
			struct f571_pl pl;
			const struct f571_msg *mp = NULL;
			char hy[400], hr[200];

			memset(&pl, 0, sizeof(pl));
			f571_nfl_drain(&pl);
			for (k = 0; k < pl.n; k++)
				if (pl.m[k].prefix[0] == 's')
					mp = &pl.m[k];
			f572_tap_drain(0);
			printf("F572 A|sec=comp|arm=comp_l2l3|door=brp|mode=9|"
			       "base=0|off=-1|len=-1|imm=-|rcp=0|rcs=0|rcw=-1|"
			       "sendrc=%d|snt=1|cntp=%llu|cnts=%llu|cntw=-1|"
			       "polls=%d|u6n=%d|u6len=%d|u6sport=%d\n",
			       0, c1p - c0p, c1s - c0s, k, r.u6n - r0.u6n,
			       r.u6len, r.u6sport);
			printf("F572 N|prelen=%d|pre=%s|postlen=%d|"
			       "postind=%d|posthw=-1|prel2=-1|prehw=-1\n",
			       mp ? mp->plen : -1,
			       mp ? f559_hexs(hy, sizeof(hy), mp->p, mp->plen)
				  : "-",
			       mp ? mp->plen : -1, mp ? mp->indev : -1);
			printf("F572 T|brn=%d|brlen=%d|brhex=%s|farn=-1|"
			       "farlen=-1|farhex=-|brdst=%s|brtype=%s|"
			       "fardst=-|bartype=-\n",
			       F572_TAP[0].n, F572_TAP[0].len,
			       F572_TAP[0].len > 0
				       ? f559_hexs(hr, sizeof(hr),
						   F572_TAP[0].b, 20) : "-",
			       F572_TAP[0].len > 0
				       ? f559_hexs(hr, sizeof(hr),
						   F572_TAP[0].b, 6) : "-",
			       F572_TAP[0].len > 13
				       ? f559_hexs(hr, sizeof(hr),
						   F572_TAP[0].b + 12, 2) : "-");
		}
	}
	(void)C;

	/* the reverse: rewrite 86dd -> 0800 is above; now an ip6-only cell
	 * (offset 7) must be refused if the guard still sees ip6 -- and the
	 * same rule with a cell ip6 refuses but ip4 allows is `comp_l2l3`. */
	f572_flush_all();
	f571_nfl_drain(NULL);
	{
		struct f571_cfg N;
		struct f572_rep r0, r;
		unsigned long long c0p, c0s, c1p, c1s;
		int k;

		memset(&r0, 0, sizeof(r0));
		memset(&r, 0, sizeof(r));
		f571_zero(&N, "pre");
		f572_snap(&r0);
		f571_rule(&D572[E_BRP], "pre0", "p", &N, &acks);
		nlh = msg_start(opbuf, (int)sizeof(opbuf),
				(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_NEWRULE,
				NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE |
					NLM_F_APPEND, NFPROTO_BRIDGE);
		put_str(nlh, NFTA_RULE_TABLE, D572[E_BRP].table);
		put_str(nlh, NFTA_RULE_CHAIN, "ch");
		exprs = nest_start(nlh, NFTA_RULE_EXPRESSIONS);
		f565_store(nlh, NFT_PAYLOAD_LL_HEADER, 12, 2, et0800, 0, 0);
		f565_store(nlh, NFT_PAYLOAD_NETWORK_HEADER, 7, 1, A72_N4, 0, 0);
		log_expr(nlh, 5, "s");
		counter_expr(nlh);
		accept_expr(nlh);
		nest_end(nlh, exprs);
		printf("F572 C|arm=comp_h7|rc=%d\n",
		       f557_nft_one(opbuf, (int)nlh->nlmsg_len, &acks));
		c0p = f555_count(NFPROTO_BRIDGE, D572[E_BRP].table, "pre0");
		c0s = f555_count(NFPROTO_BRIDGE, D572[E_BRP].table, "ch");
		f572_u6_drain(&r0);
		pkt_send_p("x0", F572_FR, F572_FRLEN, 0x86dd);
		for (k = 0; k < 12; k++) {
			usleep(120000);
			f572_snap(&r);
			if (r.u6n > r0.u6n || r.i6in > r0.i6in ||
			    r.y0rxp > r0.y0rxp)
				break;
		}
		f572_snap(&r);
		c1p = f555_count(NFPROTO_BRIDGE, D572[E_BRP].table, "pre0");
		c1s = f555_count(NFPROTO_BRIDGE, D572[E_BRP].table, "ch");
		f572_tap_drain(0);
		printf("F572 A|sec=comp|arm=comp_h7|door=brp|mode=9|base=0|"
		       "off=-1|len=-1|imm=-|rcp=0|rcs=0|rcw=-1|sendrc=0|snt=1|"
		       "cntp=%llu|cnts=%llu|cntw=-1|polls=%d|u6n=%d|u6len=%d|"
		       "u6sport=%d\n", c1p - c0p, c1s - c0s, k,
		       r.u6n - r0.u6n, r.u6len, r.u6sport);
		{
			char hr[200];

			printf("F572 T|brn=%d|brlen=%d|brhex=%s|farn=-1|"
			       "farlen=-1|farhex=-|brdst=-|brtype=%s|fardst=-|"
			       "bartype=-\n", F572_TAP[0].n, F572_TAP[0].len,
			       F572_TAP[0].len > 0
				       ? f559_hexs(hr, sizeof(hr),
						   F572_TAP[0].b, 20) : "-",
			       F572_TAP[0].len > 13
				       ? f559_hexs(hr, sizeof(hr),
						   F572_TAP[0].b + 12, 2) : "-");
		}
		printf("F572 N|prelen=-1|pre=-|postlen=-1|postind=-1|posthw=-1|"
		       "prel2=-1|prehw=-1\n");
	}
}


/* ---------- section `diag`: when is the nflog message built? ------------ */

static void f572_sec_diag(void)
{
	struct f571_cfg S, E;

	/* dg1: the store lives in the chain that runs FIRST (prio 10) and logs
	 * as 'p'; the second chain (prio 20) only logs, as 's'. */
	f572_wr(&S, "st", NFT_PAYLOAD_LL_HEADER, 6, 6, A72_NEEDLE);
	f571_zero(&E, "e");
	f572_arm(E_IN6, "diag", "dg1", &S, &E, NULL, 1, 12);

	/* dg2: the store lives in the chain that runs SECOND (prio 20) and logs
	 * as 's'; the first chain only logs, as 'p'. */
	f572_wr(&S, "st", NFT_PAYLOAD_LL_HEADER, 6, 6, A72_NEEDLE);
	f571_zero(&E, "e");
	f572_arm(E_IN6, "diag", "dg2", &E, &S, NULL, 1, 12);
}

/* ---------- main ---------- */

int f572_entry(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "ll3br";
	int rc;

	printf("F572 BEGIN|mode=%s\n", mode);
	rc = f572_env();
	printf("F572 ENVRC|rc=%d\n", rc);
	if (rc)
		return 3;
	rc = f572_chains();
	printf("F572 CHAINS|rc=%d\n", rc);
	if (rc)
		return 4;
	printf("F572 START\n");
	fflush(stdout);

	f572_sec_ref();
	f572_sec_diag();
	f572_sec_rd();
	f572_sec_wr();
	f572_sec_inv();
	f572_sec_comp();

	printf("F572 END\n");
	return 0;
}
/* differ573_add.c -- turn 573 (F51).
 *
 *  THE DEBT (named at the end of 572): a frame flooded to SEVERAL ports -- does
 *  a store at a bridge door reach every copy or only the last, and who shares
 *  the head after __skb_clone()?  Plus: the layer-3 door of a *VLAN-filtering*
 *  bridge.
 *
 *  Mode `flood`: three veth pairs x0/x1, y0/y1, z0/z1, one bridge br0 with the
 *  ports x1, y1, z1, IPv6 enabled on br0 only (fd02::92/128, UDP6 socket on
 *  5000).  Three frames, all IPv6 fd02::11 -> fd02::92, UDP 40000->5000:
 *
 *    A  ethernet broadcast                        (80 bytes)
 *    B  ethernet unicast to br0's MAC             (80 bytes)
 *    C  ethernet broadcast, 802.1Q vid 100        (84 bytes)
 *
 *  Four doors of the same frame:
 *
 *    brp  bridge prerouting  (NF_BR_PRE_ROUTING)  before br_flood() splits it
 *    brf  bridge forward     (NF_BR_FORWARD)      once per port copy
 *    brl  bridge input       (NF_BR_LOCAL_IN)     the local copy only
 *    in6  ip6  prerouting                         the local copy, after br0
 *
 *  Every arm carries a counter+log+accept at prio 0 in all four doors (the
 *  census: how many copies each door sees) and at most one counter+store/read+
 *  log+accept at prio 10 in one door.  Oracles: the doors' own counters, the
 *  NFLOG messages (prefix, indev, outdev, payload = skb->data at that moment),
 *  four AF_PACKET taps opened per arm by a mask (x1 = the ingress port, y0 and
 *  z0 = the ports, br0 = the local copy), the UDP6 socket, the net-wide SNMP6
 *  counters and IFLA_STATS64 (rx_otherhost_dropped) of the ports.
 *
 *  The question the arms answer: a store reaches exactly the copies made AFTER
 *  it, and it is in place or a head copy depending on whether anything cloned
 *  the skb BEFORE it (__skb_clone() marks the source too: skbuff.c:1637).
 *
 *  Every helper below the new code is the one that produced F31..F50.
 */

#define F573_SPORT	40000
#define F573_DPORT	5000
#define F573_TAPN	4
#define F573_NPL	16
#define ND73		4

static const unsigned char A73_SRC[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x11 };
static const unsigned char A73_DST[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x92 };
static const unsigned char A73_BC[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
static const unsigned char A73_N6[6] = { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95 };
/* N7 is never stored into a *source*, so the bridge never learns it: the FDB
 * entry that a source store teaches would turn a later destination store into
 * a known unicast back to the ingress port (measured in smoke a). */
static const unsigned char A73_N7[6] = { 0x90, 0x91, 0x92, 0x93, 0x94, 0x97 };
static const unsigned char A73_ET[2] = { 0x08, 0x06 };
static const unsigned char A73_HL[1] = { 0x90 };

/* ---------- the four doors ---------- */

static struct f571_door D573[] = {
	{ "brp", NFPROTO_BRIDGE, "e73a", NULL, 0, 10, 20 },	/* PRE_ROUTING */
	{ "brf", NFPROTO_BRIDGE, "e73b", NULL, 2, 30, 40 },	/* FORWARD     */
	{ "brl", NFPROTO_BRIDGE, "e73c", NULL, 1, 50, 60 },	/* LOCAL_IN    */
	{ "in6", NFPROTO_IPV6,   "e73d", NULL, 0, 70, 80 },	/* PRE_ROUTING */
};
enum { E73_BRP = 0, E73_BRF, E73_BRL, E73_IN6 };

/* taps: 0 = x1 (ingress port), 1 = y0, 2 = z0, 3 = br0 (the local copy) */
enum { T_X1 = 0, T_Y0, T_Z0, T_BR0 };
#define T_Y0Z0	((1 << T_Y0) | (1 << T_Z0))
#define T_ALL3	((1 << T_Y0) | (1 << T_Z0) | (1 << T_BR0))
#define T_ALL4	((1 << T_X1) | T_ALL3)

struct f573_tap {
	int fd;
	int n;
	int flen;
	int len;
	unsigned char b[112];
};
static struct f573_tap F573_TAP[F573_TAPN];
static const char *F573_TAPDEV[F573_TAPN] = { "x1", "y0", "z0", "br0" };

static unsigned char F573_X0M[6], F573_BRM[6];
static int F573_U6 = -1, F573_NFL = -1;
static unsigned char F573_FA[128], F573_FB[128], F573_FC[128];
static int F573_LA = -1, F573_LB = -1, F573_LC = -1;

/* ---------- /sys helpers ---------- */

static int f573_sysint(const char *path)
{
	FILE *f = fopen(path, "r");
	int v = -2;

	if (!f)
		return -1;
	if (fscanf(f, "%d", &v) != 1)
		v = -3;
	fclose(f);
	return v;
}

static int f573_exists(const char *path)
{
	FILE *f = fopen(path, "r");

	if (!f)
		return 0;
	fclose(f);
	return 1;
}

/* ---------- IFLA_STATS64 (rx_otherhost_dropped lives only here) ---------- */
struct f573_lst {
	unsigned long long rxp, rxb, rxd, other;
	int ok;
};

static unsigned long long f573_u64(const unsigned char *p)
{
	unsigned long long v = 0;
	int i;

	for (i = 7; i >= 0; i--)
		v = (v << 8) | (unsigned long long)p[i];
	return v;
}

#define F573_IFLA_STATS64	23
#define F573_OFF_OTHERHOST	192

static void f573_stats(const char *dev, struct f573_lst *s)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
	} req;
	unsigned char rbuf[8192];
	struct nlmsghdr *nlh;
	struct sockaddr_nl sa;
	int fd, idx = f555_ifindex(dev), r;

	memset(s, 0, sizeof(*s));
	if (idx < 0)
		return;
	fd = socket(AF_NETLINK, SOCK_RAW | SOCK_CLOEXEC, NETLINK_ROUTE);
	if (fd < 0)
		return;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_GETLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST;
	req.nlh.nlmsg_seq = 9;
	req.ifi.ifi_family = AF_UNSPEC;
	req.ifi.ifi_index = idx;
	if (sendto(fd, &req, req.nlh.nlmsg_len, 0, (struct sockaddr *)&sa,
		   sizeof(sa)) < 0) {
		close(fd);
		return;
	}
	r = (int)recv(fd, rbuf, sizeof(rbuf), 0);
	close(fd);
	if (r < (int)(NLMSG_HDRLEN + sizeof(struct ifinfomsg)))
		return;
	nlh = (struct nlmsghdr *)rbuf;
	if (nlh->nlmsg_type == NLMSG_ERROR)
		return;
	{
		const char *p = (const char *)nlh + NLMSG_HDRLEN +
				sizeof(struct ifinfomsg);
		const char *end = (const char *)nlh + nlh->nlmsg_len;

		for (; p + (int)sizeof(struct nlattr) <= end; ) {
			const struct nlattr *a = (const struct nlattr *)p;
			int al = (int)a->nla_len, t;

			if (al < (int)sizeof(*a) || p + al > end)
				break;
			t = a->nla_type & 0x3fff;
			if (t == F573_IFLA_STATS64 &&
			    al - NLA_HDRLEN >= F573_OFF_OTHERHOST + 8) {
				const unsigned char *d =
					(const unsigned char *)a + NLA_HDRLEN;

				s->rxp = f573_u64(d + 0);
				s->rxb = f573_u64(d + 16);
				s->rxd = f573_u64(d + 48);
				s->other = f573_u64(d + F573_OFF_OTHERHOST);
				s->ok = 1;
			}
			p += NLA_ALIGN_(al);
		}
	}
}

/* ---------- NFLOG drain: up to F573_NPL messages with their provenance ---- */

struct f573_msg {
	int plen;
	unsigned char p[96];
	int indev, outdev;
	char prefix[8];
};
struct f573_pl {
	int n;
	struct f573_msg m[F573_NPL];
};

static void f573_nfl_drain(struct f573_pl *v)
{
	unsigned char b[16384];
	int guard = 0, rl;

	if (v)
		memset(v, 0, sizeof(*v));
	if (F573_NFL < 0)
		return;
	while (guard++ < 64) {
		struct nlmsghdr *h;
		int len;

		rl = (int)recv(F573_NFL, b, sizeof(b), MSG_DONTWAIT);
		if (rl <= 0)
			break;
		len = rl;
		for (h = (struct nlmsghdr *)b; NLMSG_OK(h, len);
		     h = NLMSG_NEXT(h, len)) {
			const char *p, *end, *prefix = NULL;
			const unsigned char *pl = NULL;
			int pll = 0, ind = -1, outd = -1;

			if (h->nlmsg_type == NLMSG_DONE ||
			    h->nlmsg_type == NLMSG_ERROR)
				continue;
			p = (const char *)h + NLMSG_HDRLEN +
			    sizeof(struct nfgenmsg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int al = (int)a->nla_len;
				int t;

				if (al < (int)sizeof(*a) || p + al > end)
					break;
				t = a->nla_type & 0x3fff;
				if (t == NFULA_PREFIX_) {
					prefix = (const char *)a + NLA_HDRLEN;
				} else if (t == NFULA_PAYLOAD_) {
					pl = (const unsigned char *)a +
					     NLA_HDRLEN;
					pll = al - NLA_HDRLEN;
				} else if (t == NFULA_IFINDEX_INDEV_) {
					__be32 x;

					memcpy(&x, (const char *)a + NLA_HDRLEN,
					       4);
					ind = (int)ntohl(x);
				} else if (t == NFULA_IFINDEX_OUTDEV_) {
					__be32 x;

					memcpy(&x, (const char *)a + NLA_HDRLEN,
					       4);
					outd = (int)ntohl(x);
				}
				p += NLA_ALIGN_(al);
			}
			if (!v || !prefix || prefix[0] == 0)
				continue;
			if (v->n < F573_NPL) {
				struct f573_msg *M = &v->m[v->n];
				int k;

				snprintf(M->prefix, sizeof(M->prefix), "%s",
					 prefix);
				if (pl) {
					k = pll < (int)sizeof(M->p) ? pll
						     : (int)sizeof(M->p);
					memcpy(M->p, pl, (size_t)k);
					M->plen = k;
				}
				M->indev = ind;
				M->outdev = outd;
			}
			v->n++;
		}
	}
}

/* ---------- the environment ---------- */

static int f573_frame_tag(unsigned char *out, const unsigned char *dmac,
			  const unsigned char *smac)
{
	memset(out, 0, 128);
	memcpy(out, dmac, 6);
	memcpy(out + 6, smac, 6);
	out[12] = 0x81;
	out[13] = 0x00;			/* TPID 802.1Q */
	out[14] = 0x00;			/* priority 0  */
	out[15] = 0x64;			/* vid 100     */
	out[16] = 0x86;			/* inner ethertype */
	out[17] = 0xdd;
	return 18 + f570_ip6(out + 18, A73_SRC, A73_DST, 0, F573_SPORT,
			     F573_DPORT);
}

static int f573_env(void)
{
	f555_sysctl("/proc/sys/net/ipv6/conf/default/disable_ipv6", "1");
	f555_sysctl("/proc/sys/net/ipv6/conf/default/accept_dad", "0");
	if (link_add_veth("x0", "x1") || link_add_veth("y0", "y1") ||
	    link_add_veth("z0", "z1")) {
		printf("F573 FAIL|veth\n");
		return -1;
	}
	if (f556_link_add_kind("br0", "bridge")) {
		printf("F573 FAIL|bridge\n");
		return -1;
	}
	set_up("x0");
	set_up("x1");
	set_up("y0");
	set_up("y1");
	set_up("z0");
	set_up("z1");
	set_up("br0");
	if (mac_get("x0", F573_X0M)) {
		printf("F573 FAIL|mac\n");
		return -1;
	}
	/* ports are enslaved after everything is up, so br_stp_enable_port()
	 * runs and the ports are FORWARDING with no STP */
	printf("F573 REF|port=x1|master=br0|rc=%d\n",
	       f556_link_enslave("x1", "br0"));
	printf("F573 REF|port=y1|master=br0|rc=%d\n",
	       f556_link_enslave("y1", "br0"));
	printf("F573 REF|port=z1|master=br0|rc=%d\n",
	       f556_link_enslave("z1", "br0"));
	/* br0's MAC is recalculated when a port is added, so read it AFTER */
	if (mac_get("br0", F573_BRM)) {
		printf("F573 FAIL|mac_br\n");
		return -1;
	}
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/disable_ipv6", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/accept_dad", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/dad_transmits", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/accept_ra", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/autoconf", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/forwarding", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/drop_unicast_in_l2_multicast",
		    "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0/router_solicitations", "0");
	f555_sysctl("/sys/class/net/br0/bridge/multicast_snooping", "0");
	f555_sysctl("/sys/class/net/br0/bridge/multicast_querier", "0");
	printf("F573 ADDR6|rc=%d\n", f564_addr6("br0", A73_DST, 128));
	F573_U6 = f564_udp_bind(AF_INET6, 0, A73_DST, F573_DPORT);
	F573_NFL = nfl_open(5);
	F571_NFL = F573_NFL;		/* the inherited drain reads F571_NFL */
	F573_LA = f570_frame_plain(F573_FA, A73_BC, F573_X0M, A73_SRC,
				   A73_DST, 0);
	F573_LB = f570_frame_plain(F573_FB, F573_BRM, F573_X0M, A73_SRC,
				   A73_DST, 0);
	F573_LC = f573_frame_tag(F573_FC, A73_BC, F573_X0M);
	{
		char hb[32], hx[32], ha[256], hc[256];

		printf("F573 ENV|u6=%d|nfl=%d|la=%d|lb=%d|lc=%d|br0=%d|x1=%d|"
		       "y0=%d|z0=%d|y1=%d|z1=%d|br0mac=%s|x0mac=%s\n",
		       F573_U6, F573_NFL, F573_LA, F573_LB, F573_LC,
		       f555_ifindex("br0"), f555_ifindex("x1"),
		       f555_ifindex("y0"), f555_ifindex("z0"),
		       f555_ifindex("y1"), f555_ifindex("z1"),
		       f559_hexs(hb, sizeof(hb), F573_BRM, 6),
		       f559_hexs(hx, sizeof(hx), F573_X0M, 6));
		printf("F573 FRM|a=%s\n", f559_hexs(ha, sizeof(ha), F573_FA,
						    F573_LA));
		printf("F573 FRM|c=%s\n", f559_hexs(hc, sizeof(hc), F573_FC,
						    F573_LC));
	}
	/* let the RS/MLD burst of the address come and go */
	usleep(4000000);
	printf("F573 SYS|stp=%d|x1state=%d|y1state=%d|z1state=%d|"
	       "mcsnoop=%d|br0v6=%d|y0v6=%d|z0v6=%d|x1v6=%d|br0mclen=%d|"
	       "vf=%d|vfpath=%d\n",
	       f573_sysint("/sys/class/net/br0/bridge/stp_state"),
	       f573_sysint("/sys/class/net/x1/brport/state"),
	       f573_sysint("/sys/class/net/y1/brport/state"),
	       f573_sysint("/sys/class/net/z1/brport/state"),
	       f573_sysint("/sys/class/net/br0/bridge/multicast_snooping"),
	       f573_sysint("/proc/sys/net/ipv6/conf/br0/disable_ipv6"),
	       f573_sysint("/proc/sys/net/ipv6/conf/y0/disable_ipv6"),
	       f573_sysint("/proc/sys/net/ipv6/conf/z0/disable_ipv6"),
	       f573_sysint("/proc/sys/net/ipv6/conf/x1/disable_ipv6"),
	       f573_sysint("/sys/class/net/br0/mtu"),
	       f573_sysint("/sys/class/net/br0/bridge/vlan_filtering"),
	       f573_exists("/sys/class/net/br0/bridge/vlan_filtering"));
	return 0;
}

static int f573_chains(void)
{
	int i, rc = 0;

	for (i = 0; i < ND73; i++) {
		struct f571_door *D = &D573[i];
		int a, b, c;

		a = add_table(D->fam, D->table);
		b = f556_add_chain(D->fam, D->table, "pre0", D->hook,
				   (uint32_t)D->prio0, 1, D->dev);
		c = f556_add_chain(D->fam, D->table, "ch", D->hook,
				   (uint32_t)D->prio1, 1, D->dev);
		printf("F573 CH|door=%s|fam=%d|hook=%u|table=%d|pre0=%d|ch=%d\n",
		       D->tag, (int)D->fam, D->hook, a, b, c);
		rc |= a | b | c;
	}
	return rc;
}

static void f573_flush_all(void)
{
	int i, acks = 0;

	for (i = 0; i < ND73; i++) {
		f557_flush(D573[i].fam, D573[i].table, "pre0", &acks);
		f557_flush(D573[i].fam, D573[i].table, "ch", &acks);
	}
}

/* ---------- the snapshot ---------- */

struct f573_rep {
	int u6n, u6len, u6sport;
	unsigned long long i6in, i6hdr, i6addr, i6unk, i6trunc, i6nor, i6deliv,
			   i6disc, i6mcast, u6in, u6err, u6nop;
	unsigned long long yrxp, yrxd, yoth, zrxp, zrxd, zoth, brrxp, brrxb,
			   x1rxp;
};

static void f573_u6_drain(struct f573_rep *R)
{
	unsigned char b[1024];
	struct sockaddr_in6 sa;
	socklen_t sl;
	int r;

	if (F573_U6 < 0)
		return;
	for (;;) {
		memset(&sa, 0, sizeof(sa));
		sl = sizeof(sa);
		r = (int)recvfrom(F573_U6, b, sizeof(b), MSG_DONTWAIT,
				  (struct sockaddr *)&sa, &sl);
		if (r < 0)
			break;
		if (!f568_needle(b, r))
			continue;
		R->u6n++;
		R->u6len = r;
		R->u6sport = ntohs(sa.sin6_port);
	}
}

static void f573_snap(struct f573_rep *R)
{
	struct f573_lst s;

	f573_u6_drain(R);
	R->i6in = f564_snmp6("Ip6InReceives");
	R->i6hdr = f564_snmp6("Ip6InHdrErrors");
	R->i6addr = f564_snmp6("Ip6InAddrErrors");
	R->i6unk = f564_snmp6("Ip6InUnknownProtos");
	R->i6trunc = f564_snmp6("Ip6InTruncatedPkts");
	R->i6nor = f564_snmp6("Ip6InNoRoutes");
	R->i6deliv = f564_snmp6("Ip6InDelivers");
	R->i6disc = f564_snmp6("Ip6InDiscards");
	R->i6mcast = f564_snmp6("Ip6InMcastPkts");
	R->u6in = f564_snmp6("Udp6InDatagrams");
	R->u6err = f564_snmp6("Udp6InErrors");
	R->u6nop = f564_snmp6("Udp6NoPorts");
	f573_stats("y0", &s);
	R->yrxp = s.rxp;
	R->yrxd = s.rxd;
	R->yoth = s.other;
	f573_stats("z0", &s);
	R->zrxp = s.rxp;
	R->zrxd = s.rxd;
	R->zoth = s.other;
	f573_stats("br0", &s);
	R->brrxp = s.rxp;
	R->brrxb = s.rxb;
	f573_stats("x1", &s);
	R->x1rxp = s.rxp;
}

/* ---------- settle: no IPv6 chatter from the address setup ---------- */

/* Enabling IPv6 on br0 makes the kernel send RS/MLD, the bridge floods them to
 * every port and each port's ip6_rcv_core counts them (Ip6InReceives before
 * the disable_ipv6 check).  An arm that starts while that burst is still in
 * flight measures the burst, not the frame -- the F569 counter=2 lesson.  Wait
 * until two consecutive snapshots agree on every counter the arms use. */
struct f573_key {
	unsigned long long k[6];
};

static void f573_key_get(struct f573_key *K)
{
	struct f573_rep R;

	memset(&R, 0, sizeof(R));
	f573_snap(&R);
	K->k[0] = R.i6in;
	K->k[1] = R.i6disc;
	K->k[2] = R.yrxp;
	K->k[3] = R.zrxp;
	K->k[4] = R.brrxp;
	K->k[5] = R.u6in;
}

static int f573_settle(void)
{
	struct f573_key a, b;
	int i;

	memset(&a, 0, sizeof(a));
	{
		int stable = 0;

		for (i = 0; i < 30; i++) {
			f573_key_get(&a);
			usleep(300000);
			f573_key_get(&b);
			stable = memcmp(&a, &b, sizeof(a)) ? 0 : stable + 1;
			if (stable >= 3)
				return i + 1;
		}
	}
	return -1;
}

static void f573_tap_close_all(void)
{
	int i;

	for (i = 0; i < F573_TAPN; i++) {
		if (F573_TAP[i].fd >= 0)
			close(F573_TAP[i].fd);
		F573_TAP[i].fd = -1;
		F573_TAP[i].n = 0;
		F573_TAP[i].len = -1;
		F573_TAP[i].flen = -1;
	}
}

static void f573_tap_open_mask(int mask)
{
	int i;

	for (i = 0; i < F573_TAPN; i++) {
		F573_TAP[i].n = 0;
		F573_TAP[i].len = -1;
		F573_TAP[i].flen = -1;
		F573_TAP[i].fd = -1;
		if (!(mask & (1 << i)))
			continue;
		F573_TAP[i].fd = f571_tap_open(F573_TAPDEV[i]);
	}
}

static void f573_tap_drain(int i)
{
	unsigned char b[2048];
	int r;

	F573_TAP[i].n = 0;
	F573_TAP[i].len = -1;
	F573_TAP[i].flen = -1;
	if (F573_TAP[i].fd < 0)
		return;
	while ((r = (int)recv(F573_TAP[i].fd, b, sizeof(b), MSG_DONTWAIT)) >
	       0) {
		int k;

		if (!f568_needle(b, r))
			continue;
		F573_TAP[i].n++;
		if (F573_TAP[i].len < 0) {
			F573_TAP[i].flen = r;
			k = r < (int)sizeof(F573_TAP[i].b) ? r
			    : (int)sizeof(F573_TAP[i].b);
			memcpy(F573_TAP[i].b, b, (size_t)k);
			F573_TAP[i].len = k;
		}
	}
}

/* ---------- one arm ---------- */

/* fk: 0 = frame A, 1 = frame B, 2 = frame C, -1 = no injection.
 * door: index into D573, or -1 for no store/read chain.
 * C == NULL with door >= 0: the ch chain carries only counter+log+accept. */
static void f573_arm(const char *arm, int fk, int tapmask, int door,
		     const struct f571_cfg *C)
{
	struct f571_cfg N;
	struct f573_rep r0, r;
	struct f573_pl pl;
	const unsigned char *fr = NULL;
	int flen = 0, proto = 0x86dd;
	unsigned long long c0[ND73], c1[ND73], s0 = 0, s1 = 0;
	int i, acks = 0, snd = 0, polls = 0, k, maxp = 12, st = -9;
	char hx[64];
	const char *fkn = "A";

	memset(&r0, 0, sizeof(r0));
	memset(&r, 0, sizeof(r));
	f571_zero(&N, "p");
	if (fk == 0) {
		fr = F573_FA;
		flen = F573_LA;
		fkn = "A";
	} else if (fk == 1) {
		fr = F573_FB;
		flen = F573_LB;
		fkn = "B";
	} else if (fk == 2) {
		fr = F573_FC;
		flen = F573_LC;
		proto = 0x8100;
		fkn = "C";
	}
	f573_flush_all();
	f573_nfl_drain(NULL);
	st = f573_settle();
	f573_tap_close_all();
	f573_tap_open_mask(tapmask);
	for (i = 0; i < F573_TAPN; i++)
		if (F573_TAP[i].fd >= 0)
			f573_tap_drain(i);
	/* every arm carries the census: counter+log+accept at prio 0 in all
	 * four doors */
	for (i = 0; i < ND73; i++) {
		char nm[8];

		snprintf(nm, sizeof(nm), "p%d", i);
		if (f571_rule(&D573[i], "pre0", nm, &N, &acks))
			printf("F573 RUFAIL|arm=%s|door=%s|chain=pre0\n", arm,
			       D573[i].tag);
	}
	if (door >= 0) {
		struct f571_cfg Z;

		f571_zero(&Z, "s");
		if (f571_rule(&D573[door], "ch", "s", C ? C : &Z, &acks))
			printf("F573 RUFAIL|arm=%s|door=%s|chain=ch\n", arm,
			       D573[door].tag);
	}
	for (i = 0; i < ND73; i++)
		c0[i] = f555_count(D573[i].fam, D573[i].table, "pre0");
	s0 = door >= 0 ? f555_count(D573[door].fam, D573[door].table, "ch") : 0;
	f573_snap(&r0);		/* the baseline: every delta is against this */
	f573_u6_drain(&r0);
	if (fk >= 0) {
		snd = pkt_send_p("x0", fr, flen, (unsigned short)proto);
		for (k = 0; k < maxp; k++) {
			usleep(120000);
			f573_snap(&r);
			polls++;
			if (r.u6n > r0.u6n || r.i6in > r0.i6in ||
			    r.i6disc > r0.i6disc || r.yrxp > r0.yrxp ||
			    r.zrxp > r0.zrxp || r.brrxp > r0.brrxp)
				break;
		}
	} else {
		usleep(300000);
		polls = 1;
	}
	f573_snap(&r);
	usleep(150000);
	f573_snap(&r);
	for (i = 0; i < ND73; i++)
		c1[i] = f555_count(D573[i].fam, D573[i].table, "pre0");
	s1 = door >= 0 ? f555_count(D573[door].fam, D573[door].table, "ch") : 0;
	memset(&pl, 0, sizeof(pl));
	f573_nfl_drain(&pl);
	for (i = 0; i < F573_TAPN; i++)
		f573_tap_drain(i);

	printf("F573 A|arm=%s|fk=%s|door=%s|mode=%d|base=%u|off=%d|len=%d|"
	       "imm=%s|rcs=%d|snt=%d|sendrc=%d|polls=%d|tapmask=%d|"
	       "u6n=%d|u6len=%d|u6sport=%d|nfl=%d|st=%d\n",
	       arm, fkn, door >= 0 ? D573[door].tag : "-",
	       C ? C->mode : (door >= 0 ? 0 : -1), C ? C->base : 0,
	       C ? C->off : -1, C ? C->len : -1,
	       C ? f559_hexs(hx, sizeof(hx), C->imm, C->len) : "-", acks,
	       fk >= 0, snd, polls, tapmask, r.u6n - r0.u6n, r.u6len, r.u6sport,
	       pl.n, st);
	printf("F573 C|brp=%llu,%lld|brf=%llu,%lld|brl=%llu,%lld|"
	       "in6=%llu,%lld\n",
	       c1[E73_BRP] - c0[E73_BRP],
	       door == E73_BRP ? (long long)(s1 - s0) : -1LL,
	       c1[E73_BRF] - c0[E73_BRF],
	       door == E73_BRF ? (long long)(s1 - s0) : -1LL,
	       c1[E73_BRL] - c0[E73_BRL],
	       door == E73_BRL ? (long long)(s1 - s0) : -1LL,
	       c1[E73_IN6] - c0[E73_IN6],
	       door == E73_IN6 ? (long long)(s1 - s0) : -1LL);
	printf("F573 B|i6in_d=%llu|i6hdr_d=%llu|i6addr_d=%llu|i6unk_d=%llu|"
	       "i6trunc_d=%llu|i6nor_d=%llu|deliv_d=%llu|disc_d=%llu|"
	       "mcas_d=%llu|u6in_d=%llu|u6err_d=%llu|u6nop_d=%llu|"
	       "y0rxp_d=%llu|y0rxd_d=%llu|y0oth_d=%llu|z0rxp_d=%llu|"
	       "z0rxd_d=%llu|z0oth_d=%llu|brrxp_d=%llu|brrxb_d=%llu|"
	       "x1rxp_d=%llu\n",
	       r.i6in - r0.i6in, r.i6hdr - r0.i6hdr, r.i6addr - r0.i6addr,
	       r.i6unk - r0.i6unk, r.i6trunc - r0.i6trunc,
	       r.i6nor - r0.i6nor, r.i6deliv - r0.i6deliv,
	       r.i6disc - r0.i6disc, r.i6mcast - r0.i6mcast,
	       r.u6in - r0.u6in, r.u6err - r0.u6err, r.u6nop - r0.u6nop,
	       r.yrxp - r0.yrxp, r.yrxd - r0.yrxd, r.yoth - r0.yoth,
	       r.zrxp - r0.zrxp, r.zrxd - r0.zrxd, r.zoth - r0.zoth,
	       r.brrxp - r0.brrxp, r.brrxb - r0.brrxb, r.x1rxp - r0.x1rxp);
	{
		char mb[1400];
		int o2 = 0;

		mb[0] = 0;
		for (i = 0; i < pl.n && i < F573_NPL; i++) {
			char hh[220];
			int w = snprintf(mb + o2, sizeof(mb) - (size_t)o2,
					 "|m%d=%s:%d:%d:%d:%s", i,
					 pl.m[i].prefix, pl.m[i].indev,
					 pl.m[i].outdev, pl.m[i].plen,
					 f559_hexs(hh, sizeof(hh), pl.m[i].p,
						   pl.m[i].plen > 42 ? 42
								     : pl.m[i].plen));

			if (w < 0 || w >= (int)sizeof(mb) - o2)
				break;
			o2 += w;
		}
		printf("F573 M|n=%d%s\n", pl.n, mb);
	}
	{
		char tb[1400];
		int o2 = 0;

		tb[0] = 0;
		for (i = 0; i < F573_TAPN; i++) {
			char hh[260];
			int w;

			if (F573_TAP[i].len > 0) {
				w = snprintf(tb + o2, sizeof(tb) - (size_t)o2,
					     "|t%d=%s:%d:%d:%s", i,
					     F573_TAPDEV[i], F573_TAP[i].n,
					     F573_TAP[i].flen,
					     f559_hexs(hh, sizeof(hh),
						       F573_TAP[i].b,
						       F573_TAP[i].len));
			} else {
				w = snprintf(tb + o2, sizeof(tb) - (size_t)o2,
					     "|t%d=%s:%d:%d:-", i,
					     F573_TAPDEV[i], F573_TAP[i].n,
					     F573_TAP[i].flen);
			}
			if (w < 0 || w >= (int)sizeof(tb) - o2)
				break;
			o2 += w;
		}
		printf("F573 T|%s\n", tb[0] ? tb + 1 : tb);
	}
}

/* ---------- config builders ---------- */

static void f573_wr(struct f571_cfg *C, uint32_t base, int off, int len,
		    const unsigned char *imm)
{
	f571_wr(C, "s", base, off, len, imm, 0, 0);
}

static void f573_rdv(struct f571_cfg *C, uint32_t base, int off, int len,
		     const unsigned char *imm)
{
	f571_zero(C, "s");
	C->mode = 3;
	C->base = base;
	C->off = off;
	C->len = len;
	memcpy(C->imm, imm, (size_t)len);
}

/* ---------- sections ---------- */

static void f573_sec_topo(void)
{
	f573_arm("topo", -1, 0, -1, NULL);
}

static void f573_sec_ctl(void)
{
	f573_arm("ctlA", 0, T_Y0Z0 | (1 << T_BR0), -1, NULL);
	f573_arm("ctlX", 0, T_ALL4, -1, NULL);
	f573_arm("uniC", 1, T_Y0Z0 | (1 << T_BR0), -1, NULL);
}

static void f573_sec_pre(void)
{
	struct f571_cfg C;

	f573_wr(&C, NFT_PAYLOAD_LL_HEADER, 6, 6, A73_N6);
	f573_arm("preS", 0, T_Y0Z0 | (1 << T_BR0), E73_BRP, &C);
	f573_arm("preS_x1", 0, T_ALL4, E73_BRP, &C);
	f573_wr(&C, NFT_PAYLOAD_LL_HEADER, 0, 6, A73_N6);
	/* preS just taught the bridge that N6 lives on x1, so this store turns
	 * the frame into a known unicast *back to the ingress port* */
	f573_arm("preD", 0, T_Y0Z0 | (1 << T_BR0), E73_BRP, &C);
	f573_wr(&C, NFT_PAYLOAD_LL_HEADER, 0, 6, A73_N7);
	f573_arm("preD7", 0, T_Y0Z0 | (1 << T_BR0), E73_BRP, &C);
	f573_wr(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, A73_ET);
	f573_arm("preE", 0, T_Y0Z0 | (1 << T_BR0), E73_BRP, &C);
}

static void f573_sec_fwd(void)
{
	struct f571_cfg C;

	f573_wr(&C, NFT_PAYLOAD_LL_HEADER, 6, 6, A73_N6);
	f573_arm("fwdS", 0, T_Y0Z0 | (1 << T_BR0), E73_BRF, &C);
	f573_wr(&C, NFT_PAYLOAD_LL_HEADER, 0, 6, A73_N6);
	f573_arm("fwdD", 0, T_Y0Z0 | (1 << T_BR0), E73_BRF, &C);
	f573_wr(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, A73_ET);
	f573_arm("fwdE", 0, T_Y0Z0 | (1 << T_BR0), E73_BRF, &C);
}

static void f573_sec_local(void)
{
	struct f571_cfg C;

	f573_wr(&C, NFT_PAYLOAD_LL_HEADER, 0, 6, A73_N6);
	f573_arm("in6D", 0, T_Y0Z0 | (1 << T_BR0), E73_IN6, &C);
	f573_arm("in6D_noT", 0, T_Y0Z0, E73_IN6, &C);
	f573_wr(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, A73_ET);
	f573_arm("in6E", 0, T_Y0Z0 | (1 << T_BR0), E73_IN6, &C);
	f573_wr(&C, NFT_PAYLOAD_NETWORK_HEADER, 7, 1, A73_HL);
	f573_arm("brlH", 0, T_Y0Z0 | (1 << T_BR0), E73_BRL, &C);
	/* the same local door on the unicast frame: no flood, so the
	 * instrument's own tap is the only clone before the store */
	f573_wr(&C, NFT_PAYLOAD_LL_HEADER, 0, 6, A73_N6);
	f573_arm("uniD", 1, T_Y0Z0 | (1 << T_BR0), E73_IN6, &C);
	f573_arm("uniD_noT", 1, 0, E73_IN6, &C);
}

/* The VLAN section is deliberately small: CONFIG_BRIDGE_VLAN_FILTERING is not
 * set (see F573 SYS: vfpath=0), so the *named* debt cannot be built here, and a
 * tagged frame on a non-filtering bridge produced, in the smoke, counters that
 * disagree with the bytes the taps saw.  These two arms are recorded as
 * observations with the contradiction named, not as a claim. */
static void f573_sec_vlan(void)
{
	struct f571_cfg C;
	unsigned char v2[2] = { 0x86, 0xdd };

	f573_arm("vlanC", 2, T_Y0Z0 | (1 << T_BR0), -1, NULL);
	/* the inner ethertype would be at 12 if the tag were popped */
	f573_rdv(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, v2);
	f573_arm("vlanR", 2, T_Y0Z0 | (1 << T_BR0), E73_BRP, &C);
}

/* the read machinery of this instrument, proven on a frame we know */
static void f573_sec_rd(void)
{
	struct f571_cfg C;

	f573_rdv(&C, NFT_PAYLOAD_LL_HEADER, 0, 6, A73_BC);
	f573_arm("rdA", 0, T_Y0Z0 | (1 << T_BR0), E73_BRP, &C);
	f573_rdv(&C, NFT_PAYLOAD_LL_HEADER, 0, 6, A73_N7);
	f573_arm("rdAmiss", 0, T_Y0Z0 | (1 << T_BR0), E73_BRP, &C);
}

int f573_entry(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "flood";
	int rc;

	printf("F573 BEGIN|mode=%s\n", mode);
	rc = f573_env();
	printf("F573 ENVRC|rc=%d\n", rc);
	if (rc)
		return 3;
	rc = f573_chains();
	printf("F573 CHAINS|rc=%d\n", rc);
	if (rc)
		return 4;
	printf("F573 START\n");
	fflush(stdout);

	f573_sec_topo();
	f573_sec_ctl();
	f573_sec_pre();
	f573_sec_fwd();
	f573_sec_local();
	f573_sec_rd();
	f573_sec_vlan();

	printf("F573 END\n");
	return 0;
}
/* differ574_add.c -- turn 574 (F52).
 *
 *  THE DEBT (named at the end of 573, §8): a tagged frame on the bridge --
 *  the local copy never reaches the ip6 door although `brl` counts it, and
 *  `@ll,12,2` at the bridge door is not the inner ethertype although the taps
 *  show 86dd at 12..13.  Two questions: what IS the `@ll` domain of a tagged
 *  frame, and what kills the local copy between LOCAL_IN and PRE_ROUTING.
 *
 *  Mode `tag`: the same three-port bridge as F51 (x1/y1/z1 on br0, IPv6 only
 *  on br0).  Five doors of one frame:
 *
 *    brp  bridge prerouting   (NF_BR_PRE_ROUTING)   before br_flood()
 *    brf  bridge forward      (NF_BR_FORWARD)       once per port copy
 *    brl  bridge local-in     (NF_BR_LOCAL_IN)      the local copy
 *    in6  ip6 prerouting      (br0, or br0.100 in group D)
 *    ndy  netdev ingress on y0 (the far end of one port copy)
 *
 *  Frames, all broadcast, IPv6 fd02::11 -> fd02::92, UDP 40000->5000:
 *    A  plain, 86dd at 12..13                                (74+6 bytes)
 *    B  802.1Q TCI 0x0064  (vid 100)                         (78+6 bytes)
 *    C  802.1Q TCI 0x0000  (priority tag, vid 0)             (78+6 bytes)
 *
 *  Groups: S = B with no VLAN device, V = C, D = B with br0.100 up, F = store
 *  at the forward door.  Every arm carries the census (counter+log+accept at
 *  prio 0 in all five doors) and at most one counter+store/read+log+accept at
 *  prio 10 in one door.
 */

#define F574_SPORT	40000
#define F574_DPORT	5000
#define ND74		5

static const unsigned char A74_SRC[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x11 };
static const unsigned char A74_DST[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x92 };
static const unsigned char A74_BC[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
static const unsigned char A74_N6[6] = { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95 };

/* ---------- the five doors ---------- */

static struct f571_door D574[] = {
	{ "brp", NFPROTO_BRIDGE, "e74a", NULL, 0, 10, 20 },	/* PRE_ROUTING */
	{ "brf", NFPROTO_BRIDGE, "e74b", NULL, 2, 30, 40 },	/* FORWARD     */
	{ "brl", NFPROTO_BRIDGE, "e74c", NULL, 1, 50, 60 },	/* LOCAL_IN    */
	{ "in6", NFPROTO_IPV6,   "e74d", NULL, 0, 70, 80 },	/* PRE_ROUTING */
	{ "ndy", NFPROTO_NETDEV, "e74e", "y0", 0, 90, 100 },	/* INGRESS     */
};
enum { E74_BRP = 0, E74_BRF, E74_BRL, E74_IN6, E74_NDY };

#define T_A4	((1 << T_X1) | (1 << T_Y0) | (1 << T_Z0) | (1 << T_BR0))

static unsigned char F574_FA[128], F574_FB[128], F574_FC[128];
static int F574_LA = -1, F574_LB = -1, F574_LC = -1;

/* ---------- a 802.1Q frame: 14 + 4 + IPv6/UDP ---------- */

static int f574_frame_tag(unsigned char *out, const unsigned char *dmac,
			  const unsigned char *smac, unsigned int tci)
{
	memset(out, 0, 128);
	memcpy(out, dmac, 6);
	memcpy(out + 6, smac, 6);
	out[12] = 0x81;
	out[13] = 0x00;			/* TPID 802.1Q */
	out[14] = (unsigned char)((tci >> 8) & 0xff);
	out[15] = (unsigned char)(tci & 0xff);
	out[16] = 0x86;			/* inner ethertype */
	out[17] = 0xdd;
	return 18 + f570_ip6(out + 18, A74_SRC, A74_DST, 0, F574_SPORT,
			     F574_DPORT);
}

/* ---------- the VLAN device (group D) ---------- */

#define F574_IFLA_VLAN_ID	1

static int f574_link_add_vlan(const char *name, const char *link,
			      unsigned short vid)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[256];
	} req;
	struct nlattr *li, *data;
	uint32_t lidx = (uint32_t)f555_ifindex(link);
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, name, (int)strlen(name) + 1);
	attr_put(&req.nlh, IFLA_LINK, &lidx, 4);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, "vlan", 5);
	data = nest_start(&req.nlh, IFLA_INFO_DATA);
	attr_put(&req.nlh, F574_IFLA_VLAN_ID, &vid, 2);
	nest_end(&req.nlh, data);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

/* ---------- environment: F51's bridge plus the three frames ---------- */

static int f574_env(void)
{
	int rc = f573_env();
	char ha[256], hb[256], hc[256];

	printf("F574 ENVRC|f573=%d\n", rc);
	if (rc)
		return rc;
	F574_LA = f570_frame_plain(F574_FA, A74_BC, F573_X0M, A74_SRC,
				   A74_DST, 0);
	F574_LB = f574_frame_tag(F574_FB, A74_BC, F573_X0M, 0x0064);
	F574_LC = f574_frame_tag(F574_FC, A74_BC, F573_X0M, 0x0000);
	printf("F574 FRM|a=%s\n", f559_hexs(ha, sizeof(ha), F574_FA, F574_LA));
	printf("F574 FRM|b=%s\n", f559_hexs(hb, sizeof(hb), F574_FB, F574_LB));
	printf("F574 FRM|c=%s\n", f559_hexs(hc, sizeof(hc), F574_FC, F574_LC));
	printf("F574 ENV|la=%d|lb=%d|lc=%d|x0mac=%s|br0mac=%s|br0=%d|x1=%d|"
	       "y0=%d|z0=%d|u6=%d|nfl=%d\n",
	       F574_LA, F574_LB, F574_LC,
	       f559_hexs(ha, sizeof(ha), F573_X0M, 6),
	       f559_hexs(hb, sizeof(hb), F573_BRM, 6),
	       f555_ifindex("br0"), f555_ifindex("x1"), f555_ifindex("y0"),
	       f555_ifindex("z0"), F573_U6, F573_NFL);
	return 0;
}

static int f574_chains(void)
{
	int i, rc = 0;

	for (i = 0; i < ND74; i++) {
		struct f571_door *D = &D574[i];
		int a, b, c;

		a = add_table(D->fam, D->table);
		b = f556_add_chain(D->fam, D->table, "pre0", D->hook,
				   (uint32_t)D->prio0, 1, D->dev);
		c = f556_add_chain(D->fam, D->table, "ch", D->hook,
				   (uint32_t)D->prio1, 1, D->dev);
		printf("F574 CH|door=%s|fam=%d|hook=%u|dev=%s|table=%d|"
		       "pre0=%d|ch=%d\n", D->tag, (int)D->fam, D->hook,
		       D->dev ? D->dev : "-", a, b, c);
		rc |= a | b | c;
	}
	return rc;
}

static void f574_flush_all(void)
{
	int i, acks = 0;

	for (i = 0; i < ND74; i++) {
		f557_flush(D574[i].fam, D574[i].table, "pre0", &acks);
		f557_flush(D574[i].fam, D574[i].table, "ch", &acks);
	}
}

/* ---------- the snapshot: F51's plus br0's OTHERHOST counter ---------- */

struct f574_rep {
	struct f573_rep b;
	unsigned long long broth, brrxd;
};

static void f574_snap(struct f574_rep *R)
{
	struct f573_lst s;

	f573_snap(&R->b);
	f573_stats("br0", &s);
	R->broth = s.other;
	R->brrxd = s.rxd;
}

/* ---------- one arm ---------- */

static void f574_arm2(const char *arm, int fk, int tapmask, int door,
		      const struct f571_cfg *C, int door2,
		      const struct f571_cfg *C2);

static void f574_arm(const char *arm, int fk, int tapmask, int door,
		     const struct f571_cfg *C)
{
	f574_arm2(arm, fk, tapmask, door, C, -1, NULL);
}

static void f574_arm2(const char *arm, int fk, int tapmask, int door,
		      const struct f571_cfg *C, int door2,
		      const struct f571_cfg *C2)
{
	struct f571_cfg N, Z;
	struct f574_rep r0, r;
	struct f573_pl pl;
	const unsigned char *fr = NULL;
	int flen = 0, proto = 0x8100;
	unsigned long long c0[ND74], c1[ND74], s0 = 0, s1 = 0, s2 = 0, s20 = 0;
	int i, acks = 0, snd = 0, polls = 0, k, maxp = 12, st = -9, rcs = -99;
	int rcs2 = -99;
	char hx[64];
	const char *fkn = "A";

	memset(&r0, 0, sizeof(r0));
	memset(&r, 0, sizeof(r));
	f571_zero(&N, "p");
	if (fk == 0) {
		fr = F574_FA;
		flen = F574_LA;
		proto = 0x86dd;
		fkn = "A";
	} else if (fk == 1) {
		fr = F574_FB;
		flen = F574_LB;
		fkn = "B";
	} else if (fk == 2) {
		fr = F574_FC;
		flen = F574_LC;
		fkn = "C";
	}
	f574_flush_all();
	f573_nfl_drain(NULL);
	st = f573_settle();
	f573_tap_close_all();
	f573_tap_open_mask(tapmask);
	for (i = 0; i < F573_TAPN; i++)
		if (F573_TAP[i].fd >= 0)
			f573_tap_drain(i);
	for (i = 0; i < ND74; i++) {
		char nm[8];

		snprintf(nm, sizeof(nm), "p%d", i);
		if (f571_rule(&D574[i], "pre0", nm, &N, &acks))
			printf("F574 RUFAIL|arm=%s|door=%s|chain=pre0\n", arm,
			       D574[i].tag);
	}
	if (door >= 0) {
		f571_zero(&Z, "s");
		rcs = f571_rule(&D574[door], "ch", "s", C ? C : &Z, &acks);
	}
	if (door2 >= 0) {
		f571_zero(&Z, "q");
		rcs2 = f571_rule(&D574[door2], "ch", "q",
				 C2 ? C2 : &Z, &acks);
	}
	for (i = 0; i < ND74; i++)
		c0[i] = f555_count(D574[i].fam, D574[i].table, "pre0");
	s0 = door >= 0 ? f555_count(D574[door].fam, D574[door].table, "ch") : 0;
	s20 = door2 >= 0 ? f555_count(D574[door2].fam, D574[door2].table, "ch")
			 : 0;
	f574_snap(&r0);
	f573_u6_drain(&r0.b);
	if (fk >= 0) {
		snd = pkt_send_p("x0", fr, flen, (unsigned short)proto);
		for (k = 0; k < maxp; k++) {
			usleep(120000);
			f574_snap(&r);
			polls++;
			if (r.b.u6n > r0.b.u6n || r.b.i6in > r0.b.i6in ||
			    r.b.i6disc > r0.b.i6disc || r.b.yrxp > r0.b.yrxp ||
			    r.b.zrxp > r0.b.zrxp || r.b.brrxp > r0.b.brrxp ||
			    r.broth > r0.broth)
				break;
		}
	} else {
		usleep(300000);
		polls = 1;
	}
	f574_snap(&r);
	usleep(150000);
	f574_snap(&r);
	for (i = 0; i < ND74; i++)
		c1[i] = f555_count(D574[i].fam, D574[i].table, "pre0");
	s1 = door >= 0 ? f555_count(D574[door].fam, D574[door].table, "ch") : 0;
	s2 = door2 >= 0 ? f555_count(D574[door2].fam, D574[door2].table, "ch")
		       : 0;
	memset(&pl, 0, sizeof(pl));
	f573_nfl_drain(&pl);
	for (i = 0; i < F573_TAPN; i++)
		f573_tap_drain(i);

	printf("F574 A|arm=%s|fk=%s|door=%s|d2=%s|mode=%d|base=%u|off=%d|"
	       "len=%d|imm=%s|rcs=%d|rcs2=%d|snt=%d|sendrc=%d|polls=%d|"
	       "tapmask=%d|u6n=%d|u6len=%d|u6sport=%d|nfl=%d|st=%d\n",
	       arm, fkn, door >= 0 ? D574[door].tag : "-",
	       door2 >= 0 ? D574[door2].tag : "-",
	       C ? C->mode : (door >= 0 ? 0 : -1), C ? C->base : 0,
	       C ? C->off : -1, C ? C->len : -1,
	       C ? f559_hexs(hx, sizeof(hx), C->imm, C->len) : "-", rcs, rcs2,
	       fk >= 0, snd, polls, tapmask, r.b.u6n - r0.b.u6n, r.b.u6len,
	       r.b.u6sport, pl.n, st);
	printf("F574 C|brp=%llu,%lld|brf=%llu,%lld|brl=%llu,%lld|"
	       "in6=%llu,%lld|ndy=%llu,%lld|c2=%lld\n",
	       c1[E74_BRP] - c0[E74_BRP],
	       door == E74_BRP ? (long long)(s1 - s0) : -1LL,
	       c1[E74_BRF] - c0[E74_BRF],
	       door == E74_BRF ? (long long)(s1 - s0) : -1LL,
	       c1[E74_BRL] - c0[E74_BRL],
	       door == E74_BRL ? (long long)(s1 - s0) : -1LL,
	       c1[E74_IN6] - c0[E74_IN6],
	       door == E74_IN6 ? (long long)(s1 - s0) : -1LL,
	       c1[E74_NDY] - c0[E74_NDY],
	       door == E74_NDY ? (long long)(s1 - s0) : -1LL,
	       door2 >= 0 ? (long long)(s2 - s20) : -1LL);
	printf("F574 B|i6in_d=%llu|i6hdr_d=%llu|i6addr_d=%llu|i6unk_d=%llu|"
	       "i6trunc_d=%llu|i6nor_d=%llu|deliv_d=%llu|disc_d=%llu|"
	       "mcas_d=%llu|u6in_d=%llu|u6err_d=%llu|u6nop_d=%llu|"
	       "y0rxp_d=%llu|y0oth_d=%llu|z0rxp_d=%llu|z0oth_d=%llu|"
	       "brrxp_d=%llu|brrxb_d=%llu|broth_d=%llu|brrxd_d=%llu|"
	       "x1rxp_d=%llu\n",
	       r.b.i6in - r0.b.i6in, r.b.i6hdr - r0.b.i6hdr,
	       r.b.i6addr - r0.b.i6addr, r.b.i6unk - r0.b.i6unk,
	       r.b.i6trunc - r0.b.i6trunc, r.b.i6nor - r0.b.i6nor,
	       r.b.i6deliv - r0.b.i6deliv, r.b.i6disc - r0.b.i6disc,
	       r.b.i6mcast - r0.b.i6mcast, r.b.u6in - r0.b.u6in,
	       r.b.u6err - r0.b.u6err, r.b.u6nop - r0.b.u6nop,
	       r.b.yrxp - r0.b.yrxp, r.b.yoth - r0.b.yoth,
	       r.b.zrxp - r0.b.zrxp, r.b.zoth - r0.b.zoth,
	       r.b.brrxp - r0.b.brrxp, r.b.brrxb - r0.b.brrxb,
	       r.broth - r0.broth, r.brrxd - r0.brrxd,
	       r.b.x1rxp - r0.b.x1rxp);
	{
		char mb[1400];
		int o2 = 0;

		mb[0] = 0;
		for (i = 0; i < pl.n && i < F573_NPL; i++) {
			char hh[220];
			int w = snprintf(mb + o2, sizeof(mb) - (size_t)o2,
					 "|m%d=%s:%d:%d:%d:%s", i,
					 pl.m[i].prefix, pl.m[i].indev,
					 pl.m[i].outdev, pl.m[i].plen,
					 f559_hexs(hh, sizeof(hh), pl.m[i].p,
						   pl.m[i].plen > 42 ? 42
								     : pl.m[i].plen));

			if (w < 0 || w >= (int)sizeof(mb) - o2)
				break;
			o2 += w;
		}
		printf("F574 M|n=%d%s\n", pl.n, mb);
	}
	{
		char tb[1400];
		int o2 = 0;

		tb[0] = 0;
		for (i = 0; i < F573_TAPN; i++) {
			char hh[260];
			int w;

			if (F573_TAP[i].len > 0) {
				w = snprintf(tb + o2, sizeof(tb) - (size_t)o2,
					     "|t%d=%s:%d:%d:%s", i,
					     F573_TAPDEV[i], F573_TAP[i].n,
					     F573_TAP[i].flen,
					     f559_hexs(hh, sizeof(hh),
						       F573_TAP[i].b,
						       F573_TAP[i].len));
			} else {
				w = snprintf(tb + o2, sizeof(tb) - (size_t)o2,
					     "|t%d=%s:%d:%d:-", i,
					     F573_TAPDEV[i], F573_TAP[i].n,
					     F573_TAP[i].flen);
			}
			if (w < 0 || w >= (int)sizeof(tb) - o2)
				break;
			o2 += w;
		}
		printf("F574 T|%s\n", tb[0] ? tb + 1 : tb);
	}
}

/* ---------- config builders ---------- */

static void f574_wr(struct f571_cfg *C, uint32_t base, int off, int len,
		    const unsigned char *imm)
{
	f571_wr(C, "s", base, off, len, imm, 0, 0);
}

static void f574_rdv(struct f571_cfg *C, uint32_t base, int off, int len,
		     const unsigned char *imm)
{
	f571_zero(C, "s");
	C->mode = 3;
	C->base = base;
	C->off = off;
	C->len = len;
	memcpy(C->imm, imm, (size_t)len);
}

/* ---------- sections ---------- */

static void f574_sec_topo(void)
{
	f574_arm("topo", -1, 0, -1, NULL);
}

/* S: the tagged frame with vid 100 and no VLAN device */
static void f574_sec_s(void)
{
	struct f571_cfg C;
	unsigned char b12[2] = { 0x81, 0x00 };
	unsigned char i12[2] = { 0x86, 0xdd };
	unsigned char t14[2] = { 0x00, 0x64 };
	unsigned char i16[2] = { 0x86, 0xdd };
	unsigned char v18[2] = { 0x60, 0x00 };
	unsigned char p4[4] = { 0x60, 0x00, 0x00, 0x00 };
	unsigned char hl[1] = { 0x40 };
	unsigned char z14[2] = { 0x00, 0x00 };
	unsigned char z4[4] = { 0x00, 0x00, 0x00, 0x00 };
	unsigned char et[2] = { 0x08, 0x06 };
	unsigned char v4[2] = { 0x08, 0x00 };

	f574_arm("c100", 1, T_A4, -1, NULL);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 0, 6, A74_BC);
	f574_arm("r0", 1, T_A4, E74_BRP, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 6, 6, F573_X0M);
	f574_arm("r6", 1, T_A4, E74_BRP, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, b12);
	f574_arm("r12t", 1, T_A4, E74_BRP, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, i12);
	f574_arm("r12i", 1, T_A4, E74_BRP, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, t14);
	f574_arm("r14", 1, T_A4, E74_BRP, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, i16);
	f574_arm("r16", 1, T_A4, E74_BRP, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 18, 2, v18);
	f574_arm("r18", 1, T_A4, E74_BRP, &C);
	f574_rdv(&C, NFT_PAYLOAD_NETWORK_HEADER, 7, 1, hl);
	f574_arm("nh7", 1, T_A4, E74_BRP, &C);
	f574_rdv(&C, NFT_PAYLOAD_NETWORK_HEADER, 0, 4, p4);
	f574_arm("nh0", 1, T_A4, E74_BRP, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, i16);
	f574_arm("brl16", 1, T_A4, E74_BRL, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, t14);
	f574_arm("ndy14", 1, T_A4, E74_NDY, &C);
	f574_wr(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, t14);
	f574_arm("w14_same", 1, T_A4, E74_BRP, &C);
	f574_wr(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, z14);
	f574_arm("w14_0", 1, T_A4, E74_BRP, &C);
	f574_wr(&C, NFT_PAYLOAD_LL_HEADER, 14, 4, z4);
	f574_arm("w14_len4", 1, T_A4, E74_BRP, &C);
	f574_wr(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, et);
	f574_arm("w12_p", 1, T_A4, E74_BRP, &C);
	f574_wr(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, v4);
	f574_arm("w16", 1, T_A4, E74_BRP, &C);
	f574_wr(&C, NFT_PAYLOAD_LL_HEADER, 0, 6, A74_N6);
	f574_arm("w0d", 1, T_A4, E74_BRP, &C);
	/* offset 12 with len 4: `struct vlan_ethhdr` has h_vlan_proto at 12 and
	 * h_vlan_TCI at 14, so this one expression can set both at once */
	f574_wr(&C, NFT_PAYLOAD_LL_HEADER, 12, 4, z4);
	f574_arm("w12_4", 1, T_A4, E74_BRP, &C);
}

/* F: the same store at the forward door -- once per port copy */
static void f574_sec_f(void)
{
	struct f571_cfg C;
	unsigned char z14[2] = { 0x00, 0x00 };

	f574_wr(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, z14);
	f574_arm("wf14", 1, T_A4, E74_BRF, &C);
	/* the same store at the forward door, with the far end asked what TCI it
	 * received: the store on a clone must reach that clone and no other */
	f574_arm2("wf14_ndy", 1, T_A4, E74_BRF, &C, E74_NDY, &C);
}

/* V: the priority tag (vid 0) -- same bytes, different vid */
static void f574_sec_v(void)
{
	struct f571_cfg C;
	unsigned char t100[2] = { 0x00, 0x64 };

	f574_arm("c0", 2, T_A4, -1, NULL);
	f574_wr(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, t100);
	f574_arm("w14_100", 2, T_A4, E74_BRP, &C);
}

/* D: the same frame with a VLAN device on br0 -- mechanism, not correlation */
static void f574_sec_d(void)
{
	struct f571_cfg C;
	unsigned char i16[2] = { 0x86, 0xdd };
	unsigned char b12[2] = { 0x81, 0x00 };
	unsigned char i12[2] = { 0x86, 0xdd };
	unsigned char v14[2] = { 0x60, 0x00 };
	unsigned char l16[2] = { 0x00, 0x00 };
	unsigned char l16o[2] = { 0x00, 0x1a };
	unsigned char n18[2] = { 0x00, 0x1a };
	int rc;

	rc = f574_link_add_vlan("br0.100", "br0", 100);
	printf("F574 VLANDEV|name=br0.100|link=br0|vid=100|rc=%d\n", rc);
	set_up("br0.100");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0.100/disable_ipv6", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0.100/accept_dad", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0.100/dad_transmits", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0.100/accept_ra", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0.100/autoconf", "0");
	f555_sysctl("/proc/sys/net/ipv6/conf/br0.100/forwarding", "0");
	printf("F574 VDSYS|idx=%d|v6=%d\n", f555_ifindex("br0.100"),
	       f573_sysint("/proc/sys/net/ipv6/conf/br0.100/disable_ipv6"));
	usleep(2000000);
	f573_settle();
	f574_arm("vd_c", 1, T_A4, -1, NULL);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, i16);
	f574_arm("vd_r16i", 1, T_A4, E74_IN6, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, b12);
	f574_arm("vd_r12", 1, T_A4, E74_IN6, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, i12);
	f574_arm("vd_r12i", 1, T_A4, E74_IN6, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, v14);
	f574_arm("vd_r14", 1, T_A4, E74_IN6, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, l16);
	f574_arm("vd_r16", 1, T_A4, E74_IN6, &C);
	/* the same offset with the value the TAGGED layout puts there */
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, l16o);
	f574_arm("vd_r16old", 1, T_A4, E74_IN6, &C);
	f574_rdv(&C, NFT_PAYLOAD_LL_HEADER, 18, 2, n18);
	f574_arm("vd_r18", 1, T_A4, E74_IN6, &C);
	/* and the vid-0 frame through the same device: the tag is gone for every
	 * vid, so the LL domain does not depend on the vid here */
	f574_arm("vd_c0", 2, T_A4, -1, NULL);
}

int f574_entry(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "tag";
	int rc;

	printf("F574 BEGIN|mode=%s\n", mode);
	rc = f574_env();
	if (rc)
		return 3;
	rc = f574_chains();
	printf("F574 CHAINS|rc=%d\n", rc);
	if (rc)
		return 4;
	printf("F574 START\n");
	fflush(stdout);

	f574_sec_topo();
	f574_sec_s();
	f574_sec_f();
	f574_sec_v();
	f574_sec_d();

	printf("F574 END\n");
	return 0;
}
/* differ575_add.c -- turn 575 (F53).
 *
 *  THE QUESTION (named at the end of 574): VLAN_FLAG_REORDER_HDR, cleared from
 *  userspace, is the one configuration in this family where the kernel puts the
 *  tag BACK into the frame between vlan_do_receive() and the hook -- so it is
 *  the one place where `@ll` should read a physically tagged frame at a
 *  layer-3 door.
 *
 *  Mode `reorder`: F51's three-port bridge (br0 with x1/y1/z1, IPv6 only on
 *  br0, fd02::92 on br0, UDP6 socket on 5000) plus four VLAN devices on top of
 *  br0:
 *
 *    br0.100      8100 vid 100  flags default (REORDER_HDR set)   control
 *    br0.101      8100 vid 101  flags cleared (flags=0, mask=1)   the question
 *    br0.102      88a8 vid 102  flags cleared                     QinQ outer
 *    br0.102.200  8100 vid 200  flags default                     QinQ inner
 *
 *  Two doors:
 *    g6  ip6 prerouting, all devices     (the door of F52's group D; which
 *        device delivered the frame is NFULA_IFINDEX_INDEV of its message --
 *        a device-specific ip6 chain is refused with -EOPNOTSUPP)
 *    n1  netdev ingress, x1              (the tag is still metadata here)
 *
 *  Frames, all broadcast, IPv6 fd02::11 -> fd02::92, UDP 42000 -> 5000:
 *    A  plain                                             (74 + 18)
 *    B  8100 vid 100                                      (78 + 18)
 *    E  8100 vid 101                                      (78 + 18)
 *    Q  88a8 vid 102 + 8100 vid 200                       (82 + 18)
 *
 *  Every arm carries the census (counter+log+accept at prio0 in both doors)
 *  and at most one counter+store/read+log+accept rule at prio1 in one door.
 */

#define F575_SPORT	42000
#define F575_DPORT	F573_DPORT

static const unsigned char A75_SRC[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00,
					   0x11 };
static const unsigned char A75_DST[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00,
					   0x92 };
static const unsigned char A75_N6[6] = { 0x90, 0x91, 0x92, 0x93, 0x94, 0x95 };

/* ---------- the five doors ---------- */

/* ip6 chains take no NFTA_HOOK_DEV in this kernel (the CREATE returns
 * -EOPNOTSUPP -- measured in the first smoke), so the layer-3 door is one
 * chain for all devices and the device is read from NFULA_IFINDEX_INDEV. */
static struct f571_door D575[] = {
	{ "g6", NFPROTO_IPV6,   "e75a", NULL, 0, 210, 220 },
	{ "n1", NFPROTO_NETDEV, "e75e", "x1", 0, 290, 300 },
};
enum { E75_G6 = 0, E75_N1 };
#define ND75 2

/* ---------- taps on the VLAN devices (the state the user sees) ---------- */

#define F575_TAPN	3
struct f575_tap {
	int fd;
	int n;
	int flen;
	int len;
	unsigned char b[128];
};
static struct f575_tap F575_TAP[F575_TAPN];
static const char *F575_TAPDEV[F575_TAPN] = { "br0.100", "br0.101",
					      "br0.102.200" };
#define T575_A	(1 << 0)
#define T575_B	(1 << 1)
#define T575_Q	(1 << 2)
#define T575_AB	(T575_A | T575_B)
#define T575_ALL3 (T575_A | T575_B | T575_Q)

static void f575_tap_reset(void)
{
	int i;

	for (i = 0; i < F575_TAPN; i++) {
		if (F575_TAP[i].fd >= 0)
			close(F575_TAP[i].fd);
		F575_TAP[i].fd = -1;
		F575_TAP[i].n = 0;
		F575_TAP[i].len = -1;
		F575_TAP[i].flen = -1;
	}
}

static void f575_tap_open_mask(int mask)
{
	int i;

	f575_tap_reset();
	for (i = 0; i < F575_TAPN; i++) {
		if (!(mask & (1 << i)))
			continue;
		F575_TAP[i].fd = f571_tap_open(F575_TAPDEV[i]);
	}
}

static void f575_tap_drain(int i)
{
	unsigned char b[2048];
	int r;

	F575_TAP[i].n = 0;
	F575_TAP[i].len = -1;
	F575_TAP[i].flen = -1;
	if (F575_TAP[i].fd < 0)
		return;
	while ((r = (int)recv(F575_TAP[i].fd, b, sizeof(b), MSG_DONTWAIT)) >
	       0) {
		int k;

		if (!f568_needle(b, r))
			continue;
		F575_TAP[i].n++;
		if (F575_TAP[i].len < 0) {
			F575_TAP[i].flen = r;
			k = r < (int)sizeof(F575_TAP[i].b) ? r
			    : (int)sizeof(F575_TAP[i].b);
			memcpy(F575_TAP[i].b, b, (size_t)k);
			F575_TAP[i].len = k;
		}
	}
}

/* ---------- NFLOG drain with the hardware header and the vlan tag ---------- */

#define F575_NPL	16

struct f575_msg {
	char prefix[8];
	int indev, outdev;
	int hwtype, hwlen;
	int hlen;
	unsigned char h[32];
	int llen;
	unsigned char l[24];
	int vpresent, vproto, vtci;
	int plen;
	unsigned char p[96];
	char atrs[160];
};
struct f575_pl {
	int n;
	struct f575_msg m[F575_NPL];
};

#define F575_NFULA_HWTYPE	15
#define F575_NFULA_HWHEADER	16
#define F575_NFULA_HWLEN	17
#define F575_NFULA_VLAN		20
#define F575_NFULA_L2HDR	21
#define F575_NFULA_VLAN_PROTO	1
#define F575_NFULA_VLAN_TCI	2

static int f575_be16(const void *p)
{
	const unsigned char *b = (const unsigned char *)p;

	return ((int)b[0] << 8) | (int)b[1];
}

static void f575_nfl_drain(struct f575_pl *v)
{
	unsigned char b[16384];
	int guard = 0, rl;

	if (v)
		memset(v, 0, sizeof(*v));
	if (F573_NFL < 0)
		return;
	while (guard++ < 64) {
		struct nlmsghdr *h;
		int len;

		rl = (int)recv(F573_NFL, b, sizeof(b), MSG_DONTWAIT);
		if (rl <= 0)
			break;
		len = rl;
		for (h = (struct nlmsghdr *)b; NLMSG_OK(h, len);
		     h = NLMSG_NEXT(h, len)) {
			const char *p, *end, *prefix = NULL;
			const unsigned char *pl = NULL, *hw = NULL, *l2 = NULL;
			int pll = 0, hwl = 0, l2l = 0, ind = -1, outd = -1;
			int hwt = -1, hwln = -1, vp = 0, vpr = -1, vtc = -1;

			if (h->nlmsg_type == NLMSG_DONE ||
			    h->nlmsg_type == NLMSG_ERROR)
				continue;
			p = (const char *)h + NLMSG_HDRLEN +
			    sizeof(struct nfgenmsg);
			end = (const char *)h + h->nlmsg_len;
			for (; p + (int)sizeof(struct nlattr) <= end; ) {
				const struct nlattr *a = (const struct nlattr *)p;
				int al = (int)a->nla_len;
				int t;

				if (al < (int)sizeof(*a) || p + al > end)
					break;
				t = a->nla_type & 0x3fff;
				if (t == NFULA_PREFIX_) {
					prefix = (const char *)a + NLA_HDRLEN;
				} else if (t == NFULA_PAYLOAD_) {
					pl = (const unsigned char *)a +
					     NLA_HDRLEN;
					pll = al - NLA_HDRLEN;
				} else if (t == NFULA_IFINDEX_INDEV_) {
					__be32 x;

					memcpy(&x, (const char *)a + NLA_HDRLEN,
					       4);
					ind = (int)ntohl(x);
				} else if (t == NFULA_IFINDEX_OUTDEV_) {
					__be32 x;

					memcpy(&x, (const char *)a + NLA_HDRLEN,
					       4);
					outd = (int)ntohl(x);
				} else if (t == F575_NFULA_HWTYPE) {
					hwt = f575_be16((const char *)a +
							NLA_HDRLEN);
				} else if (t == F575_NFULA_HWLEN) {
					hwln = f575_be16((const char *)a +
							 NLA_HDRLEN);
				} else if (t == F575_NFULA_HWHEADER) {
					hw = (const unsigned char *)a +
					     NLA_HDRLEN;
					hwl = al - NLA_HDRLEN;
				} else if (t == F575_NFULA_L2HDR) {
					l2 = (const unsigned char *)a +
					     NLA_HDRLEN;
					l2l = al - NLA_HDRLEN;
				} else if (t == F575_NFULA_VLAN) {
					const char *q = (const char *)a +
							NLA_HDRLEN;
					const char *qend = (const char *)a + al;

					vp = 1;
					for (; q + (int)sizeof(struct nlattr)
					       <= qend; ) {
						const struct nlattr *b2 =
							(const struct nlattr *)q;
						int bl = (int)b2->nla_len;
						int bt;

						if (bl < (int)sizeof(*b2) ||
						    q + bl > qend)
							break;
						bt = b2->nla_type & 0x3fff;
						if (bt == F575_NFULA_VLAN_TCI)
							vtc = f575_be16(q +
								NLA_HDRLEN);
						else if (bt ==
							 F575_NFULA_VLAN_PROTO)
							vpr = f575_be16(q +
								NLA_HDRLEN);
						q += NLA_ALIGN_(bl);
					}
				}
				p += NLA_ALIGN_(al);
			}
			if (!v || !prefix || prefix[0] == 0)
				continue;
			if (v->n < F575_NPL) {
				struct f575_msg *M = &v->m[v->n];
				int k;

				{
					const char *q = (const char *)h + NLMSG_HDRLEN +
							sizeof(struct nfgenmsg);
					int o2 = 0;

					M->atrs[0] = 0;
					while (q + (int)sizeof(struct nlattr) <= end &&
					       o2 < (int)sizeof(M->atrs) - 16) {
						const struct nlattr *a2 =
							(const struct nlattr *)q;
						int al2 = (int)a2->nla_len;

						if (al2 < (int)sizeof(*a2) ||
						    q + al2 > end)
							break;
						o2 += snprintf(M->atrs + o2,
							       sizeof(M->atrs) - (size_t)o2,
							       "%d:%d,",
							       a2->nla_type & 0x3fff,
							       al2 - NLA_HDRLEN);
						q += NLA_ALIGN_(al2);
					}
				}

				snprintf(M->prefix, sizeof(M->prefix), "%s",
					 prefix);
				if (pl) {
					k = pll < (int)sizeof(M->p) ? pll
						     : (int)sizeof(M->p);
					memcpy(M->p, pl, (size_t)k);
					M->plen = k;
				}
				if (hw) {
					k = hwl < (int)sizeof(M->h) ? hwl
						   : (int)sizeof(M->h);
					memcpy(M->h, hw, (size_t)k);
					M->hlen = k;
				}
				if (l2) {
					k = l2l < (int)sizeof(M->l) ? l2l
						   : (int)sizeof(M->l);
					memcpy(M->l, l2, (size_t)k);
					M->llen = k;
				}
				M->indev = ind;
				M->outdev = outd;
				M->hwtype = hwt;
				M->hwlen = hwln;
				M->vpresent = vp;
				M->vproto = vpr;
				M->vtci = vtc;
			}
			v->n++;
		}
	}
}

/* ---------- the VLAN devices ---------- */

#define F575_IFLA_VLAN_ID	1
#define F575_IFLA_VLAN_FLAGS	2
#define F575_IFLA_VLAN_PROTOCOL	5

/* proto == 0: leave the kernel default (0x8100).  clear_reorder: send
 * IFLA_VLAN_FLAGS{flags = 0, mask = VLAN_FLAG_REORDER_HDR}. */
static int f575_link_add_vlan(const char *name, const char *link,
			      unsigned short vid, unsigned short proto,
			      int clear_reorder)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
		char attrs[320];
	} req;
	struct nlattr *li, *data;
	uint32_t lidx = (uint32_t)f555_ifindex(link);
	int fd, rc;

	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_NEWLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;
	req.nlh.nlmsg_seq = 1;
	req.ifi.ifi_family = AF_UNSPEC;
	attr_put(&req.nlh, IFLA_IFNAME, name, (int)strlen(name) + 1);
	attr_put(&req.nlh, IFLA_LINK, &lidx, 4);
	li = nest_start(&req.nlh, IFLA_LINKINFO);
	attr_put(&req.nlh, IFLA_INFO_KIND, "vlan", 5);
	data = nest_start(&req.nlh, IFLA_INFO_DATA);
	attr_put(&req.nlh, F575_IFLA_VLAN_ID, &vid, 2);
	if (proto) {
		unsigned short be = htons(proto);

		attr_put(&req.nlh, F575_IFLA_VLAN_PROTOCOL, &be, 2);
	}
	if (clear_reorder) {
		uint32_t fl[2];

		fl[0] = 0;		/* flags */
		fl[1] = 1;		/* mask: VLAN_FLAG_REORDER_HDR */
		attr_put(&req.nlh, F575_IFLA_VLAN_FLAGS, fl, 8);
	}
	nest_end(&req.nlh, data);
	nest_end(&req.nlh, li);
	fd = rtnl_open();
	if (fd < 0)
		return -1;
	rc = rtnl_talk(fd, &req.nlh);
	close(fd);
	return rc;
}

/* Read the VLAN configuration back from the kernel: IFLA_LINKINFO ->
 * IFLA_INFO_DATA -> {PROTOCOL, ID, FLAGS}.  vlan_fill_info() emits FLAGS only
 * when vlan->flags is nonzero, so "absent" is the oracle for a cleared flag. */
static void f575_vlan_readback(const char *dev)
{
	struct {
		struct nlmsghdr nlh;
		struct ifinfomsg ifi;
	} req;
	unsigned char rbuf[8192];
	struct nlmsghdr *nlh;
	struct sockaddr_nl sa;
	int fd, idx = f555_ifindex(dev), r, got = 0;
	int proto = -1, id = -1, flags = -1, mask = -1, present = 0;

	if (idx < 0) {
		printf("F575 VDEV|dev=%s|idx=-1\n", dev);
		return;
	}
	fd = socket(AF_NETLINK, SOCK_RAW | SOCK_CLOEXEC, NETLINK_ROUTE);
	if (fd < 0)
		return;
	memset(&sa, 0, sizeof(sa));
	sa.nl_family = AF_NETLINK;
	memset(&req, 0, sizeof(req));
	req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.nlh.nlmsg_type = RTM_GETLINK;
	req.nlh.nlmsg_flags = NLM_F_REQUEST;
	req.nlh.nlmsg_seq = 21;
	req.ifi.ifi_family = AF_UNSPEC;
	req.ifi.ifi_index = idx;
	if (sendto(fd, &req, req.nlh.nlmsg_len, 0, (struct sockaddr *)&sa,
		   sizeof(sa)) < 0) {
		close(fd);
		return;
	}
	r = (int)recv(fd, rbuf, sizeof(rbuf), 0);
	close(fd);
	if (r <= 0)
		return;
	for (nlh = (struct nlmsghdr *)rbuf; NLMSG_OK(nlh, r);
	     nlh = NLMSG_NEXT(nlh, r)) {
		struct ifinfomsg *ifi;
		const char *p, *end;

		if (nlh->nlmsg_type != RTM_NEWLINK)
			continue;
		ifi = (struct ifinfomsg *)NLMSG_DATA(nlh);
		(void)ifi;
		p = (const char *)nlh + NLMSG_HDRLEN + sizeof(struct ifinfomsg);
		end = (const char *)nlh + nlh->nlmsg_len;
		for (; p + (int)sizeof(struct nlattr) <= end; ) {
			const struct nlattr *a = (const struct nlattr *)p;
			int al = (int)a->nla_len;
			int t = a->nla_type & 0x3fff;

			if (al < (int)sizeof(*a) || p + al > end)
				break;
			if (t == IFLA_LINKINFO) {
				const char *q = p + NLA_HDRLEN;
				const char *qend = p + al;

				for (; q + (int)sizeof(struct nlattr) <= qend; ) {
					const struct nlattr *b2 =
						(const struct nlattr *)q;
					int bl = (int)b2->nla_len;
					int bt = b2->nla_type & 0x3fff;

					if (bl < (int)sizeof(*b2) ||
					    q + bl > qend)
						break;
					if (bt == IFLA_INFO_DATA) {
						const char *s = q + NLA_HDRLEN;
						const char *send = q + bl;

						for (; s + (int)sizeof(struct nlattr)
						       <= send; ) {
							const struct nlattr *c =
							  (const struct nlattr *)s;
							int cl = (int)c->nla_len;
							int ct = c->nla_type &
								 0x3fff;

							if (cl < (int)sizeof(*c) ||
							    s + cl > send)
								break;
							if (ct ==
							    F575_IFLA_VLAN_PROTOCOL)
								proto = f575_be16(s +
									NLA_HDRLEN);
							else if (ct ==
								 F575_IFLA_VLAN_ID) {
								const unsigned char *v =
								  (const unsigned char *)s +
								  NLA_HDRLEN;

								id = (int)v[0] |
								     ((int)v[1] << 8);
							}
							else if (ct ==
								 F575_IFLA_VLAN_FLAGS) {
								const unsigned char *f =
								  (const unsigned char *)s +
								  NLA_HDRLEN;

								if (cl >=
								    (int)sizeof(*c) +
								    8) {
									memcpy(&flags,
									       f, 4);
									memcpy(&mask,
									       f + 4,
									       4);
									present = 1;
								}
							}
							s += NLA_ALIGN_(cl);
						}
					}
					q += NLA_ALIGN_(bl);
					got = 1;
				}
			}
			p += NLA_ALIGN_(al);
		}
	}
	printf("F575 VDEV|dev=%s|idx=%d|linkinfo=%d|flags_present=%d|"
	       "flags=%d|mask=%d|proto=%04x|vid=%d\n",
	       dev, idx, got, present, flags, mask, proto, id);
}

/* ---------- environment ---------- */

static unsigned char F575_FA[160], F575_FB[160], F575_FE[160], F575_FQ[160];
static int F575_LA = -1, F575_LB = -1, F575_LE = -1, F575_LQ = -1;

/* a 802.1Q frame with an explicit TPID: 14 + 4 + IPv6/UDP */
static int f575_frame_tag(unsigned char *out, unsigned short tpid,
			  const unsigned char *dmac, const unsigned char *smac,
			  unsigned int tci)
{
	memset(out, 0, 160);
	memcpy(out, dmac, 6);
	memcpy(out + 6, smac, 6);
	out[12] = (unsigned char)((tpid >> 8) & 0xff);
	out[13] = (unsigned char)(tpid & 0xff);
	out[14] = (unsigned char)((tci >> 8) & 0xff);
	out[15] = (unsigned char)(tci & 0xff);
	out[16] = 0x86;
	out[17] = 0xdd;
	return 18 + f570_ip6(out + 18, A75_SRC, A75_DST, 0, F575_SPORT,
			     F575_DPORT);
}

/* 88a8/outer + 8100/inner + IPv6/UDP */
static int f575_frame_qinq(unsigned char *out, const unsigned char *dmac,
			   const unsigned char *smac, unsigned int otci,
			   unsigned int itci)
{
	int n;

	memset(out, 0, 160);
	memcpy(out, dmac, 6);
	memcpy(out + 6, smac, 6);
	out[12] = 0x88;
	out[13] = 0xa8;
	out[14] = (unsigned char)((otci >> 8) & 0xff);
	out[15] = (unsigned char)(otci & 0xff);
	out[16] = 0x81;
	out[17] = 0x00;
	out[18] = (unsigned char)((itci >> 8) & 0xff);
	out[19] = (unsigned char)(itci & 0xff);
	out[20] = 0x86;
	out[21] = 0xdd;
	n = f570_ip6(out + 22, A75_SRC, A75_DST, 0, F575_SPORT, F575_DPORT);
	return 22 + n;
}

static int f575_env(void)
{
	int rc = f574_env();
	char hb[256], hc[256], hd[256], he[256];
	int r1, r2, r3, r4;

	printf("F575 ENVRC|f574=%d\n", rc);
	if (rc)
		return rc;
	F575_LA = F574_LA;
	memcpy(F575_FA, F574_FA, (size_t)F574_LA);
	printf("F575 FRM|a=%s\n", f559_hexs(hb, sizeof(hb), F575_FA, F575_LA));
	F575_LB = f575_frame_tag(F575_FB, 0x8100, A74_BC, F573_X0M, 0x0064);
	F575_LE = f575_frame_tag(F575_FE, 0x8100, A74_BC, F573_X0M, 0x0065);
	F575_LQ = f575_frame_qinq(F575_FQ, A74_BC, F573_X0M, 0x0066, 0x00c8);
	printf("F575 FRM|b=%s\n", f559_hexs(hc, sizeof(hc), F575_FB, F575_LB));
	printf("F575 FRM|e=%s\n", f559_hexs(hd, sizeof(hd), F575_FE, F575_LE));
	printf("F575 FRM|q=%s\n", f559_hexs(he, sizeof(he), F575_FQ, F575_LQ));

	r1 = f575_link_add_vlan("br0.100", "br0", 100, 0, 0);
	r2 = f575_link_add_vlan("br0.101", "br0", 101, 0, 1);
	r3 = f575_link_add_vlan("br0.102", "br0", 102, 0x88a8, 1);
	printf("F575 VNEW|d100=%d|d101=%d|d102=%d\n", r1, r2, r3);
	f575_vlan_readback("br0.100");
	f575_vlan_readback("br0.101");
	f575_vlan_readback("br0.102");
	if (r1 || r2 || r3)
		return -5;
	set_up("br0.100");
	set_up("br0.101");
	set_up("br0.102");
	r4 = f575_link_add_vlan("br0.102.200", "br0.102", 200, 0, 0);
	printf("F575 VNEW|d102_200=%d\n", r4);
	f575_vlan_readback("br0.102.200");
	if (r4)
		return -6;
	set_up("br0.102.200");
	{
		const char *dv[] = { "br0.100", "br0.101", "br0.102",
				     "br0.102.200" };
		char path[160];
		int i;

		for (i = 0; i < 4; i++) {
			int a;

			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6",
				 dv[i]);
			f555_sysctl(path, "0");
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/accept_dad", dv[i]);
			f555_sysctl(path, "0");
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/dad_transmits",
				 dv[i]);
			f555_sysctl(path, "0");
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/accept_ra", dv[i]);
			f555_sysctl(path, "0");
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/autoconf", dv[i]);
			f555_sysctl(path, "0");
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/forwarding", dv[i]);
			f555_sysctl(path, "0");
			a = f564_addr6(dv[i], A75_DST, 128);
			snprintf(path, sizeof(path),
				 "/proc/sys/net/ipv6/conf/%s/disable_ipv6",
				 dv[i]);
			printf("F575 VADDR|dev=%s|rc=%d|v6=%d|idx=%d\n", dv[i],
			       a, f573_sysint(path), f555_ifindex(dv[i]));
		}
	}
	usleep(3000000);
	f573_settle();
	{
		char hx[64];

		printf("F575 ENV|br0=%d|x1=%d|d100=%d|d101=%d|d102=%d|d102200=%d|"
		       "la=%d|lb=%d|le=%d|lq=%d|x0mac=%s\n",
		       f555_ifindex("br0"), f555_ifindex("x1"),
		       f555_ifindex("br0.100"), f555_ifindex("br0.101"),
		       f555_ifindex("br0.102"), f555_ifindex("br0.102.200"),
		       F575_LA, F575_LB, F575_LE, F575_LQ,
		       f559_hexs(hx, sizeof(hx), F573_X0M, 6));
	}
	return 0;
}

static int f575_chains(void)
{
	int i, rc = 0;

	for (i = 0; i < ND75; i++) {
		struct f571_door *D = &D575[i];
		int a, b, c;

		a = add_table(D->fam, D->table);
		b = f556_add_chain(D->fam, D->table, "pre0", D->hook,
				   (uint32_t)D->prio0, 1, D->dev);
		c = f556_add_chain(D->fam, D->table, "ch", D->hook,
				   (uint32_t)D->prio1, 1, D->dev);
		printf("F575 CH|door=%s|fam=%d|hook=%u|dev=%s|table=%d|"
		       "pre0=%d|ch=%d\n", D->tag, (int)D->fam, D->hook,
		       D->dev ? D->dev : "-", a, b, c);
		rc |= a | b | c;
	}
	return rc;
}

static void f575_flush_all(void)
{
	int i, acks = 0;

	for (i = 0; i < ND75; i++) {
		f557_flush(D575[i].fam, D575[i].table, "pre0", &acks);
		f557_flush(D575[i].fam, D575[i].table, "ch", &acks);
	}
}

/* ---------- one arm ---------- */

static void f575_arm(const char *arm, int fk, int tapmask, int door,
		     const struct f571_cfg *C)
{
	struct f571_cfg N, Z;
	struct f573_rep r0, r;
	struct f575_pl pl;
	const unsigned char *fr = NULL;
	int flen = 0, proto = 0x86dd;
	unsigned long long c0[ND75], c1[ND75], s0 = 0, s1 = 0;
	int i, acks = 0, snd = 0, polls = 0, k, maxp = 12, st = -9, rcs = -99;
	char hx[64];
	const char *fkn = "A";

	memset(&r0, 0, sizeof(r0));
	memset(&r, 0, sizeof(r));
	f571_zero(&N, "p");
	if (fk == 0) {
		fr = F575_FA;
		flen = F575_LA;
		fkn = "A";
	} else if (fk == 1) {
		fr = F575_FB;
		flen = F575_LB;
		fkn = "B";
	} else if (fk == 2) {
		fr = F575_FE;
		flen = F575_LE;
		fkn = "E";
	} else if (fk == 3) {
		fr = F575_FQ;
		flen = F575_LQ;
		fkn = "Q";
	}
	f575_flush_all();
	f575_nfl_drain(NULL);
	st = f573_settle();
	f575_tap_open_mask(tapmask);
	for (i = 0; i < F575_TAPN; i++)
		if (F575_TAP[i].fd >= 0)
			f575_tap_drain(i);
	for (i = 0; i < ND75; i++) {
		char nm[8];

		snprintf(nm, sizeof(nm), "p%d", i);
		if (f571_rule(&D575[i], "pre0", nm, &N, &acks))
			printf("F575 RUFAIL|arm=%s|door=%s|chain=pre0\n", arm,
			       D575[i].tag);
	}
	if (door >= 0) {
		f571_zero(&Z, "s");
		rcs = f571_rule(&D575[door], "ch", "s", C ? C : &Z, &acks);
	}
	for (i = 0; i < ND75; i++)
		c0[i] = f555_count(D575[i].fam, D575[i].table, "pre0");
	s0 = door >= 0 ? f555_count(D575[door].fam, D575[door].table, "ch") : 0;
	f573_snap(&r0);
	f573_u6_drain(&r0);
	if (fk >= 0) {
		snd = pkt_send_p("x0", fr, flen, (unsigned short)proto);
		for (k = 0; k < maxp; k++) {
			usleep(120000);
			f573_snap(&r);
			polls++;
			if (r.u6n > r0.u6n || r.i6in > r0.i6in ||
			    r.i6hdr > r0.i6hdr || r.i6disc > r0.i6disc ||
			    r.brrxp > r0.brrxp || r.x1rxp > r0.x1rxp)
				break;
			{
				int any = 0;

				for (i = 0; i < ND75; i++) {
					unsigned long long cv =
						f555_count(D575[i].fam,
							   D575[i].table,
							   "pre0");

					if (cv > c0[i])
						any = 1;
				}
				if (any && polls >= 3)
					break;
			}
		}
	} else {
		usleep(300000);
		polls = 1;
	}
	f573_snap(&r);
	usleep(150000);
	f573_snap(&r);
	for (i = 0; i < ND75; i++)
		c1[i] = f555_count(D575[i].fam, D575[i].table, "pre0");
	s1 = door >= 0 ? f555_count(D575[door].fam, D575[door].table, "ch") : 0;
	f575_nfl_drain(&pl);
	for (i = 0; i < F575_TAPN; i++)
		f575_tap_drain(i);

	printf("F575 A|arm=%s|fk=%s|door=%s|mode=%d|base=%u|off=%d|len=%d|"
	       "imm=%s|rcs=%d|snt=%d|sendrc=%d|polls=%d|tapmask=%d|u6n=%d|"
	       "u6len=%d|u6sport=%d|nfl=%d|st=%d\n",
	       arm, fkn, door >= 0 ? D575[door].tag : "-",
	       C ? C->mode : (door >= 0 ? 0 : -1), C ? C->base : 0,
	       C ? C->off : -1, C ? C->len : -1,
	       C ? f559_hexs(hx, sizeof(hx), C->imm, C->len) : "-", rcs,
	       fk >= 0, snd, polls, tapmask, r.u6n, r.u6len, r.u6sport, pl.n,
	       st);
	printf("F575 C|g6=%llu|n1=%llu|ch=%lld\n",
	       c1[E75_G6] - c0[E75_G6], c1[E75_N1] - c0[E75_N1],
	       door >= 0 ? (long long)(s1 - s0) : -1LL);
	printf("F575 B|i6in_d=%llu|i6hdr_d=%llu|i6addr_d=%llu|i6unk_d=%llu|"
	       "i6trunc_d=%llu|i6nor_d=%llu|deliv_d=%llu|disc_d=%llu|"
	       "mcas_d=%llu|u6in_d=%llu|u6err_d=%llu|u6nop_d=%llu|"
	       "brrxp_d=%llu|brrxb_d=%llu|x1rxp_d=%llu\n",
	       r.i6in - r0.i6in, r.i6hdr - r0.i6hdr, r.i6addr - r0.i6addr,
	       r.i6unk - r0.i6unk, r.i6trunc - r0.i6trunc,
	       r.i6nor - r0.i6nor, r.i6deliv - r0.i6deliv,
	       r.i6disc - r0.i6disc, r.i6mcast - r0.i6mcast,
	       r.u6in - r0.u6in, r.u6err - r0.u6err, r.u6nop - r0.u6nop,
	       r.brrxp - r0.brrxp, r.brrxb - r0.brrxb, r.x1rxp - r0.x1rxp);
	{
		char mb[2400];
		int o2 = 0;

		mb[0] = 0;
		for (i = 0; i < pl.n && i < F575_NPL; i++) {
			char hh[160], hw[80], l2[80];
			int w = snprintf(mb + o2, sizeof(mb) - (size_t)o2,
					 "|m%d=%s:%d:%d:%d:%d:%d:%s:%d:%s:"
					 "%d:%04x:%04x:%d:%s", i,
					 pl.m[i].prefix, pl.m[i].indev,
					 pl.m[i].outdev, pl.m[i].hwtype,
					 pl.m[i].hwlen, pl.m[i].hlen,
					 f559_hexs(hw, sizeof(hw), pl.m[i].h,
						   pl.m[i].hlen),
					 pl.m[i].llen,
					 f559_hexs(l2, sizeof(l2), pl.m[i].l,
						   pl.m[i].llen),
					 pl.m[i].vpresent, pl.m[i].vproto,
					 pl.m[i].vtci, pl.m[i].plen,
					 f559_hexs(hh, sizeof(hh), pl.m[i].p,
						   pl.m[i].plen > 42 ? 42
								     : pl.m[i].plen));

			if (w < 0 || w >= (int)sizeof(mb) - o2)
				break;
			o2 += w;
		}
		printf("F575 M|n=%d%s\n", pl.n, mb);
		if (pl.n > 0)
			printf("F575 ATTR|m0=%s\n", pl.m[0].atrs);
	}
	{
		char tb[1400];
		int o2 = 0;

		tb[0] = 0;
		for (i = 0; i < F575_TAPN; i++) {
			char hh[260];
			int w;

			if (F575_TAP[i].len > 0) {
				w = snprintf(tb + o2, sizeof(tb) - (size_t)o2,
					     "|t%d=%s:%d:%d:%s", i,
					     F575_TAPDEV[i], F575_TAP[i].n,
					     F575_TAP[i].flen,
					     f559_hexs(hh, sizeof(hh),
						       F575_TAP[i].b,
						       F575_TAP[i].len));
			} else {
				w = snprintf(tb + o2, sizeof(tb) - (size_t)o2,
					     "|t%d=%s:%d:%d:-", i,
					     F575_TAPDEV[i], F575_TAP[i].n,
					     F575_TAP[i].flen);
			}
			if (w < 0 || w >= (int)sizeof(tb) - o2)
				break;
			o2 += w;
		}
		printf("F575 T|%s\n", tb[0] ? tb + 1 : tb);
	}
}

/* ---------- config builders ---------- */

static void f575_wr(struct f571_cfg *C, uint32_t base, int off, int len,
		    const unsigned char *imm)
{
	f571_wr(C, "s", base, off, len, imm, 0, 0);
}

static void f575_rdv(struct f571_cfg *C, uint32_t base, int off, int len,
		     const unsigned char *imm)
{
	f571_zero(C, "s");
	C->mode = 3;
	C->base = base;
	C->off = off;
	C->len = len;
	memcpy(C->imm, imm, (size_t)len);
}

/* ---------- sections ---------- */

static void f575_sec_topo(void)
{
	f575_arm("topo", -1, 0, -1, NULL);
}

/* A: an untagged frame is nobody's VLAN frame */
static void f575_sec_a(void)
{
	struct f571_cfg C;
	unsigned char i12[2] = { 0x86, 0xdd };

	f575_arm("a_ctl", 0, T575_AB, -1, NULL);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, i12);
	f575_arm("a_r12", 0, T575_AB, E75_G6, &C);
}

/* B: the control -- br0.100 with the flag set (F52's group D, same door) */
static void f575_sec_b(void)
{
	struct f571_cfg C;
	unsigned char i12[2] = { 0x86, 0xdd };
	unsigned char t12[2] = { 0x81, 0x00 };
	unsigned char v14[2] = { 0x60, 0x00 };
	unsigned char z16[2] = { 0x00, 0x00 };
	unsigned char p18[2] = { 0x00, 0x1a };
	unsigned char hl[1] = { 0x40 };
	unsigned char z14[2] = { 0x00, 0x00 };

	f575_arm("b_ctl", 1, T575_AB, -1, NULL);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, i12);
	f575_arm("b_r12_i", 1, T575_AB, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, t12);
	f575_arm("b_r12_t", 1, T575_AB, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, v14);
	f575_arm("b_r14", 1, T575_AB, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, z16);
	f575_arm("b_r16", 1, T575_AB, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 18, 2, p18);
	f575_arm("b_r18", 1, T575_AB, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_NETWORK_HEADER, 7, 1, hl);
	f575_arm("b_nh7", 1, T575_AB, E75_G6, &C);
	/* the store boundary: off+len <= mac_len = 14 at this door */
	f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, t12);
	f575_arm("b_w12", 1, T575_AB, E75_G6, &C);
	f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, z14);
	f575_arm("b_w14", 1, T575_AB, E75_G6, &C);
	f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, z14);
	f575_arm("b_w16", 1, T575_AB, E75_G6, &C);
	/* probes: a value that is neither 8100 nor 86dd, and a store well inside
	 * the MAC header -- both must be visible in NFULA_HWHEADER if the store
	 * reaches the frame at all */
	{
		unsigned char alt[2] = { 0x12, 0x34 };

		f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, alt);
		f575_arm("b_w12x", 1, T575_AB, E75_G6, &C);
		f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 6, 6, A75_N6);
		f575_arm("b_w6", 1, T575_AB, E75_G6, &C);
	}
}

/* E: the question -- br0.101 with VLAN_FLAG_REORDER_HDR cleared */
static void f575_sec_e(void)
{
	struct f571_cfg C;
	unsigned char t12[2] = { 0x81, 0x00 };
	unsigned char i12[2] = { 0x86, 0xdd };
	unsigned char t14[2] = { 0x00, 0x65 };
	unsigned char v16[2] = { 0x60, 0x00 };
	unsigned char z18[2] = { 0x00, 0x00 };
	unsigned char hl[1] = { 0x40 };
	unsigned char z14[2] = { 0x00, 0x00 };
	unsigned char et[2] = { 0x08, 0x06 };

	f575_arm("e_ctl", 2, T575_AB, -1, NULL);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 0, 6, A74_BC);
	f575_arm("e_r0", 2, T575_AB, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, t12);
	f575_arm("e_r12_t", 2, T575_AB, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, i12);
	f575_arm("e_r12_i", 2, T575_AB, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, t14);
	f575_arm("e_r14", 2, T575_AB, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, i12);
	f575_arm("e_r16", 2, T575_AB, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 18, 2, v16);
	f575_arm("e_r18", 2, T575_AB, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 20, 2, z18);
	f575_arm("e_r20", 2, T575_AB, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_NETWORK_HEADER, 7, 1, hl);
	f575_arm("e_nh7", 2, T575_AB, E75_G6, &C);
	/* the same store boundary, now off+len <= mac_len = 18 */
	f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, et);
	f575_arm("e_w12", 2, T575_AB, E75_G6, &C);
	f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, z14);
	f575_arm("e_w14", 2, T575_AB, E75_G6, &C);
	f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, et);
	f575_arm("e_w16", 2, T575_AB, E75_G6, &C);
	f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 18, 2, z14);
	f575_arm("e_w18", 2, T575_AB, E75_G6, &C);
	f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 0, 6, A75_N6);
	f575_arm("e_w0", 2, T575_AB, E75_G6, &C);
	{
		unsigned char alt[2] = { 0x12, 0x34 };

		f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, alt);
		f575_arm("e_w12x", 2, T575_AB, E75_G6, &C);
		f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 6, 6, A75_N6);
		f575_arm("e_w6", 2, T575_AB, E75_G6, &C);
	}
}

/* M: the same four bytes while they are still metadata (netdev ingress) */
static void f575_sec_m(void)
{
	struct f571_cfg C;
	unsigned char t14[2] = { 0x00, 0x65 };
	unsigned char tnew[2] = { 0x00, 0x66 };
	unsigned char et[2] = { 0x08, 0x06 };
	unsigned char i16[2] = { 0x86, 0xdd };
	unsigned char v4[2] = { 0x08, 0x00 };

	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, t14);
	f575_arm("m_r14", 2, T575_AB, E75_N1, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, i16);
	f575_arm("m_r16", 2, T575_AB, E75_N1, &C);
	f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, t14);
	f575_arm("m_w14_same", 2, T575_AB, E75_N1, &C);
	f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, tnew);
	f575_arm("m_w14_102", 2, T575_AB, E75_N1, &C);
	f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, et);
	f575_arm("m_w12", 2, T575_AB, E75_N1, &C);
	f575_wr(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, v4);
	f575_arm("m_w16", 2, T575_AB, E75_N1, &C);
}

/* Q: two tags, the outer device with the flag cleared */
static void f575_sec_q(void)
{
	struct f571_cfg C;
	unsigned char s12[2] = { 0x88, 0xa8 };
	unsigned char o14[2] = { 0x01, 0x02 };
	unsigned char i16[2] = { 0x86, 0xdd };
	unsigned char v18[2] = { 0x60, 0x00 };
	unsigned char q12[2] = { 0x81, 0x00 };

	f575_arm("q_ctl", 3, T575_ALL3, -1, NULL);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, s12);
	f575_arm("q_r12", 3, T575_ALL3, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 12, 2, q12);
	f575_arm("q_r12_q", 3, T575_ALL3, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, o14);
	f575_arm("q_r14", 3, T575_ALL3, E75_G6, &C);
	{
		unsigned char otci[2] = { 0x00, 0x66 };

		f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 14, 2, otci);
		f575_arm("q_r14b", 3, T575_ALL3, E75_G6, &C);
	}
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 16, 2, i16);
	f575_arm("q_r16", 3, T575_ALL3, E75_G6, &C);
	f575_rdv(&C, NFT_PAYLOAD_LL_HEADER, 18, 2, v18);
	f575_arm("q_r18", 3, T575_ALL3, E75_G6, &C);
}

int f575_entry(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "reorder";
	int rc;

	printf("F575 BEGIN|mode=%s\n", mode);
	rc = f575_env();
	if (rc)
		return 3;
	rc = f575_chains();
	printf("F575 CHAINS|rc=%d\n", rc);
	if (rc)
		return 4;
	printf("F575 START\n");
	fflush(stdout);

	f575_sec_topo();
	f575_sec_a();
	f575_sec_b();
	f575_sec_e();
	f575_sec_m();
	f575_sec_q();

	printf("F575 END\n");
	return 0;
}
/* differ576_add.c -- turn 576 (F54).
 *
 *  THE TWO DEBTS, named at the end of 575:
 *
 *   1. A store into the 802.1Q tag that has a WIRE.  F52 measured the tag as
 *      skb metadata at a bridge door (the store changes no byte of the frame
 *      and decides everything); F53 measured it as frame bytes on a layer-3
 *      door behind a VLAN device with VLAN_FLAG_REORDER_HDR cleared (the store
 *      changes a byte and decides nothing).  Neither had a frame that leaves.
 *
 *      Here the frame is ROUTED.  It arrives tagged 8100/101 on x1, the VLAN
 *      device x1.101 (REORDER_HDR cleared) carries it, IPv6 forwarding sends
 *      it to fd02::92 out of that same VLAN device, and vlan_dev_hard_header()
 *      + vlan_dev_hard_start_xmit() decide what the real device transmits.
 *
 *      The witness of the wire is the FAR END's own VLAN demux: x0 carries
 *      x0.101 and x0.102, and their rx_packets say which vid actually left the
 *      box.  That fact does not depend on how veth represents the tag (bytes
 *      or metadata), on a hexdump, or on my reading of one.
 *
 *      Doors, in the order the frame meets them:
 *        n1  netdev ingress x1        (the tag is metadata here: F53)
 *        g6  ip6 prerouting           (the frame is out of x1.101's L3)
 *        f6  ip6 forward
 *        e0  netdev egress x1.101     (after vlan_dev_hard_header, before
 *                                      vlan_dev_hard_start_xmit)
 *        e1  netdev egress x1         (the last door before the wire)
 *        r0  netdev ingress x0        (the far end, in the same netns)
 *
 *   2. A minimal reproduction of the WARN `invalid VLAN protocol: 0x%04x`
 *      that F53 met by accident.  The first smoke of this turn showed that
 *      the store alone is not enough: vlan_find_dev() only reaches
 *      vlan_proto_idx() when the receiving device HAS a vlan_info, so a bare
 *      veth pair cannot warn.  Mode `warn` therefore carries exactly one VLAN
 *      device and one rule.
 */

#include <sys/syscall.h>

#define F576_SPORT	43000
#define F576_DPORT	5000

static const unsigned char A76_SRC[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00,
					   0x11 };
/* the frame's destination: NOT a local address, on-link behind x1.101 */
static const unsigned char A76_DST[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00,
					   0x92 };
/* x1.101's own address */
static const unsigned char A76_LOC[16] = { 0xfd, 0x02, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00,
					   0x00, 0x00, 0x00, 0x00, 0x00,
					   0x93 };
static const unsigned char A76_BC[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

#define F576_B_LL	0

/* hook numbers as this kernel numbers them: NF_INET_PRE_ROUTING = 0,
 * NF_INET_FORWARD = 2, NF_NETDEV_INGRESS = 0, NF_NETDEV_EGRESS = 1. */
#define F576_PREROUTING_	0
#define F576_FORWARD_		2
#define F576_ND_INGRESS_	0
#define F576_ND_EGRESS_		1

static struct f571_door D576[] = {
	{ "g6", NFPROTO_IPV6,   "e76a", NULL,     F576_PREROUTING_, 210, 220 },
	{ "f6", NFPROTO_IPV6,   "e76b", NULL,     F576_FORWARD_,    230, 240 },
	{ "n1", NFPROTO_NETDEV, "e76c", "x1",     F576_ND_INGRESS_, 290, 300 },
	{ "e0", NFPROTO_NETDEV, "e76d", "x1.102", F576_ND_EGRESS_,  310, 320 },
	{ "e1", NFPROTO_NETDEV, "e76e", "x1",     F576_ND_EGRESS_,  330, 340 },
	{ "r0", NFPROTO_NETDEV, "e76f", "x0",     F576_ND_INGRESS_, 350, 360 },
};
enum { E76_G6 = 0, E76_F6, E76_N1, E76_E0, E76_E1, E76_R0 };
#define ND76 6

static unsigned char F576_X0M[6], F576_X1M[6];
static int F576_NFL = -1;
static unsigned char F576_FT[192], F576_FP[192];	/* tagged, plain */
static int F576_LT = -1, F576_LP = -1;
static int F576_ST = -9;
static unsigned int F576_DOORMASK = 0x3f;

/* ---------- taps: the far end of the port, and the port itself ---------- */

#define F576_TAPN	2
struct f576_tap {
	int fd;
	int n;
	int flen;
	int len;
	unsigned char b[160];
};
static struct f576_tap F576_TAP[F576_TAPN];
static const char *F576_TAPDEV[F576_TAPN] = { "x0", "x1" };
#define T576_X0	(1 << 0)
#define T576_X1	(1 << 1)

static void f576_tap_open_mask(int mask)
{
	int i;

	for (i = 0; i < F576_TAPN; i++) {
		if (F576_TAP[i].fd >= 0)
			close(F576_TAP[i].fd);
		F576_TAP[i].fd = -1;
		F576_TAP[i].n = 0;
		F576_TAP[i].len = -1;
		F576_TAP[i].flen = -1;
	}
	for (i = 0; i < F576_TAPN; i++) {
		if (!(mask & (1 << i)))
			continue;
		F576_TAP[i].fd = f571_tap_open(F576_TAPDEV[i]);
	}
}

static void f576_tap_drain(int i)
{
	unsigned char b[2048];
	int r;

	F576_TAP[i].n = 0;
	F576_TAP[i].len = -1;
	F576_TAP[i].flen = -1;
	if (F576_TAP[i].fd < 0)
		return;
	for (;;) {
		struct sockaddr_ll from;
		socklen_t fl = sizeof(from);
		int k;

		memset(&from, 0, sizeof(from));
		r = (int)recvfrom(F576_TAP[i].fd, b, sizeof(b), MSG_DONTWAIT,
				  (struct sockaddr *)&from, &fl);
		if (r <= 0)
			break;
		/* the tap sees what this box transmits as well (packet_snd ->
		 * dev_queue_xmit_nit); the wire witness is what arrives */
		if (from.sll_pkttype == 4 /* PACKET_OUTGOING */)
			continue;
		if (!f568_needle(b, r))
			continue;
		F576_TAP[i].n++;
		if (F576_TAP[i].len < 0) {
			F576_TAP[i].flen = r;
			k = r < (int)sizeof(F576_TAP[i].b) ?
			    r : (int)sizeof(F576_TAP[i].b);
			memcpy(F576_TAP[i].b, b, (size_t)k);
			F576_TAP[i].len = k;
		}
	}
}

/* ---------- frames ---------- */

static int f576_frame_tag(unsigned char *out, const unsigned char *dmac,
			  const unsigned char *smac, unsigned short tpid,
			  unsigned short tci)
{
	memcpy(out, dmac, 6);
	memcpy(out + 6, smac, 6);
	out[12] = (unsigned char)(tpid >> 8);
	out[13] = (unsigned char)(tpid & 0xff);
	out[14] = (unsigned char)(tci >> 8);
	out[15] = (unsigned char)(tci & 0xff);
	out[16] = 0x86;
	out[17] = 0xdd;
	return 18 + f570_ip6(out + 18, A76_SRC, A76_DST, 0, F576_SPORT,
			     F576_DPORT);
}

static int f576_frame_plain(unsigned char *out, const unsigned char *dmac,
			    const unsigned char *smac)
{
	memcpy(out, dmac, 6);
	memcpy(out + 6, smac, 6);
	out[12] = 0x86;
	out[13] = 0xdd;
	return 14 + f570_ip6(out + 14, A76_SRC, A76_DST, 0, F576_SPORT,
			     F576_DPORT);
}

/* ---------- snapshot: the far end's demux is the wire witness ---------- */

struct f576_rep {
	unsigned long long i6in, i6deliv, i6disc, i6hdr, i6nor, i6addr,
		i6unk, i6trunc, i6mcast, i6fwd;
	unsigned long long u6in, u6err, u6nop;
	unsigned long long x0rxp, x0oth, x0rxb;
	unsigned long long x1rxp, x1oth;
	unsigned long long v101p, v101b, v101d;
	unsigned long long v102p, v102b, v102d;
	unsigned long long v111p, v111b;
};

static void f576_snap(struct f576_rep *R)
{
	struct f573_lst s;

	memset(R, 0, sizeof(*R));
	R->i6in = f564_snmp6("Ip6InReceives");
	R->i6hdr = f564_snmp6("Ip6InHdrErrors");
	R->i6addr = f564_snmp6("Ip6InAddrErrors");
	R->i6unk = f564_snmp6("Ip6InUnknownProtos");
	R->i6trunc = f564_snmp6("Ip6InTruncatedPkts");
	R->i6nor = f564_snmp6("Ip6InNoRoutes");
	R->i6deliv = f564_snmp6("Ip6InDelivers");
	R->i6disc = f564_snmp6("Ip6InDiscards");
	R->i6mcast = f564_snmp6("Ip6InMcastPkts");
	R->i6fwd = f564_snmp6("Ip6OutForwDatagrams");
	R->u6in = f564_snmp6("Udp6InDatagrams");
	R->u6err = f564_snmp6("Udp6InErrors");
	R->u6nop = f564_snmp6("Udp6NoPorts");
	f573_stats("x0", &s);
	R->x0rxp = s.rxp;
	R->x0rxb = s.rxb;
	R->x0oth = s.other;
	f573_stats("x1", &s);
	R->x1rxp = s.rxp;
	R->x1oth = s.other;
	f573_stats("x0.101", &s);
	R->v101p = s.rxp;
	R->v101b = s.rxb;
	R->v101d = s.rxd;
	f573_stats("x0.102", &s);
	R->v102p = s.rxp;
	R->v102b = s.rxb;
	R->v102d = s.rxd;
	f573_stats("x1.101", &s);
	R->v111p = s.rxp;
	R->v111b = s.rxb;
}

/* ---------- kmsg: how many splats did the kernel print ---------- */

#define F576_KMSG_MAX 262144
static char F576_KMSG[F576_KMSG_MAX];

/* returns the number of lines containing `needle` in the whole ring buffer;
 * up to `keep` of them are copied into out, separated by '|' */
static int f576_kmsg(const char *needle, char *out, int maxout, int keep)
{
	long r;
	int n = 0, o = 0, kept = 0, i = 0;

	if (out && maxout > 0)
		out[0] = 0;
	r = syscall(SYS_syslog, 3 /* SYSLOG_ACTION_READ_ALL */, F576_KMSG,
		    F576_KMSG_MAX - 1);
	if (r <= 0)
		return -1;
	F576_KMSG[r] = 0;
	while (i < (int)r) {
		int j = i, k;

		while (j < (int)r && F576_KMSG[j] != '\n')
			j++;
		F576_KMSG[j] = 0;
		if (strstr(F576_KMSG + i, needle)) {
			n++;
			if (out && kept < keep) {
				k = (int)strlen(F576_KMSG + i);
				if (k > 150)
					k = 150;
				if (o + k + 2 < maxout) {
					if (o)
						out[o++] = '|';
					memcpy(out + o, F576_KMSG + i,
					       (size_t)k);
					o += k;
					out[o] = 0;
				}
				kept++;
			}
		}
		i = j + 1;
	}
	return n;
}


/* ---------- topology of mode `xf` ---------- */

static int f576_env(void)
{
	int r1, r2, r3;
	char path[160];
	/* the on-link /64 lives on the EGRESS device, so the forwarded
	 * frame leaves through a device other than the one it arrived on
	 * (ip6_forward() sends an ICMPv6 redirect when they are equal). */
	const char *v6dev = "x1.102";

	f558_link_del("br0");
	f558_link_del("x0");
	f555_sysctl("/proc/sys/net/ipv6/conf/default/disable_ipv6", "1");
	f555_sysctl("/proc/sys/net/ipv6/conf/default/accept_dad", "0");
	if (link_add_veth("x0", "x1")) {
		printf("F576 FAIL|veth\n");
		return -1;
	}
	set_up("x0");
	set_up("x1");
	if (mac_get("x0", F576_X0M) || mac_get("x1", F576_X1M)) {
		printf("F576 FAIL|mac\n");
		return -1;
	}
	r1 = f575_link_add_vlan("x1.101", "x1", 101, 0, 1);
	r2 = f575_link_add_vlan("x1.102", "x1", 102, 0, 1);
	r3 = f575_link_add_vlan("x0.101", "x0", 101, 0, 0);
	printf("F576 VNEW|x1_101=%d|x1_102=%d|x0_101=%d\n", r1, r2, r3);
	if (r1 | r2 | r3)
		return -6;
	printf("F576 VNEW2|x0_102=%d\n",
	       f575_link_add_vlan("x0.102", "x0", 102, 0, 0));
	f575_vlan_readback("x1.101");
	f575_vlan_readback("x1.102");
	set_up("x1.101");
	set_up("x1.102");
	set_up("x0.101");
	set_up("x0.102");
	f555_sysctl("/proc/sys/net/ipv6/conf/all/forwarding", "1");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/%s/disable_ipv6",
		 v6dev);
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/x1.101/disable_ipv6");
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/x1.101/forwarding");
	f555_sysctl(path, "1");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/x1.101/accept_dad");
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path),
		 "/proc/sys/net/ipv6/conf/x1.101/router_solicitations");
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/x1.101/accept_ra");
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/x1.101/autoconf");
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/%s/accept_dad",
		 v6dev);
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path),
		 "/proc/sys/net/ipv6/conf/%s/dad_transmits", v6dev);
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/%s/accept_ra",
		 v6dev);
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/%s/autoconf",
		 v6dev);
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path),
		 "/proc/sys/net/ipv6/conf/%s/router_solicitations", v6dev);
	f555_sysctl(path, "0");
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/%s/forwarding",
		 v6dev);
	f555_sysctl(path, "1");
	snprintf(path, sizeof(path),
		 "/proc/sys/net/ipv6/conf/%s/drop_unicast_in_l2_multicast",
		 v6dev);
	f555_sysctl(path, "0");
	/* forwarding in and out of the same device normally sends an
	 * ICMPv6 redirect; that redirect needs the SOURCE resolved, so it
	 * emits a neighbour solicitation -- a second frame through every
	 * door below.  Measured in the first smoke (e0=2, r0=2 per packet). */
	snprintf(path, sizeof(path), "/proc/sys/net/ipv6/conf/%s/send_redirects",
		 v6dev);
	f555_sysctl(path, "0");
	printf("F576 ADDR6|rc=%d|dev=%s\n", f564_addr6(v6dev, A76_LOC, 64),
	       v6dev);
	printf("F576 INADDR|v6=%d|addr=%d\n",
	       f573_sysint("/proc/sys/net/ipv6/conf/x1.101/disable_ipv6"),
	       f573_sysint("/proc/sys/net/ipv6/conf/x1.101/forwarding"));
	printf("F576 NEIGH|rc=%d\n",
	       f569_neigh6_add("x1.102", A76_DST, F576_X0M));
	F576_NFL = nfl_open(5);
	F573_NFL = F576_NFL;
	F571_NFL = F576_NFL;
	F576_LT = f576_frame_tag(F576_FT, F576_X1M, F576_X0M, 0x8100, 0x0065);
	F576_LP = f576_frame_plain(F576_FP, A76_BC, F576_X0M);
	{
		char ht[512], hp[512], hx[32], hb[32];

		printf("F576 ENV|nfl=%d|lt=%d|lp=%d|x0=%d|x1=%d|d101=%d|"
		       "d101x=%d|d102x=%d|d102=%d|x0mac=%s|x1mac=%s\n",
		       F576_NFL, F576_LT, F576_LP, f555_ifindex("x0"),
		       f555_ifindex("x1"), f555_ifindex("x1.101"),
		       f555_ifindex("x0.101"), f555_ifindex("x0.102"),
		       f555_ifindex("x1.102"),
		       f559_hexs(hx, sizeof(hx), F576_X0M, 6),
		       f559_hexs(hb, sizeof(hb), F576_X1M, 6));
		printf("F576 FRM|t=%s\n",
		       f559_hexs(ht, sizeof(ht), F576_FT, F576_LT));
		printf("F576 FRM|p=%s\n",
		       f559_hexs(hp, sizeof(hp), F576_FP, F576_LP));
	}
	usleep(4000000);
	F576_ST = f573_settle();
	printf("F576 SETTLE|st=%d|v6=%d|fwd=%d|allfwd=%d|d101v6=%d|d102v6=%d|"
	       "x1v6=%d\n", F576_ST,
	       f573_sysint("/proc/sys/net/ipv6/conf/x1.101/disable_ipv6"),
	       f573_sysint("/proc/sys/net/ipv6/conf/x1.101/forwarding"),
	       f573_sysint("/proc/sys/net/ipv6/conf/all/forwarding"),
	       f573_sysint("/proc/sys/net/ipv6/conf/x0.101/disable_ipv6"),
	       f573_sysint("/proc/sys/net/ipv6/conf/x0.102/disable_ipv6"),
	       f573_sysint("/proc/sys/net/ipv6/conf/x1/disable_ipv6"));
	return 0;
}

static int f576_chains(void)
{
	int i, rc = 0;

	for (i = 0; i < ND76; i++) {
		struct f571_door *D = &D576[i];
		int a, b, c;

		if (!(F576_DOORMASK & (1u << i)))
			continue;
		a = add_table(D->fam, D->table);
		b = f556_add_chain(D->fam, D->table, "pre0", D->hook,
				   (uint32_t)D->prio0, 1, D->dev);
		c = f556_add_chain(D->fam, D->table, "ch", D->hook,
				   (uint32_t)D->prio1, 1, D->dev);
		printf("F576 CH|door=%s|fam=%d|hook=%u|dev=%s|table=%d|"
		       "pre0=%d|ch=%d\n", D->tag, (int)D->fam, D->hook,
		       D->dev ? D->dev : "-", a, b, c);
		rc |= a | b | c;
	}
	return rc;
}

static void f576_flush_all(void)
{
	int i, acks = 0;

	for (i = 0; i < ND76; i++) {
		if (!(F576_DOORMASK & (1u << i)))
			continue;
		f557_flush(D576[i].fam, D576[i].table, "pre0", &acks);
		f557_flush(D576[i].fam, D576[i].table, "ch", &acks);
	}
}

/* ---------- one arm of mode `xf` ---------- */

struct f576_act {
	int door;
	const struct f571_cfg *C;
};

static void f576_arm(const char *arm, int fk, int nsend, int tapmask,
		     const struct f576_act *A, int na)
{
	struct f571_cfg N;
	struct f576_rep r0, r;
	struct f575_pl pl;
	const unsigned char *fr = NULL;
	int flen = 0, proto = 0x86dd;
	unsigned long long c0[ND76], c1[ND76], s0[2], s1[2];
	int i, j, acks = 0, snd = 0, polls = 0, k, rcs[2] = { -99, -99 };
	char hx[64];
	const char *fkn = "T";

	memset(&r0, 0, sizeof(r0));
	memset(&r, 0, sizeof(r));
	memset(s0, 0, sizeof(s0));
	memset(s1, 0, sizeof(s1));
	f571_zero(&N, "p");
	if (fk == 0) {
		fr = F576_FT;
		flen = F576_LT;
		fkn = "T";
	} else if (fk == 1) {
		fr = F576_FP;
		flen = F576_LP;
		fkn = "P";
	}
	f576_flush_all();
	f575_nfl_drain(NULL);
	F576_ST = f573_settle();
	f576_tap_open_mask(tapmask);
	for (i = 0; i < F576_TAPN; i++)
		if (F576_TAP[i].fd >= 0)
			f576_tap_drain(i);
	for (i = 0; i < ND76; i++) {
		char nm[8];

		if (!(F576_DOORMASK & (1u << i)))
			continue;
		snprintf(nm, sizeof(nm), "p%d", i);
		if (f571_rule(&D576[i], "pre0", nm, &N, &acks))
			printf("F576 RUFAIL|arm=%s|door=%s|chain=pre0\n", arm,
			       D576[i].tag);
	}
	for (j = 0; j < na && j < 2; j++)
		rcs[j] = f571_rule(&D576[A[j].door], "ch", "s", A[j].C, &acks);
	for (i = 0; i < ND76; i++)
		c0[i] = (F576_DOORMASK & (1u << i)) ?
			f555_count(D576[i].fam, D576[i].table, "pre0") : 0;
	for (j = 0; j < na && j < 2; j++)
		s0[j] = f555_count(D576[A[j].door].fam, D576[A[j].door].table,
				   "ch");
	f576_snap(&r0);
	if (fk >= 0 && nsend > 0) {
		for (k = 0; k < nsend; k++) {
			snd += (pkt_send_p("x0", fr, flen,
					   (unsigned short)proto) == 0);
			if (k + 1 < nsend)
				usleep(120000);
		}
		for (k = 0; k < 14; k++) {
			int any = 0;

			usleep(110000);
			f576_snap(&r);
			polls++;
			for (i = 0; i < ND76; i++)
				if ((F576_DOORMASK & (1u << i)) &&
				    f555_count(D576[i].fam, D576[i].table,
					       "pre0") > c0[i])
					any = 1;
			for (j = 0; j < na && j < 2; j++)
				if (f555_count(D576[A[j].door].fam,
					       D576[A[j].door].table, "ch") >
				    s0[j])
					any = 1;
			if (r.v101p > r0.v101p || r.i6in > r0.i6in ||
			    r.i6fwd > r0.i6fwd || r.x1oth > r0.x1oth)
				break;
			if (any && polls >= 3)
				break;
		}
	} else {
		usleep(300000);
		polls = 1;
	}
	f576_snap(&r);
	usleep(200000);
	f576_snap(&r);
	for (i = 0; i < ND76; i++)
		c1[i] = (F576_DOORMASK & (1u << i)) ?
			f555_count(D576[i].fam, D576[i].table, "pre0") : 0;
	for (j = 0; j < na && j < 2; j++)
		s1[j] = f555_count(D576[A[j].door].fam, D576[A[j].door].table,
				   "ch");
	f575_nfl_drain(&pl);
	for (i = 0; i < F576_TAPN; i++)
		if (F576_TAP[i].fd >= 0)
			f576_tap_drain(i);

	printf("F576 A|arm=%s|fk=%s|nsend=%d|snt=%d|polls=%d|tab=%d|st=%d|"
	       "na=%d|d0=%s|off0=%d|len0=%d|imm0=%s|rc0=%d|d1=%s|rc1=%d|"
	       "u6n=%llu|nfl=%d\n",
	       arm, fkn, nsend, snd, polls, tapmask, F576_ST, na,
	       na > 0 ? D576[A[0].door].tag : "-",
	       na > 0 ? A[0].C->off : -1, na > 0 ? A[0].C->len : -1,
	       na > 0 ? f559_hexs(hx, sizeof(hx), A[0].C->imm,
				  A[0].C->len) : "-",
	       na > 0 ? rcs[0] : -99,
	       na > 1 ? D576[A[1].door].tag : "-", na > 1 ? rcs[1] : -99,
	       r.u6in - r0.u6in, pl.n);
	printf("F576 C|g6=%llu|f6=%llu|n1=%llu|e0=%llu|e1=%llu|r0=%llu|"
	       "ch0=%lld|ch1=%lld\n",
	       c1[E76_G6] - c0[E76_G6], c1[E76_F6] - c0[E76_F6],
	       c1[E76_N1] - c0[E76_N1], c1[E76_E0] - c0[E76_E0],
	       c1[E76_E1] - c0[E76_E1], c1[E76_R0] - c0[E76_R0],
	       na > 0 ? (long long)(s1[0] - s0[0]) : -1LL,
	       na > 1 ? (long long)(s1[1] - s0[1]) : -1LL);
	printf("F576 B|i6in_d=%llu|deliv_d=%llu|disc_d=%llu|hdr_d=%llu|"
	       "nor_d=%llu|addr_d=%llu|unk_d=%llu|trunc_d=%llu|mcast_d=%llu|"
	       "fwd_d=%llu|u6in_d=%llu|u6err_d=%llu|u6nop_d=%llu\n",
	       r.i6in - r0.i6in, r.i6deliv - r0.i6deliv, r.i6disc - r0.i6disc,
	       r.i6hdr - r0.i6hdr, r.i6nor - r0.i6nor, r.i6addr - r0.i6addr,
	       r.i6unk - r0.i6unk, r.i6trunc - r0.i6trunc,
	       r.i6mcast - r0.i6mcast, r.i6fwd - r0.i6fwd,
	       r.u6in - r0.u6in, r.u6err - r0.u6err, r.u6nop - r0.u6nop);
	/* the wire witness: the far end's own VLAN demux */
	printf("F576 F|v101p_d=%llu|v101b_d=%llu|v101d_d=%llu|v102p_d=%llu|"
	       "v102b_d=%llu|v102d_d=%llu|v111p_d=%llu|v111b_d=%llu|"
	       "x0rxp_d=%llu|x0rxb_d=%llu|x0oth_d=%llu|x1rxp_d=%llu|"
	       "x1oth_d=%llu\n",
	       r.v101p - r0.v101p, r.v101b - r0.v101b, r.v101d - r0.v101d,
	       r.v102p - r0.v102p, r.v102b - r0.v102b, r.v102d - r0.v102d,
	       r.v111p - r0.v111p, r.v111b - r0.v111b,
	       r.x0rxp - r0.x0rxp, r.x0rxb - r0.x0rxb, r.x0oth - r0.x0oth,
	       r.x1rxp - r0.x1rxp, r.x1oth - r0.x1oth);
	{
		char mb[2600];
		int o2 = 0;

		mb[0] = 0;
		for (i = 0; i < pl.n && i < F575_NPL; i++) {
			char hh[120], hw[80], l2[80];
			int w = snprintf(mb + o2, sizeof(mb) - (size_t)o2,
					 "|m%d=%s:%d:%d:%d:%d:%d:%s:%d:%s:"
					 "%d:%04x:%04x:%d:%s", i,
					 pl.m[i].prefix, pl.m[i].indev,
					 pl.m[i].outdev, pl.m[i].hwtype,
					 pl.m[i].hwlen, pl.m[i].hlen,
					 f559_hexs(hw, sizeof(hw), pl.m[i].h,
						   pl.m[i].hlen),
					 pl.m[i].llen,
					 f559_hexs(l2, sizeof(l2), pl.m[i].l,
						   pl.m[i].llen),
					 pl.m[i].vpresent, pl.m[i].vproto,
					 pl.m[i].vtci, pl.m[i].plen,
					 f559_hexs(hh, sizeof(hh), pl.m[i].p,
						   pl.m[i].plen > 42 ?
						   42 : pl.m[i].plen));

			if (w < 0 || w >= (int)sizeof(mb) - o2)
				break;
			o2 += w;
		}
		printf("F576 M|n=%d%s\n", pl.n, mb);
	}
	{
		char tb[1400];
		int o2 = 0;

		tb[0] = 0;
		for (i = 0; i < F576_TAPN; i++) {
			int w;

			if (F576_TAP[i].len > 0) {
				char hh[400];

				w = snprintf(tb + o2, sizeof(tb) - (size_t)o2,
					     "|t%d=%s:%d:%d:%s", i,
					     F576_TAPDEV[i], F576_TAP[i].n,
					     F576_TAP[i].flen,
					     f559_hexs(hh, sizeof(hh),
						       F576_TAP[i].b,
						       F576_TAP[i].len));
			} else {
				w = snprintf(tb + o2, sizeof(tb) - (size_t)o2,
					     "|t%d=%s:%d:%d:-", i,
					     F576_TAPDEV[i], F576_TAP[i].n,
					     F576_TAP[i].flen);
			}
			if (w < 0 || w >= (int)sizeof(tb) - o2)
				break;
			o2 += w;
		}
		printf("F576 T|%s\n", tb[0] ? tb + 1 : tb);
	}
}

/* ---------- config helpers ---------- */

static void f576_wr(struct f571_cfg *C, uint32_t base, int off, int len,
		    const unsigned char *imm)
{
	f571_wr(C, "s", base, off, len, imm, 0, 0);
}

static void f576_rd(struct f571_cfg *C, uint32_t base, int off, int len,
		    const unsigned char *imm)
{
	f571_zero(C, "s");
	C->mode = 3;
	C->base = base;
	C->off = off;
	C->len = len;
	memcpy(C->imm, imm, (size_t)len);
}

/* ---------- sections of mode `xf` ---------- */

static void f576_sec_xf(void)
{
	struct f576_act A[2];
	unsigned char tci67[2] = { 0x00, 0x67 };
	unsigned char tci66[2] = { 0x00, 0x66 };
	unsigned char tci65[2] = { 0x00, 0x65 };
	unsigned char pc1[2] = { 0x20, 0x65 };
	unsigned char tpid[2] = { 0x81, 0x00 };
	unsigned char zero4[4] = { 0, 0, 0, 0 };

	/* 0. nothing sent: the baseline of every counter in this mode */
	f576_arm("n0", -1, 0, 0, NULL, 0);
	/* 1. control: the tagged frame is routed and leaves the box */
	f576_arm("ctl", 0, 1, T576_X0, NULL, 0);
	/* 2. the tag as the ingress device carried it (vid 101) */
	{
		struct f571_cfg r2;

		f576_rd(&r2, F576_B_LL, 14, 2, tci65);
		A[0].door = E76_G6;
		A[0].C = &r2;
		f576_arm("rd_g6_65", 0, 1, T576_X0, A, 1);
	}
	/* 3. store vid 103 at prerouting, read it back at FORWARD */
	{
		struct f571_cfg w2, r2;

		f576_wr(&w2, F576_B_LL, 14, 2, tci67);
		f576_rd(&r2, F576_B_LL, 14, 2, tci67);
		A[0].door = E76_G6;
		A[0].C = &w2;
		A[1].door = E76_F6;
		A[1].C = &r2;
		f576_arm("w67_g6_rd_f6", 0, 1, T576_X0, A, 2);
	}
	/* 4. the same store at FORWARD, read at the egress door of the egress
	 *    VLAN device -- vlan_dev_hard_header() runs between these doors */
	{
		struct f571_cfg w2, r2;

		f576_wr(&w2, F576_B_LL, 14, 2, tci67);
		f576_rd(&r2, F576_B_LL, 14, 2, tci66);
		A[0].door = E76_F6;
		A[0].C = &w2;
		A[1].door = E76_E0;
		A[1].C = &r2;
		f576_arm("w67_f6_rd_e0_66", 0, 1, T576_X0, A, 2);
	}
	/* 5. the same store, read at the LAST door before the wire */
	{
		struct f571_cfg w2, r2;

		f576_wr(&w2, F576_B_LL, 14, 2, tci67);
		f576_rd(&r2, F576_B_LL, 14, 2, tci66);
		A[0].door = E76_F6;
		A[0].C = &w2;
		A[1].door = E76_E1;
		A[1].C = &r2;
		f576_arm("w67_f6_rd_e1_66", 0, 1, T576_X0, A, 2);
	}
	/* 6. the value the frame already carries at that point: value, not act */
	{
		struct f571_cfg w2, r2;

		f576_wr(&w2, F576_B_LL, 14, 2, tci66);
		f576_rd(&r2, F576_B_LL, 14, 2, tci66);
		A[0].door = E76_F6;
		A[0].C = &w2;
		A[1].door = E76_E0;
		A[1].C = &r2;
		f576_arm("same66_f6_rd_e0", 0, 1, T576_X0, A, 2);
	}
	/* 7. the priority bits: stored in the frame, read where the device
	 *    composes its own tag */
	{
		struct f571_cfg w2, r2;

		f576_wr(&w2, F576_B_LL, 14, 2, pc1);
		f576_rd(&r2, F576_B_LL, 14, 2, tci66);
		A[0].door = E76_F6;
		A[0].C = &w2;
		A[1].door = E76_E0;
		A[1].C = &r2;
		f576_arm("pc1_f6_rd_e0_66", 0, 1, T576_X0, A, 2);
	}
	/* 8. what the last door before the wire reads by itself */
	{
		struct f571_cfg r2;

		f576_rd(&r2, F576_B_LL, 12, 2, tpid);
		A[0].door = E76_E1;
		A[0].C = &r2;
		f576_arm("e1_rd_tpid", 0, 1, T576_X0, A, 1);
	}
	/* 9. the four bytes that deleted the tag in F52: here the tag is frame
	 *    bytes, so this deletes it from the frame */
	{
		struct f571_cfg w2;

		f576_wr(&w2, F576_B_LL, 12, 4, zero4);
		A[0].door = E76_G6;
		A[0].C = &w2;
		f576_arm("del12_g6", 0, 1, T576_X0, A, 1);
	}
	/* 10. store the metadata TCI at ingress: retarget to vid 103 */
	{
		struct f571_cfg w2;

		f576_wr(&w2, F576_B_LL, 14, 2, tci67);
		A[0].door = E76_N1;
		A[0].C = &w2;
		f576_arm("n67", 0, 1, T576_X0, A, 1);
	}
	/* 11. store the metadata PCP at ingress, same vid */
	{
		struct f571_cfg w2;

		f576_wr(&w2, F576_B_LL, 14, 2, pc1);
		A[0].door = E76_N1;
		A[0].C = &w2;
		f576_arm("n_pc1", 0, 1, T576_X0, A, 1);
	}
}

/* ---------- mode `warn`: one rule, one frame, one VLAN device ---------- */

static int f576_warn_env(void)
{
	f558_link_del("br0");
	f558_link_del("x0");
	f555_sysctl("/proc/sys/net/ipv6/conf/default/disable_ipv6", "1");
	if (link_add_veth("x0", "x1")) {
		printf("F576 WFAIL|veth\n");
		return -1;
	}
	set_up("x0");
	set_up("x1");
	if (mac_get("x0", F576_X0M) || mac_get("x1", F576_X1M)) {
		printf("F576 WFAIL|mac\n");
		return -1;
	}
	/* the one device that makes vlan_find_dev() reach vlan_proto_idx() */
	printf("F576 WVNEW|rc=%d\n",
	       f575_link_add_vlan("x1.101", "x1", 101, 0, 0));
	set_up("x1.101");
	F576_NFL = nfl_open(5);
	F573_NFL = F576_NFL;
	F571_NFL = F576_NFL;
	F576_LT = f576_frame_tag(F576_FT, A76_BC, F576_X0M, 0x8100, 0x0065);
	F576_LP = f576_frame_plain(F576_FP, A76_BC, F576_X0M);
	{
		char ht[512], hx[32], hb[32];

		printf("F576 WENV|nfl=%d|lt=%d|lp=%d|x0=%d|x1=%d|d101=%d|"
		       "x0mac=%s|x1mac=%s\n", F576_NFL, F576_LT, F576_LP,
		       f555_ifindex("x0"), f555_ifindex("x1"),
		       f555_ifindex("x1.101"),
		       f559_hexs(hx, sizeof(hx), F576_X0M, 6),
		       f559_hexs(hb, sizeof(hb), F576_X1M, 6));
		printf("F576 FRM|t=%s\n",
		       f559_hexs(ht, sizeof(ht), F576_FT, F576_LT));
	}
	usleep(600000);
	F576_ST = f573_settle();
	return 0;
}

static void f576_warn_arm(const char *arm, const struct f571_cfg *C,
			  int fk, int nsend)
{
	struct f576_rep s0, s1;
	const unsigned char *fr;
	int flen, snd = 0, k, rcs = -99, acks = 0;
	int spl0, spl1;
	char msg[900];
	unsigned long long ch0 = 0, ch1 = 0;

	fr = fk == 0 ? F576_FT : F576_FP;
	flen = fk == 0 ? F576_LT : F576_LP;
	f576_flush_all();
	f575_nfl_drain(NULL);
	f576_tap_open_mask(T576_X0);
	f576_tap_drain(0);
	if (C)
		rcs = f571_rule(&D576[E76_N1], "ch", "s", C, &acks);
	ch0 = f555_count(D576[E76_N1].fam, D576[E76_N1].table, "ch");
	spl0 = f576_kmsg("invalid VLAN protocol", NULL, 0, 0);
	f576_snap(&s0);
	for (k = 0; k < nsend; k++) {
		snd += (pkt_send_p("x0", fr, flen, 0x8100) == 0);
		usleep(150000);
	}
	usleep(400000);
	spl1 = f576_kmsg("invalid VLAN protocol", msg, (int)sizeof(msg), 4);
	f576_snap(&s1);
	ch1 = f555_count(D576[E76_N1].fam, D576[E76_N1].table, "ch");
	f576_tap_drain(0);
	printf("F576 W|arm=%s|fk=%s|nsend=%d|snt=%d|rcs=%d|ch=%lld|"
	       "spl0=%d|spl1=%d|dspl=%d|st=%d|tapx0=%d|tapx0len=%d|"
	       "x1rxp_d=%llu|x1oth_d=%llu|v111p_d=%llu\n",
	       arm, fk == 0 ? "T" : "P", nsend, snd, rcs,
	       (long long)(ch1 - ch0), spl0, spl1,
	       (spl1 >= 0 && spl0 >= 0) ? spl1 - spl0 : -99, F576_ST,
	       F576_TAP[0].n, F576_TAP[0].flen,
	       s1.x1rxp - s0.x1rxp, s1.x1oth - s0.x1oth,
	       s1.v111p - s0.v111p);
	printf("F576 WM|arm=%s|%s\n", arm, msg);
}

static void f576_sec_warn(void)
{
	struct f571_cfg w;
	unsigned char bad[2] = { 0x08, 0x06 };
	unsigned char good[2] = { 0x81, 0x00 };

	/* 0. the same frame with no rule at all */
	f576_warn_arm("w_ctl", NULL, 0, 1);
	/* 1. one rule, one store, one frame */
	f576_wr(&w, F576_B_LL, 12, 2, bad);
	f576_warn_arm("w_tag", &w, 0, 1);
	/* 2. three frames: is the message per packet or once? */
	f576_warn_arm("w_tag_x3", &w, 0, 3);
	/* 3. the same rule on a frame that carries no tag */
	f576_warn_arm("w_untag", &w, 1, 1);
	/* 4. the value the frame already carries */
	f576_wr(&w, F576_B_LL, 12, 2, good);
	f576_warn_arm("w_same", &w, 0, 1);
}

/* ---------- entry ---------- */

static void f576_usage(const char *p)
{
	printf("F576 USAGE|%s <warn|xf>\n", p);
}

int main(int argc, char **argv)
{
	const char *mode = argc > 1 ? argv[1] : "";

	if (!strcmp(mode, "warn")) {
		F576_DOORMASK = 1u << E76_N1;
		if (f576_warn_env())
			return 2;
		if (f576_chains())
			return 3;
		f576_sec_warn();
		printf("F576 WARN_DONE\n");
		return 0;
	}
	if (!strcmp(mode, "xf")) {
		F576_DOORMASK = 0x3f;
		if (f576_env())
			return 2;
		if (f576_chains())
			return 3;
		f576_sec_xf();
		printf("F576 XF_DONE\n");
		return 0;
	}
	f576_usage(argv[0]);
	return 1;
}
